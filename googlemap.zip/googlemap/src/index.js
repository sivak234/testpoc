export { default as GoogleLayer } from "./GoogleLayer";
