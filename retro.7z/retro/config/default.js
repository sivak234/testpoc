module.exports = {
  listener: {
    port: 3001
  },
  database: {
    uri: `mysql://${process.env.DB_USER || 'root'}:${process.env.DB_PASS || ''}@${process.env
      .DB_HOST || 'localhost'}/poc`,
    version: {
      select: 'select version()',
      get: '[0][0].version()'
    },
    dialect: 'mysql'
  }
}
