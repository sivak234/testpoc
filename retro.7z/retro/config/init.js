export const database = {
  uri: `mysql://${process.env.DB_DDL_USER || 'root'}:${process.env.DB_DDL_PASS || ''}@${process.env
    .DB_DDL_HOST || 'localhost'}/poc`,
  version: {
    select: 'select version()',
    get: '[0][0].version()'
  },
  dialect: 'mysql'
}
