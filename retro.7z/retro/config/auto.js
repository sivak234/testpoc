module.exports = {
  database: {
    url: `mysql://${process.env.DB_USER || 'root'}:${process.env.DB_PASS || ''}@${process.env
      .DB_HOST || 'localhost'}/poc-auto`
  },
  listener: {
    port: 300
  }
}
