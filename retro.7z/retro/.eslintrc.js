module.exports = {
  extends: ["eslint:recommended", "prettier"],
  parser: "babel-eslint",
  env: {
    node: true,
    es6: true
  },
  // ecmaFeatures: {
  //   modules: true
  // },
  // globals: {
  //   __DEV__: true
  // },
  plugins: ["prettier"],
  rules: {
    'import/no-unassigned-import': 'off',
    'import/prefer-default-export': 'off',
    'import/extensions': 'off',
    //'import/no-unresolved': 'off',
    'prettier/prettier': [
      'error',
      {
        singleQuote: true,
        semi: false,
        bracketSpacing: false,
        printWidth: 100
      }
    ]
  },
  "settings": {
    "import/resolver": {
      "node": {
        "extensions": [".js", ".jsx", ".ts", ".tsx"]
      }
    }
  },
};
