import express from 'express'
import usersRoutes from './users'
import meetingRoutes from './meeting'
import participantsRoutes from './participants'
import notesRoutes from './notes'
import topicsRoutes from './topics'

const router = express.Router()

export default () => {
  router.use('/users', usersRoutes())

  router.use('/meeting', meetingRoutes())

  router.use('/notes', notesRoutes())

  router.use('/participants', participantsRoutes())

  router.use('/topics', topicsRoutes())

  return router
}
