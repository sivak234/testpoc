import express from 'express'
import {models} from '../../db/shared/sqlz-helpr'

const router = express.Router({mergeRoutes: true})
const {users} = models

export default () => {
  router.get('/', async (req, res) => {
    // let results = await users.findAndCountAll()
    // res.send(results)
    // eslint-disable-next-line no-console
    console.log(req.params.id)
    res.send('respond with a resource')
  })
  router.get('/:id', async (req, res) => {
    let userId = parseInt(req.params.id)
    let result = await users.find({where: {userId: userId}})
    res.send(result)
  })

  router.post('/', async (req, res) => {
    let userLoginId = req.body.userLoginId
    let firstname = req.body.userFirstName
    let lastname = req.body.userLastName
    let active = req.body.active

    let result = await users.create({
      userLoginId: userLoginId,
      userFirstName: firstname,
      userLastName: lastname,
      active: active
    })
    if (result._options.isNewRecord) {
      res.status(201).send({result: 'success'})
    }
  })

  router.put('/:id', async (req, res) => {
    let firstname = req.body.user_first_name
    let lastname = req.body.user_last_name

    let result = await users.update(
      {
        userFirstName: firstname,
        userLastName: lastname
      },
      {where: {userId: req.params.id}, returning: true}
    )
    res.send({result: `Updated records ${result[1]}`})
  })

  router.delete('/:id', async (req, res) => {
    let result = await users.update(
      {
        active: 'N'
      },
      {where: {userId: req.params.id}, returning: true}
    )
    res.send({result: `Deleted records ${result[1]}`})
  })

  return router
}
