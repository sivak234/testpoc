import debug from 'debug'

const appname = process.env.APP_NAME || 'app:expressApi'
const logger = debug(appname)
//logger.log = console.log.bind(console)
const errorLogger = debug(`${appname}:error`)
//errorLogger.log = console.error.bind(console)
export function error(err) {
  errorLogger(err)
}
export function log(msg) {
  logger(msg)
}
