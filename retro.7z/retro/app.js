import express from 'express'
import createError from 'http-errors'
import cookieParser from 'cookie-parser'
import appRoutes from './routes/index'

const path = require('path')
const logger = require('morgan')

export default (async function() {
  const app = express()
  const port = 3001
  app.set('port', port)
  // // view engine setup
  // app.set('views', path.join(__dirname, 'views'))
  // app.set('view engine', 'jade')

  app.use(logger('dev'))
  app.use(express.json())
  app.use(express.urlencoded({extended: false}))
  app.use(cookieParser())
  app.use(express.static(path.join(__dirname, 'public')))

  //root API
  app.get('/', (req, res) => {
    res.send(`Welcome to Retro Api!\n This api is written in node.js & express framework.`)
  })
  app.listen(port, () => {
    const listeningPort = parseInt(port)
    // eslint-disable-next-line no-console
    console.log(`Find the server at port: ${listeningPort}`)
  })

  //load & listen all app routes
  app.use('/', appRoutes())

  // catch 404 and forward to error handler
  app.use(function(req, res, next) {
    next(createError(404))
  })

  // error handler
  app.use(function(err, req, res, next) {
    // set locals, only providing error in development
    console.log(next) // eslint-disable-line no-console
    res.locals.message = err.message
    res.locals.error = req.app.get('env') === 'development' ? err : {}

    // render the error page
    res.status(err.status || 500)
    res.render('error')
  })
})()
