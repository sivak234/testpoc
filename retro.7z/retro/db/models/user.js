export default function(sequelize, DataTypes) {
  return sequelize.define(
    'users',
    {
      userId: {
        type: DataTypes.BIGINT,
        allowNull: false,
        primaryKey: true,
        autoIncrement: true,
        field: 'user_id'
      },
      userLoginId: {
        type: DataTypes.STRING(50),
        allownull: false,
        field: 'user_login_id'
      },
      userFirstName: {
        type: DataTypes.STRING(100),
        allowNull: false,
        field: 'user_first_name'
      },
      userLastName: {
        type: DataTypes.STRING(100),
        allowNull: false,
        field: 'user_last_name'
      },
      createdBy: {
        type: DataTypes.STRING(50),
        allownull: true,
        field: 'created_by'
      },
      createdAt: {
        type: DataTypes.DATE,
        allownull: true,
        field: 'created_tsp'
      },
      updatedBy: {
        type: DataTypes.STRING(50),
        allownull: true,
        field: 'updated_by'
      },
      updatedAt: {
        type: DataTypes.DATE,
        allownull: true,
        field: 'updated_tsp'
      },
      active: {
        type: DataTypes.STRING(1),
        allownull: false,
        field: 'active_indicator'
      }
    },
    {
      freezeTableName: true,
      tableName: 'user',
      timestamps: true,
      createdAt: 'created_tsp',
      updatedAt: 'updated_tsp',
      underscored: true
    }
  )
}
