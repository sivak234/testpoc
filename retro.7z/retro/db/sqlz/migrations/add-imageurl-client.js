module.exports = {
  up: function(queryInterface, Sequelize) {
    return [
      queryInterface.addColumn('client', 'logo_url', {
        type: Sequelize.STRING(100),
        allowNull: false
      })
    ]
  },

  down: function(queryInterface) {
    return [queryInterface.removeColumn('client', 'logo_url')]
  }
}
