module.exports = {
  up: function(queryInterface, Sequelize) {
    return [
      queryInterface.addColumn('client_community', 'image_url', {
        type: Sequelize.STRING(100),
        allowNull: false
      })
    ]
  },

  down: function(queryInterface) {
    return [queryInterface.removeColumn('client_community', 'image_url')]
  }
}
