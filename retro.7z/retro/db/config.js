const config = require('config')

module.exports = {
  development: {
    url: config.database.url,
    dialect: config.database.dialect
  }
}
