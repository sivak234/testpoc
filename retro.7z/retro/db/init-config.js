module.exports = {
  init: {
    username: 'root' || process.env.DDL_USER,
    password: null || process.env.DDL_PASS,
    database: 'poc',
    host: 'localhost' || process.env.DDL_HOST,
    dialect: 'mysql'
  }
}
