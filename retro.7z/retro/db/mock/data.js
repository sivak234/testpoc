// var AccountType = {
//   External: 'External',
//   Aetna: 'Aetna',
//   Aetna_Managed: 'Aetna_Managed'
// }

var Clients = [
  {
    clientId: 'd217fde8-fad7-4f27-a215-1b2f8d9be453',
    client: 'AETNA',
    description: '',
    email: 'aetna-admin@aetna.com',
    'account-type': 'AETNA'
    //"roles": ["power-user","Admin"]
  },
  {
    clientId: '232b6e0c-b8c5-430f-852e-4eb46a9ae847',
    client: 'WALMART',
    description: '',
    email: 'walmart-admin@walmart.com',
    'account-type': 'EXTERNAL'
    //"roles": ["Analyst"]
  },
  {
    clientId: '7be23636-f65c-4855-a275-1ad7fc9fdddd',
    client: 'HOME DEPOT',
    description: '',
    email: 'hd-admin@home-depot.com',
    'account-type': 'EXTERNAL'
    //"roles": ["Analyst"]
  },
  {
    clientId: '72b5195d-e85a-4baf-9bd3-6dd67d448e64',
    client: 'XYZ Corp',
    description: '',
    email: 'xyz-admin@xyz.com',
    'account-type': 'AETNA MANAGED'
    //"roles": ["Analyst"]
  }
]

var Roles = {
  administrator: 'administrator',
  power_user: 'power-user',
  executive: 'executive',
  product_team: 'product-team',
  support_team: 'support-team',
  analyst: 'analyst'
}

var ClientRoles = [
  {
    id: 1,
    clientId: '232b6e0c-b8c5-430f-852e-4eb46a9ae847', //walmart
    roles: [Roles.analyst, Roles.executive, Roles.support_team, Roles.product_team]
  },
  {
    id: 2,
    clientId: 'd217fde8-fad7-4f27-a215-1b2f8d9be453',
    roles: [Roles.administrator, Roles.power_user, Roles.executive, Roles.product_team]
  },
  {
    id: 3,
    clientId: 3, //Ahome depot
    roles: ['administrator', 'analyst', 'executive', 'product-team']
  },
  {
    id: 4,
    clientId: 6, //Banner
    roles: ['administrator', 'executive']
  }
]

var ClientSpaces = [
  {
    clientId: 'd217fde8-fad7-4f27-a215-1b2f8d9be453',
    communityclientId: 1,
    spaceId: '885c44f7-8751-4928-8e4a-ea3e7acae701',
    spaceName: 'BDW RedShift 2 Space'
  },
  {
    clientId: '232b6e0c-b8c5-430f-852e-4eb46a9ae847',
    communityclientId: 2,
    spaceId: '885c44f7-8751-4928-8e4a-ea3e7acae701',
    spaceName: 'BDW RedShift 2 Space'
  },
  {
    clientId: '7be23636-f65c-4855-a275-1ad7fc9fdddd',
    communityclientId: 3,
    spaceId: '9c267a60-d83f-448c-b504-8b56cf9468e6',
    spaceName: 'ART Reporting System PI1 Sprint 5'
  },
  {
    clientId: '72b5195d-e85a-4baf-9bd3-6dd67d448e64',
    communityclientId: 4,
    spaceId: '9c267a60-d83f-448c-b504-8b56cf9468e6',
    spaceName: 'ART Reporting System PI1 Sprint 5'
  },
  {
    clientId: '27445f74-cdb2-4c84-9861-999e71a9bae3',
    communityclientId: 5,
    spaceId: '885c44f7-8751-4928-8e4a-ea3e7acae701',
    spaceName: 'BDW RedShift 2 Space'
  },
  {
    clientId: '232b6e0c-b8c5-430f-852e-4eb46a9ae847',
    communityclientId: 6,
    spaceId: '9c267a60-d83f-448c-b504-8b56cf9468e6',
    spaceName: 'ART Reporting System PI1 Sprint 5'
  }
]

var ClientPathways = [
  {
    clientId: 'd217fde8-fad7-4f27-a215-1b2f8d9be453',
    DBId: 1,
    SeqId: 1,
    spaceId: '885c44f7-8751-4928-8e4a-ea3e7acae701',
    Title: 'Aetna > Space One > Title One',
    Commentary: 'some commentary for Aetna'
  },
  {
    clientId: '232b6e0c-b8c5-430f-852e-4eb46a9ae847',
    DBId: 2,
    SeqId: 2,
    spaceId: '885c44f7-8751-4928-8e4a-ea3e7acae701',
    Title: 'Walmart > Space One > Title One',
    Commentary: 'some commentary for Walmart'
  },
  {
    clientId: '232b6e0c-b8c5-430f-852e-4eb46a9ae847',
    DBId: 3,
    SeqId: 3,
    spaceId: '885c44f7-8751-4928-8e4a-ea3e7acae701',
    Title: 'Walmart > Space One > Title Two',
    Commentary: 'some commentary for Walmart 2'
  }
]

var Permissions = {
  what_if_create: 'what-if-create',
  what_if_view: 'what-if-view',
  dashboard_create: 'dashboard-create',
  dashboard_view: 'dashboard-view',
  storyboard_create: 'storyboard-create',
  storyboard_view: 'storyboard-view',
  client_setup: 'client-setup'
}

var ClientRolePermissions = [
  {
    id: 1,
    clientId: 'd217fde8-fad7-4f27-a215-1b2f8d9be453', //walmart
    roles: 'administrator', //todo: change this
    permissions: Permissions
  },
  {
    id: 2,
    clientId: '232b6e0c-b8c5-430f-852e-4eb46a9ae847', //walmart
    roles: 'executive', //todo: change this
    permissions: [
      Permissions.what_if_create,
      Permissions.what_if_view,
      Permissions.dashboard_create,
      Permissions.dashboard_view
    ]
  }
]

var MockData = {
  Clients: Clients,
  ClientSpaces: ClientSpaces,
  ClientRoles: ClientRoles,
  ClientRolePermissions: ClientRolePermissions,
  ClientPathways: ClientPathways
}

module.exports = MockData
