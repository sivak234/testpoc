import fs from 'fs'
import path from 'path'
import Sequelize from 'sequelize'
import config from 'config'
import {log} from '../../shared/logger'

export const strict = {
  onDelete: 'CASCADE',
  foreignKey: {
    allowNull: false
  }
}

export const sequelize = new Sequelize(config.database.uri, {dialect: config.database.dialect})
export const models = getModels()

function getModels() {
  const modelPath = path.join(__dirname, '..', 'models')
  log(`get-models: model-path=${modelPath}`)
  const models = {}
  fs.readdirSync(modelPath)
    .filter(file => {
      return file.endsWith('.js')
    })
    .forEach(file => {
      log(`found model=${file}`)
      const model = sequelize.import(path.join(modelPath, file))
      models[model.name] = model
    })
  return models
}
