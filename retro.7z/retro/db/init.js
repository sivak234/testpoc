import {log} from '../shared/logger'
import {sequelize} from './shared/sqlz-helpr'

export default (async () => {
  log('syncing models with database...')
  await sequelize.sync({alter: false})
  log('sync complete!')
  //The following will be called only within the context of CLI
  /* eslint-disable unicorn/no-process-exit */
  process.exit(0)
})()
