//import config from 'config'
import getReduxPage from '../shared/redux-page'
import getFeathersActions from '../web-helpr/feathers-actions'
import {openSnackbar} from '../layout/layout-redux'

let apiHost ='localhost:3001'
const {resource} = 'client'
const actions = getFeathersActions({apiHost, resource})
export default getReduxPage({
  resource,
  actions,
  limit: 5,
  onSuccess: ({dispatch}) => dispatch(openSnackbar('success')),
  onFailure: ({dispatch, result}) =>
    dispatch(openSnackbar(result.message || result.payload.message))
})
export {apiHost}
