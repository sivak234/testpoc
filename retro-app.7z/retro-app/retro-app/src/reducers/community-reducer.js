import config from 'config'
import getReduxPage from '../shared/redux-page'
import getFeathersActions from '../web-helpr/feathers-actions'
import {openSnackbar} from '../layout/layout-redux'
import {extractErrorMessage} from '../shared/util'
//let apiHost ='localhost:3001'
const url = config.apiHost
const resource = `$${localStorage.getItem('clientId')}
}`
const actions = getFeathersActions({url, resource})

export default getReduxPage({
  resource,
  actions,
  limit: 50,
  onSuccess: ({dispatch}) => dispatch(openSnackbar('success')),
  onFailure: ({dispatch, result}) => dispatch(openSnackbar(extractErrorMessage(result))),
})
export {url}
