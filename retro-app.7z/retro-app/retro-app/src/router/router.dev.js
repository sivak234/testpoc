import debug from 'debug'
import React from 'react'
import {Router, Route} from 'react-router-dom'
import getHistory from 'history/createHashHistory'
import Layout from '../layout'

let dbg = debug('app:router:dev')

const history = getHistory()
dbg('history=%o', history)


export default () => {
  dbg('render')
  const routerdiv = (
    <div id="router-div">
      <Router history={history}>
        <Route path="/" component={Layout} />
      </Router>
    </div>
  )
  return routerdiv
}
