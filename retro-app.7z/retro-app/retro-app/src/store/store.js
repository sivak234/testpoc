import {applyMiddleware, createStore, compose} from 'redux'
import logger from 'redux-logger'
import thunk from 'redux-thunk'
import promise from 'redux-promise-middleware'
import {middleware as reduxPackMiddleware} from 'redux-pack'
import reducer from '../reducers'

//More about thunk here https://github.com/gaearon/redux-thunk
const middleware = applyMiddleware(thunk, promise, reduxPackMiddleware, logger)

export default createStore(reducer, compose(middleware))
