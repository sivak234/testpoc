import debug from 'debug'
import {createStore, applyMiddleware, compose} from 'redux'
import thunkMiddleware from 'redux-thunk'
import promiseMiddleware from 'redux-promise'
import {middleware as reduxPackMiddleware} from 'redux-pack'
import {createLogger} from 'redux-logger'
import rootReducer from '../reducers'

const dbg = debug('app:store:prod')

export default () => {
  dbg('root-reducer=%o', rootReducer)

  return createStore(
    rootReducer,
    compose(
      applyMiddleware(
        thunkMiddleware,
        promiseMiddleware,
        reduxPackMiddleware,
        createLogger({
          collapsed: true
        })
      )
    )
  )
}
