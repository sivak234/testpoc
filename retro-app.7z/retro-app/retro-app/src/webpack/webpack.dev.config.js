var _ = require('lodash')
var DefinePlugin = require('webpack/lib/DefinePlugin')
var commonConfig = require('./webpack.common.config')

const config = _.extend(commonConfig, {
  // devtool: 'eval', // fastest, least-helpful
  //devtool: 'cheap-module-eval-source-map', // medium-fast, medium-helpful
  node: {
    dns: 'mock',
    net: 'mock'
  },
  devtool: 'source-map', // slowest, most-helpful
  // debug: true,
  devServer: {
    proxy: {
      '/api/*': 'http://localhost:3000'
    }
  },
  plugins: [
    ...commonConfig.plugins,
    new DefinePlugin({
      __DEV__: true
    })
  ]
})

// eslint-disable-next-line no-console
console.log('webpack-config=%s', JSON.stringify(config, null, 2))

module.exports = config
