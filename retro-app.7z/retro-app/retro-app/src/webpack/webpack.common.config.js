const path = require('path')
const fs = require('fs-extra')
const HtmlWebpackPlugin = require('html-webpack-plugin')
const ProvidePlugin = require('webpack/lib/ProvidePlugin')
const DefinePlugin = require('webpack/lib/DefinePlugin')
//const UglifyJsPlugin = require('uglifyjs-webpack-plugin')
//const FaviconsWebpackPlugin = require('favicons-webpack-plugin')
const config = require('config')
const WebpackGitHash = require('webpack-git-hash')

// https://github.com/lorenwest/node-config/wiki/Webpack-Usage
const configJson = '../build/client.json'
fs.outputFileSync(path.resolve(__dirname, configJson), JSON.stringify(config))

module.exports = {
  node: {
    dns: 'mock',
    net: 'mock'
  },
  entry: {
    app: ['./app/index.js']
  },
  output: {
    path: path.resolve(__dirname, '../build'),
    //filename: '[name].[hash].bundle.js'
    filename: '[name].[githash].bundle.js'
  },
  resolve: {
    alias: {
      underscore: 'lodash',
      config: path.resolve(__dirname, configJson)
    }
  },
  plugins: [
    new ProvidePlugin({
      jQuery: 'jquery'
    }),
    new HtmlWebpackPlugin({
      template: 'app/index.html',
      hash: true, //append a unique webpack compilation hash to all included scripts and css files "for cache busting"
      inject: 'body'
    }),
    new DefinePlugin({
      'process.env.NODE_ENV': JSON.stringify(process.env.NODE_ENV),
      'process.env.DEBUG': JSON.stringify(process.env.DEBUG)
    }),
    new WebpackGitHash()
    // new DefinePlugin({
    //   'process.env': Object.keys(process.env).reduce(function(o, k) {
    //     o[k] = JSON.stringify(process.env[k])
    //     return o
    //   }, {})
    // })
    // new DefinePlugin({
    //   'process.env.NODE_ENV': JSON.stringify('production')
    // })
    // new UglifyJsPlugin({
    //   test: /\.js($|\?)/i
    // })
    // new FaviconsWebpackPlugin({
    //   logo: './app/logo.svg',
    //   icons: {
    //     android: false,
    //     appleIcon: false,
    //     appleStartup: false,
    //     coast: false,
    //     favicons: true,
    //     firefox: false,
    //     opengraph: false,
    //     twitter: false,
    //     yandex: false,
    //     windows: false
    //   }
    // })
  ],
  module: {
    rules: [
      // {
      //   test: /\.jsx?$/,
      //   loader: 'xo-loader',
      //   exclude: /node_modules/,
      //   enforce: 'pre'
      // },
      {
        test: /\.scss$/,
        use: ['style-loader', 'css-loader', 'sass-loader']
      },
      {
        test: /\.jsx?$/,
        loader: 'babel-loader',
        exclude: /node_modules/,
        query: {
          presets: ['react', 'env', 'stage-0'],
          plugins: [
            'transform-decorators-legacy',
            'transform-class-properties',
            'transform-es2015-arrow-functions',
            'transform-es2015-classes',
            'transform-es2015-shorthand-properties'
          ]
        }
      },
      {
        test: /\.js?$/,
        loaders: 'babel-loader',
        exclude: /(node_modules|__tests__)/,
        query: {
          presets: ['react', 'env', 'stage-0'],
          plugins: [
            'transform-decorators-legacy',
            'transform-class-properties',
            'transform-es2015-arrow-functions',
            'transform-es2015-classes',
            'transform-es2015-shorthand-properties'
          ]
        }
      },
      {
        test: /\.js?$/,
        loaders: 'babel-loader',
        include: [
          path.resolve(__dirname, '../node_modules/csv-generate/'),
          path.resolve(__dirname, '../node_modules/csv-parse/'),
          path.resolve(__dirname, '../node_modules/csv-stringify/'),
          path.resolve(__dirname, '../node_modules/stream-transform/')
        ]
      },
      {
        test: /\.css$/,
        use: ['style-loader', 'css-loader']
      },
      {
        test: /\.(png|jpg|gif)$/,
        loader: 'url-loader'
      },
      {
        test: /\.woff(2)?(\?v=[0-9]\.[0-9]\.[0-9])?$/,
        loader: 'url-loader'
      },
      {
        test: /\.(ttf|eot|svg)(\?v=[0-9]\.[0-9]\.[0-9])?$/,
        loader: 'file-loader'
      }
    ]
  }
}
