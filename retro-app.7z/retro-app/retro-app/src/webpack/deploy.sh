# #! /bin/sh

# export NODE_ENV="${NODE_ENV:-development}"

# npm --prefix /app run build

# echo 'copying build to nginx root'
# cp -r /app/build/* /usr/share/nginx/html/ 

# echo 'starting nginx...'
# nginx -g "daemon off;"