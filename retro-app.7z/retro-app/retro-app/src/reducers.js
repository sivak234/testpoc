import debug from 'debug'
import {combineReducers} from 'redux'
import {reducer as form} from 'redux-form'
import clientredux from './reducers/clients-reducer'
import communityredux from './reducers/community-reducer'


const dbg = debug('app:reducers')

const reducers = {
  form,
  communities: communityredux.reducer,
  clients: clientredux.reducer,
}

dbg('reducers=%o', reducers)

export default combineReducers(reducers)
