import {createMuiTheme} from '@material-ui/core/styles'
import createPalette from '@material-ui/core/styles/createPalette'
import blue from '@material-ui/core/colors/blue'
import purple from '@material-ui/core/colors/purple'
import green from '@material-ui/core/colors/green'
import red from '@material-ui/core/colors/red'
import orange from '@material-ui/core/colors/orange'
import grey from '@material-ui/core/colors/grey'
// import DownArrow from '../images/chevron-down.png'
// import selectDown from '../images/downarrow.png'

export default createMuiTheme({type: 'light'})

const theme = {
  textColor: {
    primary: '#7E3A99',
    secondary: '#FFFFFF',
    hover: '#000000'
  },
  backgroundColor: {
    default: '#7D3F98',
    white: '#FFFFFF',
    hover: '#B18CC1'
  },
  fontFamily: 'Open Sans',
  fontSize: {
    primary: '16px'
  },
  spinnerClass: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    margin: '0 auto',
    position: 'absolute',
    height: '100px',
    width: '100px',
    top: '40%',
    left: '50%'
  }
}
export const blueTheme = createMuiTheme({
  palette: createPalette({
    // palette: {
    primary: {light: blue[300], main: blue[500], dark: blue[700]},
    secondary: {main: blue[500], A400: '#FFFFFF'},
    type: 'light',
    // error: red,
    navHeader: theme.textColor.primary,
    iconFocus: '#E8DCEC',
    backgroundColor: theme.backgroundColor.default,
    button: {
      hoverBackgroundColor: theme.backgroundColor.hover,
      hoverTextColor: theme.textColor.hover,
      borderRadius: '15px'
    },
    fontFamily: theme.fontFamily,
    textColor: {
      primary: theme.textColor.primary,
      secondary: theme.textColor.secondary
    },
    cancelbutton: {
      boxSizing: 'border-box',
      height: '42px',
      width: '95px',
      border: '1px solid #DADFE7',
      borderRadius: '15px',
      backgroundColor: theme.backgroundColor.default,
      //color: '#39393A',
      fontFamily: theme.fontFamily,
      '&:hover': {
        backgroundColor: theme.backgroundColor.hover,
        color: theme.textColor.hover,
        fontWeight: 600,
        fontSize: '16px'
      },
      fontSize: '16px',
      color: '#FFFFFF',
      lineHeight: '10px',
      //textTransform: 'initial' -- Comment by Abirami For UI FIX
      textTransform: 'capitalize'
    },
    savebutton: {
      height: '41px',
      minWidth: '159.55px',
      borderRadius: '15px',
      backgroundColor: theme.backgroundColor.default,
      '&:hover': {
        backgroundColor: theme.backgroundColor.hover,
        color: theme.textColor.hover,
        fontWeight: 600,
        fontSize: '16px'
      },
      marginLeft: '2%',
      color: '#FFFFFF',
      fontFamily: theme.fontFamily,
      fontSize: '16px',
      lineHeight: '10px',
      //textTransform: 'initial' -- Comment by Abirami For UI FIX
      textTransform: 'capitalize'
    },
    saveclientuserbutton: {
      height: '41px',
      minWidth: '86px',
      borderRadius: '15px',
      backgroundColor: theme.backgroundColor.default,
      '&:hover': {
        backgroundColor: theme.backgroundColor.hover,
        color: theme.textColor.hover,
        fontWeight: 600,
        fontSize: '16px'
      },
      marginLeft: '2%',
      color: '#FFFFFF',
      fontFamily: theme.fontFamily,
      fontSize: '16px',
      lineHeight: '10px',
      //textTransform: 'initial' -- Comment by Abirami For UI FIX
      textTransform: 'capitalize'
    },
    textFieldInput: {
      borderRadius: 4,
      background: theme.backgroundColor.white,
      border: '1px solid #ced4da',
      fontSize: 16,
      padding: '12px',
      width: '89%',
      fontFamily: theme.fontFamily,
      //transition: theme.transitions.create(['border-color', 'box-shadow']),
      '&:focus': {
        borderRadius: 3,
        border: `2px solid ${theme.backgroundColor.default}`
        //boxShadow: '0 0 0 0.2rem rgba(0,123,255,.25)',
      }
    },
    textFieldInputError: {
      border: '2px solid #DB4437',
      borderRadius: 3
    },
    defaultButton: {
      borderRadius: '16px',
      fontSize: '16px',
      fontFamily: theme.fontFamily,
      textTransform: 'capitalize',
      boxShadow: '0 2px 4px 0 rgba(0,0,0,0.34)',
      backgroundColor: theme.backgroundColor.default,
      color: theme.textColor.secondary,
      '&:hover': {
        backgroundColor: theme.backgroundColor.hover,
        color: theme.textColor.hover,
        boxShadow: '0 2px 4px 0 rgba(0,0,0,0.34)',
        fontWeight: 600,
        fontSize: '16px'
      }
    },
    violetButton: {
      borderRadius: '16px',
      border: `2px solid ${theme.backgroundColor.default}`,
      fontSize: '16px',
      fontFamily: theme.fontFamily,
      textTransform: 'capitalize',
      boxShadow: '0 2px 4px 0 rgba(0,0,0,0.34)',
      backgroundColor: theme.backgroundColor.white,
      color: theme.textColor.primary,
      '&:hover': {
        backgroundColor: theme.backgroundColor.hover,
        color: theme.textColor.hover,
        boxShadow: '0 2px 4px 0 rgba(0,0,0,0.34)',
        fontWeight: 600,
        fontSize: '16px'
      }
    },
    select: {
      root: {
        borderRadius: 20.5,
        background: '#F5F5F5',
        //border: '1px solid #ced4da',
        padding: ' 2px 5px 1px 15px',
        width: '100%',
        fontFamily: theme.fontFamily,
        fontSize: '16px',
        //transition: theme.transitions.create(['border-color', 'box-shadow']),
        '&:focus': {
          borderColor: '#80bdff',
          boxShadow: '0 0 0 0.2rem rgba(0,123,255,.25)'
        },
        height: '38px'
      },
      selectMenu: {
        fontFamily: theme.fontFamily,
        fontSize: '14px',
        color: '#505050',
        padding: '2px 5px',
        '&:focus': {
          background: 'none'
        }
      },
      disabled: {
        color: '#BEBEBE',
        fontFamily: theme.fontFamily,
        fontSize: '14px'
      }
    },
    dropdown: {
      root: {
        height: '35px',
        //padding: '3px 6px 0px 6px',
        border: '1px solid #ced4da',
        borderRadius: 4,
        width: '100%',
        fontFamily: theme.fontFamily,
        fontSize: '14px'
      },
      dropdownMenu: {
        fontFamily: theme.fontFamily,
        fontSize: '16px',
        color: '#414141',
        //padding: '2px 5px',
        paddingLeft: '12px',
        lineHeight: '40px',
        borderRadius: 4,
        height: '30px',
        paddingTop: '2px'
      },
      disabled: {
        color: '#BEBEBE',
        fontFamily: theme.fontFamily,
        fontSize: '16px',
        backgroundColor: '#F5F5F5',
        paddingLeft: '12px',
        // lineHeight: '40px', //commented by Abirami for UI Fix
        borderRadius: 4
        //height: '42px' //commented by Abirami for UI Fix
      }
    },
    inputLabel: {
      padding: '12px 0',
      fontSize: '14px',
      fontFamily: theme.fontFamily,
      color: '#414141'
    },
    menuListText: {
      fontSize: '14px',
      fontFamily: theme.fontFamily
    },
    checkBox: {
      root: {
        fontSize: '2.5rem'
      },
      checked: {
        color: theme.backgroundColor.default
      }
    }
  }),
  scratch: {
    colors: {
      social: 'rgba(71, 138, 247, 0.72)',
      grey: '#dddddd'
    }
  }
})

export const myTheme = createMuiTheme({
  palette: {
    primary: {light: purple[300], main: purple[500], dark: purple[700]}, // Purple and green play nicely together.
    secondary: {main: green[500], A400: '#00e677'},
    error: red,
    type: 'light'
  },
  scratch: {
    colors: {
      social: 'rgba(71, 138, 247, 0.72)',
      grey: '#dddddd'
    }
  }
})
export const orangeTheme = createMuiTheme({
  palette: {
    primary: {light: orange[300], main: orange[500], dark: orange[700]},
    secondary: {main: grey[500], A400: '#bdbdbd'},
    error: red,
    type: 'light'
  },
  scratch: {
    colors: {
      social: 'rgba(71, 138, 247, 0.72)',
      grey: '#dddddd'
    }
  }
})
