import React, {Component} from 'react'
import {MuiThemeProvider, withStyles} from '@material-ui/core/styles'
import {connect} from 'react-redux'
import {bindActionCreators} from 'redux'
import {Switch, Route, withRouter} from 'react-router-dom'
import debug from 'debug'
import _ from 'lodash'
import Grid from '@material-ui/core/Grid'
//import Home from '../home'
import help from '../help'
//import landingpage from '../landing'
import * as actions from '../layout/layout-redux'
import '../App.css'
// import TopNavContainer from '../header'
// import TopHeader from '../top-header'
// import SnackbarContainer from '../snackbar'
// import Footer from '../footer'

import {blueTheme} from './get-theme'

const dbg = debug('app:layout')
//const termsActions = termsContentRedux.actions

const styles = theme => ({
  layoutRoot: {
    flexGrow: 1,
    minHeight: '91vh'
  },
  container: {
    display: 'grid',
    'flex-direction': 'column',
    //height: '100%',
    '@global': {
      a: {
        textDecoration: 'none',
        '&:visited': {
          color: theme.palette.primary[500]
        }
      }
    }
  },
  middle: {
    // flex: 'auto',
    position: 'relative',
    //'overflow-y': 'auto',
    paddingTop: 100,
    padding: 40
    //height: '100%'
  },
  top: {
    display: 'flex',
    flexDirection: 'row'
    // position: 'none'
  },
  ends: {
    // 'flex-shrink': 0,
    display: 'flex',
    flexDirection: 'row'
  },
  adjustMargin: {
    marginTop: '0'
  },
  fixedHeaderTop: {
    width: '100%'
  },
  fixedHeaderbottom: {
    width: '100%'
  }
})

class layout extends Component {
  constructor(props) {
    super(props)
    this.state = {
      reload: 0,
      currentpath: ''
    }
    this.clearUserTimeout = this.clearUserTimeout.bind(this)
  }

  componentWillUnmount() {
    this.clearUserTimeout()
  }

  componentWillReceiveProps(nextProps) {
    this.setState({currentpath: nextProps.location.pathname})
  }

  clearUserTimeout() {
    if (this.timeoutHandle) {
      clearTimeout(this.timeoutHandle)
      this.timeoutHandle = null
    }
  }

  render() {
    dbg('props=%o', this.props)
    const {classes} = this.props

    return (
      <MuiThemeProvider theme={blueTheme}>
        <div>
          <Grid container spacing={0}>
            <Grid item xl={12} lg={12} md={12} sm={12} xs={12} className={classes.layoutRoot}>
              <Switch>
                <Route exact path="/" component={help} />
                <Route path="/help" component={help} />
              </Switch>
            </Grid>
          </Grid>
        </div>
      </MuiThemeProvider>
    )
  }
}

export default withRouter(
  connect(
    state => {
      dbg('connect: state=%o', state)
      return {
        session: state.session,
      }
    },
    dispatch => {
      dbg('connect: actions=%o', actions)
      return bindActionCreators({...actions}, dispatch)
    }
  )(withStyles(styles)(layout))
)
