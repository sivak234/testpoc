import assert from 'assert'
import _ from 'lodash'
import debug from 'debug'
import {stringify} from '../helpr'
import getActions from './rest-actions'

const dbg = debug('lib:web-helpr:feathers-actions')

const wildIn = '*'
const re = new RegExp(`\\${wildIn}`, 'g')
const wildOut = '%'

export default function({url, resource}) {
  const actions = getActions({url, resource})

  return {
    ...actions,
    index: async ({query, url}) => {
      const result = await actions.index({query: xformQuery({query}), url})
      assert(result.data, `unexpected result=${stringify(result)}`)
      const {data} = result
      if (!data.rows) {
        throw new Error(data.message || stringify(data))
      }

      // feathers results look like: {total: 0, limit: 5, skip: 0, data: []}
      //
      return {
        rows: data.rows,
        total: data.count,
        query
      }
    }
  }
}

export function xformQuery({query}) {
  dbg('xform-query: query=%o', query)
  return _.transform(query, (result, val, key) => {
    if (key === 'offset') {
      result['offset'] = val
    } else if (key === 'limit') {
      result['limit'] = val
    } else if (val && _.isString(val) && val.indexOf(wildIn) >= 0) {
      result[`${key}[$like]`] = val.replace(re, wildOut)
    } else if (key === 'sort' && val) {
      val.field && (result[`sort[${val.field}]`] = val.isAscending ? 1 : -1)
    } else {
      result[key] = val
    }
  })
}
