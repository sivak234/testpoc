import axios from 'axios'
import debug from 'debug'
// import {SESSION_KEYS} from '../constants/constant'
import {setAxiosHeader} from '../shared/util'

const dbg = debug('lib:web-helpr:rest-actions')

setAxiosHeader(axios)

export default function({url, resource}) {
  const _url = `${url}/${resource}`
  const idUrl = id => `${_url}/${id}`

  return {
    index: async ({query, url}) => {
      const result = await setAxiosHeader(axios).get(url || _url, {params: query})
      dbg('index: url=%o, query=%o, result=%o', url || _url, query, result)
      return result
    },
    get: async ({id, url}) => {
      let result = {}
      if (url) {
        const altIdUrl = id => `${url}/${id}`
        result = await setAxiosHeader(axios).get(altIdUrl(id))
        dbg('get: url=%o, id=%o, result=%o', url, id, result)
      } else {
        result = await setAxiosHeader(axios).get(idUrl(id))
        dbg('get: url=%o, id=%o, result=%o', _url, id, result)
      }
      return result.data
    },
    create: async ({data, url}) => {
      const dbg = debug('lib:web-helpr:rest-actions')
      const result = await setAxiosHeader(axios).post(url || _url, data)
      dbg('create: url=%o, data=%o, result=%o', _url, data, result)
      return result
    },
    update: async ({id, data, url}) => {
      let result = {}
      if (url) {
        const altIdUrl = id => `${url}/${id}`
        result = await setAxiosHeader(axios).put(altIdUrl(id), data)
        dbg('update: url=%o, id=%o, data=%o, result=%o', url, id, data, result)
      } else {
        result = await setAxiosHeader(axios).put(idUrl(id), data)
        dbg('update: url=%o, id=%o, data=%o, result=%o', _url, id, data, result)
      }
      return result
    },
    patch: async ({id, data, url}) => {
      let result = {}
      if (url) {
        const altIdUrl = id => `${url}/${id}`
        result = await setAxiosHeader(axios).patch(altIdUrl(id), data)
        dbg('update: url=%o, id=%o, data=%o, result=%o', url, id, data, result)
      } else {
        result = await setAxiosHeader(axios).patch(idUrl(id), data)
        dbg('update: url=%o, id=%o, data=%o, result=%o', url, id, data, result)
      }
      dbg('patch: url=%o, id=%o, data=%o, result=%o', _url, id, data, result)
      return result
    },
    delete: async ({id, url}) => {
      let result = {}
      if (url) {
        const altIdUrl = id => `${url}/${id}`
        result = await setAxiosHeader(axios).delete(altIdUrl(id))
        dbg('delete: url=%o, id=%o, result=%o', url, id, result)
      } else {
        result = await setAxiosHeader(axios).delete(idUrl(id))
        dbg('delete: url=%o, id=%o, result=%o', _url, id, result)
      }

      return result
    }
  }
}
