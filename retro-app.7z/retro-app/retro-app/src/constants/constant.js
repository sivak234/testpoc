export const Constant = {
  BIRST_MODULE: 'newDashboards',
  BIRST_EMBEDDED: true,
  BIRST_HIDEDASHBOARDNAVIGATION: false,
  BIRST_HIDEDASHBOARDPROMPTS: false,
  BIRST_PAGEID: 'Rx Dashboard 2 ',
  BIRST_DASHBOARDID: 'ART_D_Landing Page_KPI',
  Folder: 'Folder',
  Pathway: 'Pathway',
  Dashboard: 'Dashboard',
  Report: 'Report',
  ComponentType: {
    DASHBOARD: 'DASHBOARD',
    PATHWAYS: 'PATHWAYS',
    VISUALIZERS: 'VISUALIZERS',
    REPORTS: 'REPORTS',
    ACCOUNTSTRUCTURE: 'ACCOUNTSTRUCTURE'
  },
  VISUALIZER_READONLY: '_object_Visualizer_readonly',
  CLIENT_REPORT_READONLY: '_object_Visualizer_readonly',
  THRESHOLD_SYMBOL: '%'
}
export const SESSION_KEYS = {
  BIRST_SPACES: 'BirstSpaces',
  BIRST_TOKEN: 'BirstToken',
  BIRST_SSO_TOKENS: 'BirstSsoTokens',
  BIRST_PARAMS: 'BirstParameters',
  UserClientId: 'user-client-id',
  LoggedInUserId: 'logged-in-user-id',
  UserTermsAcceptedDate: 'user-terms-accepted-date',
  UserLastAccessedUrl: 'user-last-accessed-url',
  UserAuthToken: 'user-auth-token',
  ClientTermsContent: 'client-terms-content',
  UserAssociatedClients: 'user-associated-clients',
  UserAssociatedCommunities: 'user-associated-communities',
  UserIsProductAdmin: 'user-is-product-admin',
  UserAssociatedPermissions: 'user-associated-permissions',
  AccessToken: 'access_token',
  Idp_token: 'Idp_token',
  UserLoginId: 'user-login-Id',
  UserSelectedAccountStructure: 'user-selected-account-structure',
  CommunityPermissions: 'community-permissions',
  UserTimedOut: 'user-timed-out',
  UserChangedAccountStructure: 'user-changed-account-structure',
  UserPermission: 'user-permission',
  CommunityIsSelected: 'community-is-selected',
  PreferredUsername: 'preferred-username',
  RecentUserHistory: 'recent-user-history',
  Lag: 'lag',
  PeriodRange: 'period-range',
  UserSelectedUserFilter: 'user-selected-user-filter',
  UserSelectedFundingType: 'user-selected-funding-type'
}

export const PERMISSION_TYPES = {
  SHOW_ADMIN: '_functionality_AdminIcon',
  MODIFY_CLIENT: '_functionality_AdminClient_modifiable',
  VIEW_CLIENT: '_functionality_AdminClient_readonly',
  MODIFY_ROLE: '_functionality_AdminRole_modifiable',
  VIEW_ROLE: '_functionality_AdminRole_readonly',
  MODIFY_COMMUNITY: '_functionality_AdminCommunity_modifiable',
  VIEW_COMMUNITY: '_functionality_AdminCommunity_readonly',
  MODIFY_USERS: '_functionality_AdminUsers_modifiable',
  VIEW_USERS: '_functionality_AdminUsers_readonly',
  ACCESS_VISUALIZER: '_object_Visualizer_readonly',
  MODIFY_VISUALIZER: '_object_Visualizer_modifiable',
  ACCESS_DASHBOARDS: '_object_Dashboard_modifiable',
  MANAGE_ALERTS: '_functionality_Alerts',
  MANAGE_CONTENT: '_functionality_ManageContent',
  WHATIF_ANALYSIS: '_functionality_WhatIf'
}

export const PERMISSION_LEVEL = {
  ROOT: 'ROOT',
  CLIENT: 'CLIENT',
  COMMUNITY: 'COMMUNITY',
  ANY: 'ANY'
}