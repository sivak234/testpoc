import React, {Component} from 'react'
import PropTypes from 'prop-types'
import Typography from '@material-ui/core/Typography'
import moment from 'moment'
import Table from '@material-ui/core/Table'
import TableBody from '@material-ui/core/TableBody'
import TableCell from '@material-ui/core/TableCell'
import TableHead from '@material-ui/core/TableHead'
import TableRow from '@material-ui/core/TableRow'
import Tooltip from '@material-ui/core/Tooltip'
import TableSortLabel from '@material-ui/core/TableSortLabel'
import {NavLink} from 'react-router-dom'
import IconButton from '@material-ui/core/IconButton'
import {withStyles} from '@material-ui/core/styles'
import debug from 'debug'
import _ from 'lodash'
import createUltimatePagination from '@watchmen/react-ultimate-pagination-material-ui'
import EditIcon from '../../images/editnew.png'

const dbg = debug('lib:material-ui-data-table')

const Pager = createUltimatePagination()

const styles = theme => {
  dbg('theme=%o', theme)
  const space2 = theme.spacing.unit * 2
  const pagerPadding = space2 - 5

  return {
    root: {
      display: 'grid',
      flexDirection: 'column'
    },
    label: {
      textTransform: 'capitalize'
    },
    thead: {
      padding: space2,
      textAlign: 'left',
      borderBottom: '1px solid #0E55CA',
      height: '24px',
      color: '#414141',
      fontFamily: 'Open Sans',
      fontSize: '18px',
      fontWeight: 'bold',
      lineHeight: '24px'
    },
    tbody: {
      height: '19px',
      width: '39px',
      color: '#4A4A4A',
      fontFamily: 'Open Sans',
      fontSize: '14px',
      lineHeight: '19px'
    },
    table: {
      borderCollapse: 'collapse',
      fontFamily: 'Open Sans',
      minWidth: 600,
      fontSize: '14px'
    },
    tableWrapper: {
      overflowX: 'auto',
      maxWidth: '100%'
    },
    tr: {
      'border-bottom': '1px solid #ced4da',
      '&:hover': {
        background: '#E8DCEC',
        fontWeight: 'bold'
      }
    },
    pager: {
      alignSelf: 'center',
      padding: pagerPadding,
      color: '#7E3A99'
    },
    text: {
      padding: '4%',
      textAlign: 'center',
      color: '#4A4A4A',
      fontFamily: 'Open Sans',
      fontSize: '14px',
      lineHeight: '19px',
      height: '25px'
    },
    edittooltip: {
      color: '#4A4A4A',
      fontFamily: 'Open Sans',
      fontSize: '14px',
      lineHeight: '19px',
      background: '#E8DCEC'
    },
    tablecell: {
      width: '18%',
      borderBottom: '0px solid #7E3A99',
      color: '#4A4A4A',
      fontFamily: 'Open Sans',
      fontSize: '16px',
      lineHeight: '21px',
      height: '21px',
      paddingLeft: space2,
      paddingRight: '0px',
      paddingTop: '5px',
      paddingBottom: '5px'
    }
  }
}
function formatDateTime(date) {
  //let hours = date.getHours()
  //let minutes = date.getMinutes()
  //let ampm = hours >= 12 ? 'pm' : 'am'
  //hours = hours % 12
  //hours = hours ? hours : 12 // the hour '0' should be '12'
  //minutes = minutes < 10 ? '0' + minutes : minutes
  //var strTime = hours + ':' + minutes + ' ' + ampm
  //return date.getMonth() + 1 + '/' + date.getDate() + '/' + date.getFullYear() + '  ' + strTime
  return moment.utc(date).format('MM/DD/YYYY')
}
class dataTable extends Component {
  constructor(props) {
    super(props)
    this.getOnSort = this.getOnSort.bind(this)
  }
  getOnSort(field) {
    return function() {
      const {orderBy} = this.props.page.query
      const arrangeBy = this.props.page.query.arrangeBy
      const isAscending = orderBy && (_.eq(arrangeBy, 'ASC') ? false : true)
      dbg('on-sort: field=%o, isAscending=%o, props=%o', field, isAscending, this.props)
      this.props.onSort({field, isAscending: isAscending})
    }
  }
  // getOnSort = field => () => {
  //   const {orderBy} = this.props.page.query
  //   const arrangeBy = this.props.page.query.arrangeBy
  //   const isAscending = orderBy && (_.eq(arrangeBy, 'ASC') ? false : true)
  //   dbg('on-sort: field=%o, isAscending=%o, props=%o', field, isAscending, this.props)
  //   this.props.onSort({field, isAscending: isAscending})
  // }

  render() {
    dbg('render: props=%o', this.props)
    const {
      columns,
      page,
      classes,
      noRecordsFound,
      zoomCell,
      routePath,
      idColumn,
      parent,
      parentIdColumn,
      grandParentPrefixUrl,
      suppressEditIcon
    } = this.props
    const {query, rows} = page
    const sortField = _.get(query, 'orderBy')
    const isAscending = _.eq(_.get(query, 'arrangeBy'), 'ASC')
    dbg('rows=%0', rows)
    const head = (
      <TableHead>
        <TableRow>
          {zoomCell && !suppressEditIcon && <TableCell key={-1} padding="checkbox" />}
          {columns.map(column => {
            return (
              <TableCell
                key={column.id}
                numeric={column.numeric}
                padding={column.padding}
                className={classes.thead}
              >
                <Tooltip title={column.label || column.id}>
                  <TableSortLabel
                    active={sortField === column.id}
                    direction={isAscending ? 'asc' : 'desc'}
                    onClick={this.getOnSort(column.id)}
                  >
                    {column.label || column.id}
                  </TableSortLabel>
                </Tooltip>
              </TableCell>
            )
          }, this)}
        </TableRow>
      </TableHead>
    )

    const body = (
      <TableBody className={classes.tbody}>
        {rows &&
          rows.map(row => {
            return (
              <TableRow key={`${_.get(row, idColumn)}`} className={classes.tr}>
                {zoomCell &&
                  !suppressEditIcon && (
                    <TableCell
                      key={`${_.get(row, idColumn)}:zoom`}
                      padding="checkbox"
                      className={classes.tablecell}
                    >
                      {grandParentPrefixUrl &&
                        parent && (
                          <NavLink
                            to={`/${grandParentPrefixUrl}/${parent}/${_.get(
                              row,
                              parentIdColumn
                            )}/${routePath}/${_.get(row, idColumn)}`}
                          >
                            <IconButton className={classes.tbody}>
                              <img src={EditIcon} />
                            </IconButton>
                          </NavLink>
                        )}
                      {!grandParentPrefixUrl &&
                        parent && (
                          <NavLink
                            to={`/${parent}/${_.get(row, parentIdColumn)}/${routePath}/${_.get(
                              row,
                              idColumn
                            )}`}
                          >
                            <IconButton className={classes.tbody}>
                              <img src={EditIcon} />
                            </IconButton>
                          </NavLink>
                        )}
                      {!parent && (
                        <NavLink to={`/${routePath}/${_.get(row, idColumn)}`}>
                          <IconButton className={classes.tbody}>
                            <img src={EditIcon} />
                          </IconButton>
                        </NavLink>
                      )}
                    </TableCell>
                  )}
                {columns.map(column => {
                  let cols = column.id.split('.')
                  let dateString = ''
                  if (
                    !_.isNaN(Date.parse(row[column.id])) &&
                    !_.gt(row[column.id], 9) &&
                    (_.indexOf(row[column.id], '-') !== -1 || _.indexOf(row[column.id], '/') !== -1)
                  ) {
                    dateString = formatDateTime(new Date(row[column.id]))
                  } else {
                    dateString = row[column.id]
                  }
                  return (
                    <TableCell
                      className={classes.tablecell}
                      key={`${row.idColumn}:${column.id}`}
                      numeric={column.numeric}
                      padding={column.padding}
                    >
                      {!_.eq(column.formatter, 'custom')
                        ? cols.length > 1 ? _.get(row, column.id) : dateString
                        : this.props.cellFormatter(row, column)}
                    </TableCell>
                  )
                })}
              </TableRow>
            )
          })}
      </TableBody>
    )

    return (
      rows &&
      (rows.length ? (
        <div>
          <div className={classes.root}>
            <div className={classes.tableWrapper}>
              <Table className={classes.table}>
                {head}
                {body}
              </Table>
            </div>
          </div>
          <div className={classes.pager}>
            <Pager
              currentPage={page.currentPage}
              totalPages={page.totalPages}
              boundaryPagesRange={1}
              siblingPagesRange={1}
              hidePreviousAndNextPageLinks={false}
              hideFirstAndLastPageLinks={false}
              hideEllipsis={false}
              onChange={this.props.onPage}
            />
          </div>
        </div>
      ) : (
        noRecordsFound || (
          <Typography className={classes.text} variant="subheading" gutterBottom>
            No Results Found
          </Typography>
        )
      ))
    )
  }
}

dataTable.propTypes = {
  onSort: PropTypes.func.isRequired,
  onPage: PropTypes.func.isRequired,
  page: PropTypes.shape({
    data: PropTypes.array,
    query: PropTypes.shape({
      offset: PropTypes.integer,
      limit: PropTypes.integer,
      sort: PropTypes.shape({
        field: PropTypes.string,
        isAscending: PropTypes.boolean
      })
    })
  }).isRequired,
  columns: PropTypes.array.isRequired,
  classes: PropTypes.object.isRequired,
  noRecordsFound: PropTypes.element,
  zoomCell: PropTypes.element,
  routePath: PropTypes.string,
  idColumn: PropTypes.string,
  parent: PropTypes.string,
  parentIdColumn: PropTypes.string,
  grandParentPrefixUrl: PropTypes.string,
  suppressEditIcon: PropTypes.bool
}

export default withStyles(styles)(dataTable)
