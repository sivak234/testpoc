module.exports = {
  apiHost: 'http://localhost:3001',
  apiResource: {
    legalcontent: {
      resource: 'content'
    },
    client: {
      resource: 'clients'
    }
  }
}
