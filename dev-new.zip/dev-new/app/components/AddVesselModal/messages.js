/*
 * AddVesselModal Messages
 *
 * This contains all the text for the AddVesselModal component.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.components.AddVesselModal';

export default defineMessages({
  addHeader: {
    id: `${scope}.addHeader`,
    defaultMessage: 'Add Vessel',
  },
  viewHeader: {
    id: `${scope}.viewHeader`,
    defaultMessage: 'View Vessel',
  },
  updateHeader: {
    id: `${scope}.updateHeader`,
    defaultMessage: 'Update Vessel',
  },
  deleteHeader: {
    id: `${scope}.deleteHeader`,
    defaultMessage: 'Delete Vessel',
  },
  addVessel: {
    id: `${scope}.addVessel`,
    defaultMessage: 'Add Vessel',
  },
  update: {
    id: `${scope}.update`,
    defaultMessage: 'Update',
  },
  delete: {
    id: `${scope}.delete`,
    defaultMessage: 'Delete',
  },
  cancel: {
    id: `${scope}.cancel`,
    defaultMessage: 'Cancel',
  },
  close: {
    id: `${scope}.close`,
    defaultMessage: 'Close',
  },
});
