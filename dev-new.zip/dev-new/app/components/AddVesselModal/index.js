/**
 *
 * AddVesselModal
 *
 */

import React, { memo, useState, createRef, useEffect, Fragment } from 'react';
import PropTypes from 'prop-types';
import update from 'immutability-helper';
import { Button, Form, Container } from 'reactstrap';
import { FormattedMessage } from 'react-intl';

import messages from './messages';

import VesselDetails from '../VesselDetails/Loadable';
import VesselDimensions from '../VesselDimensions/Loadable';
import VesselCapacities from '../VesselCapacities/Loadable';
import VesselDesigns from '../VesselDesigns/Loadable';
import TankerDetails from '../TankerDetails/Loadable';
import VesselReferenceMenu from '../VesselReferenceMenu/Loadable';
import AddUserSuccessMsgModal from '../AddUserSuccessMsgModal/Loadable';

import {
  yearOptions,
  vesselType,
  yesNoOptions,
  yesNoLookup,
  calculateTPCMI,
} from './_helper';

import { disableValueChangeOnScroll } from '../../utils/commonRenderers';
import { matchNumericRegex } from '../../utils/validation';
import { filteredAccess } from '../../utils/rbac';
import './index.scss';

function AddVesselModal({
  closeVesselForm,
  openFormModal,
  vesselMetadata,
  addVesselData,
  updateVesselData,
  showResponseModal,
  messageHeader,
  messageContent,
  onConfirmModal,
  vesselInformation,
  formType,
  handleUpdateClickFromView,
  handleDeleteClickFromView,
  checkIfImoExists,
  imoExistResponse,
  vesselTypes,
  vesselFormParams,
  fetchVesselSizeCategoriesList,
  vesselSizeCategories,
  moduleId,
  handleMapZoomEvent,
  mapReference,
  fromLandingPage,
  vesselInfoClass,
}) {
  useEffect(() => {
    if (formType === 'Update') {
      setVesselModalDataForUpdate(vesselInformation);
    }
    disableValueChangeOnScroll();
  });

  const [vesselModalData, setVesselModalData] = useState(vesselFormParams);
  const [updateVesselModalData, setVesselModalDataForUpdate] = useState({
    ...vesselInformation,
  });

  const [validationErrorCheck, setValidationErrorCheck] = useState(false);
  const [validationErrorCount, setValidationErrorCount] = useState(false);
  const [selectedField, setSelectedField] = useState('');
  const [isSubmitClicked, setSubmitClicked] = useState(false);

  const vesselDetails = {};

  const vesselDetailsRef = createRef();
  const ownerDetailsRef = createRef();
  const vesselDimensionsRef = createRef();
  const vesselCapacitiesRef = createRef();
  const vesselDesignRef = createRef();
  const tankerDetailsRef = createRef();
  const imoInputRef = createRef();

  const getErrorMessageCount = errorCount => {
    setValidationErrorCount(errorCount);
  };

  const handleAddVessel = () => {
    setValidationErrorCheck(true);
    setSubmitClicked(true);
    if (checkVesselModalData(vesselModalData) && validationErrorCount === 0) {
      vesselModalData.wopVesselType = vesselTypes.filter(
        shipType =>
          shipType.mstWopVesselTypeId === vesselModalData.wopVesselTypeId,
      )[0].wopVesselDesc;

      vesselModalData.wopVesselSizeClassification = vesselSizeCategories.filter(
        classification =>
          classification.vesselSizeCategoryID ===
          vesselModalData.wopVesselSizeClassificationId,
      )[0].sizeCategory;
      setValidationErrorCheck(false);
      addVesselData(vesselModalData);
      setTimeout(() => {
        setVesselModalData(vesselFormParams);
        setVesselModalDataForUpdate(vesselFormParams);
      }, 3000);
    } else {
      vesselDetailsRef.current.scrollIntoView();
      imoInputRef.current.focus();
    }
  };

  const checkVesselModalData = data => {
    let validationFlag = false;
    if (
      data.imo &&
      data.vesselName &&
      data.dwt &&
      data.draft &&
      data.tpcmi &&
      data.wopVesselType &&
      data.wopVesselSizeClassification
    )
      validationFlag = true;
    return validationFlag;
  };
  const handleUpdateVessel = () => {
    setValidationErrorCheck(true);
    setSubmitClicked(true);
    const updatedVesselData = {
      ...vesselInformation,
      ...updateVesselModalData,
    };
    if (
      updatedVesselData &&
      updateVesselModalData.wopVesselType &&
      validationErrorCount === 0
    ) {
      updatedVesselData.wopVesselType = vesselTypes.filter(
        shipType =>
          shipType.mstWopVesselTypeId === updateVesselModalData.wopVesselTypeId,
      )[0].wopVesselDesc;
    }
    if (
      updatedVesselData &&
      updateVesselModalData.wopVesselSizeClassification &&
      validationErrorCount === 0
    ) {
      updatedVesselData.wopVesselSizeClassification = vesselSizeCategories.filter(
        classification =>
          classification.vesselSizeCategoryID ===
          updateVesselModalData.wopVesselSizeClassificationId,
      )[0].sizeCategory;
      setValidationErrorCheck(false);
      updateVesselData(updatedVesselData);
      setTimeout(() => {
        setVesselModalData(vesselFormParams);
        setVesselModalDataForUpdate(vesselFormParams);
      }, 3000);
    } else {
      vesselDetailsRef.current.scrollIntoView();
    }
  };

  const onJumpSection = event => {
    switch (event.target.dataset.target) {
      case 'VesselDetails':
        vesselDetailsRef.current.scrollIntoView();
        break;
      case 'OwnerDetails':
        ownerDetailsRef.current.scrollIntoView();
        break;
      case 'VesselDimensions':
        vesselDimensionsRef.current.scrollIntoView();
        break;
      case 'VesselCapacities':
        vesselCapacitiesRef.current.scrollIntoView();
        break;
      case 'VesselDesign':
        vesselDesignRef.current.scrollIntoView();
        break;

      case 'TankerDetails':
        tankerDetailsRef.current.scrollIntoView();
        break;
      default:
        break;
    }
  };

  const getHeaderOrControl = control => {
    let value = '';
    switch (formType) {
      case 'Add':
        value =
          control === 'header' ? (
            <FormattedMessage {...messages.addHeader} />
          ) : (
            <Button color="primary" type="button" onClick={handleAddVessel}>
              <FormattedMessage {...messages.addVessel} />
            </Button>
          );
        break;
      case 'View':
        value =
          control === 'header' ? (
            <FormattedMessage {...messages.viewHeader} />
          ) : (
            <>
              {filteredAccess(moduleId, 'delete') && (
                <Button
                  color="primary"
                  type="button"
                  onClick={handleDeleteClickFromView}
                >
                  <FormattedMessage {...messages.delete} />
                </Button>
              )}

              {filteredAccess(moduleId, 'edit') && (
                <Button
                  color="primary"
                  type="button"
                  onClick={handleUpdateClickFromView}
                >
                  <FormattedMessage {...messages.update} />
                </Button>
              )}
            </>
          );
        break;
      case 'Update':
        value =
          control === 'header' ? (
            <FormattedMessage {...messages.updateHeader} />
          ) : (
            <Button color="primary" type="button" onClick={handleUpdateVessel}>
              <FormattedMessage {...messages.update} />
            </Button>
          );
        break;
      case 'Delete':
        value = <FormattedMessage {...messages.deleteHeader} />;
        break;
      default:
        break;
    }
    return value;
  };
  const validateFieldCheck = id => {
    switch (id) {
      case 'imo':
      case 'vesselName':
      case 'dwt':
      case 'draft':
      case 'wopVesselType':
      case 'wopVesselSizeClassification':
      case 'depth':
      case 'net':
      case 'loa':
      case 'parallelBodyLength':
      case 'ktm':
      case 'manifoldDistance':
      case 'manifoldToBow':
      case 'manifoldToStern':
        setValidationErrorCheck(true);
        setSelectedField(id);
        break;
      default:
        break;
    }
  };

  const validateField = (
    event,
    beforeDecimal,
    afterDecimal,
    allowNull = true,
  ) => {
    const result = matchNumericRegex(
      event,
      beforeDecimal,
      afterDecimal,
      allowNull,
      true,
    );
    if (!result) {
      event.preventDefault();
      event.stopPropagation();
      return false;
    }
    handleChange(event);
    return result;
  };

  const handleChange = event => {
    const { id, value } = event.target;
    if (id === 'imo') if (value.length === 7) checkIfImoExists(value);

    const intermediateState = update(vesselDetails, {
      [id]: { $set: value },
    });

    if (formType === 'Update') {
      updateVesselModalData[id] = value;
      if (id === 'wopVesselType') {
        updateVesselModalData.wopVesselTypeId = value;
      }
      if (id === 'wopVesselSizeClassification') {
        updateVesselModalData.wopVesselSizeClassificationId = value;
      }
    }

    validateFieldCheck(id);
    if (id === 'wopVesselType') {
      vesselModalData.wopVesselTypeId = intermediateState.wopVesselType;
      fetchVesselSizeCategoriesList(vesselModalData.wopVesselTypeId);
    }
    if (id === 'wopVesselSizeClassification') {
      vesselModalData.wopVesselSizeClassificationId =
        intermediateState.wopVesselSizeClassification;
    }

    // ------------Calculate tpcmi on dwt & draft change-----------------
    if (id === 'dwt' && formType.toLowerCase() !== 'update') {
      vesselModalData.dwt = value;
      vesselModalData.tpcmi = calculateTPCMI(vesselModalData);
    } else if (id === 'dwt' && formType.toLowerCase() === 'update') {
      updateVesselModalData.dwt = value;
      updateVesselModalData.tpcmi = calculateTPCMI(updateVesselModalData);
    }
    if (id === 'draft' && formType.toLowerCase() !== 'update') {
      vesselModalData.draft = value;
      vesselModalData.tpcmi = calculateTPCMI(vesselModalData);
    } else if (id === 'draft' && formType.toLowerCase() === 'update') {
      updateVesselModalData.draft = value;
      updateVesselModalData.tpcmi = calculateTPCMI(updateVesselModalData);
    }
    // --------------------------------------------------------------------

    if (formType !== 'Update')
      setVesselModalData({ ...vesselModalData, ...intermediateState });
    else
      setVesselModalDataForUpdate({
        ...(updateVesselModalData || vesselInformation),
        ...intermediateState,
      });
  };

  const closeVesselModal = () => {
    closeVesselForm();
    setValidationErrorCheck(false);
    setSubmitClicked(false);
    if (formType !== 'Update') setVesselModalData(vesselFormParams);
  };

  const disableMapZoomEvent = () => {
    handleMapZoomEvent(mapReference, true);
  };

  const enableMapZoomEvent = () => {
    handleMapZoomEvent(mapReference, false);
  };

  useEffect(() => {
    if (!openFormModal) {
      handleMapZoomEvent(mapReference, false);
    }
  });

  return (
    <Container fluid>
      <AddUserSuccessMsgModal
        show={showResponseModal}
        content={messageContent}
        statusCode="success"
        header={messageHeader}
        successModalCloseTrigger={onConfirmModal}
        closeVesselForm={closeVesselForm}
      />

      {openFormModal && (
        <Fragment>
          <div
            className={`modal d-block ${
              vesselInfoClass === 'View' ? 'viewPanel' : ''
            }`}
            id="vesselViewModal"
            tabIndex="-1"
            role="dialog"
            aria-labelledby="vesselViewModal"
            aria-hidden="true"
          >
            <div
              className="modal-dialog"
              role="document"
              onMouseOver={disableMapZoomEvent}
              onFocus={disableMapZoomEvent}
              onMouseOut={enableMapZoomEvent}
              onBlur={enableMapZoomEvent}
            >
              <Form>
                <div className="modal-content">
                  <div className="modal-header">
                    <h5 className="modal-title">
                      {getHeaderOrControl('header')}
                    </h5>
                    <button
                      type="button"
                      className={`close ${formType && 'formType'}`}
                      data-dismiss="modal"
                      aria-label="Close"
                      onClick={closeVesselModal}
                    >
                      <span aria-hidden="true">&times;</span>
                    </button>
                  </div>
                  <div className="vessel-management-popup modal-body">
                    <div className="jump_btn_container pb-2">
                      <VesselReferenceMenu onJumpSection={onJumpSection} />
                    </div>
                    <hr />
                    <div className="add-vessel-modal container">
                      <VesselDetails
                        yearOptions={yearOptions}
                        vesselTypeOptions={vesselType}
                        vesselMetadata={vesselMetadata}
                        handleChange={handleChange}
                        validateField={validateField}
                        passedRef={vesselDetailsRef}
                        ownerRef={ownerDetailsRef}
                        vesselInformation={vesselInformation}
                        formType={formType}
                        validationErrorCheck={validationErrorCheck}
                        vesselModalData={
                          formType === 'Update'
                            ? updateVesselModalData
                            : vesselModalData
                        }
                        imoExistResponse={imoExistResponse}
                        vesselTypes={vesselTypes}
                        getErrorMessageCount={getErrorMessageCount}
                        fetchVesselSizeCategoriesList={
                          fetchVesselSizeCategoriesList
                        }
                        vesselSizeCategories={vesselSizeCategories}
                        selectedField={selectedField}
                        isSubmitClicked={isSubmitClicked}
                        imoInputRef={imoInputRef}
                      />
                      <VesselDimensions
                        handleChange={handleChange}
                        validateField={validateField}
                        passedRef={vesselDimensionsRef}
                        vesselInformation={vesselInformation}
                        formType={formType}
                        validationErrorCheck={validationErrorCheck}
                        vesselModalData={
                          formType === 'Update'
                            ? updateVesselModalData
                            : vesselModalData
                        }
                        getErrorMessageCount={getErrorMessageCount}
                        selectedField={selectedField}
                        isSubmitClicked={isSubmitClicked}
                      />
                      <VesselCapacities
                        validateField={validateField}
                        passedRef={vesselCapacitiesRef}
                        vesselInformation={vesselInformation}
                        formType={formType}
                        vesselModalData={
                          formType === 'Update'
                            ? updateVesselModalData
                            : vesselModalData
                        }
                      />
                      <VesselDesigns
                        yesNoOptions={yesNoOptions}
                        yesNoLookup={yesNoLookup}
                        vesselMetadata={vesselMetadata}
                        handleChange={handleChange}
                        validateField={validateField}
                        passedRef={vesselDesignRef}
                        vesselInformation={vesselInformation}
                        formType={formType}
                        vesselModalData={
                          formType === 'Update'
                            ? updateVesselModalData
                            : vesselModalData
                        }
                      />

                      <TankerDetails
                        yesNoOptions={yesNoOptions}
                        yesNoLookup={yesNoLookup}
                        handleChange={handleChange}
                        validateField={validateField}
                        passedRef={tankerDetailsRef}
                        vesselInformation={vesselInformation}
                        formType={formType}
                        validationErrorCheck={validationErrorCheck}
                        vesselModalData={
                          formType === 'Update'
                            ? updateVesselModalData
                            : vesselModalData
                        }
                        getErrorMessageCount={getErrorMessageCount}
                        selectedField={selectedField}
                        isSubmitClicked={isSubmitClicked}
                      />
                    </div>
                  </div>
                  <div className="modal-footer">
                    {!fromLandingPage && getHeaderOrControl('button')}
                    <Button
                      outline
                      color="primary"
                      type="button"
                      onClick={closeVesselModal}
                    >
                      {fromLandingPage ? (
                        <FormattedMessage {...messages.close} />
                      ) : (
                        <FormattedMessage {...messages.cancel} />
                      )}
                    </Button>
                  </div>
                </div>
              </Form>
            </div>
          </div>
        </Fragment>
      )}
    </Container>
  );
}

AddVesselModal.propTypes = {
  handleUpdateClickFromView: PropTypes.func.isRequired,
  handleDeleteClickFromView: PropTypes.func.isRequired,
  closeVesselForm: PropTypes.func.isRequired,
  checkIfImoExists: PropTypes.func.isRequired,
  fetchVesselSizeCategoriesList: PropTypes.func.isRequired,
  openFormModal: PropTypes.bool,
  showResponseModal: PropTypes.bool,
  vesselMetadata: PropTypes.any,
  addVesselData: PropTypes.func,
  updateVesselData: PropTypes.func,
  messageHeader: PropTypes.string,
  messageContent: PropTypes.string,
  onConfirmModal: PropTypes.func,
  vesselInformation: PropTypes.object,
  formType: PropTypes.string,
  imoExistResponse: PropTypes.string,
  vesselTypes: PropTypes.array,
  vesselFormParams: PropTypes.object,
  vesselSizeCategories: PropTypes.array,
  fromLandingPage: PropTypes.bool,
  moduleId: PropTypes.any,
  handleMapZoomEvent: PropTypes.func,
  mapReference: PropTypes.object,
  vesselInfoClass: PropTypes.string,
};
AddVesselModal.defaultProps = {
  fromLandingPage: false,
  openFormModal: false,
  handleMapZoomEvent: () => {},
};
export default memo(AddVesselModal);
