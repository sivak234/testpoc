/**
 *
 * Asynchronously loads the component for AddVesselModal
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
