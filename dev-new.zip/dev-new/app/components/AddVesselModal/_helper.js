/*
 *
 * AddVesselModal helper
 *
 */
import React from 'react';

export function defaultFunction(text) {
  return text;
}

const currentYear = new Date().getFullYear();
const YearOptions = [];
for (let i = 1970; i <= currentYear; i += 1) {
  YearOptions.push(<option key={i}>{i}</option>);
}
export const yearOptions = YearOptions;

const VesselType = [
  'Anchor Handling Tug/Supply',
  'Barge',
  'Bucket Dredger',
  'Drill Platform',
  'Dredger',
  'Drill Ship',
  'Fire Fighting Tug',
  'Fire Fighting Tractor Tug',
  'Ferry',
  'Lighthouse/Tender',
  'Maintenance',
  'Patrol Ship',
  'Pontoon',
  'Pusher Tug',
  'Research',
  'Roll On/Roll Off',
];
export const vesselType = VesselType.map(e => <option key={e}>{e}</option>);

const SearchVesselType = ['Tanker', 'LNG', 'Cargo'];
export const searchVesselType = SearchVesselType.map(e => (
  <option key={e} value={e}>
    {e}
  </option>
));

const DataSourceType = ['Internal', 'Lloyds', 'AJS Data'];
export const dataSourceType = DataSourceType.map(e => (
  <option key={e} value={e}>
    {e}
  </option>
));

const YesNo = ['Yes', 'No'];
export const yesNoOptions = YesNo.map(e => (
  <option key={e} value={e[0]}>
    {e}
  </option>
));
export const yesNoLookup = {
  Y: 'Yes',
  N: 'No',
};

export const calculateTPCMI = data => {
  if (data.dwt && data.dwt !== '' && data.draft && data.draft !== '') {
    const tpcmi = data.dwt / (data.draft * 100);
    return tpcmi.toFixed(2);
  }
  return '';
};
