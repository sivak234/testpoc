/**
 *
 * AisVesselCreator
 *
 */

import React, { memo } from 'react';
import { Marker } from 'react-google-maps';
// import { VesselType, IconPath } from '../../containers/Ais/constants';

function AisVesselCreator(props) {
  let polygons = [];

  if (props.vesselList !== undefined && props.vesselList.length > 0) {
    const vessles = props.vesselList.splice(0, 1000);

    polygons = vessles.map(vessels => {
      // let vesselColor = '#00FF00';
      // let vesselIconPath = '';
      let vesselObj = vessels;
      let vessel = {};
      const urlPath = '../../assets/images/TankerLoaded.svg';
      if (typeof vessels === 'string') {
        vesselObj = vessels.split(',');
        vessel = {
          vesselBreadth: vesselObj[0],
          vesselHeading: parseFloat(vesselObj[1]),
          vesselLng: parseFloat(vesselObj[2]),
          vesselLat: parseFloat(vesselObj[3]),
          vesselLength: vesselObj[4],
          vesselName: vesselObj[5],
          vesselSpeed: vesselObj[6],
          vesselType: vesselObj[7],
        };
      }
      if (typeof vessels === 'object') {
        vesselObj = vessels;
        vessel = {
          vesselBreadth: vesselObj.vesselBreadth,
          vesselHeading: parseFloat(vesselObj.vesselHeading),
          vesselLng: parseFloat(vesselObj.vesselLng),
          vesselLat: parseFloat(vesselObj.vesselLat),
          vesselLength: vesselObj.vesselLength,
          vesselName: vesselObj.vesselName,
          vesselSpeed: vesselObj.vesselSpeed,
          vesselType: vesselObj.vesselType,
        };
      }

      // switch (vessel.vesselType) {
      //   case VesselType.CONTAINER:
      //     vesselColor = '#FF0000';
      //     vesselIconPath = IconPath.TANKER;
      //     break;
      //   case VesselType.CARGO:
      //     vesselColor = '#00FF00';
      //     vesselIconPath = IconPath.TANKER;
      //     break;
      //   case VesselType.PASSENGER:
      //     vesselColor = '#800000';
      //     vesselIconPath = IconPath.TANKER;
      //     break;
      //   case VesselType.TANKER:
      //     vesselIconPath = IconPath.TANKER;
      //     vesselIconPath = IconPath.TANKER;
      //     break;
      //   case VesselType.BULK_CARRIER:
      //     vesselColor = '#FF4500';
      //     vesselIconPath = IconPath.TANKER;
      //     break;
      //   default:
      //     break;
      // }
      const icon = {
        // eslint-disable-next-line global-require
        url: require('../../assets/images/TankerLoaded.svg'),
        fillOpacity: 0.6,
        strokeWeight: 0,
        scale: 0.5,
        rotation: parseFloat(vesselObj[1]),
      };
      const polygon = (
        <div>
          <Marker
            key={vessel.vesselLat}
            position={{
              lat: vessel.vesselLat,
              lng: vessel.vesselLng,
            }}
            icon={icon}
            onMouseOver={() => props.handleTooltip(vessel)}
            onFocus={() => props.handleTooltip(vessel)}
            onMouseOut={() => props.handleTooltip(null)}
            onBlur={() => props.handleTooltip(null)}
          >
            {' '}
          </Marker>{' '}
        </div>
      );

      const marker = document.querySelector(`[src="${urlPath}"]`);

      if (marker) {
        // when it hasn't loaded, it's null
        marker.style.transform = `rotate(90deg)`;
      }
      return polygon;
    });
    return polygons;
  }
}

export default memo(AisVesselCreator);
