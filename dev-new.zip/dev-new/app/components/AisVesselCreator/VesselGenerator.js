import {
  SOUTH_EAST_LINE_VALUE,
  SOUTH_WEST_LINE_VALUE,
  NORTH_WEST_LINE_VALUE,
  NORTH_EAST_LINE_VALUE,
  HEADER_DIRECTION_VALUE,
} from '../../containers/Ais/constants';
export const generatevesselData = vesselData => {
  let matPow;
  let centPix;
  const paths = [];
  const angleRad = (vesselData.vesselHeading * Math.PI) / 180.0;

  if (vesselData && vesselData.vesselLng !== undefined) {
    matPow = 2 ** 12;
    centPix = {
      lat: parseInt(vesselData.vesselLat, 10) * matPow,
      lng: parseInt(vesselData.vesselLng, 10) * matPow,
    };

    let he = {
      lat: (centPix.lat + HEADER_DIRECTION_VALUE) / matPow,
      lng: centPix.lng / matPow,
    };
    let ne = {
      lat: (centPix.lat + NORTH_EAST_LINE_VALUE) / matPow,
      lng: (centPix.lng + NORTH_EAST_LINE_VALUE) / matPow,
    };
    let se = {
      lat: (centPix.lat + SOUTH_EAST_LINE_VALUE) / matPow,
      lng: (centPix.lng - SOUTH_EAST_LINE_VALUE) / matPow,
    };
    let sw = {
      lat: (centPix.lat - SOUTH_WEST_LINE_VALUE * 3) / matPow,
      lng: (centPix.lng - SOUTH_WEST_LINE_VALUE) / matPow,
    };
    let nw = {
      lat: (centPix.lat - NORTH_WEST_LINE_VALUE * 3) / matPow,
      lng: (centPix.lng + NORTH_WEST_LINE_VALUE) / matPow,
    };

    he = {
      lat:
        Math.cos(angleRad) * (he.lat - he.lat) -
        Math.sin(angleRad) * (he.lng - he.lng) +
        he.lat,
      lng:
        Math.sin(angleRad) * (he.lat - he.lat) +
        Math.cos(angleRad) * (he.lng - he.lng) +
        he.lng,
    };
    ne = {
      lat:
        Math.cos(angleRad) * (ne.lat - he.lat) -
        Math.sin(angleRad) * (ne.lng - he.lng) +
        he.lat,
      lng:
        Math.sin(angleRad) * (ne.lat - he.lat) +
        Math.cos(angleRad) * (ne.lng - he.lng) +
        he.lng,
    };
    se = {
      lat:
        Math.cos(angleRad) * (se.lat - he.lat) -
        Math.sin(angleRad) * (se.lng - he.lng) +
        he.lat,
      lng:
        Math.sin(angleRad) * (se.lat - he.lat) +
        Math.cos(angleRad) * (se.lng - he.lng) +
        he.lng,
    };
    sw = {
      lat:
        Math.cos(angleRad) * (sw.lat - he.lat) -
        Math.sin(angleRad) * (sw.lng - he.lng) +
        he.lat,
      lng:
        Math.sin(angleRad) * (sw.lat - he.lat) +
        Math.cos(angleRad) * (sw.lng - he.lng) +
        he.lng,
    };
    nw = {
      lat:
        Math.cos(angleRad) * (nw.lat - he.lat) -
        Math.sin(angleRad) * (nw.lng - he.lng) +
        he.lat,
      lng:
        Math.sin(angleRad) * (nw.lat - he.lat) +
        Math.cos(angleRad) * (nw.lng - he.lng) +
        he.lng,
    };

    paths.push(ne);
    paths.push(he);
    paths.push(se);
    paths.push(sw);
    paths.push(nw);
  }
  return paths;
};
