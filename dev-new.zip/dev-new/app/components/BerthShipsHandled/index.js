/**
 *
 * BerthShipsHandled
 *
 */

import React, { memo } from 'react';
import PropTypes from 'prop-types';
import { Row, Col } from 'reactstrap';
import CargoHandledEditable from '../CargoHandledEditable/Loadable';

function BerthShipsHandled({
  passedRef,
  metaData,
  data,
  vessels,
  vesselClassification,
  readOnly,
  dDeleteBerthDataCargoHandled,
  dUpdateBerthDataCargoHandled,
  dHandleCargoTypeChange,
}) {
  const sectionName = 'Ship';
  const newMetaData = { ...metaData };
  newMetaData.vessels = vessels || [];
  newMetaData.vesselClassification = vesselClassification || [];
  return (
    <>
      <div className="ships-handled-params group-dd">
        <Row className="add-berth-section-header mb-3 mt-3">
          <Col xs={12}>
            <h4 className="mb-0" ref={passedRef}>
              Ships Handled
            </h4>
          </Col>
        </Row>
        <CargoHandledEditable
          metaData={newMetaData}
          dHandleCargoTypeChange={dHandleCargoTypeChange}
          dUpdateBerthDataCargoHandled={dUpdateBerthDataCargoHandled}
          dDeleteBerthDataCargoHandled={dDeleteBerthDataCargoHandled}
          data={data.cargoHandled[sectionName.toLowerCase()]}
          sectionName={sectionName}
          readOnly={readOnly}
        />
      </div>
    </>
  );
}

BerthShipsHandled.propTypes = {
  passedRef: PropTypes.any,
  metaData: PropTypes.object,
  data: PropTypes.object,
  vessels: PropTypes.array,
  vesselClassification: PropTypes.array,
  readOnly: PropTypes.bool,
  dDeleteBerthDataCargoHandled: PropTypes.func,
  dUpdateBerthDataCargoHandled: PropTypes.func,
  dHandleCargoTypeChange: PropTypes.func,
};

export default memo(BerthShipsHandled);
