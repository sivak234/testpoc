/**
 *
 * AisLandingSearch
 *
 */

import React, { memo } from 'react';
import PropTypes from 'prop-types';
import { FormattedMessage } from 'react-intl';
import { Form, Row, Col, Input, Label, Button } from 'reactstrap';
import messages from './messages';
// import { FETCH_RECORD_COUNT } from '../../utils/constants';
import AutoComplete from '../AutoCompleteTextBox/Loadable';
import DropDown from '../Dropdown';

function AisLandingSearch({
  vesselName,
  portName,
  vesselTypeOptions,
  vesselSizeOptions,
  vesselConditionOptions,
  vesselStatusOptions,
  selectedSearch,
  vesselTypeSelected,
  vesselSizeSelected,
  vesselConditionSelected,
  vesselStatusSelected,
  nextPortSelected,
  vesselDetails,
  portDetails,
  fetchVesselSize,
  fetchPortName,
  fetchVesselName,
  fetchPortDetails,
  fetchPortStatisticDetails,
  fetchVesselData,
  fetchPortMoveMapData,
  fetchAisVesselVoyageDetails,
  fetchAisVesselDetails,
  fetchAisVesselData,
  fetchselectedImoData,
  fetchNearestRangeVesselsByImo,
  searchAppliedFilter,
  fetchAdditionFilterData,
  additionalFilterObj,
  fetchTerminalCodeNames,
  dCancelSearchApply,
  // fetchVesselList,
  fetchTankerMapData,
  fetchStroogMapData,
  fetchCargoCarrierMapData,
  fetchBulkContainerMapData,
}) {
  const CancelSearchApply = () => {
    dCancelSearchApply();
    // fetchVesselList({
    //   pageNo: 0,
    //   fetchRecordCount: FETCH_RECORD_COUNT,
    // });
    fetchTankerMapData({});
    fetchStroogMapData({});
    fetchCargoCarrierMapData({});
    fetchBulkContainerMapData({});
  };
  const onVesselTypeSelected = evt => {
    vesselTypeSelected(evt.target.value, evt.target.selectedOptions[0].text);
    fetchVesselSize(evt.target.value);
  };

  const onVesselSizeSelected = evt => {
    vesselSizeSelected(evt.target.value, evt.target.selectedOptions[0].text);
  };

  const onVesselConditionSelected = evt => {
    vesselConditionSelected(evt.target.value);
  };

  const onVesselStatusSelected = evt => {
    if (evt.target.value) {
      vesselStatusSelected(
        evt.target.value,
        evt.target.selectedOptions[0].text,
      );
    } else {
      vesselStatusSelected(evt.target.value, '');
    }
  };

  const onNextPortSelected = (evt, type) => {
    nextPortSelected(evt.split('^')[0], evt.split('^')[1], type);
  };

  let defaultValue = '';
  const onTextChange = (field, evt) => {
    defaultValue = evt.target.validity.valid ? evt.target.value : '';
    fetchAdditionFilterData(field, defaultValue);
  };
  return (
    <Form className="ais-landing-search-container mt-3">
      <Row className="ais-management-container-search-header mb-3">
        <Col>
          <h4 className="mb-0">
            <FormattedMessage {...messages.searchFilterTitle} />
          </h4>
        </Col>
      </Row>
      <Row>
        <Col sm={6} xs={12}>
          <AutoComplete
            label={
              <FormattedMessage
                {...messages.aisSearchPageVesselAutocompleteLabel}
              />
            }
            suggestions={vesselName}
            type="vesselimo"
            vesselDetails={vesselDetails}
            fetchVesselName={fetchVesselName}
            fetchAisVesselVoyageDetails={fetchAisVesselVoyageDetails}
            fetchAisVesselDetails={fetchAisVesselDetails}
            fetchAisVesselData={fetchAisVesselData}
            fetchselectedImoData={fetchselectedImoData}
            fetchNearestRangeVesselsByImo={fetchNearestRangeVesselsByImo}
            onNextPortSelected={onNextPortSelected}
            userInput={selectedSearch.vesselName}
          />
        </Col>
        <Col sm={6} xs={12}>
          <AutoComplete
            label={
              <FormattedMessage
                {...messages.aisSearchPagePortAutocompleteLabel}
              />
            }
            suggestions={portName}
            type="portunlo"
            portDetails={portDetails}
            fetchPortName={fetchPortName}
            fetchPortDetails={fetchPortDetails}
            fetchPortStatisticDetails={fetchPortStatisticDetails}
            fetchVesselData={fetchVesselData}
            fetchPortMoveMapData={fetchPortMoveMapData}
            fetchTerminalCodeNames={fetchTerminalCodeNames}
            onNextPortSelected={onNextPortSelected}
            userInput={selectedSearch.portName}
          />
        </Col>
      </Row>
      <Row>
        <Col xs={12} sm={3} className="mt-2">
          <DropDown
            label={
              <FormattedMessage {...messages.aisSearchPageVesselTypeLabel} />
            }
            options={vesselTypeOptions}
            onChange={evt => onVesselTypeSelected(evt)}
            selected={selectedSearch.vesselTypeId}
          />
        </Col>
        <Col xs={12} sm={3} className="mt-2">
          <DropDown
            label={
              <FormattedMessage {...messages.aisSearchPageVesselSizeLabel} />
            }
            options={vesselSizeOptions}
            onChange={evt => onVesselSizeSelected(evt)}
            selected={selectedSearch.VesselSizeCategoryId}
          />
        </Col>
        <Col xs={12} sm={3} className="mt-2">
          <DropDown
            label={
              <FormattedMessage
                {...messages.aisSearchPageVesselConditionLabel}
              />
            }
            options={
              vesselConditionOptions.length > 0 &&
              vesselConditionOptions.map(vesselCondObj => (
                <option value={vesselCondObj} key={vesselCondObj}>
                  {vesselCondObj}
                </option>
              ))
            }
            onChange={evt => onVesselConditionSelected(evt)}
            selected={selectedSearch.vesselConditionName}
          />
        </Col>
        <Col xs={12} sm={3} className="mt-2">
          <DropDown
            label={
              <FormattedMessage {...messages.aisSearchPageVesselStatusLabel} />
            }
            options={
              vesselStatusOptions.length > 0 &&
              vesselStatusOptions.map(vesselStatusObj => (
                <option
                  value={vesselStatusObj.navigationalStatusId}
                  key={vesselStatusObj.navigationalStatusId}
                >
                  {vesselStatusObj.navigationalStatusDesc}
                </option>
              ))
            }
            onChange={evt => onVesselStatusSelected(evt)}
            selected={selectedSearch.vesselStatusId}
          />
        </Col>
      </Row>
      <Row>
        <Col xs={12} sm={3} className="mt-2">
          <AutoComplete
            label={
              <FormattedMessage {...messages.aisSearchPageNextPortLabel} />
            }
            suggestions={portName}
            type="nextPort"
            portDetails={portDetails}
            fetchPortName={fetchPortName}
            onNextPortSelected={onNextPortSelected}
            userInput={selectedSearch.nextPortName}
          />
        </Col>
        <Col xs={12} sm={3} className="mt-2">
          <Row>
            <Col xs={12}>
              <Label className="mb-1">
                <FormattedMessage
                  {...messages.aisAdditionalFilterDeadWeightLabel}
                />
              </Label>
            </Col>

            <Col xs={12}>
              <Input
                type="text"
                onChange={event => {
                  const { value } = event.target;
                  const regx = /^[0-9]+\.?[0-9]*$/;
                  if (regx.test(value) || value === '') {
                    onTextChange('deadWeightFrom', event);
                  }
                }}
                value={additionalFilterObj.deadWeightFrom}
                min={0}
                max={9999.99}
                maxLength={7}
              />
            </Col>
          </Row>
        </Col>
        <Col xs={12} sm={3} className="mt-2">
          <Row>
            <Col xs={12}>
              <Label className="mb-1">
                <FormattedMessage {...messages.aisAdditionalFilterTo} />
              </Label>
            </Col>
            <Col xs={12}>
              <Input
                type="text"
                onChange={event => {
                  const { value } = event.target;
                  const regx = /^[0-9]+\.?[0-9]*$/;
                  if (regx.test(value) || value === '') {
                    onTextChange('deadWeightTo', event);
                  }
                }}
                value={additionalFilterObj.deadWeightTo}
                min={0}
                max={9999.99}
                maxLength={7}
              />
            </Col>
          </Row>
        </Col>
        <Col xs={12} sm={3} id="applyButton" className="mt-1 text-center">
          <Button
            color="primary"
            className="mt-4 mx-3"
            onClick={() => searchAppliedFilter()}
          >
            <FormattedMessage {...messages.aisAdditionalFilterApplyBtn} />
          </Button>
          <Button
            outline
            color="primary"
            className="mt-4"
            onClick={() => CancelSearchApply()}
          >
            <FormattedMessage {...messages.aisCancelBtn} />
          </Button>
        </Col>
      </Row>
    </Form>
  );
}

AisLandingSearch.propTypes = {
  vesselTypeOptions: PropTypes.array.isRequired,
  vesselSizeOptions: PropTypes.array.isRequired,
  vesselConditionOptions: PropTypes.array.isRequired,
  vesselStatusOptions: PropTypes.array.isRequired,
  selectedSearch: PropTypes.object.isRequired,
  vesselTypeSelected: PropTypes.func.isRequired,
  vesselSizeSelected: PropTypes.func.isRequired,
  vesselConditionSelected: PropTypes.func.isRequired,
  vesselStatusSelected: PropTypes.func.isRequired,
  nextPortSelected: PropTypes.func.isRequired,
  vesselName: PropTypes.array,
  portName: PropTypes.array.isRequired,
  vesselDetails: PropTypes.func.isRequired,
  portDetails: PropTypes.func.isRequired,
  fetchVesselSize: PropTypes.func.isRequired,
  fetchPortName: PropTypes.func,
  fetchVesselName: PropTypes.func,
  fetchPortDetails: PropTypes.func.isRequired,
  fetchPortStatisticDetails: PropTypes.func.isRequired,
  fetchVesselData: PropTypes.func.isRequired,
  fetchPortMoveMapData: PropTypes.func.isRequired,
  fetchAisVesselVoyageDetails: PropTypes.func.isRequired,
  fetchAisVesselDetails: PropTypes.func.isRequired,
  fetchAisVesselData: PropTypes.func.isRequired,
  fetchselectedImoData: PropTypes.func.isRequired,
  fetchNearestRangeVesselsByImo: PropTypes.func.isRequired,
  searchAppliedFilter: PropTypes.func.isRequired,
  fetchAdditionFilterData: PropTypes.func.isRequired,
  additionalFilterObj: PropTypes.object.isRequired,
  fetchTerminalCodeNames: PropTypes.func.isRequired,
  dCancelSearchApply: PropTypes.func.isRequired,
  fetchVesselList: PropTypes.func.isRequired,
  fetchTankerMapData: PropTypes.func.isRequired,
  fetchStroogMapData: PropTypes.func.isRequired,
  fetchCargoCarrierMapData: PropTypes.func.isRequired,
  fetchBulkContainerMapData: PropTypes.func.isRequired,
};

export default memo(AisLandingSearch);
