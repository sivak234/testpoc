/**
 *
 * Asynchronously loads the component for AisLandingSearch
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
