/*
 * AisLandingSearch Messages
 *
 * This contains all the text for the AisLandingSearch component.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.components.AisLandingSearch';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'This is the AisLandingSearch component!',
  },
  searchPageTitle: {
    id: `${scope}.searchPageTitle`,
    defaultMessage: 'Quick Search',
  },
  aisSearchPageVesselAutocompleteLabel: {
    id: `${scope}.aisSearchPageVesselAutocompleteLabel`,
    defaultMessage: 'Vessel Name or IMO',
  },
  aisSearchPagePortAutocompleteLabel: {
    id: `${scope}.aisSearchPagePortAutocompleteLabel`,
    defaultMessage: 'Port Name or UNLOCODE',
  },
  aisSearchPageVesselTypeLabel: {
    id: `${scope}.aisSearchPageVesselTypeLabel`,
    defaultMessage: 'Vessel Type',
  },
  aisSearchPageVesselSizeLabel: {
    id: `${scope}.aisSearchPageVesselSizeLabel`,
    defaultMessage: 'Vessel Size',
  },
  aisSearchPageVesselConditionLabel: {
    id: `${scope}.aisSearchPageVesselConditionLabel`,
    defaultMessage: 'Vessel Condition',
  },
  aisSearchPageVesselStatusLabel: {
    id: `${scope}.aisSearchPageVesselStatusLabel`,
    defaultMessage: 'Vessel Status',
  },
  aisSearchPageNextPortLabel: {
    id: `${scope}.aisSearchPageNextPortLabel`,
    defaultMessage: 'Next Port',
  },
  aisAdditionalFilterDeadWeightLabel: {
    id: `${scope}.aisAdditionalFilterDeadWeightLabel`,
    defaultMessage: 'Deadweight From',
  },
  aisAdditionalFilterTo: {
    id: `${scope}.aisAdditionalFilterTo`,
    defaultMessage: 'Deadweight To',
  },
  aisAdditionalFilterApplyBtn: {
    id: `${scope}.aisAdditionalFilterApplyBtn`,
    defaultMessage: 'Apply',
  },
  searchFilterTitle: {
    id: `${scope}.searchFilterTitle`,
    defaultMessage: 'Search Filters',
  },
  aisCancelBtn: {
    id: `${scope}.aisCancelBtn`,
    defaultMessage: 'Clear',
  },
});
