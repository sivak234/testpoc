import React from 'react';
export const getVesselType = vesselType => {
  const searchOptions = vesselType.map(vesselObj => (
    <option key={vesselObj} value={vesselObj}>
      {vesselObj}
    </option>
  ));
  return searchOptions;
};
