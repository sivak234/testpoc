/*
 * AdvanceSearchPage Messages
 *
 * This contains all the text for the AdvanceSearchPage component.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.components.AdvanceSearchPage';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'Search Total Results',
  },
  portName: {
    id: `${scope}.portName`,
    defaultMessage: 'Port Name',
  },
  countryName: {
    id: `${scope}.countryName`,
    defaultMessage: 'Country Name',
  },
  regionName: {
    id: `${scope}.regionName`,
    defaultMessage: 'Region Name',
  },
  terminalCount: {
    id: `${scope}.terminalCount`,
    defaultMessage: 'No of Terminal(s)',
  },
  berthCount: {
    id: `${scope}.berthCount`,
    defaultMessage: 'No. of Berth(s)',
  },
  serviceTerminalCount: {
    id: `${scope}.serviceTerminalCount`,
    defaultMessage: 'No.of Service Terminal(s)',
  },

  totalCount: {
    id: `${scope}.totalCount`,
    defaultMessage: 'Total Records',
  },
  laodSearch: {
    id: `${scope}.laodSearch`,
    defaultMessage: 'Load Search',
  },
  saveSearch: {
    id: `${scope}.saveSearch`,
    defaultMessage: 'Save Search',
  },
  newSearch: {
    id: `${scope}.newSearch`,
    defaultMessage: 'New Search',
  },
  overWriteConfirmation: {
    id: `${scope}.overWriteConfirmation`,
    defaultMessage: 'Search Name already exist, Sure you want to overwrite?',
  },
  btnYes: {
    id: `${scope}.btnYes`,
    defaultMessage: 'Yes',
  },
  btnNo: {
    id: `${scope}.btnNo`,
    defaultMessage: 'No',
  },
  title: {
    id: `${scope}.title`,
    defaultMessage: 'Title',
  },
});
