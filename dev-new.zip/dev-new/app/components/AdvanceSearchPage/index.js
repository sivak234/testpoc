/**
 *
 * AdvanceSearchPage
 *
 */

import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import { Button, Row, Col } from 'reactstrap';
import { FormattedMessage } from 'react-intl';
import messages from './messages';

import {
  portListHeader,
  getSelectedFilters,
  getPostFilters,
  validateAndSaveForm,
  LoadMySearchList,
} from './_helper';

import { clearSearchSelection } from '../AdvanceSearchFilter/_helper';
import DataTableList from '../DataTableList/Loadable';

// import ServerSideDataTable from '../ServerSideDataTable/Loadable';
import SaveAdvanceSearch from '../SaveAdvanceSearch/Loadable';
import Popup from '../Popup/Loadable';
import './index.scss';
function AdvanceSearchPage({
  data,
  currentPage,
  onPageChanged,
  dSaveSearch,
  isSaveSearchPopup,
  onToggleSavePopup,
  saveSearchFormData,
  dSetSaveSearchForm,
  searchFilter,
  dGetPortList,
  isSaveSucceedPopupOpen,
  dOnSaveSucceedPopupClose,
  dEnableSaveSearch,
  isSaveSearchDisabled,
  dGetMySearchList,
  mySearchList,
  dToggleMySearchListView,
  viewMySearch,
  dGetMySelectedSearch,
  dClearFilter,
  dValidateSearchName,
  checkIsExist,
  dToggleConfirmPopup,
  saveErrorPopup,
  dOnSaveErrorPopupClose,
  match,
}) {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [data.ports]);

  const header = portListHeader();
  const pageSize = 10;

  if (getSelectedFilters(searchFilter) === '{}') {
    dEnableSaveSearch(true);
  } else {
    dEnableSaveSearch(false);
  }
  const onPopupSaveClick = () =>
    validateAndSaveForm(
      saveSearchFormData,
      searchFilter,
      dValidateSearchName,
      dSetSaveSearchForm,
    );

  const onConfirmSave = () =>
    validateAndSaveForm(
      saveSearchFormData,
      searchFilter,
      dSaveSearch,
      dSetSaveSearchForm,
    );

  const onSavePopupClose = () => {
    onToggleSavePopup(false);
  };

  useEffect(() => {
    if (match.params.searchId === undefined) {
      clearSearchSelection(searchFilter, dClearFilter, dGetPortList);
    }
  }, []);

  const onPageChangedPost = page => {
    onPageChanged(page);
    dGetPortList({
      page: page.pageNo,
      pageSize,
      filters: getPostFilters(searchFilter),
    });
  };

  const handleMySelectedSearch = searchId => {
    dGetMySelectedSearch({
      searchId,
      filters: searchFilter,
      page: currentPage,
      pageSize,
    });
  };

  const popupButtons = [
    {
      id: 'saveSearch',
      action: onPopupSaveClick,
      title: 'Save Search',
    },
    {
      id: 'btncancelid',
      action: onSavePopupClose,
      title: 'Cancel',
    },
  ];

  return (
    <>
      <h4>
        <FormattedMessage {...messages.header} /> : {data.totalCount}
      </h4>
      {data.ports && (
        <DataTableList
          moduleId={0}
          primaryProp="berthId"
          tableHeader={header}
          tableBody={data.ports}
          rowsPerPage={10}
          fetchTableData={onPageChangedPost}
          totalRecords={data.totalCount}
          isCustom
        />
      )}
      <div className="clearfix">
        <Button
          onClick={() => onToggleSavePopup(true)}
          className="pull-right search-button"
          color="primary"
          type="button"
          size="md"
          disabled={isSaveSearchDisabled}
        >
          <FormattedMessage {...messages.saveSearch} />
        </Button>
        <Button
          onClick={() => {
            dGetMySearchList();
            dToggleMySearchListView(true);
          }}
          className="pull-right mr-2 search-button"
          color="primary"
          type="button"
          size="md"
        >
          <FormattedMessage {...messages.laodSearch} />
        </Button>
        <Button
          onClick={() =>
            clearSearchSelection(searchFilter, dClearFilter, dGetPortList)
          }
          className="pull-right mr-2 search-button"
          color="primary"
          type="button"
          size="md"
        >
          <FormattedMessage {...messages.newSearch} />
        </Button>
        <div className="d-flex">
          <SaveAdvanceSearch
            formData={saveSearchFormData}
            dSetSaveSearchForm={dSetSaveSearchForm}
            isSaveSucceedPopupOpen={isSaveSucceedPopupOpen}
            dOnSaveSucceedPopupClose={dOnSaveSucceedPopupClose}
            // checkIsExist={checkIsExist}
            // checkIsExistYs={checkIsExist}
            show={isSaveSearchPopup}
            buttons={popupButtons}
            handleClose={onSavePopupClose}
            saveErrorPopup={saveErrorPopup}
            dOnSaveErrorPopupClose={dOnSaveErrorPopupClose}
          />
        </div>
        {checkIsExist && (
          <Popup
            size="md"
            backdrop
            showFooter={false}
            show={checkIsExist}
            close={() => dToggleConfirmPopup(false)}
            title={messages.laodSearch.defaultMessage}
          >
            <Row>
              <Col xs={1} md={1}>
                <i
                  className="fa fa-3x text-warning fa-exclamation-circle mr-2"
                  aria-hidden="true"
                />
              </Col>
              <Col className="mt-2  text-left">
                <FormattedMessage {...messages.overWriteConfirmation} />
              </Col>
            </Row>
            <Row>
              <Col>
                <Button
                  onClick={() => onConfirmSave()}
                  className="mr-2"
                  color="primary"
                  type="button"
                  size="md"
                >
                  <FormattedMessage {...messages.btnYes} />
                </Button>
                <Button
                  onClick={() => dToggleConfirmPopup(false)}
                  className="mr-2"
                  color="primary"
                  outline
                  type="button"
                  size="md"
                >
                  <FormattedMessage {...messages.btnNo} />
                </Button>
              </Col>
            </Row>
          </Popup>
        )}
        {/* mySearchList dToggleMySearchListView viewMySearch */}
        <Popup
          size="sm"
          backdrop
          showFooter={false}
          show={viewMySearch}
          close={() => dToggleMySearchListView(false)}
          title={messages.laodSearch.defaultMessage}
        >
          <div className="custom-popup">
            <LoadMySearchList
              data={mySearchList}
              dGetMySelectedSearch={handleMySelectedSearch}
            />
          </div>
        </Popup>
      </div>
    </>
  );
}
AdvanceSearchPage.propTypes = {
  data: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  currentPage: PropTypes.number,
  onPageChanged: PropTypes.func,
  dSaveSearch: PropTypes.func,
  isSaveSearchPopup: PropTypes.bool,
  onToggleSavePopup: PropTypes.func,
  saveSearchFormData: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  dSetSaveSearchForm: PropTypes.func,
  dGetPortList: PropTypes.func,
  searchFilter: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  isSaveSucceedPopupOpen: PropTypes.bool,
  dOnSaveSucceedPopupClose: PropTypes.func,
  isSaveSearchDisabled: PropTypes.bool,
  dEnableSaveSearch: PropTypes.func,
  dGetMySearchList: PropTypes.func,
  mySearchList: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  dToggleMySearchListView: PropTypes.func,
  viewMySearch: PropTypes.bool,
  dGetMySelectedSearch: PropTypes.func,
  dClearFilter: PropTypes.func,
  dValidateSearchName: PropTypes.func,
  checkIsExist: PropTypes.bool,
  dToggleConfirmPopup: PropTypes.func,
  saveErrorPopup: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  dOnSaveErrorPopupClose: PropTypes.func,
  match: PropTypes.object,
};

export default AdvanceSearchPage;
