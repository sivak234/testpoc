/*
 *
 * AdvanceSearchPage helper
 *
 */
import React from 'react';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';
import { ListGroup, ListGroupItem, Button } from 'reactstrap';
import { FormattedMessage } from 'react-intl';
import messages from './messages';
import nextIcon from '../../assets/icons/next-arrow.svg';
export function portListHeader() {
  const header = [
    {
      prop: 'portName',
      title: messages.portName.defaultMessage,
      cell: row => (
        <Link to={`/my-dashboard/ptb-detail/${row.portId}/${'advancesearch'}`}>
          {row.portName}
        </Link>
      ),
    },
    { prop: 'countryName', title: messages.countryName.defaultMessage },
    { prop: 'regionName', title: messages.regionName.defaultMessage },
    {
      prop: 'terminalCount',
      title: messages.terminalCount.defaultMessage,
    },
    { prop: 'berthCount', title: messages.berthCount.defaultMessage },
    {
      prop: 'serviceTerminalCount',
      title: messages.serviceTerminalCount.defaultMessage,
    },
  ];
  return header;
}

export const LoadMySearchList = ({ data, dGetMySelectedSearch }) => {
  const items = [];
  Object.keys(data).forEach(key => {
    items.push(
      <ListGroupItem>
        {data[key].searchName}
        <Button
          color="link"
          className="float-right link p-0"
          onClick={() => {
            dGetMySelectedSearch(data[key].searchId);
          }}
        >
          <img src={nextIcon} alt=">" />
        </Button>
      </ListGroupItem>,
    );
  });
  return (
    <div className="my-search-list text-left">
      <ListGroup>
        <ListGroupItem className="header">
          <FormattedMessage {...messages.title} />
        </ListGroupItem>
        <span className="scroller">{items}</span>
      </ListGroup>
      <p />
    </div>
  );
};
LoadMySearchList.propTypes = {
  data: PropTypes.oneOfType([PropTypes.array, PropTypes.object]).isRequired,
  dGetMySelectedSearch: PropTypes.func,
};

export function getSelectedFilters(filters) {
  const slectedFilters = {};
  Object.keys(filters).forEach(parent => {
    filters[parent].forEach(child => {
      if (child.isChecked && child.isChecked === true) {
        if (!slectedFilters[parent]) {
          slectedFilters[parent] = [];
        }
        slectedFilters[parent].push(child.entityId);
      }
    });
  });
  return JSON.stringify(slectedFilters);
}

export function getPostFilters(filters) {
  if (Object.keys(filters).length === 0) return getFilterMode();

  const slectedFilters = [];
  Object.keys(filters).forEach(parent => {
    filters[parent].forEach(child => {
      if (!slectedFilters[parent]) {
        slectedFilters[parent] = [];
      }
      if (
        child.isChecked &&
        child.isChecked === true &&
        child.entityId !== -1
      ) {
        slectedFilters[parent].push(child.entityId);
      }
    });
  });
  return slectedFilters;
}

export function getFilterMode() {
  return {
    regions: [],
    countries: [],
    cargoType: [],
    mainCargoType: [],
    productType: [],
    shipType: [],
    berthStyle: [],
    shipSize: [],
    vesselsTurnAroundTime: [],
  };
}

export function validateForm(saveSearchFormData) {
  const invalidForm = { ...saveSearchFormData };
  Object.keys(invalidForm).forEach(key => {
    if ({}.hasOwnProperty.call(invalidForm[key], 'regularExp')) {
      invalidForm[key].isInvalid = !invalidForm[key].regularExp.test(
        invalidForm[key].value,
      );
    }
  });

  return invalidForm;
}

export function validateAndSaveForm(
  saveSearchFormData,
  searchFilter,
  dSaveSearch,
  dSetSaveSearchForm,
) {
  if (saveSearchFormData.name.isInvalid === false) {
    const postData = {
      searchResult: getSelectedFilters(searchFilter),
      search: {
        searchName: saveSearchFormData.name.value,
        description: saveSearchFormData.description.value,
      },
    };
    dSaveSearch(postData);
  } else {
    const invalidForm = validateForm(saveSearchFormData);
    dSetSaveSearchForm(invalidForm);
  }
}
export function defaultFunction(text) {
  return text;
}
