/**
 *
 * Asynchronously loads the component for AdvanceSearchPage
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
