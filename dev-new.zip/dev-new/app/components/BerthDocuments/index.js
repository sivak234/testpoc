/**
 *
 * BerthDocuments
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { Row, Col } from 'reactstrap';
import PtbDocuments from '../PtbDocuments/Loadable';

function BerthDocuments({
  passedref,
  numberOfCopies,
  berthdocumenttype,
  formType,
  berthptbDocument,
  uploadStatus,
  dberthDocumentsData,
  dHandleFileUpload,
  dHandleFileDownload,
  dvalidatedocumnet,
  dsetDocumentName,
  dsetDocumentType,
  dvalidatedfileuploaddocument,
  viewupdateptbDocument,
  portMasterDocumentType,
  berthselecteddocument,
  dselectedDocumentInformation,
  confirmBerthDocumentDeleteModalOpen,
  dopenberthdocumentpopupconfirmation,
  dcloseberthdocumentpopupconfirmation,
  dberthDeleteSelectDocumentInformation,
  isLoading,
}) {
  return (
    <>
      <Row className="add-berth-section-header mb-3 mt-3">
        <Col xs={12}>
          <h4 className="mb-0" ref={passedref}>
            Berth Documents
          </h4>
        </Col>
      </Row>
      <Row>
        <Col xs={12} md>
          <PtbDocuments
            numberOfCopies={numberOfCopies}
            documentType={berthdocumenttype}
            formType={formType}
            portptbDocument={berthptbDocument}
            title="Berth"
            uploadStatus={uploadStatus}
            dportDocumentsData={dberthDocumentsData}
            dHandleFileUpload={dHandleFileUpload}
            dHandleFileDownload={dHandleFileDownload}
            dvalidatedocumnet={dvalidatedocumnet}
            dsetDocumentName={dsetDocumentName}
            dsetDocumentType={dsetDocumentType}
            dvalidatedfileuploaddocument={dvalidatedfileuploaddocument}
            viewupdateptbDocument={viewupdateptbDocument}
            portMasterDocumentType={portMasterDocumentType}
            portselecteddocument={berthselecteddocument}
            dselectedDocumentInformation={dselectedDocumentInformation}
            confirmPortDocumentDeleteModalOpen={
              confirmBerthDocumentDeleteModalOpen
            }
            dopenPortDeleteDocumentConfirmation={
              dopenberthdocumentpopupconfirmation
            }
            dclosePortDeleteDocumentConfirmation={
              dcloseberthdocumentpopupconfirmation
            }
            dportDeleteSelectDocumentInformation={
              dberthDeleteSelectDocumentInformation
            }
            isLoading={isLoading}
          />
        </Col>
      </Row>
    </>
  );
}

BerthDocuments.propTypes = {
  passedref: PropTypes.any,
  numberOfCopies: PropTypes.array,
  berthdocumenttype: PropTypes.array,
  formType: PropTypes.string,
  berthptbDocument: PropTypes.array,
  uploadStatus: PropTypes.string,
  dberthDocumentsData: PropTypes.func,
  dHandleFileUpload: PropTypes.func,
  dHandleFileDownload: PropTypes.func,
  dvalidatedocumnet: PropTypes.func,
  dsetDocumentName: PropTypes.func,
  dsetDocumentType: PropTypes.func,
  dvalidatedfileuploaddocument: PropTypes.func,
  viewupdateptbDocument: PropTypes.array,
  portMasterDocumentType: PropTypes.array,
  berthselecteddocument: PropTypes.array,
  dselectedDocumentInformation: PropTypes.func,
  confirmBerthDocumentDeleteModalOpen: PropTypes.bool,
  dopenberthdocumentpopupconfirmation: PropTypes.func,
  dcloseberthdocumentpopupconfirmation: PropTypes.func,
  dberthDeleteSelectDocumentInformation: PropTypes.func,
  isLoading: PropTypes.bool,
};

export default BerthDocuments;
