/**
 *
 * Asynchronously loads the component for BerthDocuments
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
