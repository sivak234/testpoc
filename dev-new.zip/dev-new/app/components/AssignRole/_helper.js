/*
 *
 * AssignRole helper
 *
 */

export function defaultFunction(text) {
  return text;
}
