/*
 * AssignRole Messages
 *
 * This contains all the text for the AssignRole component.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.components.AssignRole';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'This is the AssignRole component!',
  },
  regionName: {
    id: `${scope}.regionName`,
    defaultMessage: 'Region',
  },
  countryName: {
    id: `${scope}.countryName`,
    defaultMessage: 'Country',
  },
  portsName: {
    id: `${scope}.portsName`,
    defaultMessage: 'Ports',
  },
  fromDate: {
    id: `${scope}.fromDate`,
    defaultMessage: 'From Date',
  },
  toDate: {
    id: `${scope}.toDate`,
    defaultMessage: 'To Date',
  },
  role: {
    id: `${scope}.role`,
    defaultMessage: 'Role',
  },
});
