/**
 *
 * Asynchronously loads the component for AssignRole
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
