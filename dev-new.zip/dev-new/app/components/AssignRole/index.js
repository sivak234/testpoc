/**
 *
 * AssignRole
 *
 */

import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { compose } from 'redux';
import moment from 'moment';
import { createStructuredSelector } from 'reselect';
import DatePicker from 'react-datepicker';
import { Form, Label, Row, Col, FormGroup, Button } from 'reactstrap';
import { FormattedMessage } from 'react-intl';
import MultiSelect from '../MultiSelect';
import Dropdown from '../Dropdown';
import {
  makeSelectSelected,
  makeSelectCountries,
  makeSelectPorts,
  makeSelectRegions,
} from '../../containers/UserRoleManagement/selectors';
import { getDayMonthYearDateFormat } from '../../utils/dataModification';
import './_helper';
import './index.scss';
import messages from './messages';

function AssignRole({
  roleSelect1,
  regionCheckBoxTriggered,
  countryCheckBoxTriggered,
  portCheckBoxTriggered,
  fromdateFormat,
  minDate,
  fetchFromDate1,
  todateFormat,
  fetchToDate1,
  componentAdd,
  assignComponent,
  multiselectId,
  componentRemove,
  selected,
  count,
  roleNames,
  type,
  isValid,
}) {
  const [isDategreater, handleDateValidate] = useState(null);
  const componentAddClick = selectindex => {
    componentAdd(assignComponent, selectindex);
  };

  const componentRemoveClick = selectindex => {
    componentRemove(selectindex);
  };

  const validatetoDate = selectdate => {
    const fromDate = selected.assignedRole[count].fDate;
    const fdatevalidate = dateDifferent(new Date(), fromDate);
    const selectedtoDate = getDayMonthYearDateFormat(selectdate);
    if (fdatevalidate === 0) {
      const roleValDate = getDayMonthYearDateFormat(
        selected.assignedRole[count].roleDefaultdate,
      );
      if (roleValDate === selectedtoDate) {
        handleDateValidate(null);
      }
      if (selectedtoDate < roleValDate) {
        handleDateValidate(false);
      }
      if (selectedtoDate > roleValDate) {
        handleDateValidate(true);
      }
    }
    if (fdatevalidate !== 0) {
      const roleValDt = new Date(selected.assignedRole[count].roleDefaultdate);
      roleValDt.setDate(roleValDt.getDate() + fdatevalidate);
      const fdatediff = dateDifferent(fromDate, selectdate);
      const fdatediff1 = dateDifferent(fromDate, roleValDt);
      if (fdatediff1 === fdatediff) {
        handleDateValidate(null);
      }
      if (fdatediff1 > fdatediff) {
        handleDateValidate(false);
      }
      if (fdatediff1 < fdatediff) {
        handleDateValidate(true);
      }
    }
  };

  const validatefromDate = selectdate => {
    const datediff = dateDifferent(new Date(), selectdate);
    if (
      datediff > 0 &&
      selected.assignedRole[count].tDate !== '' &&
      selected.assignedRole[count].roleDefaultdate !== ''
    ) {
      const toDate = new Date(selected.assignedRole[count].roleDefaultdate);
      toDate.setDate(toDate.getDate() + datediff);
      fetchToDate1(toDate, count);
      handleDateValidate(null);
    }
    const roleValDate = selected.assignedRole[count].roleDefaultdate;
    if (datediff === 0) {
      handleDateValidate(null);
      fetchToDate1(roleValDate !== '' ? roleValDate : new Date(), count);
    }
  };
  const dateDifferent = (date1, date2) => {
    const dt1 = date1;
    const dt2 = date2;
    return Math.floor(
      (new Date(dt2.getFullYear(), dt2.getMonth(), dt2.getDate()) -
        new Date(dt1.getFullYear(), dt1.getMonth(), dt1.getDate())) /
        (1000 * 60 * 60 * 24),
    );
  };
  const handleRoleChange = event => {
    roleSelect1({ evt: event, count });
    handleDateValidate(null);
  };
  const assignRole = selected.assignedRole.filter(x => x.isDelete === false);
  let roleIndex = 0;
  selected.assignedRole.forEach((item, index) => {
    if (item.isDelete === false) {
      roleIndex = index;
    }
  });
  const roleList = roleNames.filter(x => x.props.defaultPeriod !== '000000');
  let isValidDate = false;
  if (
    selected.assignedRole[count].fDate &&
    selected.assignedRole[count].tDate &&
    moment(selected.assignedRole[count].fDate).format('DD/MM/YYYY') >
      moment(selected.assignedRole[count].tDate).format('DD/MM/YYYY')
  ) {
    isValidDate = true;
  }
  return (
    <>
      <Form>
        <div>
          {type !== 'View' && (
            <Row>
              <Col xs={2} md>
                <FormGroup>
                  <Label>
                    <FormattedMessage {...messages.role} />
                  </Label>
                  {type !== 'View' && (
                    <Dropdown
                      options={roleList}
                      onChange={event => handleRoleChange(event)}
                      selected={selected.assignedRole[count].roleId}
                      count={count}
                    />
                  )}
                </FormGroup>
              </Col>
              <Col xs={2} md>
                <FormGroup>
                  <Label>
                    <FormattedMessage {...messages.regionName} />
                  </Label>
                  {type !== 'View' && (
                    <MultiSelect
                      options={selected.regionsOptions}
                      handleIds={regionCheckBoxTriggered}
                      selectedCheckIds={selected.assignedRole[count].regionIds}
                      selectedCheckValues={
                        selected.assignedRole[count].regionNames
                      }
                      selectedIndex={count}
                      multiSelectId={`popover-multiselect_${multiselectId}_${count}_0`}
                      selectAllText="All Regions Selected"
                    />
                  )}
                </FormGroup>
              </Col>
              <Col xs={2} md>
                <FormGroup>
                  <Label>
                    <FormattedMessage {...messages.countryName} />
                  </Label>
                  {type !== 'View' && (
                    <MultiSelect
                      options={selected.assignedRole[count].countryOptions}
                      handleIds={countryCheckBoxTriggered}
                      selectedCheckIds={selected.assignedRole[count].countryIds}
                      selectedCheckValues={
                        selected.assignedRole[count].countryNames
                      }
                      selectedIndex={count}
                      multiSelectId={`popover-multiselect_${multiselectId}_${count}_1`}
                      selectAllText="All Countries Selected"
                    />
                  )}
                </FormGroup>
              </Col>
              <Col xs={2} md>
                <FormGroup>
                  <Label>
                    <FormattedMessage {...messages.portsName} />
                  </Label>
                  {type !== 'View' && (
                    <MultiSelect
                      options={selected.assignedRole[count].portOptions}
                      handleIds={portCheckBoxTriggered}
                      selectedCheckIds={selected.assignedRole[count].portIds}
                      selectedCheckValues={
                        selected.assignedRole[count].portNames
                      }
                      selectedIndex={count}
                      multiSelectId={`popover-multiselect_${multiselectId}_${count}_2`}
                      selectAllText="All Ports Selected"
                      type="Port"
                    />
                  )}
                </FormGroup>
                {selected.assignedRole[count].portIds.length > 49 && (
                  <div>Maximum 50 Ports are allowed</div>
                )}
              </Col>
              <Col xs={2} md />
            </Row>
          )}
          {type !== 'View' && (
            <Row>
              <Col xs={2} md>
                <FormGroup controlid="fromdateControl">
                  <Label>
                    <FormattedMessage {...messages.fromDate} />
                  </Label>
                  {type !== 'View' && (
                    <DatePicker
                      selected={selected.assignedRole[count].fDate}
                      value={fromdateFormat}
                      minDate={minDate}
                      onChange={e => {
                        fetchFromDate1(e, count);
                        validatefromDate(e);
                      }}
                    />
                  )}
                </FormGroup>
              </Col>
              <Col xs={2} md>
                <FormGroup controlid="todateControl">
                  <Label>
                    <FormattedMessage {...messages.toDate} />
                  </Label>
                  {type !== 'View' && (
                    <DatePicker
                      selected={selected.assignedRole[count].tDate}
                      value={todateFormat}
                      onChange={e => {
                        fetchToDate1(e, count);
                        validatetoDate(e);
                      }}
                    />
                  )}
                </FormGroup>
              </Col>
              <Col xs={4} md>
                {selected.assignedRole[count].roleId !== '' && (
                  <div>
                    {!isValidDate && isDategreater !== null && isDategreater && (
                      <div style={{ paddingTop: '22px' }}>
                        <p>
                          Seletced period is greater than the default Role
                          period
                        </p>
                      </div>
                    )}
                    {!isValidDate && isDategreater !== null && !isDategreater && (
                      <div style={{ paddingTop: '22px' }}>
                        <p>
                          Seletced period is lesser than the default Role period
                        </p>
                      </div>
                    )}
                    {isValid && isValidDate && (
                      <div style={{ paddingTop: '22px' }}>
                        <p>To Date should greater than From Date</p>
                      </div>
                    )}
                  </div>
                )}
              </Col>
              <Col xs={2} md />
              <Col xs={2} md>
                <Button
                  type="button"
                  name="deleteBtn"
                  className="buttonTop assign-role-buttons"
                  outline
                  color="primary"
                  size="sm"
                  onClick={() => componentRemoveClick(count)}
                >
                  <i className="fa fa-minus" />
                </Button>
                {type === 'Add' && assignRole.length === count + 1 && (
                  <Button
                    type="button"
                    name="addBtn"
                    className="buttonTop buttonLeft assign-role-buttons"
                    outline
                    color="primary"
                    size="sm"
                    onClick={() => componentAddClick(count)}
                  >
                    <i className="fa fa-plus" aria-hidden="true" />
                  </Button>
                )}
                {type === 'Update' &&
                  assignRole.length > 0 &&
                  (roleIndex === count && (
                    <Button
                      type="button"
                      name="addBtn"
                      className="buttonTop buttonLeft assign-role-buttons"
                      outline
                      color="primary"
                      size="sm"
                      onClick={() => componentAddClick(count)}
                    >
                      <i className="fa fa-plus" aria-hidden="true" />
                    </Button>
                  ))}
              </Col>
            </Row>
          )}
        </div>
      </Form>
    </>
  );
}

AssignRole.propTypes = {
  roleSelect1: PropTypes.func.isRequired,
  regionCheckBoxTriggered: PropTypes.func.isRequired,
  countryCheckBoxTriggered: PropTypes.func.isRequired,
  portCheckBoxTriggered: PropTypes.func.isRequired,
  fromdateFormat: PropTypes.string,
  minDate: PropTypes.oneOfType([PropTypes.string, PropTypes.instanceOf(Date)]),
  fetchFromDate1: PropTypes.func,
  todateFormat: PropTypes.string,
  fetchToDate1: PropTypes.func.isRequired,
  componentAdd: PropTypes.func,
  componentRemove: PropTypes.func,
  assignComponent: PropTypes.array.isRequired,
  multiselectId: PropTypes.number,
  selected: PropTypes.array,
  count: PropTypes.number,
  type: PropTypes.string,
  roleNames: PropTypes.array,
  isValid: PropTypes.any,
};
const mapStateToProps = createStructuredSelector({
  selected: makeSelectSelected(),
  countries: makeSelectCountries(),
  ports: makeSelectPorts(),
  regions: makeSelectRegions(),
});

const withConnect = connect(mapStateToProps);
export default compose(withConnect)(AssignRole);
