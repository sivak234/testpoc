/*
 * Bunkers Messages
 *
 * This contains all the text for the Bunkers component.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.components.Bunkers';

export default defineMessages({
  bunkers: {
    id: `${scope}.bunkers`,
    defaultMessage: 'Bunkers',
  },
  fuel: {
    id: `${scope}.fuel`,
    defaultMessage: 'Fuel',
  },
  supplyType: {
    id: `${scope}.supplyType`,
    defaultMessage: 'Supply Type',
  },
  notes: {
    id: `${scope}.notes`,
    defaultMessage: 'Notes',
  },
  notesMessage: {
    id: `${scope}.notesMessage`,
    defaultMessage:
      '* For Bunker notes please refer corresponding terminal for this port',
  },
});
