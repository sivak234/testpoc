/**
 *
 * Bunkers
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { FormattedMessage } from 'react-intl';
import { Table, Row, Col } from 'reactstrap';
import messages from './messages';
import './index.scss';
function Bunkers({ data }) {
  const bunkersData = [];
  const displayText = { marginBottom: '16px' };
  let entries;
  if (data !== undefined && data !== null) {
    if (Array.isArray(data)) {
      entries = data;
      if (entries.length > 0) {
        entries.forEach(item =>
          bunkersData.push(
            <tr key={item.fuelSupplyTypeId}>
              <td>{item.fuelTypeName}</td>
              <td>{item.fuelSupplyTypeName}</td>
            </tr>,
          ),
        );
      } else {
        bunkersData.push(
          <tr key="some-key">
            <td>--</td>
            <td>--</td>
          </tr>,
        );
      }
    } else {
      entries = Object.entries(data);
      if (entries.length > 0) {
        entries.forEach(item =>
          bunkersData.push(
            <tr key={item[0]}>
              <td>{item[0]}</td>
              <td>{item[1]}</td>
            </tr>,
          ),
        );
      } else {
        bunkersData.push(
          <tr key="some-key">
            <td>--</td>
            <td>--</td>
          </tr>,
        );
      }
    }
  }
  return (
    <>
      <Row className="port_overview_row_cls">
        {data !== undefined && data !== null && data.length > 0 ? (
          <Col>
            <Table responsive className="table">
              <thead>
                <tr>
                  <th width="33.33%">
                    <FormattedMessage {...messages.fuel} />
                  </th>
                  <th width="73.33%">
                    <FormattedMessage {...messages.supplyType} />
                  </th>
                </tr>
              </thead>
              <tbody>{bunkersData}</tbody>
            </Table>
          </Col>
        ) : null}
      </Row>
      <Row style={displayText} id="bunker-comment">
        <Col>
          <span className="bunker-ext-port-comment">
            <FormattedMessage {...messages.notesMessage} />
          </span>
        </Col>
      </Row>
    </>
  );
}

Bunkers.propTypes = {
  data: PropTypes.oneOfType([PropTypes.array, PropTypes.object]).isRequired,
};

export default Bunkers;
