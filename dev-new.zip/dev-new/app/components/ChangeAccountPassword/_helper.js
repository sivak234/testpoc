/*
 *
 * ChangeAccountPassword helper
 *
 */

export function defaultFunction(text) {
  return text;
}
