/**
 *
 * Asynchronously loads the component for TerminalManagement
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
