/**
 *
 * BerthManagement
 *
 */

import React, { useEffect, createRef } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';
import './index.scss';
import LoadingIndicator from '../LoadingIndicator';
import AddBerth from '../AddBerth/Loadable';
import SearchBerthManagement from '../SearchBerthManagement/Loadable';
import SearchResultBerth from '../SearchResultBerth/Loadable';

import {
  getMetaData,
  berthConfirmModal,
  berthConfirmModalClose,
  berthMessageModal,
  // Add View Update
  openAddBerthModal,
  closeAddBerthModal,
  openViewBerthModal,
  closeViewBerthModal,
  closeUpdateBerthModal,
  getBerthData,
  resetBerthData,
  handleBerthInputChange,
  validateBerthData,
  // Search
  handleBerthSearchInputChange,
  clearSearchBerth,
  validateSearchBerth,
  checkAllBerth,
  checkBerth,
  // Delete
  berthDelete,
  getVessels,
  // cargo handled input
  handleCargoTypeChange,
  updateBerthDataCargoHandled,
  deleteBerthDataCargoHandled,
  getVesselClassification,
  getPtbMapData,
  getPortsList,
  getTerminalsList,
  updateBerthValidationStatus,
  updateBerthSearchParam,
  getAllPortsDataForMap,
  storeterminalberthimageinformation,
  selectedTerminalBerthimageinfo,
  openberthimagepopupconfirmation,
  closeberthimagepopupconfirmation,
  deleteTerminalBerthSelectedImages,
  berthDocumentsData,
  validatedocumnet,
  setDocumentName,
  setDocumentType,
  validatedfileuploaddocument,
  selectedDocumentInformation,
  openberthdocumentpopupconfirmation,
  closeberthdocumentpopupconfirmation,
  berthDeleteSelectDocumentInformation,
  updateBerthInputChange,
  tempBerthAddDataModal,
  removeFromCollection,
  openUpdateBerthModal,
  ptbPublishWithoutChanges,
  getUserDetails,
  noRecordsForExport,
} from '../../containers/PortTerminalBerthManagement/actions';

import {
  // General
  makeSelectPortsLoading,
  makeSelectPortsHasError,
  makeSelectPortsError,
  makeSelectFormType,
  // Berth
  makeSelectPortsMetaData,
  makeSelectBerthMessage,
  makeSelectBerthSelectedBerthId,
  makeSelectBerthSelectedBerthName,
  makeSelectBerthConfirmModalOpen,
  makeSelectBerthMessageModalOpen,
  // Berth Add View Update
  makeSelectBerthAddOpen,
  makeSelectBerthViewOpen,
  makeSelectBerthEditOpen,
  makeSelectBerthAddParam,
  makeSelectBerthAddValidationStatus,
  makeSelectCheckLegacy,
  // Berth Search
  makeSelectBerthSearchParam,
  makeSelectBerthSearchValidationStatus,
  makeSelectBerthSearchResult,
  makeSelectBerthSelectedBerths,

  // Vessel for berth
  makeSelectBerthVessels,
  makeSelectVesselClassification,
  makeSelectBerthValidationMessages,
  makeSelectBerthAddValidationRules,
  // Berth Map
  makeSelectPortModalStatus,
  makeSelectFinalGeoFenceData,
  makeSelectSelectedGeoFenceData,
  makeSelectportViewData,
  makeSelectBerthDocumentModalOpen,
  makeSelectstoreterminalimageinformation,
  makeSelectBerthDocumentstoreselectedberthimagefile,
  makeSelectconfirmBerthImageDeleteModalOpen,
  makeSelectBerthImagesData,
  makeSelectBerthDocumentTypesInformation,
  makeSelectstoreBerthDocumentinformation,
  makeSelectBerthSelectedDocumentMessages,
  makeSelectBerthConfirmDocumentModalMessages,
  makeSelectTerminalGeoSelectedTermId,
  makeSelectMessageModalType,
  makeIsBerthClientAccessNotSelected,
  makeSelectLinkedWithLegacy,
  makeSelectLIsNotPublishedPTB,
  makeSelectPTBStatus,
} from '../../containers/PortTerminalBerthManagement/selectors';

import {
  messagePopup,
  confirmPopup,
  numberOfCopies,
  getDocumentTypeOptions,
} from './_helper';
import {
  validateField,
  makeValidationArray,
  makeDynamicValidation,
} from '../AddBerth/_helper';

const typeAheadDropdownBerth = {
  countryRef: createRef(),
  portRef: createRef(),
  terminalRef: createRef(),
};

function BerthManagement({
  // General
  isLoading,
  hasError,
  error,
  formType,
  // Berth
  metaData,
  berthMessage,
  berthId,
  berthName,
  confirmModalOpen,
  messageModalOpen,
  messageModalType,
  dHandleMessageClose,
  isCheckLegacy,
  // Add View Update Values
  isBerthAddOpen,
  berthData,
  berthValidationStatus,
  // Add View Update Actions
  dOpenUpdateBerthModal,
  dHandleAddOpen,
  dHandleAddClose,
  dHandleUpdateOpen,
  dHandleViewOpen,
  dResetBerthData,
  dHandleBerthInputChange,
  dValidateBerthDataAdd,
  dValidateBerthDataPublish,
  dValidateBerthDataUpdate,
  dValidateBerthDataPublishUpdate,
  // Search Values
  searchParam,
  searchValidation,
  searchResult,
  selectedBerths,
  // Search Action
  dHandleSearchInputChange,
  dValidateSearchBerth,
  dClearSearchBerth,
  dCheckAllBerth,
  dCheckBerth,
  dHandleSearchParam,
  // Delete Func
  dHandleDelete,
  dHandleDeleteClose,
  dBerthDelete,
  // Upload
  onFileChangeHandler,
  berthptbImage,
  dPortImagesData,
  updateImageData,
  uploadStatus,
  dHandleFileUpload,
  dHandleFileDownload,
  ptbDocumentsList,
  dPtbDocumentsData,
  updateDocumentData,
  // Vessels for berth popup
  dGetVessels,
  vessels,
  // Vessels Classification for berth Popup
  vesselClassification,
  dGetVesselClassification,
  dUpdateBerthDataCargoHandled,
  dDeleteBerthDataCargoHandled,
  dHandleCargoTypeChange,
  // Export
  exportEnable,
  selectExportType,
  dChangePtbExportType,
  submitPtbExportSelectedBerth,
  selectExportValidationStatus,
  dberthUpdateImageData,
  dshowModel,
  importPtb,
  dshandleImportChanged,
  getbtpLogResults,
  logResult,
  islogResult,
  totalRecords,
  getGeoFencingData,
  finalGeoFenceData,
  selectedGeoFenceData,
  portViewData,
  moduleType,
  regionList,
  countryList,
  dGetPortsList,
  dGetTerminalsList,
  portsList,
  terminalsList,
  dUpdateBerthValidationStatus,
  berthValidationMessages,
  berthAddValidationRules,
  dgetAllPortsDataForMap,
  berthImages,
  berthimageinfo,
  dstoreimageinformation,
  dselectedTerminalBerthimageinfo,
  storeselectedberthimagefile,
  confirmBerthImageDeleteModalOpen,
  dopenberthimagepopupconfirmation,
  dclsoeberthimagepopupconfirmation,
  ddeleteTerminalBerthSelectedImages,
  berthdocumenttype,
  berthptbDocument,
  dberthDocumentsData,
  dvalidatedocumnet,
  dsetDocumentName,
  dsetDocumentType,
  dvalidatedfileuploaddocument,
  dselectedDocumentInformation,
  berthselecteddocument,
  confirmBerthDocumentDeleteModalOpen,
  dopenberthdocumentpopupconfirmation,
  dcloseberthdocumentpopupconfirmation,
  dberthDeleteSelectDocumentInformation,
  dHandleUpdateBerthInputChange,
  // Temp Berth Data
  tempBerthAddData,
  dremoveFromCollection,
  type,
  dgetAllPortsDataForMapByCountryId,
  berthIssTransfer,
  dhandleYssTransferCheck,
  dPtbPublishWithoutChanges,
  dGetCountryList,
  geoSelectedTerminalId,
  dGetUserDetails,
  isBerthClientAccessNotSelected,
  dNoRecordsForExport,
  dgetAllPortsDataForMapByPortId,
  linkedWithLegacy,
  ptbStatus,
  isNotPublishedPTB,
  isMapRefresh,
  dsetNewLatLong,
  ptbMapCoordinates,
  dlocateLatLong,
  ptbSelectedCoordinates,
  isLocateClicked,
  dDisableLocate,
  isInValidLatLng,
  dcloseLocateDialog,
}) {
  useEffect(() => {
    dGetVesselClassification();
    let tempBerthAddId = '';
    if (sessionStorage.getItem('ptbTempBerthId')) {
      tempBerthAddId = sessionStorage.getItem('ptbTempBerthId');
      tempBerthAddData(tempBerthAddId);
    }
  }, []);

  const moduleId = 12;

  let validationRules = {
    ...makeValidationArray('oil'),
    ...makeValidationArray('gas'),
    ...makeValidationArray('dry'),
  };
  if (vessels.length > 0) {
    const dynamicRules = makeDynamicValidation(['oil', 'gas', 'dry'], vessels);
    validationRules = { ...validationRules, ...dynamicRules };
  }
  const onInputChange = el => {
    dHandleBerthInputChange(el);
    let newFields = '';
    if (el.preventDefault || el.target) {
      newFields = { ...berthData, [el.target.name]: el.target.value };
    } else {
      newFields = { ...berthData, [el.name]: el.value };
    }
    const validation = validateField(newFields, validationRules);
    if (validation) {
      const newBerthValidationStatus = {
        ...validation.inValidFields,
      };
      const newBerthValidationMessages = {
        ...validation.messages,
      };
      const newBerthAddValidationRules = {
        ...berthAddValidationRules,
        ...validation.validatorRules,
      };
      dUpdateBerthValidationStatus({
        newBerthValidationMessages,
        newBerthValidationStatus,
        newBerthAddValidationRules,
      });
    }
  };

  let documentType;

  if (berthdocumenttype !== undefined) {
    documentType = getDocumentTypeOptions(berthdocumenttype);
  }
  return (
    <>
      <AddBerth
        isLoading={isLoading}
        formType={formType}
        metaData={metaData}
        isBerthAddOpen={isBerthAddOpen}
        berthData={berthData}
        berthValidationStatus={berthValidationStatus}
        handleModalOpen={dHandleAddOpen}
        handleModalClose={dHandleAddClose}
        resetBerthData={dResetBerthData}
        handleBerthInputChange={onInputChange}
        validateBerthData={dValidateBerthDataAdd}
        validateBerthDataPublish={dValidateBerthDataPublish}
        isCheckLegacy={isCheckLegacy}
        onFileChangeHandler={onFileChangeHandler}
        ptbImage={berthptbImage}
        dPortImagesData={dPortImagesData}
        updateImageData={updateImageData}
        uploadStatus={uploadStatus}
        dHandleFileUpload={dHandleFileUpload}
        dHandleFileDownload={dHandleFileDownload}
        ptbDocumentsList={ptbDocumentsList}
        dPtbDocumentsData={dPtbDocumentsData}
        updateDocumentData={updateDocumentData}
        dGetVessels={dGetVessels}
        vessels={vessels}
        vesselClassification={vesselClassification}
        dUpdateBerthDataCargoHandled={dUpdateBerthDataCargoHandled}
        dDeleteBerthDataCargoHandled={dDeleteBerthDataCargoHandled}
        dHandleCargoTypeChange={dHandleCargoTypeChange}
        dberthUpdateImageData={dberthUpdateImageData}
        dValidateBerthDataUpdate={dValidateBerthDataUpdate}
        dValidateBerthDataPublishUpdate={dValidateBerthDataPublishUpdate}
        getPtbMapData={getPtbMapData}
        dshowModel={dshowModel}
        importPtb={importPtb}
        dshandleImportChanged={dshandleImportChanged}
        getbtpLogResults={getbtpLogResults}
        logResult={logResult}
        islogResult={islogResult}
        totalRecords={totalRecords}
        getGeoFencingData={getGeoFencingData}
        finalGeoFenceData={finalGeoFenceData}
        selectedGeoFenceData={selectedGeoFenceData}
        portViewData={portViewData}
        moduleType={moduleType}
        regionList={regionList}
        countryList={countryList}
        portsList={portsList}
        terminalsList={terminalsList}
        dGetPortsList={dGetPortsList}
        dGetTerminalsList={dGetTerminalsList}
        berthValidationMessages={berthValidationMessages}
        dgetAllPortsDataForMap={dgetAllPortsDataForMap}
        berthImages={berthImages}
        berthimageinfo={berthimageinfo}
        dstoreimageinformation={dstoreimageinformation}
        dselectedTerminalBerthimageinfo={dselectedTerminalBerthimageinfo}
        storeselectedberthimagefile={storeselectedberthimagefile}
        confirmBerthImageDeleteModalOpen={confirmBerthImageDeleteModalOpen}
        dopenberthimagepopupconfirmation={dopenberthimagepopupconfirmation}
        dclsoeberthimagepopupconfirmation={dclsoeberthimagepopupconfirmation}
        ddeleteTerminalBerthSelectedImages={ddeleteTerminalBerthSelectedImages}
        berthdocumenttype={documentType}
        numberOfCopies={numberOfCopies}
        berthptbDocument={berthptbDocument}
        dberthDocumentsData={dberthDocumentsData}
        dvalidatedocumnet={dvalidatedocumnet}
        dsetDocumentName={dsetDocumentName}
        dsetDocumentType={dsetDocumentType}
        dvalidatedfileuploaddocument={dvalidatedfileuploaddocument}
        dselectedDocumentInformation={dselectedDocumentInformation}
        berthselecteddocument={berthselecteddocument}
        confirmBerthDocumentDeleteModalOpen={
          confirmBerthDocumentDeleteModalOpen
        }
        dopenberthdocumentpopupconfirmation={
          dopenberthdocumentpopupconfirmation
        }
        dcloseberthdocumentpopupconfirmation={
          dcloseberthdocumentpopupconfirmation
        }
        dberthDeleteSelectDocumentInformation={
          dberthDeleteSelectDocumentInformation
        }
        dHandleUpdateBerthInputChange={dHandleUpdateBerthInputChange}
        moduleId={moduleId}
        dremoveFromCollection={dremoveFromCollection}
        dOpenUpdateBerthModal={dOpenUpdateBerthModal}
        dHandleDelete={dHandleDelete}
        dgetAllPortsDataForMapByCountryId={dgetAllPortsDataForMapByCountryId}
        berthIssTransfer={berthIssTransfer}
        dhandleYssTransferCheck={dhandleYssTransferCheck}
        searchParam={searchParam}
        dGetCountryList={dGetCountryList}
        typeAheadDropdownBerth={typeAheadDropdownBerth}
        geoSelectedTerminalId={geoSelectedTerminalId}
        dGetUserDetails={dGetUserDetails}
        isBerthClientAccessNotSelected={isBerthClientAccessNotSelected}
        dgetAllPortsDataForMapByPortId={dgetAllPortsDataForMapByPortId}
        linkedWithLegacy={linkedWithLegacy}
        ptbStatus={ptbStatus}
        isNotPublishedPTB={isNotPublishedPTB}
        isMapRefresh={isMapRefresh}
        dsetNewLatLong={dsetNewLatLong}
        ptbMapCoordinates={ptbMapCoordinates}
        dlocateLatLong={dlocateLatLong}
        ptbSelectedCoordinates={ptbSelectedCoordinates}
        isLocateClicked={isLocateClicked}
        dDisableLocate={dDisableLocate}
        isInValidLatLng={isInValidLatLng}
        dcloseLocateDialog={dcloseLocateDialog}
      />

      <SearchBerthManagement
        searchParam={searchParam}
        searchValidation={searchValidation}
        metaData={metaData}
        dHandleSearchInputChange={dHandleSearchInputChange}
        dSearchBerth={dValidateSearchBerth}
        dClearSearchBerth={dClearSearchBerth}
        regionList={regionList}
        countryList={countryList}
        portsList={portsList}
        terminalsList={terminalsList}
        dGetPortsList={dGetPortsList}
        dGetTerminalsList={dGetTerminalsList}
        dHandleSearchParam={dHandleSearchParam}
        moduleId={moduleId}
        type={type}
        dGetCountryList={dGetCountryList}
      />
      <LoadingIndicator
        isLoading={isLoading}
        hasError={hasError}
        error={error}
      />
      <SearchResultBerth
        moduleId={moduleId}
        metaData={metaData}
        searchResult={searchResult}
        checkAllBerth={dCheckAllBerth}
        checkBerth={dCheckBerth}
        selectedBerths={selectedBerths}
        handleView={dHandleViewOpen}
        handleEdit={dHandleUpdateOpen}
        handleDelete={dHandleDelete}
        exportEnable={exportEnable}
        selectExportType={selectExportType}
        dChangePtbExportType={dChangePtbExportType}
        submitPtbExportSelectedBerth={submitPtbExportSelectedBerth}
        selectExportValidationStatus={selectExportValidationStatus}
        dSearchBerth={dValidateSearchBerth}
        dPtbPublishWithoutChanges={dPtbPublishWithoutChanges}
        dNoRecordsForExport={dNoRecordsForExport}
        linkedWithLegacy={linkedWithLegacy}
        ptbStatus={ptbStatus}
        isNotPublishedPTB={isNotPublishedPTB}
        searchParam={searchParam}
      />
      {messagePopup(
        messageModalOpen,
        dHandleMessageClose,
        berthMessage,
        formType,
        messageModalType,
      )}
      {/* Delete Modal */}
      {confirmPopup(
        confirmModalOpen,
        dHandleDeleteClose,
        'Delete',
        dBerthDelete,
        berthId,
        berthName,
        `Are you sure you want to delete ${berthName}? This action cannot be  undone!`,
      )}
      {/* Delete Modal Ends */}
    </>
  );
}

BerthManagement.propTypes = {
  // General
  isLoading: PropTypes.bool,
  hasError: PropTypes.bool,
  error: PropTypes.string,
  formType: PropTypes.string,
  // Berth
  metaData: PropTypes.object,
  berthMessage: PropTypes.string,
  berthId: PropTypes.string,
  berthName: PropTypes.string,
  confirmModalOpen: PropTypes.bool,
  messageModalOpen: PropTypes.bool,
  messageModalType: PropTypes.string,
  // dGetMetaData: PropTypes.func,
  dHandleMessageClose: PropTypes.func,
  dOpenUpdateBerthModal: PropTypes.func,
  // Add View Update
  isBerthAddOpen: PropTypes.bool,
  berthData: PropTypes.object,
  berthValidationStatus: PropTypes.object,
  dHandleAddOpen: PropTypes.func,
  dHandleAddClose: PropTypes.func,
  dHandleUpdateOpen: PropTypes.func,
  dHandleViewOpen: PropTypes.func,
  dResetBerthData: PropTypes.func,
  dHandleBerthInputChange: PropTypes.func,
  dValidateBerthDataAdd: PropTypes.func,
  dValidateBerthDataPublish: PropTypes.func,
  dValidateBerthDataUpdate: PropTypes.func,
  dValidateBerthDataPublishUpdate: PropTypes.func,
  isCheckLegacy: PropTypes.bool,
  // Search Values
  searchParam: PropTypes.object,
  searchValidation: PropTypes.object,
  searchResult: PropTypes.object,
  selectedBerths: PropTypes.array,
  // Search Action
  dHandleSearchInputChange: PropTypes.func,
  dValidateSearchBerth: PropTypes.func,
  dClearSearchBerth: PropTypes.func,
  dCheckAllBerth: PropTypes.func,
  dCheckBerth: PropTypes.func,
  dHandleSearchParam: PropTypes.func,
  // Delete Func
  dHandleDelete: PropTypes.func,
  dHandleDeleteClose: PropTypes.func,
  dBerthDelete: PropTypes.func,
  // Upload
  onFileChangeHandler: PropTypes.func,
  berthptbImage: PropTypes.array,
  dPortImagesData: PropTypes.func,
  updateImageData: PropTypes.func,
  uploadStatus: PropTypes.string,
  dHandleFileUpload: PropTypes.func,
  dHandleFileDownload: PropTypes.func,
  ptbDocumentsList: PropTypes.array,
  dPtbDocumentsData: PropTypes.func,
  updateDocumentData: PropTypes.func,
  dGetVessels: PropTypes.func,
  // Vessels for Berth Popup
  vessels: PropTypes.array,
  // Vessels Classification for berth Popup
  vesselClassification: PropTypes.array,
  dUpdateBerthDataCargoHandled: PropTypes.func,
  dDeleteBerthDataCargoHandled: PropTypes.func,
  dHandleCargoTypeChange: PropTypes.func,
  // Export
  exportEnable: PropTypes.bool,
  selectExportType: PropTypes.string,
  dChangePtbExportType: PropTypes.func,
  submitPtbExportSelectedBerth: PropTypes.func,
  selectExportValidationStatus: PropTypes.object,
  dGetVesselClassification: PropTypes.func,
  dberthUpdateImageData: PropTypes.func,
  // getPtbMapData: PropTypes.func,
  dshowModel: PropTypes.func,
  importPtb: PropTypes.object,
  dshandleImportChanged: PropTypes.func,
  getbtpLogResults: PropTypes.func,
  logResult: PropTypes.array,
  islogResult: PropTypes.bool,
  totalRecords: PropTypes.number,
  getGeoFencingData: PropTypes.func,
  finalGeoFenceData: PropTypes.object,
  selectedGeoFenceData: PropTypes.object,
  portViewData: PropTypes.object,
  moduleType: PropTypes.string,
  // region country dropdown
  regionList: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  countryList: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  portsList: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  terminalsList: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  dGetPortsList: PropTypes.func,
  dGetTerminalsList: PropTypes.func,
  dUpdateBerthValidationStatus: PropTypes.func,
  berthValidationMessages: PropTypes.object,
  berthAddValidationRules: PropTypes.object,
  dgetAllPortsDataForMap: PropTypes.func,
  berthImages: PropTypes.array,
  berthimageinfo: PropTypes.array,
  dstoreimageinformation: PropTypes.func,
  dselectedTerminalBerthimageinfo: PropTypes.func,
  storeselectedberthimagefile: PropTypes.array,
  confirmBerthImageDeleteModalOpen: PropTypes.bool,
  dopenberthimagepopupconfirmation: PropTypes.func,
  dclsoeberthimagepopupconfirmation: PropTypes.func,
  ddeleteTerminalBerthSelectedImages: PropTypes.func,
  berthdocumenttype: PropTypes.array,
  berthptbDocument: PropTypes.array,
  dberthDocumentsData: PropTypes.func,
  dvalidatedocumnet: PropTypes.func,
  dsetDocumentName: PropTypes.func,
  dsetDocumentType: PropTypes.func,
  dvalidatedfileuploaddocument: PropTypes.func,
  dselectedDocumentInformation: PropTypes.func,
  berthselecteddocument: PropTypes.array,
  confirmBerthDocumentDeleteModalOpen: PropTypes.bool,
  dopenberthdocumentpopupconfirmation: PropTypes.func,
  dcloseberthdocumentpopupconfirmation: PropTypes.func,
  dberthDeleteSelectDocumentInformation: PropTypes.func,
  dHandleUpdateBerthInputChange: PropTypes.func,
  tempBerthAddData: PropTypes.func,
  dremoveFromCollection: PropTypes.func,
  type: PropTypes.string,
  dgetAllPortsDataForMapByCountryId: PropTypes.func,
  berthIssTransfer: PropTypes.bool,
  dhandleYssTransferCheck: PropTypes.func,
  dPtbPublishWithoutChanges: PropTypes.func,
  dGetCountryList: PropTypes.func,
  geoSelectedTerminalId: PropTypes.string,
  dGetUserDetails: PropTypes.func,
  isBerthClientAccessNotSelected: PropTypes.bool,
  dNoRecordsForExport: PropTypes.func,
  dgetAllPortsDataForMapByPortId: PropTypes.func,
  linkedWithLegacy: PropTypes.object,
  ptbStatus: PropTypes.object,
  isNotPublishedPTB: PropTypes.bool,
  isMapRefresh: PropTypes.bool,
  dsetNewLatLong: PropTypes.func,
  dlocateLatLong: PropTypes.func,
  ptbMapCoordinates: PropTypes.object,
  ptbSelectedCoordinates: PropTypes.object,
  isLocateClicked: PropTypes.bool,
  dDisableLocate: PropTypes.func,
  isInValidLatLng: PropTypes.bool,
  dcloseLocateDialog: PropTypes.bool,
};

const mapStateToProps = createStructuredSelector({
  // General
  isLoading: makeSelectPortsLoading(),
  hasError: makeSelectPortsHasError(),
  error: makeSelectPortsError(),
  formType: makeSelectFormType(),
  // Berth
  metaData: makeSelectPortsMetaData(),
  berthMessage: makeSelectBerthMessage(),
  berthId: makeSelectBerthSelectedBerthId(),
  berthName: makeSelectBerthSelectedBerthName(),
  confirmModalOpen: makeSelectBerthConfirmModalOpen(),
  messageModalOpen: makeSelectBerthMessageModalOpen(),
  // Add View Update
  isBerthAddOpen: makeSelectBerthAddOpen(),
  isBerthViewOpen: makeSelectBerthViewOpen(),
  isBerthEditOpen: makeSelectBerthEditOpen(),
  berthData: makeSelectBerthAddParam(),
  berthValidationStatus: makeSelectBerthAddValidationStatus(),
  isCheckLegacy: makeSelectCheckLegacy(),
  // Search
  searchParam: makeSelectBerthSearchParam(),
  searchValidation: makeSelectBerthSearchValidationStatus(),
  searchResult: makeSelectBerthSearchResult(),
  selectedBerths: makeSelectBerthSelectedBerths(),
  // Vessel
  vessels: makeSelectBerthVessels(),
  // Vessels Classification for berth Popup
  vesselClassification: makeSelectVesselClassification(),
  // Delete
  berthValidationMessages: makeSelectBerthValidationMessages(),

  berthAddValidationRules: makeSelectBerthAddValidationRules(),
  // Berth Map
  portViewModal: makeSelectPortModalStatus(),
  finalGeoFenceData: makeSelectFinalGeoFenceData(),
  selectedGeoFenceData: makeSelectSelectedGeoFenceData(),
  portViewData: makeSelectportViewData(),
  berthImages: makeSelectBerthDocumentModalOpen(),
  berthimageinfo: makeSelectstoreterminalimageinformation(),
  storeselectedberthimagefile: makeSelectBerthDocumentstoreselectedberthimagefile(),
  confirmBerthImageDeleteModalOpen: makeSelectconfirmBerthImageDeleteModalOpen(),
  berthptbImage: makeSelectBerthImagesData(),
  berthdocumenttype: makeSelectBerthDocumentTypesInformation(),
  berthptbDocument: makeSelectstoreBerthDocumentinformation(),
  berthselecteddocument: makeSelectBerthSelectedDocumentMessages(),
  confirmBerthDocumentDeleteModalOpen: makeSelectBerthConfirmDocumentModalMessages(),
  geoSelectedTerminalId: makeSelectTerminalGeoSelectedTermId(),
  messageModalType: makeSelectMessageModalType(),
  isBerthClientAccessNotSelected: makeIsBerthClientAccessNotSelected(),
  linkedWithLegacy: makeSelectLinkedWithLegacy(),
  ptbStatus: makeSelectPTBStatus(),
  isNotPublishedPTB: makeSelectLIsNotPublishedPTB(),
});

function mapDispatchToProps(dispatch) {
  return {
    dNoRecordsForExport: () => {
      dispatch(noRecordsForExport());
    },
    dOpenUpdateBerthModal: berthId => {
      dispatch(openUpdateBerthModal(berthId));
    },
    dGetUserDetails: type => {
      dispatch(getUserDetails(type));
    },
    // Berth
    dGetMetaData: () => {
      dispatch(getMetaData());
    },
    dHandleMessageClose: () => {
      dispatch(berthMessageModal());
    },
    dHandleDeleteClose: () => {
      dispatch(berthConfirmModalClose());
    },
    // Add View Update
    dHandleAddOpen: () => {
      dispatch(openAddBerthModal('', 'add'));
    },
    dHandleAddClose: () => {
      dispatch(closeAddBerthModal());
    },
    dHandleUpdateOpen: (berthId, userType, currentPage, isPublish) => {
      dispatch(openViewBerthModal(berthId, 'update', currentPage, isPublish));
    },
    dHandleUpdateClose: () => {
      dispatch(closeUpdateBerthModal());
    },
    dHandleViewOpen: (berthId, currentPage, isPublish) => {
      dispatch(openViewBerthModal(berthId, 'view', currentPage, isPublish));
    },
    dHandleViewClose: () => {
      dispatch(closeViewBerthModal());
    },
    dGetBerthData: berthId => {
      dispatch(getBerthData(berthId));
    },
    dResetBerthData: () => dispatch(resetBerthData()),
    dHandleBerthInputChange: event => {
      if (
        typeof event.preventDefault === 'function' &&
        event.target.type !== 'checkbox'
      ) {
        event.preventDefault();
      }

      if (event.preventDefault || event.target) {
        const { name, value, checked, dataset } = event.target;
        dispatch(
          handleBerthInputChange(
            name,
            value,
            checked,
            dataset.type,
            dataset.key,
          ),
        );
      } else {
        const { name, value } = event;
        dispatch(handleBerthInputChange(name, value, false, 'flat', ''));
      }
    },
    dUpdateBerthValidationStatus: data =>
      dispatch(updateBerthValidationStatus(data)),
    dValidateBerthDataAdd: () =>
      dispatch(validateBerthData('add', 'add', typeAheadDropdownBerth)),
    dValidateBerthDataPublish: () =>
      dispatch(validateBerthData('publish', 'add', typeAheadDropdownBerth)),
    dValidateBerthDataUpdate: () =>
      dispatch(validateBerthData('update', 'update', typeAheadDropdownBerth)),
    dValidateBerthDataPublishUpdate: () =>
      dispatch(validateBerthData('publish', 'update', typeAheadDropdownBerth)),
    dHandleAdd: (berthId, berthName) => {
      dispatch(berthConfirmModal('add', berthId, berthName));
    },
    dHandleUpdate: (berthId, berthName) => {
      dispatch(berthConfirmModal('update', berthId, berthName));
    },
    // Search
    dHandleSearchInputChange: event => {
      if (event.preventDefault) {
        const { name, value } = event.target;
        dispatch(handleBerthSearchInputChange(name, value));
        event.preventDefault();
      } else {
        const { name, value } = event;
        dispatch(handleBerthSearchInputChange(name, value));
      }
    },
    dClearSearchBerth: () => dispatch(clearSearchBerth()),
    dValidateSearchBerth: (pageDetails, resetGrid = false) =>
      dispatch(validateSearchBerth(pageDetails, resetGrid)),
    dCheckAllBerth: event => {
      event.preventDefault();
      const { checked } = event.target;
      dispatch(checkAllBerth(checked));
    },
    dCheckBerth: event => {
      event.preventDefault();
      const { checked, id } = event.target;
      dispatch(checkBerth(checked, id));
    },
    // Delete
    dHandleDelete: ({ berthId, berthName, currentPage }) => {
      dispatch(berthConfirmModal('delete', berthId, berthName, currentPage));
    },
    dBerthDelete: (berthId, berthName) => {
      dispatch(berthDelete(berthId, berthName));
    },
    dGetVessels: data => {
      dispatch(getVessels(data));
    },
    dHandleCargoTypeChange: (cargoType, index, data, key) =>
      dispatch(handleCargoTypeChange(cargoType, index, data, key)),
    dUpdateBerthDataCargoHandled: (key, data) =>
      dispatch(updateBerthDataCargoHandled(key, data)),
    dDeleteBerthDataCargoHandled: (key, data) =>
      dispatch(deleteBerthDataCargoHandled(key, data)),
    dGetVesselClassification: () => {
      dispatch(getVesselClassification());
    },
    getGeoFencingData: (polygon, center, moduleType) =>
      dispatch(getPtbMapData(polygon, center, moduleType)),
    dGetPortsList: (data, tabName, source) =>
      dispatch(getPortsList(data, tabName, source)),
    dGetTerminalsList: (data, source) =>
      dispatch(getTerminalsList(data, source)),
    dHandleSearchParam: (regionId, countryId, portId, terminalId) => {
      dispatch(updateBerthSearchParam(regionId, countryId, portId, terminalId));
    },
    dgetAllPortsDataForMap: () => dispatch(getAllPortsDataForMap()),
    dstoreimageinformation: (title, storeinfo) =>
      dispatch(storeterminalberthimageinformation(title, storeinfo)),
    dselectedTerminalBerthimageinfo: (fileobject, selectedvalue, updatebtn) =>
      dispatch(
        selectedTerminalBerthimageinfo(fileobject, selectedvalue, updatebtn),
      ),
    dopenberthimagepopupconfirmation: () =>
      dispatch(openberthimagepopupconfirmation()),
    dclsoeberthimagepopupconfirmation: () =>
      dispatch(closeberthimagepopupconfirmation()),
    ddeleteTerminalBerthSelectedImages: sectiontype =>
      dispatch(deleteTerminalBerthSelectedImages(sectiontype)),
    dberthDocumentsData: docdata => dispatch(berthDocumentsData(docdata)),
    dvalidatedocumnet: (sectiontype, findex, ptbDocument) =>
      dispatch(validatedocumnet(sectiontype, findex, ptbDocument)),
    dsetDocumentName: (sectiontype, findex, ptbDocument, value) =>
      dispatch(setDocumentName(sectiontype, findex, ptbDocument, value)),
    dsetDocumentType: (sectiontype, findex, ptbDocument, value) =>
      dispatch(setDocumentType(sectiontype, findex, ptbDocument, value)),
    dvalidatedfileuploaddocument: (
      sectiontype,
      findex,
      ptbDocument,
      filesizeinfo,
      checkfiletype,
      duplicatefilename,
    ) =>
      dispatch(
        validatedfileuploaddocument(
          sectiontype,
          findex,
          ptbDocument,
          filesizeinfo,
          checkfiletype,
          duplicatefilename,
        ),
      ),
    dselectedDocumentInformation: (sectiontype, filename, seledocumentcheck) =>
      dispatch(
        selectedDocumentInformation(sectiontype, filename, seledocumentcheck),
      ),
    dopenberthdocumentpopupconfirmation: () =>
      dispatch(openberthdocumentpopupconfirmation()),
    dcloseberthdocumentpopupconfirmation: () =>
      dispatch(closeberthdocumentpopupconfirmation()),
    dberthDeleteSelectDocumentInformation: () =>
      dispatch(berthDeleteSelectDocumentInformation()),

    tempBerthAddData: berthId =>
      dispatch(tempBerthAddDataModal(berthId, 'add')),
    dHandleUpdateBerthInputChange: (
      regionId,
      countryId,
      portId,
      terminalId,
      terminalTypeId,
    ) => {
      dispatch(
        updateBerthInputChange(
          regionId,
          countryId,
          portId,
          terminalId,
          terminalTypeId,
        ),
      );
    },
    dremoveFromCollection: (sectiontype, collection, type) => {
      dispatch(removeFromCollection(sectiontype, collection, type));
    },
    dPtbPublishWithoutChanges: ids =>
      dispatch(ptbPublishWithoutChanges('Berth', ids)),
  };
}

const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);

export default compose(withConnect)(BerthManagement);
