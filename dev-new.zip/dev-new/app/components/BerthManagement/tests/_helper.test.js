// import { messagePopup } from '../_helper';

// describe('BerthManagement helpers', () => {
//   describe('Default Helper Function', () => {
//     it('returns the expected value', () => {
//       const expected = 'Sample Text';
//       expect(messagePopup('Sample Text')).toEqual(expected);
//     });
//   });
// });
describe('<BerthManagement />', () => {
  it('Expect to not log errors in BerthImages', () => {
    expect(true).toBeTruthy();
  });
});
