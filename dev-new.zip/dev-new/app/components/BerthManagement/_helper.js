/*
 *
 * BerthManagement helper
 *
 */

import React from 'react';
import { Container, Row, Col } from 'reactstrap';
import Popup from '../Popup/Loadable';

function messageButtons(close) {
  return [
    {
      title: 'Ok',
      action: close,
      id: 'btncancelid',
    },
  ];
}

function messageBody(berthMessage, type) {
  return (
    <Container>
      <Row>
        {type.toLowerCase() === 'success' && (
          <Col xs={2}>
            <i
              className="fa fa-3x text-success fa-check-circle mr-2"
              aria-hidden="true"
            />
          </Col>
        )}
        {type.toLowerCase() === 'fail' && (
          <Col xs={2}>
            <span className="delete-xclaim-icon">!</span>
          </Col>
        )}
        <Col className="pt-2">{berthMessage}</Col>
      </Row>
    </Container>
  );
}

export function messagePopup(isOpen, close, message, formType, type = '') {
  return (
    <Popup
      size="md"
      show={isOpen}
      close={close}
      title={`${formType} Berth`}
      buttons={messageButtons(close)}
    >
      {messageBody(message, type)}
    </Popup>
  );
}

function confirmButtons(success, id, name, close) {
  return [
    {
      title: 'Yes',
      action: () => success(id, name),
    },
    {
      title: 'No',
      action: close,
      id: 'btncancelid',
    },
  ];
}

function confirmBody(message) {
  return (
    <Container>
      <Row>
        <Col xs="auto">
          <span className="delete-xclaim-icon">!</span>
        </Col>
        <Col>{message}</Col>
      </Row>
    </Container>
  );
}

export function confirmPopup(isOpen, close, type, callBack, id, name, message) {
  return (
    <Popup
      size="md"
      show={isOpen}
      close={close}
      title={`${type} Berth`}
      buttons={confirmButtons(callBack, id, name, close)}
    >
      {confirmBody(message)}
    </Popup>
  );
}

export function defaultFunction(text) {
  return text;
}

const NumberOfCopies = ['01', '02', '03', '04', '05', '06', '07'];
export const numberOfCopies = NumberOfCopies.map(e => (
  <option key={e}>{e}</option>
));

export const getDocumentTypeOptions = portMasterData => {
  const options = [];
  if (portMasterData !== undefined && portMasterData.length !== 0) {
    portMasterData.forEach(item =>
      options.push(
        <option
          key={item.documenttypeid}
          value={item.documenttypeid}
          name={item.documenttypedesc}
        >
          {item.documenttypedesc}
        </option>,
      ),
    );
  }
  return options;
};
