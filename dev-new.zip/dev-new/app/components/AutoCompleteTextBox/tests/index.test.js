// /**
//  *
//  * Tests for AutoCompleteTextBox
//  *
//  * @see https://github.com/react-boilerplate/react-boilerplate/tree/master/docs/testing
//  *
//  */

// import React from 'react';
// import ReactDOM from 'react-dom';
// // import { render } from 'react-testing-library';
// // import { IntlProvider } from 'react-intl';
// // import 'jest-dom/extend-expect'; // add some helpful assertions

// import AutoCompleteTextBox from '../index';
// // import { DEFAULT_LOCALE } from '../../../i18n';

// describe('<AutoCompleteTextBox />', () => {
//   it('Expect to not log errors in AutoCompleteTextBox', () => {
//     const div = document.createElement('div');
//     ReactDOM.render(<AutoCompleteTextBox />, div);
//   });
//   // it('Expect to not log errors in console', () => {
//   //   const spy = jest.spyOn(global.console, 'error');
//   //   render(
//   //     <IntlProvider locale={DEFAULT_LOCALE}>
//   //       <AutoCompleteTextBox />
//   //     </IntlProvider>,
//   //   );
//   //   expect(spy).not.toHaveBeenCalled();
//   // });

//   // it('Expect to have additional unit tests specified', () => {
//   //   expect(true).toEqual(false);
//   // });

//   // /**
//   //  * Unskip this test to use it
//   //  *
//   //  * @see {@link https://jestjs.io/docs/en/api#testskipname-fn}
//   //  */
//   // it.skip('Should render and match the snapshot', () => {
//   //   const {
//   //     container: { firstChild },
//   //   } = render(
//   //     <IntlProvider locale={DEFAULT_LOCALE}>
//   //       <AutoCompleteTextBox />
//   //     </IntlProvider>,
//   //   );
//   //   expect(firstChild).toMatchSnapshot();
//   // });
// });
import React from 'react';
import { shallow, mount } from 'enzyme';

import AutoCompleteTextBox from '../index';

describe('<AutoCompleteTextBox />', () => {
  let testProps = null;
  const clearPoifilterMock = jest.fn();
  const onNextPortSelectedMock = jest.fn();
  const fetchPortNameMock = jest.fn();
  beforeEach(() => {
    testProps = {
      userInput: 'test',
      isLoading: false,
      isNewLandingPage: true,
      placeholder: 'Port Name Or UNLOCODE',
      suggestions: [
        {
          portCode: 'SINGKAWANG-IDSKW',
          portId: '7c4a64f1-7a85-4225-9e60-b3f518bf83c1',
        },
      ],
      clearPoiFiltersTrigger: clearPoifilterMock,
      fetchPortName: fetchPortNameMock,
      onNextPortSelected: onNextPortSelectedMock,
    };
  });
  it('Should render using enzyme', () => {
    const wrapper = mount(
      <AutoCompleteTextBox type="vesselimo" {...testProps} />,
    );
    expect(wrapper).toMatchSnapshot();
    const resetwrapper = mount(
      <AutoCompleteTextBox type="portunlo" {...testProps} />,
    );
    expect(resetwrapper).toMatchSnapshot();
    const resetProps = {
      ...testProps,
      isNewLandingPage: undefined,
      type: 'nextPort',
      isLoading: false,
    };
    const setWrapper = shallow(<AutoCompleteTextBox {...resetProps} />);
    expect(setWrapper).toMatchSnapshot();
  });
  it.only('should render function', () => {
    const event = {
      currentTarget: {
        value: 'sing',
      },
    };

    const setWrapper = shallow(
      <AutoCompleteTextBox type="nextPort" {...testProps} />,
    );
    const inputClck = setWrapper.find('input').simulate('change', event);
    const getOutComp = setWrapper.dive();
    getOutComp.setState({
      activeSuggestion: 0,
      filteredSuggestions: ['sing', 'test'],
      showSuggestions: true,
      userInput: event.currentTarget.value,
    });
    expect(inputClck).toHaveBeenCalled();
  });
});
