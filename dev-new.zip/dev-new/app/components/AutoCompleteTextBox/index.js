/* eslint-disable jsx-a11y/click-events-have-key-events */
/* eslint-disable jsx-a11y/no-noninteractive-element-interactions */
/**
 *
 * AutoCompleteTextBox
 *
 */

import React, { memo, Component } from 'react';
import PropTypes from 'prop-types';
import { Button } from 'reactstrap';
import { FETCH_RECORD_COUNT } from '../../utils/constants';
import history from '../../utils/history';
import './AutoComplete.scss';

class AutoCompleteTextBox extends Component {
  static propTypes = {
    suggestions: PropTypes.instanceOf(Array),
    label: PropTypes.instanceOf(Object),
    type: PropTypes.string,
    portDetails: PropTypes.func,
    vesselDetails: PropTypes.func,
    fetchPortName: PropTypes.func,
    fetchVesselName: PropTypes.func,
    fetchPortDetails: PropTypes.func,
    fetchPortStatisticDetails: PropTypes.func,
    fetchVesselData: PropTypes.func,
    fetchPortMoveMapData: PropTypes.func,
    fetchAisVesselVoyageDetails: PropTypes.func,
    fetchAisVesselDetails: PropTypes.func,
    fetchAisVesselData: PropTypes.func,
    fetchselectedImoData: PropTypes.func,
    fetchNearestRangeVesselsByImo: PropTypes.func,
    fetchTerminalCodeNames: PropTypes.func,
    onNextPortSelected: PropTypes.func,
    placeholder: PropTypes.string,
    searchAppliedFilter: PropTypes.func,
    singleVesselApi: PropTypes.func,
    isNewLandingPage: PropTypes.bool,
    isLoading: PropTypes.bool,
    isShowAutocompleteMsg: PropTypes.bool,
    getSinglePortDataApiCall: PropTypes.func,
    clearTextField: PropTypes.func,
    userInput: PropTypes.string,
    portCostEstimatorFieldsChange: PropTypes.func,
    fetchTerminalName: PropTypes.func,
    portCostEstimatorSelectedValues: PropTypes.object,
    portCostEstimatorPort: PropTypes.bool,
    portCostEstimatorTerminal: PropTypes.bool,
    isHeaderSearch: PropTypes.bool,
    index: PropTypes.number,
    searchRef: PropTypes.any,
    setMenuClick: PropTypes.func,
    setSearchCancelbtn: PropTypes.func,
    isshowCancelbtn: PropTypes.bool,
  };

  static defaultProperty = {
    suggestions: [],
  };

  constructor(props) {
    super(props);
    this.state = {
      activeSuggestion: -1,
      filteredSuggestions: this.props.suggestions,
      showSuggestions: false,
      userInput: this.props.userInput,
      setChange: false,
      portEstimator: false,
    };
  }

  static getDerivedStateFromProps(nextProps) {
    if (nextProps.resetText) {
      return {
        userInput: '',
      };
    }
    if (nextProps.type === 'vesselimo' && nextProps.userInput !== undefined) {
      return {
        filteredSuggestions: nextProps.suggestions,
      };
    }
    if (nextProps.type === 'portunlo' && nextProps.userInput !== undefined) {
      return {
        filteredSuggestions: nextProps.suggestions,
      };
    }
    if (
      nextProps.type === 'portCostEstimator' &&
      nextProps.userInput !== undefined
    ) {
      return {
        filteredSuggestions: nextProps.suggestions,
      };
    }
    if (
      nextProps.type === 'portCostEstimatorVessel' &&
      nextProps.userInput !== undefined
    ) {
      return {
        filteredSuggestions: nextProps.suggestions,
      };
    }
    if (
      nextProps.type === 'portCostEstimatorTerminal' &&
      nextProps.userInput !== undefined
    ) {
      return {
        filteredSuggestions: nextProps.suggestions,
      };
    }
    if (nextProps.type === 'nextPort' && nextProps.userInput !== undefined) {
      return {
        filteredSuggestions: nextProps.suggestions,
        userInput: nextProps.userInput,
      };
    }
    if (
      nextProps.type === 'ptbstausport' &&
      nextProps.userInput !== undefined
    ) {
      return {
        filteredSuggestions: nextProps.suggestions,
        userInput: nextProps.userInput,
      };
    }

    if (
      nextProps &&
      nextProps.suggestions &&
      nextProps.suggestions.length > 0
    ) {
      return {
        filteredSuggestions: nextProps.suggestions,
      };
    }
    return [];
  }

  onChange = e => {
    if (this.props.type === 'vessel') {
      const vesselName = e.currentTarget.value;
      if (vesselName.length > 2) {
        this.props.fetchVesselName(vesselName);
      }
    } else if (this.props.type === 'port') {
      const portName = e.currentTarget.value;
      if (portName.length >= 2) {
        this.props.fetchPortName(portName);
      }
    } else if (this.props.type === 'vesselimo') {
      const vesselName = e.currentTarget.value;
      this.props.fetchVesselName(vesselName);
    } else if (this.props.type === 'portCostEstimatorVessel') {
      const vesselName = e.currentTarget.value;
      const targetValue = e.target.getAttribute('value');
      const split = targetValue.split('^');
      const [getSelectedPortId] = split;
      this.props.portCostEstimatorFieldsChange(
        'vesselName',
        getSelectedPortId,
        e.currentTarget.innerText,
        'vessel',
      );
      if (vesselName.length >= 3) {
        this.props.fetchVesselName(vesselName);
      }
    } else if (this.props.type === 'portCostEstimatorTerminal') {
      const terminalName = e.currentTarget.value;
      const targetValue = e.target.getAttribute('value');
      const split = targetValue.split('^');
      const [getSelectedTerminalId] = split;
      this.props.portCostEstimatorFieldsChange(
        'terminalName',
        getSelectedTerminalId,
        terminalName,
        'port',
        this.props.index,
      );
      if (
        terminalName.length >= 3 &&
        this.props.portCostEstimatorSelectedValues.portId === ''
      ) {
        this.props.fetchTerminalName(terminalName, this.props.index);
      }
    } else if (
      this.props.type === 'portunlo' ||
      this.props.type === 'nextPort' ||
      this.props.type === 'portCostEstimator'
    ) {
      const portName = e.currentTarget.value;
      if (portName.length >= 3) {
        this.props.fetchPortName(portName);
      }
      if (this.props.type === 'portCostEstimator') {
        this.props.portCostEstimatorFieldsChange(
          'portName',
          '',
          portName,
          'port',
          this.props.index,
        );
      }
    } else {
      const portName = e.currentTarget.value;
      if (portName.length >= 2) {
        this.props.fetchPortName(portName);
      }
    }
    const { suggestions } = this.props;
    const userInput = e.currentTarget.value;
    const portSuggestions = suggestions && suggestions.map(val => val.portCode);
    let filteredSuggestions = [];
    const numbers = /^[0-9]+$/;
    let isNo = false;
    if (e.currentTarget.value.match(numbers)) {
      isNo = true;
    }
    if (this.props.type === 'vessel') {
      filteredSuggestions = suggestions.filter(
        suggestion =>
          suggestion !== undefined &&
          isNo &&
          suggestion.imo.toLowerCase().indexOf(userInput.toLowerCase()) > -1,
        suggestion =>
          suggestion !== undefined &&
          !isNo &&
          suggestion.vesselName.toLowerCase().indexOf(userInput.toLowerCase()) >
            -1,
      );
    } else if (this.props.type === 'port') {
      filteredSuggestions = portSuggestions.filter(
        suggestion =>
          suggestion !== undefined &&
          suggestion.toLowerCase().indexOf(userInput.toLowerCase()) > -1,
      );
    } else if (this.props.type === 'vesselimo') {
      filteredSuggestions = suggestions.filter(
        suggestion =>
          suggestion !== undefined &&
          isNo &&
          suggestion.imo.toLowerCase().indexOf(userInput.toLowerCase()) > -1,
        suggestion =>
          suggestion !== undefined &&
          !isNo &&
          suggestion.vesselName.toLowerCase().indexOf(userInput.toLowerCase()) >
            -1,
      );
    } else if (this.props.type === 'portCostEstimatorVessel') {
      filteredSuggestions = suggestions.filter(
        suggestion =>
          suggestion !== undefined &&
          isNo &&
          suggestion.imo.toLowerCase().indexOf(userInput.toLowerCase()) > -1,
        suggestion =>
          suggestion !== undefined &&
          !isNo &&
          suggestion.vesselName.toLowerCase().indexOf(userInput.toLowerCase()) >
            -1,
      );
    } else if (this.props.type === 'portCostEstimatorTerminal') {
      filteredSuggestions = suggestions.filter(
        suggestion =>
          suggestion !== undefined &&
          isNo &&
          suggestion.terminalCode
            .toLowerCase()
            .indexOf(userInput.toLowerCase()) > -1,
        suggestion =>
          suggestion !== undefined &&
          !isNo &&
          suggestion.terminalName
            .toLowerCase()
            .indexOf(userInput.toLowerCase()) > -1,
      );
    } else if (
      this.props.type === 'portunlo' ||
      this.props.type === 'portCostEstimator'
    ) {
      filteredSuggestions = portSuggestions.filter(
        suggestion =>
          suggestion !== undefined &&
          suggestion.toLowerCase().indexOf(userInput.toLowerCase()) > -1,
      );
    } else if (this.props.type === 'nextPort') {
      filteredSuggestions = portSuggestions.filter(
        suggestion =>
          suggestion !== undefined &&
          suggestion.toLowerCase().indexOf(userInput.toLowerCase()) > -1,
      );
      this.props.onNextPortSelected(e.currentTarget.value, this.props.type);
    } else if (this.props.type === 'ptbstausport') {
      this.props.fetchPortDetails(e.currentTarget.value);
    }

    this.setState({
      activeSuggestion: -1,
      filteredSuggestions,
      showSuggestions: true,
      userInput: e.currentTarget.value,
      portEstimator: false,
    });
  };

  onClick = e => {
    e.stopPropagation();
    e.preventDefault();
    const { type } = this.props;
    if (type === 'vessel') {
      this.handleVesselMovement(e.target.value);
    } else if (type === 'port') {
      this.handlePortMovement(e.target.value);
    } else if (type === 'nextPort') {
      this.props.onNextPortSelected(e.target.value, this.props.type);
    } else if (type === 'vesselimo') {
      const { searchAppliedFilter } = this.props;
      if (this.props.searchRef !== undefined && this.props.searchRef.current) {
        // eslint-disable-next-line no-underscore-dangle
        this.props.searchRef.current._instance.clear();
      }
      if(this.props.setSearchCancelbtn !== undefined){
        this.props.setSearchCancelbtn(false);
      }
      if (this.props.isNewLandingPage) {
        searchAppliedFilter(e.target.value);
      }
      if (
        this.props.isHeaderSearch !== undefined &&
        this.props.isHeaderSearch &&
        !window.location.pathname.includes('/vessel-tracking')
      ) {
        sessionStorage.setItem('vesselportSearch', true);
        sessionStorage.setItem('portNameUnlo', null);
        sessionStorage.setItem('selectedPortDetail', null);
        history.push(`/vessel-tracking`);
      }
    } else if (type === 'portCostEstimatorVessel') {
      this.props.singleVesselApi(e.target.value);
      const targetValue = e.target.getAttribute('value');
      const split = targetValue.split('^');
      const [getSelectedPortId] = split;
      this.props.portCostEstimatorFieldsChange(
        'vesselName',
        getSelectedPortId,
        e.currentTarget.innerText,
        'vessel',
      );
    } else if (type === 'portCostEstimatorTerminal') {
      const targetValue = e.target.getAttribute('value');
      const split = targetValue.split('^');
      const [getSelectedTerminalId] = split;
      this.props.portCostEstimatorFieldsChange(
        'terminalName',
        getSelectedTerminalId,
        e.currentTarget.innerText,
        'port',
        this.props.index,
      );
    } else if (type === 'portunlo') {
      /* Please dont uncommet on the below line.
      const { clearPoiFiltersTrigger } = this.props;
      clearPoiFiltersTrigger('portunlo');
      */
      const targetValue = e.target.getAttribute('value');
      const split = targetValue.split('^');
      const [getSelectedPortId] = split;
      this.props.getSinglePortDataApiCall(getSelectedPortId);
      if (
        this.props.isHeaderSearch !== undefined &&
        this.props.isHeaderSearch &&
        !window.location.pathname.includes('/vessel-tracking')
      ) {
        sessionStorage.setItem('vesselportSearch', true);
        sessionStorage.setItem('portNameUnlo', null);
        sessionStorage.setItem('selectedPortDetail', null);
        history.push(`/vessel-tracking`);
      }
    } else if (type === 'ptbstausport') {
      this.props.fetchPortDetails(e.currentTarget.innerText);
    } else if (type === 'portCostEstimator') {
      const targetValue = e.target.getAttribute('value');
      const split = targetValue.split('^');
      const [getSelectedPortId] = split;
      this.props.portCostEstimatorFieldsChange(
        'portName',
        getSelectedPortId,
        e.currentTarget.innerText,
        'port',
        this.props.index,
      );
      this.props.fetchTerminalName(getSelectedPortId, this.props.index);
    }
    this.setState({
      activeSuggestion: 0,
      filteredSuggestions: [],
      showSuggestions: false,
      userInput: e.currentTarget.innerText,
      setChange: false,
      portEstimator: false,
    });
  };

  handlePortMovement = portIdValue => {
    this.props.portDetails(portIdValue);
    this.props.fetchPortDetails(portIdValue);
    this.props.fetchPortStatisticDetails(portIdValue);
    const options = {
      portId: portIdValue,
      pageNo: 0,
      fetchRecordCount: FETCH_RECORD_COUNT,
    };
    this.props.fetchVesselData(options);
    this.props.fetchPortMoveMapData(portIdValue);
    this.props.fetchTerminalCodeNames({
      portId: portIdValue,
      type: 'portMovement',
    });
  };

  handleVesselMovement = vesselIdValue => {
    this.props.vesselDetails(vesselIdValue);
    this.props.fetchAisVesselDetails(vesselIdValue);
    this.props.fetchAisVesselVoyageDetails(vesselIdValue);
    const options = {
      imo: vesselIdValue,
      pageNo: 0,
      fetchRecordCount: FETCH_RECORD_COUNT,
    };
    this.props.fetchAisVesselData(options);
    this.props.fetchselectedImoData(vesselIdValue);
    this.props.fetchNearestRangeVesselsByImo(vesselIdValue);
  };

  onKeyDown = e => {
    const { clearTextField, type } = this.props;
    if (e.keyCode === 9 || e.keyCode === 16) {
      clearTextField(type, true);
    }
    const { filteredSuggestions, userInput } = this.state;
    let { activeSuggestion } = this.state;
    let isDefaultvalue = false;
    if (
      e.keyCode === 40 &&
      activeSuggestion === -1 &&
      filteredSuggestions.length > 0
    ) {
      activeSuggestion = 0;
      isDefaultvalue = true;
    }
    let inputValue = filteredSuggestions[activeSuggestion];
    if (
      this.props.type === 'portunlo' ||
      this.props.type === 'nextPort' ||
      this.props.type === 'portCostEstimator'
    ) {
      inputValue =
        activeSuggestion >= 0 &&
        userInput &&
        userInput.length > 1 &&
        filteredSuggestions &&
        filteredSuggestions.length > 0 &&
        `${filteredSuggestions[activeSuggestion].portCode}`;
    } else if (this.props.type === 'vesselimo') {
      inputValue =
        activeSuggestion >= 0 &&
        userInput &&
        userInput.length > 1 &&
        filteredSuggestions &&
        filteredSuggestions.length > 0 &&
        `${filteredSuggestions[activeSuggestion].vesselName}`;
    } else if (this.props.type === 'portCostEstimatorVessel') {
      inputValue =
        activeSuggestion >= 0 &&
        userInput &&
        userInput.length > 1 &&
        filteredSuggestions &&
        filteredSuggestions.length > 1 &&
        `${filteredSuggestions[activeSuggestion].vesselName}`;
    } else if (this.props.type === 'portCostEstimatorTerminal') {
      inputValue =
        activeSuggestion >= 0 &&
        filteredSuggestions &&
        filteredSuggestions.length > 1 &&
        `${filteredSuggestions[activeSuggestion].terminalCode}`;
    } else if (this.props.type === 'vessel') {
      inputValue =
        activeSuggestion >= 0 &&
        userInput &&
        userInput.length > 1 &&
        filteredSuggestions &&
        filteredSuggestions.length > 0 &&
        `${filteredSuggestions[activeSuggestion].vesselName}`;
    } else if (this.props.type === 'port') {
      inputValue =
        activeSuggestion >= 0 &&
        userInput &&
        userInput.length > 1 &&
        filteredSuggestions &&
        filteredSuggestions.length > 0 &&
        `${filteredSuggestions[activeSuggestion].portCode}`;
    }

    if (e.keyCode === 13) {
      if (inputValue === false || inputValue === 'undefined') {
        return;
      }
      this.setState({
        activeSuggestion: 0,
        showSuggestions: false,
        userInput: inputValue,
        portEstimator: false,
      });
      if (this.props.type === 'portunlo' || this.props.type === 'nextPort') {
        if (filteredSuggestions && filteredSuggestions.length > 0) {
          const ports = `${filteredSuggestions[activeSuggestion].portId}`;
          this.props.getSinglePortDataApiCall(ports);
        }
        if (
          this.props.type === 'portunlo' &&
          this.props.isHeaderSearch !== undefined &&
          this.props.isHeaderSearch &&
          !window.location.pathname.includes('/vessel-tracking')
        ) {
          sessionStorage.setItem('vesselportSearch', true);
          sessionStorage.setItem('portNameUnlo', null);
          sessionStorage.setItem('selectedPortDetail', null);
          history.push(`/vessel-tracking`);
        }
      } else if (this.props.type === 'portCostEstimator') {
        if (filteredSuggestions && filteredSuggestions.length > 0) {
          const ports = `${filteredSuggestions[activeSuggestion].portId}`;
          this.props.portCostEstimatorFieldsChange(
            'portName',
            ports,
            `${filteredSuggestions[activeSuggestion].portCode}`,
            'port',
            this.props.index,
          );
          this.props.fetchTerminalName(ports, this.props.index);
        }
      } else if (this.props.type === 'vesselimo') {
        if (
          this.props.searchRef !== undefined &&
          this.props.searchRef.current
        ) {
          // eslint-disable-next-line no-underscore-dangle
          this.props.searchRef.current._instance.clear();
        }
        if(this.props.setSearchCancelbtn !== undefined){
          this.props.setSearchCancelbtn(false);
        }
        const vessel =
          filteredSuggestions &&
          filteredSuggestions.length > 0 &&
          `${filteredSuggestions[activeSuggestion].imo}`;
        if (vessel) {
          if (this.props.isNewLandingPage) {
            this.props.searchAppliedFilter(vessel);
          }
        }
        if (
          this.props.isHeaderSearch !== undefined &&
          this.props.isHeaderSearch &&
          !window.location.pathname.includes('/vessel-tracking')
        ) {
          sessionStorage.setItem('vesselportSearch', true);
          sessionStorage.setItem('portNameUnlo', null);
          sessionStorage.setItem('selectedPortDetail', null);
          history.push(`/vessel-tracking`);
        }
      } else if (this.props.type === 'portCostEstimatorVessel') {
        const vessel =
          filteredSuggestions &&
          filteredSuggestions.length > 0 &&
          `${filteredSuggestions[activeSuggestion].imo}`;
        this.props.portCostEstimatorFieldsChange(
          'vesselName',
          vessel,
          `${filteredSuggestions[activeSuggestion].vesselName}`,
          'vessel',
        );
        if (vessel) {
          this.props.singleVesselApi(vessel);
        }
      } else if (this.props.type === 'portCostEstimatorTerminal') {
        const terminal =
          filteredSuggestions &&
          filteredSuggestions.length > 0 &&
          `${filteredSuggestions[activeSuggestion].terminalCode}`;
        this.props.portCostEstimatorFieldsChange(
          'terminalName',
          `${filteredSuggestions[activeSuggestion].terminalId}`,
          terminal,
          'port',
          this.props.index,
        );
      } else if (this.props.type === 'vessel') {
        const vessel =
          filteredSuggestions &&
          filteredSuggestions.length > 0 &&
          `${filteredSuggestions[activeSuggestion].imo}`;
        if (userInput.length < 1 || vessel === undefined) {
          return;
        }
        this.handleVesselMovement(vessel);
      } else if (this.props.type === 'port') {
        const port =
          filteredSuggestions &&
          filteredSuggestions.length > 0 &&
          `${filteredSuggestions[activeSuggestion].portId}`;
        if (userInput.length < 1 || port === undefined) {
          return;
        }
        this.handlePortMovement(port);
      }
    } else if (e.keyCode === 38) {
      if (activeSuggestion === 0) {
        return;
      }

      this.doScrollupForDropDown(
        userInput,
        filteredSuggestions,
        activeSuggestion,
        type,
        38,
        isDefaultvalue,
      );
      const prevNode = this.nodeRef.current;
      prevNode.children[activeSuggestion - 1].scrollIntoView();
    } else if (e.keyCode === 40) {
      const getActivesuggestionLength = activeSuggestion;
      if (
        getActivesuggestionLength + 1 === filteredSuggestions.length &&
        filteredSuggestions.length !== 1
      ) {
        return;
      }
      const nextNode = this.inputRef.current
        ? this.inputRef.current.nextSibling
        : this.nodeRef.current;
      nextNode.children[activeSuggestion].scrollIntoView();
      this.doScrollupForDropDown(
        userInput,
        filteredSuggestions,
        activeSuggestion,
        type,
        40,
        isDefaultvalue,
      );
    }
  };

  doScrollupForDropDown = (
    userInput,
    filteredSuggestions,
    activeSuggestion,
    type,
    keyName,
    isDefaultvalue,
  ) => {
    let setSuggestion = null;
    let inputValue = null;
    if (isDefaultvalue) {
      setSuggestion = activeSuggestion;
    }
    if (!isDefaultvalue) {
      if (keyName === 38) {
        setSuggestion = activeSuggestion - 1;
      } else {
        setSuggestion = activeSuggestion + 1;
      }
    }
    if (type === 'vesselimo') {
      inputValue =
        userInput.length > 0 &&
        filteredSuggestions &&
        filteredSuggestions.length > 0 &&
        `${filteredSuggestions[setSuggestion].vesselName}`;
    }
    if (type === 'portCostEstimatorVessel') {
      inputValue =
        userInput.length > 1 &&
        filteredSuggestions &&
        filteredSuggestions.length > 0 &&
        `${filteredSuggestions[setSuggestion].vesselName}`;
    } else if (type === 'portunlo' || type === 'portCostEstimator') {
      inputValue =
        userInput.length > 1 &&
        filteredSuggestions &&
        filteredSuggestions.length > 0 &&
        `${filteredSuggestions[setSuggestion].portCode}`;
    } else if (type === 'portCostEstimatorTerminal') {
      inputValue =
        filteredSuggestions &&
        filteredSuggestions.length > 0 &&
        `${filteredSuggestions[setSuggestion].terminalCode}`;
    }

    this.setState({
      activeSuggestion: setSuggestion,
      userInput: inputValue,
      portEstimator: true,
    });
  };

  nodeRef = React.createRef();

  inputRef = React.createRef();

  handleClick = () => {
    const { setChange } = this.state;
    if (!setChange) {
      this.setState({
        showSuggestions: false,
        setChange: false,
        portEstimator: false,
      });
    }
    return false;
  };

  handleFocus = e => {
    const { clearTextField, type } = this.props;
    if (clearTextField) {
      clearTextField(type);
    }
    if (type === 'portCostEstimatorTerminal') {
      this.setState({
        filteredSuggestions: this.props.suggestions,
        showSuggestions: this.props.suggestions.length > 0,
        userInput: this.props.portCostEstimatorSelectedValues.terminalValue,
      });

      if (
        this.props.portCostEstimatorSelectedValues.terminalValue.length >= 3 &&
        this.props.portCostEstimatorSelectedValues.portId === ''
      ) {
        this.props.fetchTerminalName(
          this.props.portCostEstimatorSelectedValues.terminalValue,
          this.props.index,
        );
      } else {
        this.props.portCostEstimatorFieldsChange(
          'terminalName',
          this.props.portCostEstimatorSelectedValues.terminalId,
          this.props.portCostEstimatorSelectedValues.terminalValue,
          'port',
          this.props.index,
        );
      }
    }
    if (type === 'portCostEstimator') {
      this.setState({
        userInput: this.props.portCostEstimatorSelectedValues.portValue,
      });
    }
    if (e.target.value !== '') {
      const getPortVal = e.target.value;
      const hyphenPattern = /-/g;
      const validatePortVal = hyphenPattern.test(getPortVal);
      if (validatePortVal) {
        const splitPortVal = getPortVal.split('-');
        if (type === 'portunlo' || type === 'portCostEstimator') {
          const [getSplitPortval] = splitPortVal;
          this.props.fetchPortName(getSplitPortval);
        } else if (type === 'portCostEstimatorTerminal') {
          this.setState({
            activeSuggestion: 0,
            filteredSuggestions: this.props.suggestions,
            showSuggestions: this.props.suggestions.length > 0,
            userInput: this.props.portCostEstimatorSelectedValues.terminalValue,
          });
        } else {
          const [, getSplitVesselval] = splitPortVal;
          this.props.fetchVesselName(getSplitVesselval);
        }
      }
      this.setState({
        showSuggestions: true,
        setChange: false,
      });
    }
  };

  clearText = () => {
    this.setState({
      userInput: '',
    });
    if(this.props.isshowCancelbtn !== undefined && this.props.isshowCancelbtn){
     this.props.setSearchCancelbtn(true);
    }
  };

  render() {
    const {
      onChange,
      onClick,
      onKeyDown,
      handleFocus,
      state: {
        filteredSuggestions,
        showSuggestions,
        userInput,
        activeSuggestion,
        portEstimator,
      },
    } = this;
    const intype = this.props.type;
    let suggestionsListComponent;
    if (showSuggestions && this.props.portCostEstimatorTerminal) {
      if (filteredSuggestions.length > 0) {
        suggestionsListComponent = (
          <ul
            curentText={userInput}
            ref={this.nodeRef}
            id="listId"
            active={activeSuggestion}
            className="AutoCompleteTextList"
            style={{
              overflowY: filteredSuggestions.length > 10 ? 'scroll' : 'hidden',
            }}
          >
            {filteredSuggestions.map((suggestion, index) => {
              let name = '';
              let id = '';
              if (this.props.type === 'portCostEstimatorTerminal') {
                name = suggestion.terminalCode;
                id = suggestion.terminalId;
              }
              return (
                <li
                  className={activeSuggestion === index ? 'active' : ''}
                  key={id}
                  value={
                    this.props.type === 'portCostEstimatorTerminal'
                      ? `${id}^${name}`
                      : id
                  }
                  onMouseDown={onClick}
                >
                  <Button
                    color="link"
                    className="p-0"
                    value={
                      this.props.type === 'portCostEstimatorTerminal'
                        ? `${id}^${name}`
                        : id
                    }
                    onMouseDown={onClick}
                  >
                    {name}
                  </Button>
                </li>
              );
            })}
          </ul>
        );
      } else {
        suggestionsListComponent =
          !this.props.isLoading && userInput.length > 2 ? (
            <div className="AutoCompleteText noresulttext">
              <ul>
                <li>No search result found</li>
              </ul>
            </div>
          ) : (
            <div />
          );
      }
    }
    if (showSuggestions && userInput.length > 2) {
      if (filteredSuggestions && filteredSuggestions.length > 0) {
        suggestionsListComponent = (
          <ul
            curentText={userInput}
            ref={this.nodeRef}
            id="listId"
            active={activeSuggestion}
            className="AutoCompleteTextList"
            style={{
              overflowY: filteredSuggestions.length > 10 ? 'scroll' : 'hidden',
            }}
          >
            {filteredSuggestions.map((suggestion, index) => {
              let name = '';
              let id = '';
              if (
                this.props.type === 'vessel' ||
                this.props.type === 'vesselimo' ||
                this.props.type === 'portCostEstimatorVessel'
              ) {
                name = suggestion.vesselName;
                id = suggestion.imo;
              } else if (this.props.type === 'portCostEstimatorTerminal') {
                name = suggestion.terminalCode;
                id = suggestion.terminalId;
              } else {
                name = suggestion.portCode;
                id = suggestion.portId;
              }
              return (
                <li
                  className={activeSuggestion === index ? 'active' : ''}
                  key={id}
                  value={
                    this.props.type === 'nextPort' ||
                    this.props.type === 'portunlo' ||
                    this.props.type === 'portCostEstimator'
                      ? `${id}^${name}`
                      : id
                  }
                  onMouseDown={onClick}
                >
                  <Button
                    color="link"
                    className="p-0"
                    value={
                      this.props.type === 'nextPort' ||
                      this.props.type === 'portunlo' ||
                      this.props.type === 'portCostEstimator'
                        ? `${id}^${name}`
                        : id
                    }
                    onMouseDown={onClick}
                  >
                    {name}
                  </Button>
                </li>
              );
            })}
          </ul>
        );
      } else {
        const { isLoading, isShowAutocompleteMsg } = this.props;
        if (isShowAutocompleteMsg !== undefined) {
          suggestionsListComponent =
            userInput.length > 2 && isShowAutocompleteMsg ? (
              <div className="AutoCompleteText noresulttext">
                <ul>
                  <li>No search result found</li>
                </ul>
              </div>
            ) : (
              <div />
            );
        } else {
          suggestionsListComponent =
            userInput.length > 2 && !isLoading ? (
              <div className="AutoCompleteText noresulttext">
                <ul>
                  <li>No search result found</li>
                </ul>
              </div>
            ) : (
              <div />
            );
        }
      }
    }
    const { placeholder } = this.props;
    return (
      <React.Fragment>
        <label style={{ fontWeight: 'bold' }}> {this.props.label} </label>
        {this.props.isNewLandingPage && (
          <div
            className={`AutoCompleteText ${
              this.props.isHeaderSearch !== undefined &&
              this.props.isHeaderSearch
                ? 'textbackcolor'
                : ''
            }`}
          >
            <>
              <input
                ref={this.inputRef}
                className="form-control py-2 bg-transparent textPlaceholder"
                type="text"
                onFocus={handleFocus}
                onChange={onChange}
                onKeyDown={onKeyDown}
                value={userInput}
                onBlur={this.handleClick}
                placeholder={placeholder}
              />
              {suggestionsListComponent}
              {suggestionsListComponent && suggestionsListComponent.length > 0 && (
                <button className="btn border-0 btn-pos" type="button">
                  <i className="fa fa-times" />
                </button>
              )}
              {userInput && userInput.length > 0 && intype === 'vesselimo' && (
                <span style={{ position: 'absolute' }}>
                  <button
                    className="btn border-0 btn-pos vesselcancelbtn"
                    type="button"
                    onClick={() => this.clearText()}
                  >
                    <i className="fa fa-times" />
                  </button>
                </span>
              )}
            </>
          </div>
        )}
        {this.props.isNewLandingPage === undefined && (
          <>
            {this.props.portCostEstimatorPort === undefined && (
              <>
                {this.props.portCostEstimatorTerminal === undefined && (
                  <>
                    <div className="AutoCompleteText">
                      <input
                        type="text"
                        onChange={onChange}
                        onKeyDown={onKeyDown}
                        value={userInput}
                        placeholder={placeholder}
                        onFocus={handleFocus}
                        onBlur={this.handleClick}
                      />
                      {suggestionsListComponent}
                    </div>
                  </>
                )}
              </>
            )}
          </>
        )}
        {this.props.portCostEstimatorPort && (
          <div className="AutoCompleteText">
            <input
              type="text"
              onChange={onChange}
              onKeyDown={onKeyDown}
              value={
                portEstimator
                  ? userInput
                  : this.props.portCostEstimatorSelectedValues.portValue
              }
              placeholder={placeholder}
              onFocus={handleFocus}
              onBlur={this.handleClick}
            />
            {this.props.portCostEstimatorPort && suggestionsListComponent}
          </div>
        )}
        {this.props.portCostEstimatorTerminal && (
          <div className="AutoCompleteText">
            <input
              type="text"
              onChange={onChange}
              onKeyDown={onKeyDown}
              value={
                portEstimator
                  ? userInput
                  : this.props.portCostEstimatorSelectedValues.terminalValue
              }
              placeholder={placeholder}
              onFocus={handleFocus}
              onBlur={this.handleClick}
              disabled={
                this.props.portCostEstimatorSelectedValues.vesselPurposeName ===
                  'Canal Transit' ||
                this.props.portCostEstimatorSelectedValues.vesselPurposeName ===
                  'Bunker (At Anchorage)'
              }
            />
            {this.props.portCostEstimatorTerminal && suggestionsListComponent}
          </div>
        )}
      </React.Fragment>
    );
  }
}

export default memo(AutoCompleteTextBox);
