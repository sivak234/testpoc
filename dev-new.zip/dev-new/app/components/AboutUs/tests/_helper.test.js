// import { defaultFunction } from '../_helper';

// describe('AboutUs helpers', () => {
//   describe('Default Helper Function', () => {
//     it('returns the expected value', () => {
//       const expected = 'Sample Text';
//       expect(defaultFunction('Sample Text')).toEqual(expected);
//     });
//   });
// });
describe('<AboutUs />', () => {
  it('Expect to not log errors in AboutUs', () => {
    expect(true).toBeTruthy();
  });
});
