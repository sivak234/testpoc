/* eslint-disable react/no-danger */
/**
 *
 * AboutUs
 *
 */

import React, { memo } from 'react';
import PropTypes from 'prop-types';
import { Row, Col } from 'reactstrap';
import Image from 'react-bootstrap/Image';
import { FormattedMessage } from 'react-intl';
import messages from './messages';
import './_helper';

import './index.scss';

function AboutUs({ aboutUsDetails }) {
  const isDataAvailable = aboutUsDetails.length > 0;
  const visionDetails = isDataAvailable ? aboutUsDetails[0].our_vision : '';

  return (
    <>
      {isDataAvailable && (
        <>
          <Row className="aboutUs-block">
            <Col xs={12} className="pl-0">
              <h2 className="title-navy-blue">
                {isDataAvailable && aboutUsDetails[0].title}
              </h2>
              <div
                className="aboutus-box-text"
                dangerouslySetInnerHTML={{
                  __html: isDataAvailable && aboutUsDetails[0].body,
                }}
              />
            </Col>
            <Col xs={12} />
          </Row>

          <Row className="thumbnail-img text-center">
            <Col className="pl-0 pr-0">
              {isDataAvailable && (
                <>
                  <div className="video-container">
                    <video
                      loop
                      autoPlay
                      src={aboutUsDetails[0].middle_section_background_video}
                      className="video-fluid"
                    >
                      <track kind="captions" />
                    </video>
                  </div>
                  <h1>
                    <div
                      dangerouslySetInnerHTML={{
                        __html: aboutUsDetails[0].middle_section_description,
                      }}
                      className="caption-img"
                    />
                  </h1>
                </>
              )}
            </Col>
          </Row>
          <Row className="vision-block">
            <h2 className="title-navy-blue">
              {isDataAvailable && aboutUsDetails[0].field_vision_title}
            </h2>
          </Row>
        </>
      )}
      {visionDetails && (
        <>
          <Row className="pb-4">
            <Col />
            <Col>
              <Row className="justify-content-center pl-5 pr-5">
                <Image
                  src={visionDetails[0].vision_icon}
                  alt={visionDetails[0].vision_icon_alt}
                  title={visionDetails[0].vision_icon_title}
                  className="service-carousel-item"
                />
                <Row className="pt-5">
                  <h2 className="title-navy-blue mb-3">
                    {visionDetails[0].vision_title}
                  </h2>
                </Row>
                <div
                  dangerouslySetInnerHTML={{
                    __html: visionDetails[0].vision_description,
                  }}
                  className="wrap-75 text-center min-vh-80 mt-1"
                />
              </Row>
            </Col>
            <Col />
          </Row>
          <Row className="justify-content-center p-5">
            <Col md={3} className="scrollMsg">
              <FormattedMessage {...messages.scrollDownMsg} />
            </Col>
          </Row>
          <Row className="p-5">
            <Col />
            <Col>
              <Row className="justify-content-center pt-4">
                <Image
                  src={visionDetails[1].vision_icon}
                  alt={visionDetails[1].vision_icon_alt}
                  title={visionDetails[1].vision_icon_title}
                  className="service-carousel-item"
                />
                <Row className="pt-4 full-header">
                  <h2 className="title-navy-blue custom-header mb-3">
                    {visionDetails[1].vision_title}
                  </h2>
                </Row>
                <div
                  dangerouslySetInnerHTML={{
                    __html: visionDetails[1].vision_description,
                  }}
                  className="col-12 min-vh-55 sub-class"
                />
              </Row>
            </Col>
            <Col />
          </Row>
          <Row className="justify-content-center p-3">
            <h1 className="symbol"> + </h1>
          </Row>
          <Row className="justify-content-center p-5">
            <Col xs={12} md={3} />
            <Col xs={12} md={6}>
              <Row className="justify-content-center">
                <Image
                  src={visionDetails[2].vision_icon}
                  alt={visionDetails[2].vision_icon_alt}
                  title={visionDetails[2].vision_icon_title}
                  className="service-carousel-item"
                />
                <Row className="pt-3 col-12">
                  <h2 className="title-navy-blue custom-header mb-3">
                    {visionDetails[2].vision_title}
                  </h2>
                </Row>
                <div
                  dangerouslySetInnerHTML={{
                    __html: visionDetails[2].vision_description,
                  }}
                  className="col-md-9 wrap-75 min-vh-40 col-lg-6 sub-class"
                />
              </Row>
            </Col>
            <Col xs={12} md={3} />
          </Row>
          <Row className="justify-content-center p-3">
            <h1 className="symbol"> = </h1>
          </Row>
          <Row className="justify-content-center">
            <Col xs={12} md={6}>
              <Row className="justify-content-center p-1">
                <Image
                  src={visionDetails[3].vision_icon}
                  alt={visionDetails[3].vision_icon_alt}
                  title={visionDetails[3].vision_icon_title}
                  className="service-carousel-item"
                />
                <Row className="justify-content-center content">
                  <h2 className="title-navy-blue mb-3">
                    {visionDetails[3].vision_title}
                  </h2>
                </Row>
                <div
                  dangerouslySetInnerHTML={{
                    __html: visionDetails[3].vision_description,
                  }}
                  className="description col-md-6 col-lg-4"
                />
              </Row>
            </Col>
            <Col xs={12} md={6}>
              <Row className="justify-content-center p-1">
                <Image
                  src={visionDetails[4].vision_icon}
                  alt={visionDetails[4].vision_icon_alt}
                  title={visionDetails[4].vision_icon_title}
                  className="service-carousel-item"
                />
                <Row className="justify-content-center content pb-1">
                  <h2 className="title-navy-blue">
                    {visionDetails[4].vision_title.split('&')[0]}
                    {'&'}
                  </h2>
                </Row>
                <Row className="justify-content-center content pl-xl-4">
                  <h2 className="title-navy-blue mb-3">
                    {visionDetails[4].vision_title.split('&')[1]}
                  </h2>
                </Row>
                <div
                  dangerouslySetInnerHTML={{
                    __html: visionDetails[4].vision_description,
                  }}
                  className="description col-md-6 wrap-75 col-lg-4"
                />
              </Row>
            </Col>
          </Row>
          <Row className="pt-5" />
        </>
      )}
    </>
  );
}

AboutUs.propTypes = {
  aboutUsDetails: PropTypes.array,
};

export default memo(AboutUs);
