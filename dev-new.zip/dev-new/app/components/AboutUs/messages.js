/*
 * AboutUs Messages
 *
 * This contains all the text for the AboutUs component.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.components.AboutUs';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'This is the AboutUs component!',
  },
  ourVision: {
    id: `${scope}.ourVision`,
    defaultMessage: 'Our Vision',
  },
  scrollDownMsg: {
    id: `${scope}.scrollDownMsg`,
    defaultMessage: 'Scroll down to see how we achieve this',
  },
});
