/* eslint-disable indent */
/* eslint-disable prettier/prettier */
/**
 *
 * AuditDetails
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { Row, Col } from 'reactstrap';
import { FormattedMessage } from 'react-intl';
import { dateConversion } from '../../utils/dataModification';
import './index.scss';
import messages from './messages';

function AuditDetails({
  passedRef,
  dateOfExpiration,
  userCreatedBy,
  userUpdatedBy,
  createdDate,
  updatedDate,
  viewPortData,
  selected,
  formType,
}) {
  let createdTimeStampData = '';
  let updatedTimeStampData = '';
  let portExpirationDate = '';
  if (!!viewPortData && !!viewPortData.createdTimeStamp) {
    const tempCreated = viewPortData.createdTimeStamp.split('T');
    // eslint-disable-next-line prefer-destructuring
    createdTimeStampData = tempCreated[0];
  }
  if (!!selected && !!selected[0].createdTimeStamp) {
    const tempCreated = selected[0].createdTimeStamp.split('T');
    // eslint-disable-next-line prefer-destructuring
    createdTimeStampData = tempCreated[0];
  }
  if (!!viewPortData && !!viewPortData.updatedTimeStamp) {
    const tempCreated = viewPortData.updatedTimeStamp.split('T');
    // eslint-disable-next-line prefer-destructuring
    updatedTimeStampData = tempCreated[0];
  }
  if (!!selected && !!selected[0].updatedTimeStamp) {
    const tempCreated = selected[0].updatedTimeStamp.split('T');
    // eslint-disable-next-line prefer-destructuring
    updatedTimeStampData = tempCreated[0];
  }
  if (!!viewPortData && !!viewPortData.dataExpirationDate) {
    const tempCreated = viewPortData.dataExpirationDate.split('T');
    // eslint-disable-next-line prefer-destructuring
    portExpirationDate = tempCreated[0];
  }
  if (!!selected && !!selected[0].dataExpirationDate) {
    const tempCreated = selected[0].dataExpirationDate.split('T');
    // eslint-disable-next-line prefer-destructuring
    portExpirationDate = tempCreated[0];
  }
  return (
    <>
      <Row className="add-port-section-header mb-3 mt-3">
        <Col xs={12}>
          <h4 className="mb-0" ref={passedRef}>
            <FormattedMessage {...messages.auditDetails} />
          </h4>
        </Col>
      </Row>
      <Row>
        <Col xs={3}>
          <h4>
            <FormattedMessage {...messages.dataExpDate} />
          </h4>
        </Col>
        <Col>
          {portExpirationDate !== ''
            ? dateConversion(portExpirationDate)
            : dateConversion(dateOfExpiration)}
        </Col>
      </Row>
      <Row>
        <Col xs={3}>
          <h4>
            <FormattedMessage {...messages.userCreatedBy} />
          </h4>
        </Col>
        <Col>
          {formType === 'View' && !!viewPortData && viewPortData.createdBy
            ? viewPortData.createdBy
            : userCreatedBy}
          {formType === 'Update' && selected[0] && selected[0].createdBy
            ? selected[0].createdBy
            : null}
        </Col>
      </Row>
      <Row>
        <Col xs={3}>
          <h4>
            <FormattedMessage {...messages.userUpdateBy} />
          </h4>
        </Col>
        <Col>
          {formType === 'View' && !!viewPortData && viewPortData.updatedBy
            ? viewPortData.updatedBy
            : userUpdatedBy}
          {formType === 'Update' && selected[0] && selected[0].updatedBy
            ? selected[0].updatedBy
            : null}
        </Col>
      </Row>
      <Row>
        <Col xs={3}>
          <h4>
            <FormattedMessage {...messages.createdDate} />
          </h4>
        </Col>
        <Col>
          {formType === 'View' && (
            <p>
              {!!viewPortData && viewPortData.createdTimeStamp
                ? dateConversion(createdTimeStampData)
                : dateConversion(createdDate)}
            </p>
          )}
          {formType === 'Update' && (
            <p>
              {!!selected[0] && selected[0].createdTimeStamp
                ? dateConversion(createdTimeStampData)
                : dateConversion(createdDate)}
            </p>
          )}
        </Col>
      </Row>
      <Row>
        <Col xs={3}>
          <h4>
            <FormattedMessage {...messages.updatedDate} />
          </h4>
        </Col>
        <Col>
          {formType === 'View' && (
            <p>
              {!!viewPortData && viewPortData.updatedTimeStamp
                ? dateConversion(updatedTimeStampData)
                : dateConversion(updatedDate)}
            </p>
          )}
          {formType === 'Update' && (
            <p>
              {!!selected[0] && selected[0].updatedTimeStamp
                ? dateConversion(updatedTimeStampData)
                : dateConversion(updatedDate)}
            </p>
          )}
        </Col>
      </Row>
    </>
  );
}

AuditDetails.propTypes = {
  passedRef: PropTypes.any,
  dateOfExpiration: PropTypes.string,
  userCreatedBy: PropTypes.string,
  userUpdatedBy: PropTypes.string,
  createdDate: PropTypes.string,
  updatedDate: PropTypes.string,
  viewPortData: PropTypes.object,
  selected: PropTypes.array,
  formType: PropTypes.string,
};

export default AuditDetails;
