/*
 * AuditDetails Messages
 *
 * This contains all the text for the AuditDetails component.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.components.AuditDetails';

export default defineMessages({
  auditDetails: {
    id: `${scope}.auditDetails`,
    defaultMessage: 'Audit Details',
  },
  dataExpDate: {
    id: `${scope}.dataExpDate`,
    defaultMessage: 'Data Expiration Date',
  },
  userCreatedBy: {
    id: `${scope}.userCreatedBy`,
    defaultMessage: 'User Created By',
  },
  userUpdateBy: {
    id: `${scope}.userUpdateBy`,
    defaultMessage: 'User Updated By',
  },
  createdDate: {
    id: `${scope}.createdDate`,
    defaultMessage: 'User Created Date',
  },
  updatedDate: {
    id: `${scope}.updatedDate`,
    defaultMessage: 'User Updated Date',
  },
});
