/**
 *
 * Asynchronously loads the component for BerthCargoGearFacility
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
