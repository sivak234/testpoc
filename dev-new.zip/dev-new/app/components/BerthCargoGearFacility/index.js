/**
 *
 * BerthCargoGearFacility
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { Row, Col, Label, Input, CustomInput } from 'reactstrap';
import Dropdown from '../Dropdown';
import { getDescriptionForDropdown } from '../../utils/dataModification';
function BerthCargoGearFacility({
  passedRef,
  metaData,
  data = {},
  handleBerthInputChange,
  readOnly = false,
  isDry = false,
}) {
  return (
    <>
      <Row className="add-berth-section-header mb-3 mt-3">
        <Col xs={12}>
          <h4 className="mb-0" ref={passedRef}>
            Berth Cargo Gear Facility
          </h4>
        </Col>
      </Row>
      {isDry && (
        <>
          <Row>
            <Col>
              <Label>Gear Availability at Berth</Label>
            </Col>
          </Row>
          <Row className="mb-3">
            {metaData.berthMaster &&
              metaData.berthMaster.berthGearsList &&
              metaData.berthMaster.berthGearsList.map(item => {
                let filteredArray = [];
                if (data.berthGearsTransactions)
                  filteredArray = data.berthGearsTransactions.filter(
                    innerItem => innerItem.berthGearsId === item.berthGearsId,
                  );

                return (
                  <Col xs={6} md={2} key={`${item.berthGearsId}`}>
                    <CustomInput
                      type="checkbox"
                      label={item.berthGearsDesc}
                      id={item.berthGearsId}
                      value={item.berthGearsId}
                      name="berthGearsTransactions"
                      checked={filteredArray.length}
                      readOnly={readOnly}
                      disabled={readOnly}
                      onChange={handleBerthInputChange}
                      data-type="array"
                      data-key="berthGearsId"
                    />
                  </Col>
                );
              })}
          </Row>
        </>
      )}

      <Row>
        {!isDry && (
          <>
            <Col xs={6} md>
              {readOnly && (
                <>
                  <Label>Connector Type</Label>
                  {getDescriptionForDropdown(
                    metaData.berthMaster.connectorTypeList,
                    data.connectorTypeId,
                    'connectorTypeId',
                    'connectorTypeDesc',
                  )}
                </>
              )}
              {!readOnly && (
                <Dropdown
                  label="Connector Type"
                  options={metaData.connectorTypeList}
                  onChange={handleBerthInputChange}
                  id="connectorTypeId"
                  name="connectorTypeId"
                  selected={data.connectorTypeId}
                  isDisabled={readOnly}
                />
              )}
            </Col>
          </>
        )}
        <Col xs={6} md>
          <Label htmlFor="connectionFlangeSize">Connector Flange Size</Label>
          {readOnly && data.connectionFlangeSize}
          {!readOnly && (
            <Input
              id="connectionFlangeSize"
              name="connectionFlangeSize"
              onChange={handleBerthInputChange}
              value={data.connectionFlangeSize}
              readOnly={readOnly}
              maxLength={50}
            />
          )}
        </Col>
        <Col xs={6} md>
          <Label htmlFor="gearNotes">Gear Notes</Label>
          {readOnly && data.gearNotes}
          {!readOnly && (
            <Input
              type="textarea"
              name="gearNotes"
              id="gearNotes"
              value={data.gearNotes}
              onChange={handleBerthInputChange}
              readOnly={readOnly}
            />
          )}
        </Col>
        <Col xs={6} md />
        <Col xs={6} md />
      </Row>
    </>
  );
}

BerthCargoGearFacility.propTypes = {
  passedRef: PropTypes.any,
  metaData: PropTypes.object,
  data: PropTypes.object,
  handleBerthInputChange: PropTypes.func,
  readOnly: PropTypes.bool,
  isDry: PropTypes.bool,
};

export default BerthCargoGearFacility;
