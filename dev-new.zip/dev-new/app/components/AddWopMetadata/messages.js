/*
 * AddWopMetadata Messages
 *
 * This contains all the text for the AddWopMetadata component.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.components.AddWopMetadata';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'This is the AddWopMetadata component!',
  },
});
