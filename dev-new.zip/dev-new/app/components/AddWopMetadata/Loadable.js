/**
 *
 * Asynchronously loads the component for AddWopMetadata
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
