/**
 *
 * AddWopMetadata
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { createStructuredSelector } from 'reselect';
import { compose } from 'redux';

// import { FormattedMessage } from 'react-intl';
import {
  Button,
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
  FormGroup,
  Label,
  Input,
  Row,
  Col,
} from 'reactstrap';

// import messages from './messages';

import './_helper';

import './index.scss';
import { handleFieldChange } from '../../containers/Metadata/actions';
import { makeSelectWOPFormData } from '../../containers/Metadata/selectors';

function AddWopMetadata({
  show,
  fetchModelClose,
  dAddMetaData,
  onFieldChange,
  wopData,
  parentFieldData,
  dClearMetaName,
  dClearMetaCode,
}) {
  function onMetadataAdd() {
    let dataToSubmit;
    if (parentFieldData.selectedFieldId) {
      dataToSubmit = {
        MetadataModule: parentFieldData.metadataModule,
        Master: parentFieldData.metadataEntity,
        Name: wopData[0].wopname.trim(),
        Code: wopData[0].wopcode.trim(),
        ParentEntityId: parentFieldData.selectedFieldId,
      };
    } else {
      dataToSubmit = {
        MetadataModule: parentFieldData.metadataModule,
        Master: parentFieldData.metadataEntity,
        Name: wopData[0].wopname.trim(),
        Code: wopData[0].wopcode.trim(),
      };
    }
    dAddMetaData(dataToSubmit);
    fetchModelClose();
  }
  function onCancel() {
    fetchModelClose();
    dClearMetaName();
    dClearMetaCode();
  }

  return (
    <>
      <Modal
        isOpen={show}
        toggle={() => fetchModelClose({ value: false })}
        className="custom-modal-claims"
      >
        <ModalHeader className="modelheader">Add WOP Metadata</ModalHeader>
        <ModalBody>
          <Row>
            <Col>
              <FormGroup>
                <Label for="exampleAddress">
                  WOP Name<span className="required_cls">*</span>
                </Label>
                <Input
                  type="text"
                  name="wopname"
                  required
                  onChange={onFieldChange}
                  value={wopData[0].wopname ? wopData[0].wopname : ''}
                  maxLength={100}
                />
              </FormGroup>
            </Col>
            <Col>
              <FormGroup>
                <Label for="exampleAddress">
                  WOP Code<span className="required_cls">*</span>
                </Label>
                <Input
                  type="text"
                  name="wopcode"
                  required
                  onChange={onFieldChange}
                  value={wopData[0].wopcode ? wopData[0].wopcode : ''}
                  maxLength={100}
                />
              </FormGroup>
            </Col>
          </Row>
        </ModalBody>
        <ModalFooter>
          <Button
            color="primary"
            onClick={onMetadataAdd}
            disabled={
              !!(
                wopData[0].wopname === undefined ||
                wopData[0].wopname === '' ||
                wopData[0].wopcode === undefined ||
                wopData[0].wopcode === ''
              )
            }
          >
            Add
          </Button>
          <Button color="primary" onClick={onCancel}>
            Cancel
          </Button>
        </ModalFooter>
      </Modal>
    </>
  );
}

AddWopMetadata.propTypes = {
  fetchModelClose: PropTypes.func,
  show: PropTypes.bool.isRequired,
  dAddMetaData: PropTypes.func,
  onFieldChange: PropTypes.func,
  wopData: PropTypes.array,
  parentFieldData: PropTypes.object,
  dClearMetaName: PropTypes.func,
  dClearMetaCode: PropTypes.func,
};

const mapStateToProps = createStructuredSelector({
  wopData: makeSelectWOPFormData(),
});
function mapDispatchToProps(dispatch) {
  return {
    onFieldChange: event => {
      event.preventDefault();
      const { name, value } = event.target;
      dispatch(handleFieldChange({ name, value }));
    },
    dClearMetaName: () =>
      dispatch(handleFieldChange({ name: 'wopname', value: '' })),
    dClearMetaCode: () =>
      dispatch(handleFieldChange({ name: 'wopcode', value: '' })),
    // dHandleSubmitClick: event => dispatch(handleSubmitClick(event)),
    // dLogout: () => dispatch(logout()),
  };
}
const withConnect = connect(
  mapStateToProps,
  mapDispatchToProps,
);
export default compose(withConnect)(AddWopMetadata);
