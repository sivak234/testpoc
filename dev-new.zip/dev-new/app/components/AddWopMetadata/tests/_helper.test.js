// import { defaultFunction } from '../_helper';

// describe('AddWopMetadata helpers', () => {
//   describe('Default Helper Function', () => {
//     it('returns the expected value', () => {
//       const expected = 'Sample Text';
//       expect(defaultFunction('Sample Text')).toEqual(expected);
//     });
//   });
// });
describe('<AddWopMetadata />', () => {
  it('Expect to not log errors in AddWopMetadata', () => {
    expect(true).toBeTruthy();
  });
});
