/**
 *
 * AisMapPopOver
 *
 */

import React, { memo } from 'react';

import { InfoWindow } from 'react-google-maps';
import { PropTypes } from 'prop-types';

function AisMapPopOver({ vessel }) {
  let vesselLng = '';
  let vesselLat = '';
  const showPopover =
    vessel &&
    vessel !== '' &&
    vessel.vesselLng &&
    vessel.vesselLat !== undefined;
  if (
    vessel &&
    vessel !== '' &&
    vessel.vesselLng &&
    vessel.vesselLat !== undefined
  ) {
    vesselLng = parseFloat(vessel.vesselLng);
    vesselLat = parseFloat(vessel.vesselLat) + 0.91;
  }
  // let latLang = [];

  return (
    <div>
      {' '}
      {showPopover ? (
        <InfoWindow
          maxWidth={800}
          position={{
            lat: vesselLat,
            lng: vesselLng,
          }}
        >
          <div id="mapOverPStyle">
            <p className="pStyle">
              Name <span>: </span> {vessel.vesselName}{' '}
            </p>{' '}
            <p className="pStyle">
              Vessel Type <span>: </span> {vessel.vesselType}{' '}
            </p>{' '}
            <p className="pStyle">
              Vessel Heading <span>: </span> {vessel.vesselHeading}{' '}
            </p>{' '}
          </div>{' '}
        </InfoWindow>
      ) : (
        ''
      )}{' '}
    </div>
  );
}

AisMapPopOver.propTypes = {
  vessel: PropTypes.array,
};
export default memo(AisMapPopOver);
