/*
 * AisMapPopOver Messages
 *
 * This contains all the text for the AisMapPopOver component.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.components.AisMapPopOver';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'This is the AisMapPopOver component!',
  },
});
