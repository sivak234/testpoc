/**
 *
 * Asynchronously loads the component for AisMapPopOver
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
