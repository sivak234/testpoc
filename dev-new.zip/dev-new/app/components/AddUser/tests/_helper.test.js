// import { defaultFunction } from '../_helper';

// describe('AddUser helpers', () => {
//   describe('Default Helper Function', () => {
//     it('returns the expected value', () => {
//       const expected = 'Sample Text';
//       expect(defaultFunction('Sample Text')).toEqual(expected);
//     });
//   });
// });
describe('<AddUser />', () => {
  it('Expect to not log errors in AddUser', () => {
    expect(true).toBeTruthy();
  });
});
