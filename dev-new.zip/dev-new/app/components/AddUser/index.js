/**
 *
 * AddUser
 *
 */

import React, { memo } from 'react';
import PropTypes from 'prop-types';
import { Button, Form, Row, Col } from 'reactstrap';

import { FormattedMessage } from 'react-intl';
import messages from './messages';

import './_helper';

import './index.scss';

function AddUser({ addUserModel, handleAddUserModel, editUserFlag }) {
  const AddUserTrigger = () => {
    handleAddUserModel(addUserModel, editUserFlag);
  };
  return (
    <>
      <Form>
        <Row>
          <Col xs={10}>
            <h3 className="Compose-API-Header">
              <FormattedMessage {...messages.header} />
            </h3>
          </Col>
          <Col xs={2}>
            <Button
              color="primary"
              type="button"
              onClick={() => AddUserTrigger()}
            >
              <FormattedMessage {...messages.addUser} />
            </Button>
          </Col>
        </Row>
        <hr />
      </Form>
    </>
  );
}

AddUser.propTypes = {
  addUserModel: PropTypes.bool.isRequired,
  editUserFlag: PropTypes.bool.isRequired,
  handleAddUserModel: PropTypes.func.isRequired,
};

export default memo(AddUser);
