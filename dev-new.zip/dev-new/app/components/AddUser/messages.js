/*
 * AddUser Messages
 *
 * This contains all the text for the AddUser component.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.components.AddUser';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'Add User',
  },
  addUser: {
    id: `${scope}.addUser`,
    defaultMessage: 'ADD USER',
  },
});
