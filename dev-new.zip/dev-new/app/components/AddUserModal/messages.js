/*
 * AddUserModal Messages
 *
 * This contains all the text for the AddUserModal component.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.components.AddUserModal';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'This is the AddUserModal component!',
  },
  updateUser: {
    id: `${scope}.updateUser`,
    defaultMessage: 'Update User',
  },
  userName: {
    id: `${scope}.userName`,
    defaultMessage: 'Integration User Name',
  },
  organisation: {
    id: `${scope}.organisation`,
    defaultMessage: 'Organisation',
  },
  organisationEmail: {
    id: `${scope}.organisationEmail`,
    defaultMessage: 'Organisation Email',
  },
  contactNumber: {
    id: `${scope}.contactNumber`,
    defaultMessage: 'Contact Number',
  },
  region: {
    id: `${scope}.region`,
    defaultMessage: 'Region',
  },
  country: {
    id: `${scope}.country`,
    defaultMessage: 'Country',
  },
  apiAccess: {
    id: `${scope}.apiAccess`,
    defaultMessage: 'API Name',
  },
  extractionType: {
    id: `${scope}.extractionType`,
    defaultMessage: 'Extraction Type',
  },
  extractionDate: {
    id: `${scope}.extractionDate`,
    defaultMessage: 'Extraction Date',
  },
  extractionTime: {
    id: `${scope}.extractionTime`,
    defaultMessage: 'Extraction Time',
  },
  userStatus: {
    id: `${scope}.userStatus`,
    defaultMessage: 'User Status',
  },
  validity: {
    id: `${scope}.validity`,
    defaultMessage: 'Validity',
  },
  generatePassword: {
    id: `${scope}.generatePassword`,
    defaultMessage: 'Generate Password',
  },
  addUser: {
    id: `${scope}.addUser`,
    defaultMessage: 'Add User',
  },
  cancel: {
    id: `${scope}.cancel`,
    defaultMessage: 'Cancel',
  },
  addUserHeader: {
    id: `${scope}.addUserHeader`,
    defaultMessage: 'Add User',
  },
  save: {
    id: `${scope}.save`,
    defaultMessage: 'Save',
  },
  generatePasswordMsg: {
    id: `${scope}.generatePasswordMsg`,
    defaultMessage: 'Generate Password',
  },
  extractionDateWarningMsg: {
    id: `${scope}.extractionDateWarningMsg`,
    defaultMessage:
      'If extraction date is prior to 6 months ,then initial load will be triggered',
  },
  inActiveUserStatus: {
    id: `${scope}.inActiveUserStatus`,
    defaultMessage: 'This User was Inactive status',
  },
  addUserSuccessMsg: {
    id: `${scope}.addUserSuccessMsg`,
    defaultMessage: 'added successfully.',
  },
  updateUserSuccessMsg: {
    id: `${scope}.updateUserSuccessMsg`,
    defaultMessage: 'updated successfully.',
  },
  user: {
    id: `${scope}.user`,
    defaultMessage: 'User',
  },
  userNameEmptyErrMsg: {
    id: `${scope}.userNameEmptyErrMsg`,
    defaultMessage: 'User name should not be empty',
  },
  userNameDuplicateMsg: {
    id: `${scope}.userNameDuplicateMsg`,
    defaultMessage: 'User name is already exists',
  },
  organisationEmptyErrMsg: {
    id: `${scope}.organisationEmptyErrMsg`,
    defaultMessage: 'Organisation should not be empty',
  },
  emailEmptyErrMsg: {
    id: `${scope}.emailEmptyErrMsg`,
    defaultMessage: 'Email should not be empty',
  },
  invalidMail: {
    id: `${scope}.invalidMail`,
    defaultMessage: 'Invalid Email',
  },
  contactEmptyErrMsg: {
    id: `${scope}.contactEmptyErrMsg`,
    defaultMessage: 'Contact Number should not be less than 10',
  },
  regionEmptyErrMsg: {
    id: `${scope}.regionEmptyErrMsg`,
    defaultMessage: 'Select Region',
  },
  region2EmptyErrMsg: {
    id: `${scope}.region2EmptyErrMsg`,
    defaultMessage: 'Region should be select',
  },
  countryEmptyErrMsg: {
    id: `${scope}.countryEmptyErrMsg`,
    defaultMessage: 'Select Country',
  },
  apiNameEmptyErrMsg: {
    id: `${scope}.apiNameEmptyErrMsg`,
    defaultMessage: 'Select API Name',
  },
  extractionTypeEmptyErrMsg: {
    id: `${scope}.extractionTypeEmptyErrMsg`,
    defaultMessage: 'Select Extraction Type',
  },
  userStatusEmptyErrMsg: {
    id: `${scope}.userStatusEmptyErrMsg`,
    defaultMessage: 'Select User Status',
  },
  validityEmptyErrMsg: {
    id: `${scope}.validityEmptyErrMsg`,
    defaultMessage: 'Select Validity',
  },
  validityEndDate: {
    id: `${scope}.validityEndDate`,
    defaultMessage: 'Validity End Date',
  },
  invalidUser: {
    id: `${scope}.invalidUser`,
    defaultMessage: 'User is invalid',
  },
  noApi: {
    id: `${scope}.noApi`,
    defaultMessage: `No API's found for users`,
  },
  userNameRequiredMsgValid: {
    id: `${scope}.userNameRequiredMsgValid`,
    defaultMessage: 'UserName is not vaild',
  },
});
