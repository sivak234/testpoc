// import { defaultFunction } from '../_helper';

// describe('AddUserModal helpers', () => {
//   describe('Default Helper Function', () => {
//     it('returns the expected value', () => {
//       const expected = 'Sample Text';
//       expect(defaultFunction('Sample Text')).toEqual(expected);
//     });
//   });
// });
describe('<AddUserModal />', () => {
  it('Expect to not log errors in AddUserModal', () => {
    expect(true).toBeTruthy();
  });
});
