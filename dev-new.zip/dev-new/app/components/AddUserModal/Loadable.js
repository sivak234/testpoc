/**
 *
 * Asynchronously loads the component for AddUserModal
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
