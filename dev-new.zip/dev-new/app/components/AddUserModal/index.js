/* eslint-disable indent */
/**
 *
 * AddUserModal
 *
 */

import React, { memo, useState, useEffect, useCallback } from 'react';
import PropTypes from 'prop-types';
import {
  Button,
  Modal,
  ModalHeader,
  ModalBody,
  Form,
  Label,
  Input,
  Row,
  Col,
} from 'reactstrap';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import { FormattedMessage, injectIntl, intlShape } from 'react-intl';
import messages from './messages';

import './_helper';

import './index.scss';
import DropDown from '../Dropdown';
import AddUserSuccessMsgModal from '../AddUserSuccessMsgModal/Loadable';
import ForbiddenModal from '../ForbiddenModal/Loadable';
import { FETCH_RECORD_COUNT } from '../../utils/constants';
import {
  userNameValidationRegex,
  emailValidationRegex,
  mobileValidation,
} from '../../utils/validation';
import { userNameCharCheck } from '../../utils/dataValidation';
function AddUserModal({
  show,
  UserAddModalClose,
  UserSuccessModalClose,
  regionOptions,
  countryOptions,
  userApiLists,
  selected,
  onRegionSelected,
  onCountrySelected,
  onAddUserDetails,
  onApiSelected,
  onExtractionTypeSelected,
  onExtractionDateSelected,
  onExtractionTimeSelected,
  onUserStatusSelected,
  onValiditySelected,
  extractionType,
  userStatus,
  editUserFlag,
  successMsgModal,
  triggerAddUserButton,
  triggerUpdateUserButton,
  onValidityYearSelected,
  onValidityMonthSelected,
  onValidityDateSelected,
  onGeneratePassword,
  handleSearchTrigger,
  isSearchUserList,
  intl,
}) {
  const pageDetails = {
    pageNo: 1,
    FETCH_RECORD_COUNT,
  };
  const payload = {};
  const validityYearOptions = [
    'YY',
    '0',
    '1',
    '2',
    '3',
    '4',
    '5',
    '6',
    '7',
    '8',
    '9',
    '10',
  ];
  const validityMonthOptions = [
    'MM',
    '0',
    '1',
    '2',
    '3',
    '4',
    '5',
    '6',
    '7',
    '8',
    '9',
    '10',
    '11',
  ];
  const validityDateOptions = [
    'DD',
    '0',
    '1',
    '2',
    '3',
    '4',
    '5',
    '6',
    '7',
    '8',
    '9',
    '10',
    '11',
    '12',
    '13',
    '14',
    '15',
    '16',
    '17',
    '18',
    '19',
    '20',
    '21',
    '22',
    '23',
    '24',
    '25',
    '26',
    '27',
    '28',
    '29',
    '30',
  ];
  useEffect(() => {
    if (selected.userValidationFlag) {
      setValidationTrigger(false);
    }
    if (selected.generatePasswordMsg === 'UserIsInvalid') {
      setMsgContent(
        intl.formatMessage({
          ...messages.invalidUser,
        }),
      );
      generateStatus('delete');
    } else if (selected.generatePasswordMsg === 'NoAPIsFoundForUser') {
      setMsgContent(
        intl.formatMessage({
          ...messages.noApi,
        }),
      );
      generateStatus('delete');
    } else if (selected.generatePasswordMsg !== '') {
      setMsgContent(selected.generatePasswordMsg);
      generateStatus('success');
    }
  });
  const [, updateState] = React.useState();
  function setUserStatus(data, str) {
    const options = [];
    const optionVal = data;
    data.forEach((item, index) =>
      options.push(
        <option
          key={`${str}_${optionVal[index]}`}
          value={optionVal[index]}
          name={optionVal[index]}
        >
          {item}
        </option>,
      ),
    );
    return options;
  }
  const [validityYear, setValidityYear] = useState([]);
  const [validityMonth, setValidityMonth] = useState([]);
  const [validityDate, setValidityDate] = useState([]);
  useEffect(() => {
    const validityYearOptionsVal = setUserStatus(validityYearOptions, 'year');
    const validityMonthOptionsVal = setUserStatus(
      validityMonthOptions,
      'month',
    );
    const validityDateOptionsVal = setUserStatus(validityDateOptions, 'date');
    setValidityYear(validityYearOptionsVal);
    setValidityMonth(validityMonthOptionsVal);
    setValidityDate(validityDateOptionsVal);
  }, []);

  const [msgContent, setMsgContent] = useState('');
  const [userName, setUserName] = useState('');
  const [email, setEmail] = useState(false);
  const [validationTrigger, setValidationTrigger] = useState(false);
  const [genstatus, generateStatus] = useState('success');
  const validityYearSelect = e => {
    if (e.target.value !== '') {
      const yearVal = parseInt(e.target.value, 10);
      const prevYear =
        selected.validyear === 'YY' ? 0 : parseInt(selected.validyear, 10);
      const currentDate = selected.validity;
      currentDate.setYear(currentDate.getFullYear() - prevYear);
      currentDate.setYear(currentDate.getFullYear() + yearVal);
      const valDate = currentDate;
      const valDateString = `${
        currentDate
          .toISOString()
          .match(/([^T]+)/)[0]
          .split('-')[2]
      }-${
        currentDate
          .toISOString()
          .match(/([^T]+)/)[0]
          .split('-')[1]
      }-${
        currentDate
          .toISOString()
          .match(/([^T]+)/)[0]
          .split('-')[0]
      }`;
      onValiditySelected(valDate, valDateString);
      onValidityYearSelected(parseInt(e.target.value, 10));
    }
  };
  const validityMonthSelect = e => {
    if (e.target.value !== '') {
      const monthVal = parseInt(e.target.value, 10);
      const prevMonth =
        selected.validmonth === 'MM' ? 0 : parseInt(selected.validmonth, 10);
      const currentDate = selected.validity;
      currentDate.setMonth(currentDate.getMonth() - prevMonth);
      currentDate.setMonth(currentDate.getMonth() + monthVal);
      const valDate = currentDate;
      const valDateString = `${
        currentDate
          .toISOString()
          .match(/([^T]+)/)[0]
          .split('-')[2]
      }-${
        currentDate
          .toISOString()
          .match(/([^T]+)/)[0]
          .split('-')[1]
      }-${
        currentDate
          .toISOString()
          .match(/([^T]+)/)[0]
          .split('-')[0]
      }`;
      onValiditySelected(valDate, valDateString);
      onValidityMonthSelected(parseInt(e.target.value, 10));
    }
  };
  const validityDateSelect = e => {
    if (e.target.value !== '') {
      const dateVal = parseInt(e.target.value, 10);
      const prevDate =
        selected.validdate === 'DD' ? 0 : parseInt(selected.validdate, 10);
      const currentDate = selected.validity;
      currentDate.setDate(currentDate.getDate() - prevDate);
      currentDate.setDate(currentDate.getDate() + dateVal);
      const valDate = currentDate;
      const valDateString = `${
        currentDate
          .toISOString()
          .match(/([^T]+)/)[0]
          .split('-')[2]
      }-${
        currentDate
          .toISOString()
          .match(/([^T]+)/)[0]
          .split('-')[1]
      }-${
        currentDate
          .toISOString()
          .match(/([^T]+)/)[0]
          .split('-')[0]
      }`;
      onValiditySelected(valDate, valDateString);
      onValidityDateSelected(parseInt(e.target.value, 10));
    }
  };
  const successModalCloseTrigger = () => {
    UserSuccessModalClose({ value: false });
    setValidationTrigger(false);
    if (isSearchUserList) {
      handleSearchTrigger(pageDetails, isSearchUserList);
    }
  };
  const modalCloseTrigger = () => {
    UserAddModalClose({ value: false });
    setValidationTrigger(false);
  };
  const handleChange = (field, val) => {
    if (field === 'contactnumber') {
      const updatedVal = val.replace(mobileValidation, '');
      payload[field] = updatedVal;
      onAddUserDetails(field, updatedVal);
    } else if (field === 'organisationemail') {
      const mailVal = val.match(emailValidationRegex);
      setEmail(!mailVal);
      onAddUserDetails(field, val);
    } else {
      const updatedVal = val.replace(/[<>=]/g, '');
      payload[field] = updatedVal;
      if (field === 'integrateusername') {
        setUserName(updatedVal);
      }
      onAddUserDetails(field, updatedVal);
    }
  };
  const regionSelector = evt => {
    onRegionSelected(evt.target.value, evt.target.selectedOptions[0].text);
  };
  const apiSelector = evt => {
    onApiSelected(evt.target.value, evt.target.selectedOptions[0].text);
  };
  const countrySelector = evt => {
    onCountrySelected(evt.target.value, evt.target.selectedOptions[0].text);
  };
  const extractionTypeSelector = evt => {
    onExtractionTypeSelected(
      evt.target.value,
      evt.target.selectedOptions[0].text,
    );
  };
  const extractionDateSelector = e => {
    const dateMonthYear = `${e.e.getDate()}/${e.e.getMonth() +
      1}/${e.e.getFullYear()}`;
    onExtractionDateSelected(dateMonthYear);
  };
  const extractionTimeSelector = e => {
    const ampm = e.e.getHours() <= 11 ? 'AM' : 'PM';
    const hours = e.e.getHours() >= 13 ? e.e.getHours() - 12 : e.e.getHours();
    const dateMonthYear = `${hours === 0 ? 12 : hours}:${
      e.e.getMinutes() === 0 ? '00' : e.e.getMinutes()
    } ${ampm}`;
    onExtractionTimeSelected(dateMonthYear);
  };
  const userStatusSelector = evt => {
    onUserStatusSelected(evt.target.value, evt.target.selectedOptions[0].text);
  };
  const UserAddSuccessModal = () => {
    setMsgContent(
      `${intl.formatMessage({
        ...messages.user,
      })} ${userName} ${intl.formatMessage({
        ...messages.addUserSuccessMsg,
      })}`,
    );
    triggerAddUserButton();
    setValidationTrigger(true);
  };
  const UserEditSuccessModal = useCallback(() => {
    triggerUpdateUserButton();
    setValidationTrigger(true);
    setMsgContent(
      `${intl.formatMessage({
        ...messages.user,
      })} ${userName} ${intl.formatMessage({
        ...messages.updateUserSuccessMsg,
      })}`,
    );
    updateState({});
  }, []);
  const generatePassword = () => {
    onGeneratePassword();
    setMsgContent(selected.generatePasswordMsg);
  };
  const sortedUser = options => {
    if (Array.isArray(options)) {
      return options.sort((a, b) =>
        a.props.name &&
        b.props.name &&
        a.props.name.toLowerCase().trim() < b.props.name.toLowerCase().trim()
          ? -1
          : 1,
      );
    }
    return options;
  };
  return (
    <>
      {selected.errorMsgModal === true && (
        <ForbiddenModal
          show={selected.errorMsgModal}
          content={selected.errorMsg}
          modalCloseTrigger={successModalCloseTrigger}
        />
      )}
      {selected.generatePasswordMsg === '' && (
        <AddUserSuccessMsgModal
          show={successMsgModal}
          content={msgContent}
          statusCode="success"
          header={
            editUserFlag === true ? (
              <FormattedMessage {...messages.updateUser} />
            ) : (
              <FormattedMessage {...messages.addUser} />
            )
          }
          successModalCloseTrigger={successModalCloseTrigger}
        />
      )}
      {selected.generatePasswordMsg !== '' && (
        <AddUserSuccessMsgModal
          show={successMsgModal}
          content={msgContent}
          statusCode={genstatus}
          header={<FormattedMessage {...messages.generatePassword} />}
          successModalCloseTrigger={successModalCloseTrigger}
        />
      )}

      {!successMsgModal && (
        <Modal
          md="12"
          isOpen={show}
          toggle={() => modalCloseTrigger()}
          className="custom-modal-claims"
          size="xl"
        >
          <ModalHeader toggle={() => modalCloseTrigger()}>
            {editUserFlag && <FormattedMessage {...messages.updateUser} />}
            {!editUserFlag && <FormattedMessage {...messages.addUserHeader} />}
          </ModalHeader>
          <ModalBody className="text-center">
            <Form>
              <Row>
                <Col xs={12} className="InactiveUser">
                  <>
                    {selected.userStatus === 'Inactive' && editUserFlag && (
                      <h4>
                        <FormattedMessage {...messages.inActiveUserStatus} />
                      </h4>
                    )}
                  </>
                </Col>
              </Row>
              <Row>
                <Col xs={5}>
                  <Row>
                    <Col xs={6} className="Base-API- alignText">
                      <Label>
                        <FormattedMessage {...messages.userName} />
                        <span className="astrick">&nbsp;*</span>
                      </Label>
                      <Input
                        type="text"
                        onChange={event => {
                          const { value } = event.target;
                          if (userNameCharCheck(value)) {
                            handleChange('integrateusername', value);
                          }
                        }}
                        value={selected.integrateusername}
                        maxLength="100"
                        disabled={editUserFlag}
                      />
                      {selected.integrateusername === '' && validationTrigger && (
                        <p className="validation-content">
                          <FormattedMessage {...messages.userNameEmptyErrMsg} />
                        </p>
                      )}
                      {selected.integrateusername !== '' &&
                        validationTrigger &&
                        !selected.integrateusername.match(
                          userNameValidationRegex,
                        ) && (
                          <p className="validation-content">
                            <FormattedMessage
                              {...messages.userNameRequiredMsgValid}
                            />
                          </p>
                        )}
                      {selected.errorMsg ===
                        'User Name is duplicate, Please change the user name' &&
                        validationTrigger && (
                          <p className="validation-content">
                            <FormattedMessage
                              {...messages.userNameDuplicateMsg}
                            />
                          </p>
                        )}
                    </Col>
                    <Col xs={6} className="Base-API- alignText">
                      <Label>
                        <FormattedMessage {...messages.organisation} />
                        <span className="astrick">&nbsp;*</span>
                      </Label>
                      <Input
                        type="text"
                        onChange={e => {
                          handleChange('organisation', e.target.value);
                        }}
                        value={selected.organisation}
                        maxLength="100"
                      />
                      {selected.organisation === '' && validationTrigger && (
                        <p className="validation-content">
                          <FormattedMessage
                            {...messages.organisationEmptyErrMsg}
                          />
                        </p>
                      )}
                    </Col>
                  </Row>
                </Col>
                <Col xs={7}>
                  <Row>
                    <Col xs={4} className="Base-API- alignText">
                      <Label>
                        <FormattedMessage {...messages.organisationEmail} />
                        <span className="astrick">&nbsp;*</span>
                      </Label>
                      <Input
                        type="text"
                        onChange={e => {
                          handleChange('organisationemail', e.target.value);
                        }}
                        value={selected.organisationemail}
                        maxLength="100"
                        disabled={editUserFlag}
                      />
                      {selected.organisationemail === '' && validationTrigger && (
                        <p className="validation-content">
                          <FormattedMessage {...messages.emailEmptyErrMsg} />
                        </p>
                      )}
                      {email &&
                        validationTrigger &&
                        selected.organisationemail !== '' && (
                          <p className="validation-content">
                            <FormattedMessage {...messages.invalidMail} />
                          </p>
                        )}
                    </Col>
                    <Col xs={4} className="Base-API- alignText">
                      <Label>
                        <FormattedMessage {...messages.contactNumber} />
                        <span className="astrick">&nbsp;*</span>
                      </Label>
                      <Input
                        type="text"
                        onChange={e => {
                          handleChange('contactnumber', e.target.value, e);
                        }}
                        value={selected.contactnumber}
                        maxLength={15}
                      />
                      {selected.contactnumber.length <= 9 && validationTrigger && (
                        <p className="validation-content">
                          <FormattedMessage {...messages.contactEmptyErrMsg} />
                        </p>
                      )}
                    </Col>
                    <Col xs={4} className="Base-API- alignText">
                      <Label>
                        <FormattedMessage {...messages.region} />
                        <span className="astrick">&nbsp;*</span>
                      </Label>
                      <DropDown
                        options={sortedUser(regionOptions)}
                        onChange={evt => regionSelector(evt)}
                        selected={selected.regionId}
                      />
                      {selected.regionId === '0' && validationTrigger && (
                        <p className="validation-content">
                          <FormattedMessage {...messages.regionEmptyErrMsg} />
                        </p>
                      )}
                      {selected.regionId === '' && validationTrigger && (
                        <p className="validation-content">
                          <FormattedMessage {...messages.region2EmptyErrMsg} />
                        </p>
                      )}
                    </Col>
                  </Row>
                </Col>
              </Row>
              <Row>
                <Col xs={5}>
                  <Row>
                    <Col xs={6} className="Base-API- alignText">
                      <Label>
                        <FormattedMessage {...messages.country} />
                        <span className="astrick">&nbsp;*</span>
                      </Label>
                      <DropDown
                        options={sortedUser(countryOptions)}
                        onChange={evt => countrySelector(evt)}
                        selected={selected.countryId}
                      />
                      {selected.countryId === '' && validationTrigger && (
                        <p className="validation-content">
                          <FormattedMessage {...messages.countryEmptyErrMsg} />
                        </p>
                      )}
                      {selected.countryId === '0' && validationTrigger && (
                        <p className="validation-content">
                          <FormattedMessage {...messages.countryEmptyErrMsg} />
                        </p>
                      )}
                    </Col>
                    <Col xs={6} className="Base-API- alignText">
                      <Label>
                        <FormattedMessage {...messages.apiAccess} />
                        <span className="astrick">&nbsp;*</span>
                      </Label>
                      <DropDown
                        options={sortedUser(userApiLists)}
                        onChange={evt => apiSelector(evt)}
                        selected={selected.apiid}
                        isDisabled={editUserFlag}
                      />
                      {selected.apiid === '' && validationTrigger && (
                        <p className="validation-content">
                          <FormattedMessage {...messages.apiNameEmptyErrMsg} />
                        </p>
                      )}
                      {selected.apiid === '0' && validationTrigger && (
                        <p className="validation-content">
                          <FormattedMessage {...messages.apiNameEmptyErrMsg} />
                        </p>
                      )}
                    </Col>
                  </Row>
                </Col>
                <Col xs={7}>
                  <Row>
                    <Col xs={4} className="Base-API- alignText">
                      <Label>
                        <FormattedMessage {...messages.extractionType} />
                        <span className="astrick">&nbsp;*</span>
                      </Label>
                      <DropDown
                        options={extractionType}
                        onChange={evt => extractionTypeSelector(evt)}
                        selected={selected.id}
                        isDisabled={editUserFlag}
                      />
                      {selected.id === '' && validationTrigger && (
                        <p className="validation-content">
                          <FormattedMessage
                            {...messages.extractionTypeEmptyErrMsg}
                          />
                        </p>
                      )}
                    </Col>
                    <Col xs={8} className="Base-API-">
                      <Row>
                        <Col xs={6} className="Base-API- alignText">
                          <Label>
                            <FormattedMessage {...messages.extractionDate} />
                          </Label>
                          <DatePicker
                            value={selected.extractionDate}
                            onChange={e => extractionDateSelector({ e })}
                            dateFormat="dd-MM-yyyy"
                            maxDate={new Date()}
                          />
                        </Col>
                        <Col xs={6} className="Base-API- alignText">
                          <Label>
                            <FormattedMessage {...messages.extractionTime} />
                          </Label>
                          <DatePicker
                            value={selected.extractionTime}
                            onChange={e => extractionTimeSelector({ e })}
                            showTimeSelect
                            showTimeSelectOnly
                            timeIntervals={15}
                            dateFormat="h:mm aa"
                            timeCaption="Time"
                          />
                        </Col>
                      </Row>
                      {new Date().setMonth(new Date().getMonth() - 6) >
                        new Date(selected.extractionDate).setMonth(
                          new Date(selected.extractionDate).getMonth(),
                        ) &&
                        selected.extractionDate !== null && (
                          <p>
                            <FormattedMessage
                              {...messages.extractionDateWarningMsg}
                            />
                          </p>
                        )}
                    </Col>
                  </Row>
                </Col>
              </Row>
              <Row>
                <Col xs={5}>
                  <Row>
                    <Col xs={6} className="Base-API- alignText">
                      <Label>
                        <FormattedMessage {...messages.userStatus} />
                        <span className="astrick">&nbsp;*</span>
                      </Label>
                      <DropDown
                        options={userStatus}
                        onChange={evt => userStatusSelector(evt)}
                        selected={selected.userStatus}
                        isDisabled={!editUserFlag}
                      />
                      {selected.userStatus === '' && validationTrigger && (
                        <p className="validation-content">
                          <FormattedMessage
                            {...messages.userStatusEmptyErrMsg}
                          />
                        </p>
                      )}
                    </Col>
                    <Col xs={6} className="Base-API- alignText">
                      <Label>
                        <FormattedMessage {...messages.validity} />
                        <span className="astrick">&nbsp;*</span>
                      </Label>
                      <div className="dropdownInline">
                        <DropDown
                          options={validityYear}
                          onChange={evt => validityYearSelect(evt)}
                          selected={selected.validyear}
                        />
                        <DropDown
                          options={validityMonth}
                          onChange={evt => validityMonthSelect(evt)}
                          selected={selected.validmonth}
                        />
                        <DropDown
                          options={validityDate}
                          onChange={evt => validityDateSelect(evt)}
                          selected={selected.validdate}
                        />
                      </div>
                      {selected.validyear === null &&
                        selected.validmonth === null &&
                        selected.validdate === null &&
                        validationTrigger && (
                          <p className="validation-content">
                            <FormattedMessage
                              {...messages.validityEmptyErrMsg}
                            />
                          </p>
                        )}
                      {(selected.validyear === 'YY' ||
                        selected.validyear === 0) &&
                        (selected.validmonth === 'MM' ||
                          selected.validmonth === 0) &&
                        (selected.validdate === 'DD' ||
                          selected.validdate === 0) &&
                        validationTrigger && (
                          <p className="validation-content">
                            <FormattedMessage
                              {...messages.validityEmptyErrMsg}
                            />
                          </p>
                        )}
                    </Col>
                  </Row>
                </Col>
                <Col xs={7}>
                  <Row>
                    <Col xs={4} className="Base-API- alignText">
                      <Label>
                        <FormattedMessage {...messages.validityEndDate} />
                      </Label>
                      <Input
                        selected={selected.validityString}
                        type="text"
                        value={selected.validityString}
                        disabled
                      />
                    </Col>
                  </Row>
                </Col>
              </Row>
              <Row className="modal-submit-button">
                <Col xs={12} className="button-align-center">
                  <span className="button-end">
                    {editUserFlag && (
                      <Button
                        className="buttonTop buttonLeft"
                        outline
                        color="primary"
                        type="button"
                        onClick={() => {
                          generatePassword();
                        }}
                      >
                        <FormattedMessage {...messages.generatePassword} />
                      </Button>
                    )}
                    {!editUserFlag && (
                      <Button
                        className="buttonTop buttonLeft"
                        outline
                        color="primary"
                        type="button"
                        onClick={() => UserAddSuccessModal()}
                      >
                        <FormattedMessage {...messages.addUser} />
                      </Button>
                    )}
                    {editUserFlag && (
                      <Button
                        outline
                        color="primary"
                        className="buttonTop buttonLeft"
                        type="button"
                        onClick={() => UserEditSuccessModal()}
                      >
                        <FormattedMessage {...messages.save} />
                      </Button>
                    )}
                    <Button
                      outline
                      className="buttonTop buttonLeft"
                      color="primary"
                      type="button"
                      onClick={() => {
                        modalCloseTrigger();
                      }}
                    >
                      <FormattedMessage {...messages.cancel} />
                    </Button>
                  </span>
                </Col>
              </Row>
            </Form>
          </ModalBody>
        </Modal>
      )}
    </>
  );
}

AddUserModal.propTypes = {
  UserAddModalClose: PropTypes.func,
  UserSuccessModalClose: PropTypes.func,
  show: PropTypes.bool,
  fChangeEquationConstantValue: PropTypes.func,
  regionOptions: PropTypes.array.isRequired,
  countryOptions: PropTypes.array.isRequired,
  userApiLists: PropTypes.array.isRequired,
  selected: PropTypes.object.isRequired,
  onRegionSelected: PropTypes.func.isRequired,
  onCountrySelected: PropTypes.func.isRequired,
  successModalCloseTrigger: PropTypes.func,
  onAddUserDetails: PropTypes.func.isRequired,
  onApiSelected: PropTypes.func.isRequired,
  onExtractionTypeSelected: PropTypes.func.isRequired,
  onExtractionDateSelected: PropTypes.func.isRequired,
  onExtractionTimeSelected: PropTypes.func.isRequired,
  onUserStatusSelected: PropTypes.func.isRequired,
  onValiditySelected: PropTypes.func.isRequired,
  extractionType: PropTypes.array.isRequired,
  userStatus: PropTypes.array.isRequired,
  editUserFlag: PropTypes.bool,
  successMsgModal: PropTypes.bool,
  triggerAddUserButton: PropTypes.func.isRequired,
  triggerUpdateUserButton: PropTypes.func.isRequired,
  onValidityYearSelected: PropTypes.func.isRequired,
  onValidityMonthSelected: PropTypes.func.isRequired,
  onValidityDateSelected: PropTypes.func.isRequired,
  onGeneratePassword: PropTypes.func.isRequired,
  handleSearchTrigger: PropTypes.func.isRequired,
  isSearchUserList: PropTypes.bool.isRequired,
  intl: intlShape.isRequired,
};

export default memo(injectIntl(AddUserModal));
