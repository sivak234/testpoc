/**
 *
 * Asynchronously loads the component for AisAutoComplete
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
