/**
 *
 * AisAutoComplete
 *
 */
import React, { memo, Component } from 'react';
import PropTypes from 'prop-types';
import { Button, Input } from 'reactstrap';
import './AutoComplete.scss';

class AisAutoComplete extends Component {
  static propTypes = {
    suggestions: PropTypes.instanceOf(Array),
    type: PropTypes.string,
    fetchPortName: PropTypes.func,
    fetchVesselName: PropTypes.func,
    handleItemChanged: PropTypes.func,
    rowId: PropTypes.any,
    fieldName: PropTypes.any,
    value: PropTypes.any,
    changeFieldName: PropTypes.any,
    autoFocusText: PropTypes.bool,
    dAutoCompletePopover: PropTypes.func,
    isShowAutoCompletepopOver: PropTypes.bool,
    fetchAisVesselDraught: PropTypes.func,
  };

  static defaultProperty = {
    suggestions: [],
  };

  constructor(props) {
    super(props);
    this.state = {
      activeSuggestion: 0,
      filteredSuggestions: this.props.suggestions,
      userInput: this.props.value,
    };
  }

  static getDerivedStateFromProps(nextProps) {
    if (nextProps.suggestions.length > 0) {
      return {
        filteredSuggestions: nextProps.suggestions,
      };
    }
    if (nextProps.portName.length > 0) {
      return {
        filteredSuggestions: nextProps.portName,
      };
    }
    return [];
  }

  onChange = e => {
    if (this.props.type === 'vesselName') {
      const vesselName = e.currentTarget.value;
      if (vesselName.length >= 3) {
        this.props.fetchVesselName(vesselName);
        this.props.handleItemChanged({
          rowId: this.props.rowId,
          fieldName: this.props.fieldName,
          value: e.currentTarget.value,
        });
      }
    } else {
      const portName = e.currentTarget.value;
      if (portName.length >= 3) {
        this.props.fetchPortName(portName);
        this.props.handleItemChanged({
          rowId: this.props.rowId,
          fieldName: this.props.fieldName,
          value: e.currentTarget.value,
        });
      }
    }
    const { suggestions } = this.props;
    const userInput = e.currentTarget.value;
    if (userInput.length < 3) {
      this.props.handleItemChanged({
        rowId: this.props.rowId,
        fieldName: this.props.fieldName,
        value: e.currentTarget.value,
      });
    }
    this.props.dAutoCompletePopover(true);
    this.setState({
      activeSuggestion: 0,
      filteredSuggestions: suggestions,
      userInput: e.currentTarget.value,
    });
  };

  onClick = selected => {
    if (this.props.type === 'vesselName') {
      this.props.handleItemChanged({
        rowId: this.props.rowId,
        fieldName: this.props.fieldName,
        value: selected,
      });
      this.props.fetchAisVesselDraught(selected.imo);
    } else {
      this.props.handleItemChanged({
        rowId: this.props.rowId,
        fieldName: this.props.fieldName,
        value: selected,
      });
    }
    this.props.dAutoCompletePopover(false);
    this.setState({
      activeSuggestion: 0,
      filteredSuggestions: [],
    });
  };

  onKeyDown = e => {
    const { activeSuggestion, filteredSuggestions } = this.state;

    if (e.keyCode === 13) {
      this.props.dAutoCompletePopover(false);
      this.setState({
        activeSuggestion: 0,
        userInput: filteredSuggestions[activeSuggestion],
      });
    } else if (e.keyCode === 38) {
      if (activeSuggestion === 0) {
        return;
      }

      this.setState({
        activeSuggestion: activeSuggestion - 1,
      });
    } else if (e.keyCode === 40) {
      if (activeSuggestion - 1 === filteredSuggestions.length) {
        return;
      }
      this.setState({
        activeSuggestion: activeSuggestion + 1,
      });
    }
  };

  render() {
    const {
      onChange,
      onClick,
      onKeyDown,
      state: { filteredSuggestions, userInput },
    } = this;
    let suggestionsListComponent;
    if (this.props.isShowAutoCompletepopOver) {
      if (filteredSuggestions.length > 0) {
        suggestionsListComponent = (
          <ul style={{ width: 'auto' }}>
            {filteredSuggestions.map(suggestion => {
              let className;
              let name = '';
              let id = '';
              let selected = {};
              if (
                this.props.type === 'vesselName' &&
                this.props.type === this.props.changeFieldName
              ) {
                name = suggestion.vesselName;
                id = suggestion.vesselId;
                selected = {
                  name: suggestion.vesselName,
                  imo: suggestion.imo,
                  id: suggestion.vesselId,
                };
              } else if (
                this.props.type === 'previousPortName' &&
                this.props.type === this.props.changeFieldName
              ) {
                name = suggestion.portCode;
                id = suggestion.portId;
                selected = {
                  name: suggestion.portCode,
                  id: suggestion.portId,
                };
              } else if (
                this.props.type === 'nextPortName' &&
                this.props.type === this.props.changeFieldName
              ) {
                name = suggestion.portCode;
                id = suggestion.portId;
                selected = {
                  name: suggestion.portCode,
                  id: suggestion.portId,
                  unlocode: suggestion.unlocode,
                };
              } else if (
                this.props.type === 'portName' &&
                this.props.type === this.props.changeFieldName
              ) {
                name = suggestion.portCode;
                id = suggestion.portId;
                selected = {
                  name: suggestion.portCode,
                  id: suggestion.portId,
                  unlocode: suggestion.unlocode,
                };
              }
              return (
                <li className={className} key={id}>
                  <Button
                    color="link"
                    className="p-0"
                    value={selected}
                    onClick={() => onClick(selected)}
                  >
                    {name}
                  </Button>
                </li>
              );
            })}
          </ul>
        );
      } else {
        suggestionsListComponent = (
          <div className="boxBorder">
            <em> </em>
          </div>
        );
      }
    }

    return (
      <React.Fragment>
        <div className="AisAutoCompleteText">
          <Input
            type="text"
            onChange={onChange}
            onKeyDown={onKeyDown}
            value={userInput}
            placeholder="Search.."
            autoFocus={this.props.autoFocusText}
          />
          {this.props.type === this.props.changeFieldName &&
            suggestionsListComponent}
        </div>
      </React.Fragment>
    );
  }
}

export default memo(AisAutoComplete);
