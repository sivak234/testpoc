/*
 * AddRoleManagementModol Messages
 *
 * This contains all the text for the AddRoleManagementModol component.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.components.AddRoleManagementModol';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'Role',
  },
  roleName: {
    id: `${scope}.roleName`,
    defaultMessage: 'Role Name',
  },
  roleNameExistMsg: {
    id: `${scope}.roleNameExistMsg`,
    defaultMessage: 'Role Name already exists',
  },
  copyRole: {
    id: `${scope}.copyRole`,
    defaultMessage: 'Copy Role',
  },
  roleDescription: {
    id: `${scope}.roleDescription`,
    defaultMessage: 'Role Description',
  },
  defaultPeriod: {
    id: `${scope}.defaultPeriod`,
    defaultMessage: 'Default Period',
  },
  permissionsHeader: {
    id: `${scope}.permissionsHeader`,
    defaultMessage: 'Permissions',
  },
  tableHeaderScreen: {
    id: `${scope}.tableHeaderScreen`,
    defaultMessage: 'Screens',
  },
  tableHeaderView: {
    id: `${scope}.tableHeaderView`,
    defaultMessage: 'View',
  },
  tableHeaderEdit: {
    id: `${scope}.tableHeaderEdit`,
    defaultMessage: 'Edit',
  },
  tableHeaderCreate: {
    id: `${scope}.tableHeaderCreate`,
    defaultMessage: 'Create',
  },
  tableHeaderDelete: {
    id: `${scope}.tableHeaderDelete`,
    defaultMessage: 'Delete',
  },
  tableHeaderPublish: {
    id: `${scope}.tableHeaderPublish`,
    defaultMessage: 'Publish',
  },
  addRoleBtn: {
    id: `${scope}.addRoleBtn`,
    defaultMessage: 'Add Role',
  },
  saveRoleBtn: {
    id: `${scope}.saveRoleBtn`,
    defaultMessage: 'Save',
  },
  cancelRoleBtn: {
    id: `${scope}.cancelRoleBtn`,
    defaultMessage: 'Cancel',
  },
});
