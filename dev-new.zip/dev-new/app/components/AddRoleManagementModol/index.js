/* eslint-disable react/no-find-dom-node */
/* eslint-disable react/no-danger */
/* eslint-disable array-callback-return */
/**
 *
 * AddRoleManagementModol
 *
 */

import React, { useState, createRef } from 'react';
import ReactDOM from 'react-dom';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { compose } from 'redux';
import { createStructuredSelector } from 'reselect';
import { FormattedMessage, injectIntl } from 'react-intl';
import {
  Modal,
  ModalHeader,
  ModalBody,
  Form,
  Label,
  Input,
  Row,
  Col,
  Button,
} from 'reactstrap';
import DropDown from '../Dropdown';
import {
  dateOptions,
  monthOptions,
  yearOptions,
  getViewDefaultPeriodStr,
} from './_helper';
import './index.scss';
import messages from './messages';
import { makeSelectedRoleDates } from '../../containers/UserRoleManagement/selectors';
import { filteredAccess } from '../../utils/rbac';
function AddRoleManagementModol({
  show,
  addUserModalClose,
  roleAddUserDetails,
  permissions1,
  handleRoleAdddetails,
  addRoleDetails,
  viewRoleResults,
  viewRoleflag,
  updateRoleResults,
  updateRoleFlag,
  handleUpdateEditButtonRole,
  selected,
  handleChangeMonth,
  handleChangeDate,
  handleChangeYear,
  copyEditRole,
  handleCopyRole,
  isRoleNameExists,
  roleNameExistsFunc,
  roleFieldData,
  selectedDateMonthYear,
  moduleId,
}) {
  let permissions = [];
  const handleChange = (field, val) => {
    if (field === 'roleName') {
      if (!val.match(/[^a-zA-Z0-9 ]/g)) {
        const updatedVal = val.replace(/[^a-zA-Z0-9 ]/g, '');
        addRoleDetails(field, updatedVal);
      }
    } else if (field === 'roleDescription') {
      if (!val.match(/[^a-zA-Z0-9 , . # / | $ - @ _ & ]/g)) {
        const updatedVal = val.replace(/[^a-zA-Z0-9 , . # / | $ - @ _ & ]/g);
        addRoleDetails(field, updatedVal);
      }
    } else {
      addRoleDetails(field, val);
    }
  };
  const handleEditCopy = () => {
    handleCopyRole();
  };
  const roleComponentRef = createRef();
  const roleTextRef = createRef();
  const sumbitAdd = () => {
    const isValid = validateForm();
    if (isValid) {
      roleNameExistsFunc();
    } else {
      roleComponentRef.current.scrollIntoView();
      const roleName = ReactDOM.findDOMNode(roleTextRef.current).value;
      if (roleName === '') {
        ReactDOM.findDOMNode(roleTextRef.current).focus();
      }
    }
  };
  const closeDialog = () => {
    addUserModalClose({ value: false });
    setRoleName('');
    dateErrorContent('');
    permissionErrorMessagesetContent('');
  };
  const [rolenameerror, setRoleName] = useState('');
  const [dateErrors, dateErrorContent] = useState('');
  const [permErrors, permissionErrorMessagesetContent] = useState('');
  const validateForm = () => {
    let roleNameError = '';
    let permissionErrorMessage = '';
    let dateError = '';
    let isValid = true;
    let permissionError = true;
    if (roleFieldData.roleName === '') {
      roleNameError = 'Please provide Role Name';
      setRoleName(roleNameError);
      isValid = false;
    } else {
      setRoleName(roleNameError);
    }
    let isYearValid = false;
    let isMonthValid = false;
    let isDateValid = false;
    if (
      selectedDateMonthYear.year === 'YY' ||
      selectedDateMonthYear.year === '00'
    ) {
      isYearValid = true;
    }
    if (
      selectedDateMonthYear.month === 'MM' ||
      selectedDateMonthYear.month === '00'
    ) {
      isMonthValid = true;
    }
    if (
      selectedDateMonthYear.date === 'DD' ||
      selectedDateMonthYear.date === '00'
    ) {
      isDateValid = true;
    }
    if (
      selectedDateMonthYear.year === 'YY' &&
      selectedDateMonthYear.month === 'MM' &&
      selectedDateMonthYear.date === 'DD'
    ) {
      dateError = 'Please choose Default Period';
      dateErrorContent(dateError);
      isValid = false;
    } else if (
      selectedDateMonthYear.year === '00' &&
      selectedDateMonthYear.month === '00' &&
      selectedDateMonthYear.date === '00'
    ) {
      dateError = 'Please choose Default Period';
      dateErrorContent(dateError);
      isValid = false;
    } else if (isYearValid && isMonthValid && isDateValid) {
      dateError = 'Please choose Default Period';
      dateErrorContent(dateError);
      isValid = false;
    } else {
      dateErrorContent(dateError);
    }

    permissions.map(e => {
      // eslint-disable-next-line no-restricted-syntax
      for (const m in e) {
        if (e[m] === true) {
          permissionError = false;
          break;
        }
      }
    });

    if (permissionError) {
      permissionErrorMessage = 'Please choose Permissions';
      permissionErrorMessagesetContent(permissionErrorMessage);
      isValid = false;
    } else {
      permissionErrorMessagesetContent(permissionErrorMessage);
    }
    return isValid;
  };
  const sumbitUpdate = () => {
    const isValid = validateForm();
    if (isValid) {
      handleUpdateEditButtonRole();
    } else {
      roleComponentRef.current.scrollIntoView();
    }
  };
  const onPermissionStatusChange = evt => {
    const otherScreens = permissions.map(screen => {
      if (screen.name === evt.target.name) {
        if (
          evt.target.getAttribute('action') === 'publish' &&
          evt.target.checked
        ) {
          return {
            ...screen,
            view: true,
            create: true,
            delete: true,
            edit: true,
            publish: true,
            actionName: evt.target.getAttribute('action'),
          };
        }
        if (
          evt.target.getAttribute('action') === 'edit' &&
          evt.target.checked
        ) {
          return {
            ...screen,
            view: true,
            edit: true,
            actionName: evt.target.getAttribute('action'),
          };
        }
        if (
          evt.target.getAttribute('action') === 'delete' &&
          evt.target.checked
        ) {
          return {
            ...screen,
            view: true,
            edit: true,
            delete: true,
            create: true,
            actionName: evt.target.getAttribute('action'),
          };
        }
        if (
          evt.target.getAttribute('action') === 'view' &&
          evt.target.checked
        ) {
          return {
            ...screen,
            view: true,
            actionName: evt.target.getAttribute('action'),
          };
        }
        if (
          evt.target.getAttribute('action') === 'view' &&
          !evt.target.checked
        ) {
          return {
            ...screen,
            view: false,
            actionName: evt.target.getAttribute('action'),
          };
        }
        if (
          evt.target.getAttribute('action') === 'create' &&
          evt.target.checked
        ) {
          return {
            ...screen,
            view: true,
            create: true,
            edit: true,
            actionName: evt.target.getAttribute('action'),
          };
        }
        if (
          evt.target.getAttribute('action') === 'publish' &&
          !evt.target.checked
        ) {
          return {
            ...screen,
            view: false,
            create: false,
            delete: false,
            edit: false,
            publish: false,
            actionName: evt.target.getAttribute('action'),
          };
        }
        if (
          evt.target.getAttribute('action') === 'edit' &&
          !evt.target.checked
        ) {
          return {
            ...screen,
            view: false,
            edit: false,
            actionName: evt.target.getAttribute('action'),
          };
        }
        if (
          evt.target.getAttribute('action') === 'create' &&
          !evt.target.checked
        ) {
          return {
            ...screen,
            view: false,
            create: false,
            edit: false,
            actionName: evt.target.getAttribute('action'),
          };
        }
        if (
          evt.target.getAttribute('action') === 'delete' &&
          !evt.target.checked
        ) {
          return {
            ...screen,
            view: false,
            edit: false,
            delete: false,
            create: false,
            actionName: evt.target.getAttribute('action'),
          };
        }
        return {
          ...screen,
          [evt.target.getAttribute('action')]: evt.target.checked,
        };
      }
      return screen;
    });

    handleRoleAdddetails(otherScreens);
  };

  if (roleAddUserDetails !== undefined && permissions1.length === 0) {
    if (
      roleAddUserDetails.modules !== undefined &&
      roleAddUserDetails.modules.length > 0 &&
      viewRoleflag === false &&
      updateRoleFlag === false
    ) {
      const orderedModuleList = roleAddUserDetails.modules.sort(
        (a, b) => a.moduleId - b.moduleId,
      );
      // eslint-disable-next-line array-callback-return
      orderedModuleList.map(moduleObj => {
        const permissionObj = {
          name: moduleObj.moduleDescription,
          moduleId: moduleObj.moduleId,
          view: false,
          edit: false,
          create: false,
          delete: false,
          publish: false,
        };
        permissions.push(permissionObj);
      });
    } else if (updateRoleFlag === true) {
      const orderedModuleList = updateRoleResults.moduleList.sort(
        (a, b) => a.moduleId - b.moduleId,
      );
      // eslint-disable-next-line array-callback-return
      orderedModuleList.map(moduleObj => {
        const permissionObj = {
          name: moduleObj.moduleDescription,
          moduleId: moduleObj.moduleId,
          view: moduleObj.functionAccess.isView,
          edit: moduleObj.functionAccess.isEdit,
          create: moduleObj.functionAccess.isCreate,
          delete: moduleObj.functionAccess.isDelete,
          publish: moduleObj.functionAccess.isPublish,
        };
        if (
          permissionObj.view === true &&
          permissionObj.create === true &&
          permissionObj.edit === true &&
          permissionObj.delete === true &&
          permissionObj.publish === true
        ) {
          permissionObj.actionName = 'publish';
        } else if (
          permissionObj.view === true &&
          permissionObj.create === true &&
          permissionObj.edit === true &&
          permissionObj.delete === true
        ) {
          permissionObj.actionName = 'delete';
        } else if (
          permissionObj.view === true &&
          permissionObj.create === true &&
          permissionObj.edit === true
        ) {
          permissionObj.actionName = 'create';
        } else if (permissionObj.view === true && permissionObj.edit === true) {
          permissionObj.actionName = 'edit';
        } else if (permissionObj.view === true) {
          permissionObj.actionName = 'view';
        }
        permissions.push(permissionObj);
      });
      handleRoleAdddetails(permissions);
    }
  }
  const permissionsArr = [];
  if (
    permissions.length > 0 ||
    (permissions1.length > 0 && viewRoleflag === false)
  ) {
    // eslint-disable-next-line array-callback-return
    if (permissions1.length !== 0) {
      permissions = permissions1;
    }
    permissions.map(screen => {
      const coloumnArr = [];
      coloumnArr.push(<td key={screen.name}>{screen.name}</td>);
      // eslint-disable-next-line no-restricted-syntax
      for (const key2 in screen) {
        if (typeof screen[key2] === 'boolean') {
          coloumnArr.push(
            <td key={key2}>
              <input
                type="checkbox"
                name={screen.name}
                value="true"
                checked={screen[key2]}
                action={key2}
                onChange={evt => onPermissionStatusChange(evt)}
                disabled={screen.actionName === key2 ? false : screen[key2]}
              />
            </td>,
          );
        }
      }
      permissionsArr.push(<tr>{coloumnArr}</tr>);
    });
  }
  let viewDataDetails = [];
  const viewdefaultPeriod = [];
  if (viewRoleflag === true) {
    viewdefaultPeriod.defaultPeriod = getViewDefaultPeriodStr(
      viewRoleResults.defaultPeriod,
    );

    viewDataDetails = viewRoleResults.moduleList.map(role => (
      <tr>
        <td>{role.moduleDescription}</td>

        <td
          className={role.functionAccess.isView ? 'status-green' : 'status-red'}
          dangerouslySetInnerHTML={{
            __html: role.functionAccess.isView ? '&#x2714;' : '&#x2716;',
          }}
        />
        <td
          className={role.functionAccess.isEdit ? 'status-green' : 'status-red'}
          dangerouslySetInnerHTML={{
            __html: role.functionAccess.isEdit ? '&#x2714;' : '&#x2716;',
          }}
        />
        <td
          className={
            role.functionAccess.isCreate ? 'status-green' : 'status-red'
          }
          dangerouslySetInnerHTML={{
            __html: role.functionAccess.isCreate ? '&#x2714;' : '&#x2716;',
          }}
        />
        <td
          className={
            role.functionAccess.isDelete ? 'status-green' : 'status-red'
          }
          dangerouslySetInnerHTML={{
            __html: role.functionAccess.isDelete ? '&#x2714;' : '&#x2716;',
          }}
        />
        <td
          className={
            role.functionAccess.isPublish ? 'status-green' : 'status-red'
          }
          dangerouslySetInnerHTML={{
            __html: role.functionAccess.isPublish ? '&#x2714;' : '&#x2716;',
          }}
        />
      </tr>
    ));
  }
  let type = '';
  if (viewDataDetails.length === 0) {
    if (updateRoleFlag === true && copyEditRole === false) {
      type = 'Update';
    } else {
      type = 'Add';
    }
  } else {
    type = 'View';
  }
  function dateSelect(event) {
    handleChangeDate(event.target.value, event.target.selectedOptions[0].text);
    dateErrorContent('');
  }
  function monthSelect(event) {
    handleChangeMonth(event.target.value, event.target.selectedOptions[0].text);
    dateErrorContent('');
  }
  function yearSelect(event) {
    handleChangeYear(event.target.value, event.target.selectedOptions[0].text);
    dateErrorContent('');
  }
  function getData() {
    setTimeout(() => {
      if (document.getElementById('yearNames') !== null) {
        document.getElementById('yearNames').firstElementChild.style.display =
          'none';
        document.getElementById('dateNames').firstElementChild.style.display =
          'none';
        document.getElementById('monthNames').firstElementChild.style.display =
          'none';
      }
    }, 1000);
  }

  return (
    <>
      <Modal
        md="12"
        isOpen={show}
        className="custom-modal-claims modal-lg modal-xl col-md-2"
      >
        <ModalHeader toggle={closeDialog} className="modal-bgColor">
          <h4 className="modal-title" ref={roleComponentRef}>
            {type} <FormattedMessage {...messages.header} />
          </h4>
        </ModalHeader>
        <ModalBody>
          <Form>
            <Row>
              {viewDataDetails.length === 0 && (
                <Col xs={2}>
                  <Label className="mandate">
                    <FormattedMessage {...messages.roleName} />
                  </Label>
                  <Input
                    type="text"
                    name="roleName"
                    ref={roleTextRef}
                    id="roleName"
                    onChange={e => {
                      handleChange('roleName', e.target.value);
                    }}
                    readOnly={updateRoleResults.roleName}
                    value={roleFieldData.roleName}
                    invalid={isRoleNameExists}
                    maxLength={100}
                    className="textBoxFont"
                  />
                  {roleFieldData.roleName === '' && (
                    <div className="roleNameError">
                      <span className="error">{rolenameerror}</span>
                    </div>
                  )}
                  {isRoleNameExists === true && (
                    <span className="error">
                      <FormattedMessage {...messages.roleNameExistMsg} />
                    </span>
                  )}
                </Col>
              )}
            </Row>
            {viewDataDetails.length !== 0 && (
              <Row>
                <Col xs={6}>
                  <h4>
                    <FormattedMessage {...messages.roleName} />
                  </h4>
                  {viewRoleResults.roleName}
                </Col>
                {filteredAccess(moduleId, 'add') && (
                  <Col xs={6} className="text-right">
                    <button
                      type="button"
                      className="btn btn-link btnlink"
                      onClick={() => {
                        handleEditCopy();
                      }}
                      style={{ textDecoration: 'none' }}
                    >
                      <FormattedMessage {...messages.copyRole} />
                    </button>
                  </Col>
                )}
              </Row>
            )}

            <br />
            {viewDataDetails.length === 0 && (
              <div>
                <Row>
                  <Col>
                    <Label>
                      <FormattedMessage {...messages.roleDescription} />
                    </Label>
                  </Col>
                </Row>
                <Row>
                  <Col xs={4}>
                    <textarea
                      type="text"
                      name="roleDescription"
                      id="roleDescription"
                      onChange={e => {
                        handleChange('roleDescription', e.target.value);
                      }}
                      value={roleFieldData.roleDescription}
                      className="form-control textBoxFont"
                      maxLength={250}
                    />
                  </Col>
                </Row>
              </div>
            )}
            {viewDataDetails.length !== 0 && (
              <Row>
                <Col xs={6}>
                  <h4>
                    <FormattedMessage {...messages.roleDescription} />
                  </h4>
                  {viewRoleResults.roleDescription}
                </Col>
              </Row>
            )}
            <br />
            {viewDataDetails.length === 0 && (
              <div>
                <Row>
                  <Col>
                    <Label className="mandate">
                      <FormattedMessage {...messages.defaultPeriod} />
                    </Label>
                  </Col>
                </Row>
                <Row>
                  <Col xs={1}>
                    <DropDown
                      id="yearNames"
                      name="yearNames"
                      options={yearOptions}
                      selected={selected.year}
                      onChange={yearSelect}
                    />
                  </Col>
                  <Col xs={1}>
                    <DropDown
                      id="monthNames"
                      name="monthNames"
                      options={monthOptions}
                      selected={selected.month}
                      onChange={monthSelect}
                    />
                  </Col>
                  <Col xs={1}>
                    <DropDown
                      id="dateNames"
                      name="dateNames"
                      options={dateOptions}
                      selected={selected.date}
                      onChange={dateSelect}
                    />
                  </Col>
                  {getData()}
                </Row>
                <Row>
                  <span>
                    {roleFieldData.defaultPeriod === '' && (
                      <span className="error">{dateErrors}</span>
                    )}
                  </span>
                </Row>
              </div>
            )}
            <Row>
              {viewDataDetails.length !== 0 && (
                <Col xs={6}>
                  <h4>
                    <FormattedMessage {...messages.defaultPeriod} />
                  </h4>
                  {viewdefaultPeriod.defaultPeriod}
                </Col>
              )}
            </Row>
            <br />
            <Row>
              {permissionsArr.length !== 0 && (
                <Col xs={12} className="role-result-table">
                  <Label className="mandate">
                    <FormattedMessage {...messages.permissionsHeader} />
                  </Label>
                  {roleFieldData.roleModuleAccess.length === 0 && (
                    <span className="error p-1">{permErrors}</span>
                  )}
                  <table className="table table-striped table-hover">
                    <thead className="table-head">
                      <tr>
                        <th>
                          <FormattedMessage {...messages.tableHeaderScreen} />
                        </th>
                        <th>
                          <FormattedMessage {...messages.tableHeaderView} />
                        </th>
                        <th>
                          <FormattedMessage {...messages.tableHeaderEdit} />
                        </th>
                        <th>
                          <FormattedMessage {...messages.tableHeaderCreate} />
                        </th>
                        <th>
                          <FormattedMessage {...messages.tableHeaderDelete} />
                        </th>
                        <th>
                          <FormattedMessage {...messages.tableHeaderPublish} />
                        </th>
                      </tr>
                    </thead>
                    <tbody>{permissionsArr}</tbody>
                  </table>
                </Col>
              )}
              {viewDataDetails.length !== 0 && (
                <Col xs={12} className="role-result-table">
                  <h4>
                    <FormattedMessage {...messages.permissionsHeader} />
                  </h4>
                  <table className="table table-striped table-hover">
                    <thead className="table-head">
                      <tr>
                        <th>
                          <FormattedMessage {...messages.tableHeaderScreen} />
                        </th>
                        <th>
                          <FormattedMessage {...messages.tableHeaderView} />
                        </th>
                        <th>
                          <FormattedMessage {...messages.tableHeaderEdit} />
                        </th>
                        <th>
                          <FormattedMessage {...messages.tableHeaderCreate} />
                        </th>
                        <th>
                          <FormattedMessage {...messages.tableHeaderDelete} />
                        </th>
                        <th>
                          <FormattedMessage {...messages.tableHeaderPublish} />
                        </th>
                      </tr>
                    </thead>
                    <tbody>{viewDataDetails}</tbody>
                  </table>
                </Col>
              )}
            </Row>
            <Row>
              {type === 'Add' && (
                <Col className="col text-center">
                  <Button
                    color="primary"
                    type="button"
                    name="addBtn"
                    className="mx-3"
                    onClick={() => {
                      sumbitAdd();
                    }}
                  >
                    <i className="paddingright8px" />
                    <FormattedMessage {...messages.addRoleBtn} />
                  </Button>
                  <Button
                    color="primary"
                    type="button"
                    className="btn"
                    outline
                    onClick={closeDialog}
                  >
                    <FormattedMessage {...messages.cancelRoleBtn} />
                  </Button>
                </Col>
              )}
              {type === 'Update' && (
                <Col className="col text-center">
                  <Button
                    color="primary"
                    type="button"
                    name="saveBtn"
                    className="mx-3"
                    onClick={() => {
                      sumbitUpdate();
                    }}
                  >
                    <FormattedMessage {...messages.saveRoleBtn} />
                  </Button>
                  <Button
                    color="primary"
                    type="button"
                    name="cancelBtn"
                    className="btn"
                    outline
                    onClick={closeDialog}
                  >
                    <FormattedMessage {...messages.cancelRoleBtn} />
                  </Button>
                </Col>
              )}
            </Row>
          </Form>
        </ModalBody>
      </Modal>
    </>
  );
}

AddRoleManagementModol.propTypes = {
  show: PropTypes.bool,
  addUserModalClose: PropTypes.func.isRequired,
  roleAddUserDetails: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  permissions1: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  handleRoleAdddetails: PropTypes.func,
  addRoleDetails: PropTypes.func.isRequired,
  viewRoleResults: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  viewRoleflag: PropTypes.bool,
  updateRoleResults: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  updateRoleFlag: PropTypes.bool,
  handleUpdateEditButtonRole: PropTypes.func,
  selected: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  handleChangeMonth: PropTypes.func,
  handleChangeDate: PropTypes.func,
  handleChangeYear: PropTypes.func,
  copyEditRole: PropTypes.bool,
  handleCopyRole: PropTypes.func,
  isRoleNameExists: PropTypes.any,
  roleNameExistsFunc: PropTypes.func,
  roleFieldData: PropTypes.any,
  selectedDateMonthYear: PropTypes.any,
  moduleId: PropTypes.number,
};

const mapStateToProps = createStructuredSelector({
  selected: makeSelectedRoleDates(),
});

const withConnect = connect(mapStateToProps);
export default compose(withConnect)(injectIntl(AddRoleManagementModol));
