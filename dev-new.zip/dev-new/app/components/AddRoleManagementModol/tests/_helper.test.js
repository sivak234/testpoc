// import { defaultFunction } from '../_helper';

// describe('AddRoleManagementModol helpers', () => {
//   describe('Default Helper Function', () => {
//     it('returns the expected value', () => {
//       const expected = 'Sample Text';
//       expect(defaultFunction('Sample Text')).toEqual(expected);
//     });
//   });
// });
describe('<AddRoleManagementModol />', () => {
  it('Expect to not log errors in AddRoleManagementModol', () => {
    expect(true).toBeTruthy();
  });
});
