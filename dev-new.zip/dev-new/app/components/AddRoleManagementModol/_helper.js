/*
 *
 * AddRoleManagementModol helper
 *
 */
import React from 'react';
export const fixedColumns = true;
export const changeHandler = () => {};
export function defaultFunction(text) {
  return text;
}

export const Screens = [
  'Port Data',
  'Port Cost',
  'Port Performance',
  'Vessel Line Up',
  'Vessel',
  'AIS',
  'MarketIntel',
  'News',
];

export const primaryProp = 'userId';

export const emptyRow = {
  Screens: '',
  View: '',
  Create: '',
  Edit: '',
  Publish: '',
};

export const header = [
  {
    title: 'Screens',
    prop: 'name',
  },
  {
    title: 'View',
    prop: 'view',
  },
  {
    title: 'Create',
    prop: 'countryName',
  },
  {
    title: 'Edit',
    prop: 'userType',
  },
  {
    title: 'Publish',
    prop: 'publish',
  },
];

const dateArr = [
  'DD',
  '00',
  '01',
  '02',
  '03',
  '04',
  '05',
  '06',
  '07',
  '08',
  '09',
  '10',
  '11',
  '12',
  '13',
  '14',
  '15',
  '16',
  '17',
  '18',
  '19',
  '20',
  '21',
  '22',
  '23',
  '24',
  '25',
  '26',
  '27',
  '28',
  '29',
  '30',
];

export const dateOptions = dateArr.map(e => <option key={e}>{e}</option>);
const monthArr = [
  'MM',
  '00',
  '01',
  '02',
  '03',
  '04',
  '05',
  '06',
  '07',
  '08',
  '09',
  '10',
  '11',
];

export const monthOptions = monthArr.map(e => <option key={e}>{e}</option>);
const yearArr = ['YY', '00', '01', '02', '03', '04', '05'];

export const yearOptions = yearArr.map(e => <option key={e}>{e}</option>);

export const getViewDefaultPeriodStr = data => {
  const year = data && data.substring(0, 2) ? data.substring(0, 2) : 0;
  const month = data && data.substring(2, 4) ? data.substring(2, 4) : 0;
  const day = data && data.substring(4, 6) ? data.substring(4, 6) : 0;
  const y = year > 1 ? 'Years' : 'Year';
  const m = month > 1 ? 'Months' : 'Month';
  const d = day > 1 ? 'Days' : 'Day';
  return `${year} ${y} ${month} ${m} ${day} ${d}`;
};
