/**
 *
 * BerthAddViewUpdate
 *
 */

import React, { createRef, useEffect } from 'react';
import PropTypes from 'prop-types';
import { FormattedMessage } from 'react-intl';

import {
  Container,
  Row,
  Col,
  Label,
  Input,
  FormFeedback,
  Button,
  CustomInput,
  FormGroup,
} from 'reactstrap';
import messages from './messages';
import BerthCreateInLegacy from '../BerthCreateInLegacy/Loadable';
import PermissibleVesselRestrictions from '../PermissibleVesselRestrictions/Loadable';
import PermissibleVesselParametersOil from '../PermissibleVesselParametersOil/Loadable';
import PermissibleVesselParametersGas from '../PermissibleVesselParametersGas/Loadable';
import PermissibleVesselParametersDry from '../PermissibleVesselParametersDry/Loadable';
import PermissibleManifoldParametersOil from '../PermissibleManifoldParametersOil/Loadable';
import PtbBerthRestrictions from '../PtbBerthRestrictions/Loadable';
import BerthCargoGearFacility from '../BerthCargoGearFacility/Loadable';
import OilCargoHandled from '../OilCargoHandled/Loadable';
import GasCargoHandled from '../GasCargoHandled/Loadable';
import ChemicalCargoHandled from '../ChemicalCargoHandled/Loadable';
import BerthShipsHandled from '../BerthShipsHandled/Loadable';
import BerthImages from '../BerthImages/Loadable';
import BerthDocuments from '../BerthDocuments/Loadable';
import ChooseCustomer from '../ChooseCustomer/Loadable';
import PtbAuditDetails from '../PtbAuditDetails/Loadable';
import Dropdown from '../Dropdown';
import DryCargoHandled from '../DryCargoHandled/Loadable';
import BerthContact from '../BerthContact/Loadable';
import BerthServices from '../BerthServices/Loadable';
import PtbGeoFencing from '../PtbGeoFencing/Loadable';
import LoadingIndicator from '../LoadingIndicator';
import Selectfilters from '../Selectfilters';
import { matchNumericRegex } from '../../utils/validation';
import DataTableList from '../DataTableList/Loadable';
import {
  BERTH_ZOOM_LEVEL,
  TERMINAL_BERTH_ADD_ZOOM_LEVEL,
  BERTH_LEGACY_MODULE_ID,
  BERTH_MODULE_ID,
} from '../../utils/constants';
import {
  getDescriptionForDropdown,
  getOptions,
  dateConversion,
} from '../../utils/dataModification';
import { filteredAccess } from '../../utils/rbac';

import {
  countryChangeHandler,
  portChangeHandler,
  terminalChangeHandler,
  regionChangeHandler,
  changeHistoryHeaders,
} from '../../containers/PortTerminalBerthManagement/_helper';

import { getAvaClientUsers } from './_helper';
import { disableValueChangeOnScroll } from '../../utils/commonRenderers';

/* eslint-disable no-param-reassign */
/* eslint-disable no-unused-expressions */

function BerthAddViewUpdate({
  metaData,
  data = {},
  berthValidationStatus,
  handleBerthInputChange,
  formType,
  ptbImage,
  uploadStatus,
  dHandleFileUpload,
  dHandleFileDownload,
  dGetVessels,
  vessels,
  dUpdateBerthDataCargoHandled,
  dDeleteBerthDataCargoHandled,
  dHandleCargoTypeChange,
  vesselClassification,
  dberthUpdateImageData,
  getGeoFencingData,
  finalGeoFenceData,
  selectedGeoFenceData,
  portViewData,
  moduleType,
  regionList,
  countryList,
  portsList,
  terminalsList,
  dGetPortsList,
  dGetTerminalsList,
  berthValidationMessages,
  berthImages,
  berthimageinfo,
  dstoreimageinformation,
  dselectedTerminalBerthimageinfo,
  storeselectedberthimagefile,
  confirmBerthImageDeleteModalOpen,
  dopenberthimagepopupconfirmation,
  dclsoeberthimagepopupconfirmation,
  ddeleteTerminalBerthSelectedImages,
  berthdocumenttype,
  numberOfCopies,
  berthptbDocument,
  dberthDocumentsData,
  dvalidatedocumnet,
  dsetDocumentName,
  dsetDocumentType,
  dvalidatedfileuploaddocument,
  dselectedDocumentInformation,
  berthselecteddocument,
  confirmBerthDocumentDeleteModalOpen,
  dopenberthdocumentpopupconfirmation,
  dcloseberthdocumentpopupconfirmation,
  dberthDeleteSelectDocumentInformation,
  dremoveFromCollection,
  berthIssTransfer,
  dhandleYssTransferCheck,
  dGetCountryList,
  typeAheadDropdownBerth,
  geoSelectedTerminalId,
  isLoading,
  dGetUserDetails,
  isBerthClientAccessNotSelected,
  dgetAllPortsDataForMapByPortId,
  linkedWithLegacy,
  ptbStatus,
  isMapRefresh,
  isNotPublishedPTB,
  isPublish,
  dsetNewLatLong,
  ptbMapCoordinates,
  dlocateLatLong,
  ptbSelectedCoordinates,
  isLocateClicked,
  dDisableLocate,
  isInValidLatLng,
  dcloseLocateDialog,
}) {
  useEffect(() => {
    disableValueChangeOnScroll(); // IE fix
  });
  let berthCargoTypeWet = '';
  let berthCargoTypeDry = '';
  let berthType = '';
  let oil = '';
  let gas = '';
  let chemical = '';
  const isViewOnly = formType.toLowerCase() === 'view';
  const readOnly = isViewOnly;
  metaData.berthMaster.terminalSubTypeList.map(item => {
    if (item.terminalSubTypeDescription === 'Wet') {
      berthCargoTypeWet = item.terminalSubTypeId;
    } else if (item.terminalSubTypeDescription === 'Dry') {
      berthCargoTypeDry = item.terminalSubTypeId;
    }
    return item;
  });
  if (data.terminalTypeId) {
    if (data.terminalTypeId === berthCargoTypeDry) {
      berthType = 'dry';
    } else if (data.terminalTypeId === berthCargoTypeWet) {
      berthType = 'wet';
    }
  }

  // Allow only Marine Cargo Terminal
  let filteredTerminalList = [];
  if (formType.toLowerCase() === 'view' || formType.toLowerCase() === 'add') {
    filteredTerminalList = terminalsList.filter(
      i => i.terminalTypeDescription.toLowerCase() === 'marine cargo',
    );
  } else {
    filteredTerminalList = terminalsList.filter(i => {
      let terminalSubTypeId = '';
      if (berthType === 'wet') {
        terminalSubTypeId = berthCargoTypeWet;
      } else {
        terminalSubTypeId = berthCargoTypeDry;
      }
      if (
        i.terminalTypeDescription.toLowerCase() === 'marine cargo' &&
        i.terminalSubTypeId === terminalSubTypeId
      ) {
        return true;
      }
      return false;
    });
  }
  metaData &&
    metaData.berthMaster &&
    metaData.berthMaster.berthTypeList &&
    metaData.berthMaster.berthTypeList.length &&
    metaData.berthMaster.berthTypeList.map(item => {
      if (item.berthTypeDesc.toLowerCase() === 'oil') {
        oil = item.berthTypeId;
      } else if (item.berthTypeDesc.toLowerCase() === 'gas') {
        gas = item.berthTypeId;
      } else if (item.berthTypeDesc.toLowerCase() === 'chemical') {
        chemical = item.berthTypeId;
      }
      return item;
    });

  const isOfType = type => {
    const filteredArray = data.berthTypeTransactions.filter(
      innerItem => innerItem.berthTypeId === type,
    );
    return filteredArray.length ? filteredArray.length : false;
  };

  const generalParticularsRef = createRef();
  const geoCodesRef = createRef();
  const berthCargoGearRef = createRef();
  const berthNotesRef = createRef();
  const imagesRef = createRef();
  const documentsRef = createRef();
  const chooseCustomerRef = createRef();
  const auditDetailsRef = createRef();

  const permissibleVesselRestrictionsRef = createRef();
  const permissibleVesselOilRef = createRef();
  const permissibleMainfoldOilRef = createRef();
  const permissibleVesselGasRef = createRef();
  const permissibleMainfoldGasRef = createRef();
  const permissibleVesselDryRef = createRef();

  const oilCargoRef = createRef();
  const gasCargoRef = createRef();
  const chemicalCargoRef = createRef();
  const shipsHandledRef = createRef();
  const dryCargoHandled = createRef();

  // Avaibale only in View
  const berthContactRef = createRef();
  const berthServicessRef = createRef();
  const berthRestrictionRef = createRef();
  const changeHistoryRef = createRef();
  const issBerthNotesRef = createRef();

  const onJumpSection = event => {
    switch (event.target.dataset.target) {
      case 'general-particulars':
        generalParticularsRef.current.scrollIntoView();
        break;
      case 'geo-code':
        geoCodesRef.current.scrollIntoView();
        break;
      case 'berth-cargo-gear-facility':
        berthCargoGearRef.current.scrollIntoView();
        break;
      case 'berth-notes':
        berthNotesRef.current.scrollIntoView();
        break;
      case 'images':
        imagesRef.current.scrollIntoView();
        break;
      case 'berth-documents':
        documentsRef.current.scrollIntoView();
        break;
      case 'berth-contact':
        berthContactRef.current.scrollIntoView();
        break;
      case 'choose-customers':
        chooseCustomerRef.current.scrollIntoView();
        break;
      case 'audit-details':
        auditDetailsRef.current.scrollIntoView();
        break;
      case 'permissible-vessel-restrictions':
        permissibleVesselRestrictionsRef.current.scrollIntoView();
        break;
      case 'permissible-vessel-oil':
        permissibleVesselOilRef.current.scrollIntoView();
        break;
      case 'permissible-manifold-oil':
        permissibleMainfoldOilRef.current.scrollIntoView();
        break;
      case 'permissible-vessel-gas':
        permissibleVesselGasRef.current.scrollIntoView();
        break;
      case 'permissible-vessel-dry':
        permissibleVesselDryRef.current.scrollIntoView();
        break;

      case 'permissible-manifold-gas':
        permissibleMainfoldGasRef.current.scrollIntoView();
        break;
      case 'berth-services':
        berthServicessRef.current.scrollIntoView();
        break;
      case 'berth-restrictions':
        berthRestrictionRef.current.scrollIntoView();
        break;
      case 'oil-cargo-handled':
        oilCargoRef.current.scrollIntoView();
        break;
      case 'gas-cargo-handled':
        gasCargoRef.current.scrollIntoView();
        break;
      case 'chemical-cargo-handled':
        chemicalCargoRef.current.scrollIntoView();
        break;
      case 'ships-handled':
        shipsHandledRef.current.scrollIntoView();
        break;
      case 'dry-cargo-handled':
        dryCargoHandled.current.scrollIntoView();
        break;
      case 'change-history':
        changeHistoryRef.current.scrollIntoView();
        break;
      case 'iss-berth-notes':
        issBerthNotesRef.current.scrollIntoView();
        break;
      default:
        break;
    }
  };

  const handleCargoTypes = event => {
    const { checked, value } = event.target;
    let cargoTypes = data.berthTypeTransactions.map(i => i.berthTypeId);
    if (!checked) {
      cargoTypes = cargoTypes.filter(item => item !== value);
    } else {
      cargoTypes.push(value);
    }
    dGetVessels(cargoTypes);
    handleBerthInputChange(event);
  };
  const berthStatus = [
    { key: true, value: 'Active' },
    { key: false, value: 'Inactive' },
  ];

  const validateNumber = (event, beforeDecimal, afterDecimal, allowNull) => {
    const result = matchNumericRegex(
      event,
      beforeDecimal,
      afterDecimal,
      allowNull,
    );
    if (result) handleBerthInputChange(event);
    return result;
  };
  const refData = { oil, chemical, gas, isOfType };

  const selectedCargoTypes = [];
  const customCargoHandleChange = event => {
    handleCargoTypes(event);

    if (data.terminalTypeId !== berthCargoTypeWet) {
      // clear field if type is not wet
      handleBerthInputChange({ name: 'legacySystemOilBerthName', value: '' });
      handleBerthInputChange({ name: 'legacySystemGasBerthName', value: '' });
    } else {
      if (!selectedCargoTypes[oil] && !selectedCargoTypes[chemical]) {
        // clear if both oil / chemical not selected
        handleBerthInputChange({ name: 'legacySystemOilBerthName', value: '' });
      }
      if (!selectedCargoTypes[gas]) {
        handleBerthInputChange({ name: 'legacySystemGasBerthName', value: '' });
      }
    }
  };

  const showVesselRestriction =
    data.berthTypeTransactions && data.berthTypeTransactions.length !== 0;

  let cargoTypeStyle = { display: 'block', paddingTop: '40px' };

  let metaUsers = metaData.users;
  const getTerminalSubType = value => {
    let type = '';
    if (value) {
      if (value === berthCargoTypeDry) {
        type = 'Dry';
      } else if (value === berthCargoTypeWet) {
        type = 'Wet';
      }
    }
    return type;
  };

  const getUserByTerminalSubType = (selectedTerminal, handleInputChange) => {
    const type = selectedTerminal[0]
      ? selectedTerminal[0].terminalSubTypeDescription
      : '';
    if (type.toLowerCase() === 'wet' || type.toLowerCase() === 'dry')
      dGetUserDetails(type);
    terminalChangeHandler(selectedTerminal, handleInputChange);
  };

  const type = getTerminalSubType(data.terminalTypeId);

  const showLegacyTransfer =
    data.isCreateInLegacy &&
    (formType.toLowerCase() === 'edit' || formType.toLowerCase() === 'update');

  metaUsers = getAvaClientUsers(type, metaData);
  if (!data.isCreateInLegacy || (showLegacyTransfer && !berthIssTransfer)) {
    metaUsers = metaUsers && metaUsers.filter(item => item.isLegacy === false);
  }

  let showCreateLegacy = true;
  if (
    formType === 'Add' &&
    filteredAccess(BERTH_LEGACY_MODULE_ID, 'publish') &&
    filteredAccess(BERTH_MODULE_ID, 'publish')
  ) {
    showCreateLegacy = false;
  }

  if (
    ptbStatus &&
    !ptbStatus.isTerminalActive &&
    data.terminalCode &&
    data.terminalName &&
    typeAheadDropdownBerth &&
    typeAheadDropdownBerth.terminalRef &&
    typeAheadDropdownBerth.terminalRef != null &&
    typeAheadDropdownBerth.terminalRef.current &&
    typeAheadDropdownBerth.terminalRef.current != null
  ) {
    typeAheadDropdownBerth.terminalRef.current.state.text = `
${data.terminalCode} - ${data.terminalName}`;
  }
  const isHaveNonPublishedData = (
    <FormattedMessage {...messages.isHaveNonPublishedData} />
  );
  return (
    <>
      {/* Header */}
      <Container>
        {formType.toLowerCase() !== 'add' && !isNotPublishedPTB && (
          <LoadingIndicator
            hasError={!data.isPublish}
            error={isHaveNonPublishedData.props.defaultMessage}
          />
        )}
        <Row>
          <Col>
            <div className="jump_btn_container pb-1 pt-1 sticky">
              <Button
                color="primary"
                outline
                className="mt-3 mr-3"
                data-target="general-particulars"
                onClick={onJumpSection}
              >
                General Particulars
              </Button>
              <Button
                color="primary"
                outline
                className="mt-3 mr-3"
                data-target="geo-code"
                onClick={onJumpSection}
              >
                Geo Codes
              </Button>
              {/* permissible-vessel-restrictions */}
              {showVesselRestriction && (
                <Button
                  color="primary"
                  outline
                  className="mt-3 mr-3"
                  data-target="permissible-vessel-restrictions"
                  onClick={onJumpSection}
                >
                  Permissible Vessel Restrictions at Approaches
                </Button>
              )}
              {(isOfType(oil) || isOfType(chemical)) && (
                <Button
                  color="primary"
                  outline
                  className="mt-3 mr-3"
                  data-target="permissible-vessel-oil"
                  onClick={onJumpSection}
                >
                  Permissible Vessel Parameters - Oil / Chemical
                </Button>
              )}
              {isOfType(gas) && (
                <Button
                  color="primary"
                  outline
                  className="mt-3 mr-3"
                  data-target="permissible-vessel-gas"
                  onClick={onJumpSection}
                >
                  Permissible Vessel Parameters - Gas
                </Button>
              )}
              {berthType === 'dry' && (
                <Button
                  color="primary"
                  outline
                  className="mt-3 mr-3"
                  data-target="permissible-vessel-dry"
                  onClick={onJumpSection}
                >
                  Permissible Vessel Parameters - Dry
                </Button>
              )}

              {(isOfType(oil) || isOfType(chemical)) && (
                <Button
                  color="primary"
                  outline
                  className="mt-3 mr-3"
                  data-target="permissible-manifold-oil"
                  onClick={onJumpSection}
                >
                  Permissible Manifold Parameters - Oil / Chemical
                </Button>
              )}
              {isOfType(gas) && (
                <Button
                  color="primary"
                  outline
                  className="mt-3 mr-3"
                  data-target="permissible-manifold-gas"
                  onClick={onJumpSection}
                >
                  Permissible Manifold Parameters - Gas
                </Button>
              )}
              {isViewOnly && (
                <Button
                  color="primary"
                  outline
                  className="mt-3 mr-3"
                  data-target="berth-restrictions"
                  onClick={onJumpSection}
                >
                  Berth Restrictions
                </Button>
              )}
              {isViewOnly && (
                <Button
                  color="primary"
                  outline
                  className="mt-3 mr-3"
                  data-target="berth-services"
                  onClick={onJumpSection}
                >
                  Berth Services
                </Button>
              )}

              <Button
                color="primary"
                outline
                className="mt-3 mr-3"
                data-target="berth-cargo-gear-facility"
                onClick={onJumpSection}
              >
                Berth Cargo Gear Facility
              </Button>
              {isOfType(oil) && (
                <Button
                  color="primary"
                  outline
                  className="mt-3 mr-3"
                  data-target="oil-cargo-handled"
                  onClick={onJumpSection}
                >
                  Oil Cargo Handled
                </Button>
              )}
              {isOfType(gas) && (
                <Button
                  color="primary"
                  outline
                  className="mt-3 mr-3"
                  data-target="gas-cargo-handled"
                  onClick={onJumpSection}
                >
                  Gas Cargo Handled
                </Button>
              )}
              {isOfType(chemical) && (
                <Button
                  color="primary"
                  outline
                  className="mt-3 mr-3"
                  data-target="chemical-cargo-handled"
                  onClick={onJumpSection}
                >
                  Chemical Cargo Handled
                </Button>
              )}

              {data.terminalTypeId === berthCargoTypeDry && (
                <Button
                  color="primary"
                  outline
                  className="mt-3 mr-3"
                  data-target="dry-cargo-handled"
                  onClick={onJumpSection}
                >
                  Dry Cargo Handled
                </Button>
              )}

              <Button
                color="primary"
                outline
                className="mt-3 mr-3"
                data-target="ships-handled"
                onClick={onJumpSection}
              >
                Ships Handled
              </Button>
              <Button
                color="primary"
                outline
                className="mt-3 mr-3"
                data-target="berth-notes"
                onClick={onJumpSection}
              >
                Berth Notes
              </Button>
              <Button
                color="primary"
                outline
                className="mt-3 mr-3"
                data-target="images"
                onClick={onJumpSection}
              >
                Images
              </Button>
              <Button
                color="primary"
                outline
                className="mt-3 mr-3"
                data-target="berth-documents"
                onClick={onJumpSection}
              >
                Berth Documents
              </Button>
              {isViewOnly && (
                <>
                  <Button
                    color="primary"
                    outline
                    className="mt-3 mr-3"
                    data-target="berth-contact"
                    onClick={onJumpSection}
                  >
                    Berth Contact
                  </Button>
                  <Button
                    color="primary"
                    outline
                    className="mt-3 mr-3"
                    data-target="change-history"
                    onClick={onJumpSection}
                  >
                    Change History
                  </Button>
                </>
              )}
              {filteredAccess(BERTH_MODULE_ID, 'publish') && (
                <Button
                  color="primary"
                  outline
                  className="mt-3 mr-3"
                  data-target="iss-berth-notes"
                  onClick={onJumpSection}
                >
                  <FormattedMessage {...messages.issBerthNotes} />
                </Button>
              )}
              <Button
                color="primary"
                outline
                className="mt-3 mr-3"
                data-target="choose-customers"
                onClick={onJumpSection}
              >
                Choose Customers
              </Button>
              {formType.toLowerCase() !== 'add' && (
                <Button
                  color="primary"
                  outline
                  className="mt-3 mr-3"
                  data-target="audit-details"
                  onClick={onJumpSection}
                >
                  Audit Details
                </Button>
              )}
            </div>
          </Col>
        </Row>
        <Row>
          <Col>
            <hr />
          </Col>
        </Row>
      </Container>
      {/* Body */}
      <Container
        className={
          readOnly
            ? 'readonly-container fixedHeight add-berth-parent-container'
            : 'fixedHeight add-berth-parent-container'
        }
      >
        {/* General Particulars */}
        <Row className="add-berth-section-header mb-3">
          <Col xs={12}>
            <h4 className="mb-0" ref={generalParticularsRef}>
              General Particulars
            </h4>
          </Col>
        </Row>
        <Row>
          <Col xs={6} md>
            {formType.toLowerCase() !== 'add' && (
              <>
                <Label for="region" className="view-label">
                  <FormattedMessage {...messages.region} />
                </Label>
                {data.regionName}
              </>
            )}
            {formType.toLowerCase() === 'add' && (
              <Dropdown
                label="Region"
                options={getOptions(regionList, 'regionId', 'regionName')}
                onChange={evt =>
                  regionChangeHandler(
                    evt,
                    handleBerthInputChange,
                    dGetCountryList,
                    'berth',
                    '',
                  )
                }
                name="regionId"
                selected={data.regionId}
                required
                invalid={berthValidationStatus.regionId}
                isDisabled={readOnly}
                id="regionId"
              />
            )}
            <FormFeedback> Region is mandatory </FormFeedback>
          </Col>
          <Col xs={6} md>
            <Label
              for="country"
              className={
                formType.toLowerCase() !== 'add' ? 'view-label' : 'mandate'
              }
            >
              <FormattedMessage {...messages.country} />
            </Label>
            {formType.toLowerCase() !== 'add' && data.countryName}
            {!readOnly && formType.toLowerCase() === 'add' && (
              <Selectfilters
                id="countryId"
                name="countryId"
                label="countryName"
                defaultKey="countryId"
                defaultSelected={data.countryId}
                queryResults={countryList}
                placeholder="Choose a country..."
                onChangeHandler={selectedCountry =>
                  countryChangeHandler(
                    selectedCountry,
                    dGetPortsList,
                    handleBerthInputChange,
                    'berth',
                    '',
                  )
                }
                invalid={berthValidationStatus.countryId}
                passedRef={typeAheadDropdownBerth.countryRef}
              />
            )}
            {berthValidationStatus.countryId && (
              <div className="invalid-feedback" style={{ display: 'block' }}>
                Country is mandatory
              </div>
            )}
          </Col>
          <Col xs={6} md>
            <Label
              for="portName"
              className={
                formType.toLowerCase() !== 'add' ? 'view-label' : 'mandate'
              }
            >
              <FormattedMessage {...messages.portName} />
            </Label>
            {formType.toLowerCase() !== 'add' && data.portName && (
              <FormGroup>{`${data.portUNLOCODE} - ${data.portName}`}</FormGroup>
            )}
            {formType.toLowerCase() === 'add' && (
              <Selectfilters
                id="portId"
                name="portId"
                label="portName"
                defaultKey="portId"
                defaultSelected={data.portId}
                queryResults={portsList}
                placeholder="Choose a port..."
                onChangeHandler={selectedPort => {
                  portChangeHandler(
                    selectedPort,
                    handleBerthInputChange,
                    '',
                    dGetTerminalsList,
                  );
                  dgetAllPortsDataForMapByPortId(
                    selectedPort.length > 0 ? selectedPort[0].portId : '',
                  );
                }}
                invalid={berthValidationStatus.portId}
                passedRef={typeAheadDropdownBerth.portRef}
              />
            )}
            {berthValidationStatus.portId && (
              <div className="invalid-feedback" style={{ display: 'block' }}>
                Port is mandatory
              </div>
            )}
          </Col>
          <Col xs={6} md>
            <Label
              for="terminalId"
              className={
                formType.toLowerCase() === 'view' ? 'view-label' : 'mandate'
              }
            >
              <FormattedMessage {...messages.terminal} />
            </Label>
            {readOnly && data.terminalName !== null && (
              <FormGroup>{`${data.terminalCode} - ${
                data.terminalName
              }`}</FormGroup>
            )}
            {!readOnly && (
              <Selectfilters
                id="terminalId"
                name="terminalId"
                label="terminalName"
                defaultKey="terminalId"
                defaultSelected={data.terminalId}
                queryResults={filteredTerminalList}
                placeholder="Choose a terminal..."
                onChangeHandler={selectedTerminal =>
                  getUserByTerminalSubType(
                    selectedTerminal,
                    handleBerthInputChange,
                  )
                }
                invalid={berthValidationStatus.terminalId}
                passedRef={typeAheadDropdownBerth.terminalRef}
              />
            )}
            {berthValidationStatus.terminalId && (
              <div className="invalid-feedback" style={{ display: 'block' }}>
                Terminal Name is mandatory
              </div>
            )}
          </Col>
          <Col xs={6} md>
            <Label for="berthCode">Berth Code</Label>
            {readOnly && data.berthCode}
            {!readOnly && (
              <Input
                id="berthCode"
                name="berthCode"
                onChange={handleBerthInputChange}
                value={data.berthCode}
                readOnly
                maxLength={20}
              />
            )}
          </Col>
        </Row>
        <Row className="mt-3">
          <Col xs={6} md>
            <Label for="berthMainCargoType">Berth Type</Label>
            {/* terminalTypeId */}
            {data.terminalTypeId === berthCargoTypeWet && (
              <>
                {readOnly && 'Wet'}
                {!readOnly && (
                  <Input
                    id="berthMainCargoType"
                    name="berthMainCargoType"
                    value="Wet"
                    readOnly={readOnly}
                    maxLength={20}
                  />
                )}
              </>
            )}
            {data.terminalTypeId === berthCargoTypeDry && (
              <>
                {readOnly && 'Dry'}
                {!readOnly && (
                  <Input
                    id="berthMainCargoType"
                    name="berthMainCargoType"
                    value="Dry"
                    readOnly={readOnly}
                    maxLength={20}
                  />
                )}
              </>
            )}
            {/* eslint-disable indent */}
          </Col>
          <Col xs={6} md>
            <Label
              htmlFor="berthTypeTransactions"
              className={readOnly ? '' : 'mandate'}
            >
              Cargo Types
            </Label>
            {data.terminalId &&
              metaData.berthTypeList.map(item => {
                cargoTypeStyle = { display: 'block' };
                const filteredArray = data.berthTypeTransactions.filter(
                  innerItem => innerItem.berthTypeId === item.berthTypeId,
                );
                if (filteredArray.length > 0)
                  selectedCargoTypes[filteredArray[0].berthTypeId] =
                    filteredArray[0].berthTypeId;
                return (
                  <Row
                    key={`${filteredArray.length}-${item.berthTypeId}-${
                      metaData.berthTypeList.length
                    }`}
                  >
                    <Col>
                      <CustomInput
                        type="checkbox"
                        label={item.berthTypeDesc}
                        id={item.berthTypeId}
                        value={item.berthTypeId}
                        name="berthTypeTransactions"
                        checked={filteredArray.length}
                        readOnly={readOnly}
                        disabled={readOnly}
                        onChange={customCargoHandleChange}
                        data-type="array"
                        data-key="berthTypeId"
                      />
                    </Col>
                  </Row>
                );
              })}

            {berthValidationStatus.berthTypeTransactions && (
              <div className="invalid-feedback" style={cargoTypeStyle}>
                Cargo Types is mandatory
              </div>
            )}
          </Col>
          <Col xs={6} md>
            {readOnly && (
              <>
                <Label for="Style">Style</Label>
                {getDescriptionForDropdown(
                  metaData.berthMaster.berthStyleList,
                  data.style,
                  'berthStyleId',
                  'berthStyleDesc',
                )}
              </>
            )}
            {!readOnly && (
              <Dropdown
                label="Style"
                options={metaData.berthStyleList}
                onChange={handleBerthInputChange}
                name="style"
                id="style"
                selected={data.style}
                required
                invalid={berthValidationStatus.style}
                isDisabled={readOnly}
              />
            )}
            <FormFeedback> Style is mandatory </FormFeedback>
          </Col>
          <Col xs={6} md>
            <Label for="berthName" className={readOnly ? '' : 'mandate'}>
              Berth Name
            </Label>
            {readOnly && data.berthName}
            {!readOnly && (
              <Input
                readOnly={readOnly}
                id="berthName"
                name="berthName"
                onChange={handleBerthInputChange}
                value={data.berthName}
                invalid={berthValidationStatus.berthName}
                maxLength={255}
              />
            )}
            <FormFeedback> Berth Name is mandatory </FormFeedback>
          </Col>

          <Col xs={6} md>
            <Label for="Name">Alternate Name</Label>
            {readOnly && data.alternativeName}
            {!readOnly && (
              <Input
                readOnly={readOnly}
                id="alternativeName"
                name="alternativeName"
                onChange={handleBerthInputChange}
                value={data.alternativeName}
                maxLength={255}
              />
            )}
          </Col>
        </Row>
        <Row className="mt-3">
          <Col xs={6} md>
            {readOnly && (
              <>
                <Label for="Priority">Priority</Label>
                {getDescriptionForDropdown(
                  metaData.berthMaster.priorityTypeList,
                  data.priority,
                  'priorityTypeId',
                  'priorityTypeDesc',
                )}
              </>
            )}
            {!readOnly && (
              <Dropdown
                label="Priority"
                options={metaData.priorityTypeList}
                onChange={handleBerthInputChange}
                name="priority"
                selected={data.priority}
                isDisabled={readOnly}
              />
            )}
          </Col>
          <Col xs={6} md>
            {readOnly && (
              <>
                <Label for="Status">Status</Label>
                {getDescriptionForDropdown(
                  berthStatus,
                  data.status,
                  'key',
                  'value',
                )}
              </>
            )}
            {!readOnly && (
              <Dropdown
                label="Status"
                options={metaData.berthStatus}
                onChange={handleBerthInputChange}
                name="status"
                id="status"
                selected={data.status}
                required
                invalid={berthValidationStatus.status}
                isDisabled={formType.toLowerCase() === 'add'}
              />
            )}
            <FormFeedback> Status is mandatory </FormFeedback>
          </Col>

          {readOnly && (
            <Col xs={6} md>
              <Label for="timeZone">Time Zone</Label>
              {data.timeZone}
            </Col>
          )}

          <Col xs={6} md>
            {readOnly && (
              <>
                <Label>Gangway Arrangements</Label>
                {getDescriptionForDropdown(
                  metaData.berthMaster.gangwayArrangementList,
                  data.gangWayOptions,
                  'gangwayArrangementId',
                  'gangwayArrangementDesc',
                )}
              </>
            )}
            {!readOnly && (
              <Dropdown
                label="Gangway Arrangements"
                options={metaData.gangwayArrangementList}
                onChange={handleBerthInputChange}
                name="gangWayOptions"
                selected={data.gangWayOptions}
                isDisabled={readOnly}
              />
            )}
          </Col>
          <Col xs={6} md>
            <Label htmlFor="berthFenderingTypes">Types of Fendering</Label>
            {metaData.berthMaster &&
              metaData.berthMaster.fenderingTypeList &&
              metaData.berthMaster.fenderingTypeList.map(item => {
                const filteredArray = data.berthFenderingTypes.filter(
                  innerItem =>
                    innerItem.fenderingTypeId === item.fenderingTypeId,
                );
                return (
                  <Row
                    key={`${filteredArray.length}-${item.fenderingTypeId}-${
                      metaData.berthTypeList.length
                    }`}
                  >
                    <Col>
                      <CustomInput
                        type="checkbox"
                        label={item.fenderingTypeDesc}
                        id={item.fenderingTypeId}
                        value={item.fenderingTypeId}
                        name="berthFenderingTypes"
                        checked={filteredArray.length}
                        readOnly={readOnly}
                        disabled={readOnly}
                        onChange={handleBerthInputChange}
                        data-type="array"
                        data-key="fenderingTypeId"
                      />
                    </Col>
                  </Row>
                );
              })}
          </Col>
          {!readOnly && (
            <>
              <Col xs={6} md />
            </>
          )}
        </Row>
        {readOnly && (
          <Row className="mt-4">
            <Col xs={6} md>
              <Label for="typesOfBottom">Types Of Bottom</Label>
              <p>{data.typesOfBottom}</p>
            </Col>

            <Col xs={6} md>
              <Label for="salinity">Salinity Of Water</Label>
              {data.salinityOfWater}
            </Col>

            <Col xs={6} md>
              <Label for="lastHydrographicalSurvey">
                Last Hydrographical Survey
              </Label>
              <p>{dateConversion(data.lastHydrographicalSurvey)}</p>
            </Col>

            <Col xs={6} md>
              <Label for="lastStructuralSurvey">Last Structural Survey</Label>
              <p>{dateConversion(data.lastStructuralSurvey)}</p>
            </Col>

            <Col xs={6} md>
              <Label for="berthOwner">Berth Owner</Label>
              <p>{data.berthOwner}</p>
            </Col>
          </Row>
        )}
        {readOnly && (
          <Row>
            <Col xs={6} md>
              <Label for="berthOperator">Berth Operator</Label>
              <p>{data.berthOperator}</p>
            </Col>
          </Row>
        )}
        {linkedWithLegacy &&
          linkedWithLegacy.isTerminal &&
          data.status != null &&
          data.status.toString() === 'true' &&
          data.terminalTypeId === berthCargoTypeWet && (
            <Row className="mt-3">
              <Col>
                <CustomInput
                  type="checkbox"
                  label="Create in Legacy"
                  id="isCreateInLegacy"
                  name="isCreateInLegacy"
                  onChange={handleBerthInputChange}
                  checked={data.isCreateInLegacy}
                  disabled={showCreateLegacy}
                />
              </Col>
            </Row>
          )}
        {linkedWithLegacy &&
          linkedWithLegacy.isTerminal &&
          data.isCreateInLegacy &&
          (data.status != null && data.status.toString() === 'true') && (
            <BerthCreateInLegacy
              refData={refData}
              data={data}
              handleBerthInputChange={handleBerthInputChange}
              formType={formType.toLowerCase()}
              berthValidationStatus={berthValidationStatus}
            />
          )}
        {/* Geo Codes */}
        <Row className="add-berth-section-header mb-3 mt-3">
          <Col xs={12}>
            <h4 className="mb-0" ref={geoCodesRef}>
              Geocodes
            </h4>
          </Col>
        </Row>
        <Row className="mt-3">
          <Col xs={12}>
            <PtbGeoFencing
              getGeoFencingData={getGeoFencingData}
              finalGeoFenceData={finalGeoFenceData}
              selectedGeoFenceData={selectedGeoFenceData}
              formType={formType}
              portViewData={portViewData}
              moduleType={moduleType}
              geoSelectedTerminalId={geoSelectedTerminalId}
              isMapRefresh={isMapRefresh}
              zoomLevel={
                formType.toLowerCase() === 'add'
                  ? TERMINAL_BERTH_ADD_ZOOM_LEVEL
                  : BERTH_ZOOM_LEVEL
              } // this property is added from constant
              dsetNewLatLong={dsetNewLatLong}
              ptbMapCoordinates={ptbMapCoordinates}
              dlocateLatLong={dlocateLatLong}
              ptbSelectedCoordinates={ptbSelectedCoordinates}
              isLocateClicked={isLocateClicked}
              dDisableLocate={dDisableLocate}
              isInValidLatLng={isInValidLatLng}
              dcloseLocateDialog={dcloseLocateDialog}
            />
          </Col>
        </Row>
        {/* permissibleVesselRestrictions */}
        {showVesselRestriction && (
          <>
            <PermissibleVesselRestrictions
              passedRef={permissibleVesselRestrictionsRef}
              validateNumber={validateNumber}
              data={data}
              readOnly={readOnly}
              berthValidationStatus={berthValidationStatus}
              berthValidationMessages={berthValidationMessages}
              vessels={vessels}
            />
          </>
        )}
        {/* Permissible Vessel Parameters Oil */}
        {(isOfType(oil) || isOfType(chemical)) && (
          <>
            <PermissibleVesselParametersOil
              berthValidationStatus={berthValidationStatus}
              passedRef={permissibleVesselOilRef}
              handleBerthInputChange={handleBerthInputChange}
              data={data}
              validateNumber={validateNumber}
              readOnly={readOnly}
              berthValidationMessages={berthValidationMessages}
            />
          </>
        )}
        {berthType === 'dry' && (
          <>
            <PermissibleVesselParametersDry
              berthValidationStatus={berthValidationStatus}
              validateNumber={validateNumber}
              passedRef={permissibleVesselDryRef}
              data={data}
              handleBerthInputChange={handleBerthInputChange}
              readOnly={readOnly}
              berthValidationMessages={berthValidationMessages}
            />
          </>
        )}
        {/* Permissible Vessel Parameters Gas / dry */}
        {isOfType(gas) && (
          <>
            <PermissibleVesselParametersGas
              validateNumber={validateNumber}
              berthValidationStatus={berthValidationStatus}
              passedRef={permissibleVesselGasRef}
              data={data}
              handleBerthInputChange={handleBerthInputChange}
              readOnly={readOnly}
              berthValidationMessages={berthValidationMessages}
            />
          </>
        )}
        {/* Permissible Manifold Parameters Oil */}
        {(isOfType(oil) || isOfType(chemical)) && (
          <>
            <PermissibleManifoldParametersOil
              validateNumber={validateNumber}
              passedRef={permissibleMainfoldOilRef}
              data={data}
              handleBerthInputChange={handleBerthInputChange}
              berthValidationStatus={berthValidationStatus}
              berthValidationMessages={berthValidationMessages}
              readOnly={readOnly}
              type="oil"
            />
          </>
        )}
        {/* Permissible Manifold Parameters Gas */}
        {isOfType(gas) && (
          <>
            <PermissibleManifoldParametersOil
              validateNumber={validateNumber}
              passedRef={permissibleMainfoldGasRef}
              data={data}
              handleBerthInputChange={handleBerthInputChange}
              berthValidationStatus={berthValidationStatus}
              berthValidationMessages={berthValidationMessages}
              readOnly={readOnly}
              type="gas"
            />
          </>
        )}
        {isViewOnly && data.services && (
          <>
            <BerthServices passedRef={berthServicessRef} data={data.services} />
          </>
        )}
        {isViewOnly && data.restriction && (
          <>
            <PtbBerthRestrictions
              metaData={metaData}
              passedRef={berthRestrictionRef}
              typeWet={berthCargoTypeWet}
              data={data.restriction}
              terminalTypeId={data.terminalTypeId}
            />
          </>
        )}
        {/* Berth Details */}
        <BerthCargoGearFacility
          passedRef={berthCargoGearRef}
          metaData={metaData}
          data={data}
          handleBerthInputChange={handleBerthInputChange}
          readOnly={readOnly}
          isDry={data.terminalTypeId === berthCargoTypeDry}
        />
        {/* Oil Cargo Handled */}
        {isOfType(oil) && (
          <>
            <OilCargoHandled
              validateNumber={validateNumber}
              passedRef={oilCargoRef}
              metaData={metaData}
              data={data}
              dHandleCargoTypeChange={dHandleCargoTypeChange}
              dDeleteBerthDataCargoHandled={dDeleteBerthDataCargoHandled}
              dUpdateBerthDataCargoHandled={dUpdateBerthDataCargoHandled}
              handleBerthInputChange={handleBerthInputChange}
              readOnly={readOnly}
            />
          </>
        )}
        {/* Gas Cargo Handled */}
        {isOfType(gas) && (
          <>
            <GasCargoHandled
              validateNumber={validateNumber}
              passedRef={gasCargoRef}
              metaData={metaData}
              data={data}
              dHandleCargoTypeChange={dHandleCargoTypeChange}
              dDeleteBerthDataCargoHandled={dDeleteBerthDataCargoHandled}
              dUpdateBerthDataCargoHandled={dUpdateBerthDataCargoHandled}
              handleBerthInputChange={handleBerthInputChange}
              readOnly={readOnly}
              berthTypeId={gas}
            />
          </>
        )}
        {/* Chemical Cargo */}
        {isOfType(chemical) && (
          <>
            <ChemicalCargoHandled
              validateNumber={validateNumber}
              passedRef={chemicalCargoRef}
              metaData={metaData}
              data={data}
              dHandleCargoTypeChange={dHandleCargoTypeChange}
              dDeleteBerthDataCargoHandled={dDeleteBerthDataCargoHandled}
              dUpdateBerthDataCargoHandled={dUpdateBerthDataCargoHandled}
              handleBerthInputChange={handleBerthInputChange}
              readOnly={readOnly}
              berthTypeId={chemical}
            />
          </>
        )}
        {data.terminalTypeId === berthCargoTypeDry && (
          <>
            <DryCargoHandled
              passedRef={dryCargoHandled}
              validateNumber={validateNumber}
              metaData={metaData}
              data={data}
              dHandleCargoTypeChange={dHandleCargoTypeChange}
              dDeleteBerthDataCargoHandled={dDeleteBerthDataCargoHandled}
              dUpdateBerthDataCargoHandled={dUpdateBerthDataCargoHandled}
              handleBerthInputChange={handleBerthInputChange}
              readOnly={readOnly}
              berthCargoTypeDry={berthCargoTypeDry}
            />
          </>
        )}
        {/* Ships Handled */}
        <BerthShipsHandled
          passedRef={shipsHandledRef}
          metaData={metaData}
          data={data}
          vessels={vessels}
          vesselClassification={vesselClassification}
          dHandleCargoTypeChange={dHandleCargoTypeChange}
          dDeleteBerthDataCargoHandled={dDeleteBerthDataCargoHandled}
          dUpdateBerthDataCargoHandled={dUpdateBerthDataCargoHandled}
          readOnly={readOnly}
        />
        {/* Berth Notes */}
        <Row className="add-berth-section-header mb-3 mt-3">
          <Col xs={12}>
            <h4 className="mb-0" ref={berthNotesRef}>
              Berth Notes
            </h4>
          </Col>
        </Row>
        <Row>
          <Col xs={12}>
            {readOnly && (
              <Input
                type="textarea"
                name="ptbBerthNotes"
                id="ptbBerthNotes"
                value={data.ptbBerthNotes}
                onChange={handleBerthInputChange}
                readOnly
                rows={10}
              />
            )}
            {!readOnly && (
              <Input
                type="textarea"
                name="ptbBerthNotes"
                id="ptbBerthNotes"
                value={data.ptbBerthNotes}
                onChange={handleBerthInputChange}
                readOnly={readOnly}
                rows={10}
              />
            )}
          </Col>
        </Row>
        {/* Images */}
        <BerthImages
          passedref={imagesRef}
          title="Berth"
          ptbImage={ptbImage}
          updateImageData={dberthUpdateImageData}
          uploadStatus={uploadStatus}
          dHandleFileUpload={dHandleFileUpload}
          dHandleFileDownload={dHandleFileDownload}
          viewupdateptbImage={berthImages}
          formType={formType}
          berthimageinfo={berthimageinfo}
          dstoreimageinformation={dstoreimageinformation}
          dselectedTerminalBerthimageinfo={dselectedTerminalBerthimageinfo}
          storeselectedberthimagefile={storeselectedberthimagefile}
          confirmBerthImageDeleteModalOpen={confirmBerthImageDeleteModalOpen}
          dopenberthimagepopupconfirmation={dopenberthimagepopupconfirmation}
          dclsoeberthimagepopupconfirmation={dclsoeberthimagepopupconfirmation}
          ddeleteTerminalBerthSelectedImages={
            ddeleteTerminalBerthSelectedImages
          }
          dremoveFromCollection={dremoveFromCollection}
          isLoading={isLoading}
        />
        {/* Berth Documents */}
        <BerthDocuments
          passedref={documentsRef}
          berthdocumenttype={berthdocumenttype}
          numberOfCopies={numberOfCopies}
          berthptbDocument={berthptbDocument}
          formType={formType}
          title="Berth"
          uploadStatus={uploadStatus}
          dberthDocumentsData={dberthDocumentsData}
          dHandleFileUpload={dHandleFileUpload}
          dHandleFileDownload={dHandleFileDownload}
          dvalidatedocumnet={dvalidatedocumnet}
          dsetDocumentName={dsetDocumentName}
          dsetDocumentType={dsetDocumentType}
          dvalidatedfileuploaddocument={dvalidatedfileuploaddocument}
          viewupdateptbDocument={data.ptbDocument}
          portMasterDocumentType={metaData.berthMaster.ptbDocumentTypes}
          berthselecteddocument={berthselecteddocument}
          dselectedDocumentInformation={dselectedDocumentInformation}
          confirmBerthDocumentDeleteModalOpen={
            confirmBerthDocumentDeleteModalOpen
          }
          dopenberthdocumentpopupconfirmation={
            dopenberthdocumentpopupconfirmation
          }
          dcloseberthdocumentpopupconfirmation={
            dcloseberthdocumentpopupconfirmation
          }
          dberthDeleteSelectDocumentInformation={
            dberthDeleteSelectDocumentInformation
          }
          isLoading={isLoading}
        />
        {isViewOnly && data.contactDetails && (
          <>
            <BerthContact
              passedRef={berthContactRef}
              data={data.contactDetails}
            />
          </>
        )}
        {isViewOnly && data.berthChangedHistory && (
          <>
            <Row className="add-berth-section-header mb-3 mt-3">
              <Col xs={12}>
                <h4 className="mb-0" ref={changeHistoryRef}>
                  Change History
                </h4>
              </Col>
            </Row>
            <Row>
              <Col>
                <DataTableList
                  tableHeader={changeHistoryHeaders}
                  tableBody={data.berthChangedHistory}
                  rowsPerPage={5}
                  totalRecords={
                    data.berthChangedHistory
                      ? data.berthChangedHistory.length
                      : 0
                  }
                  moduleId={0}
                />
              </Col>
            </Row>
          </>
        )}
        {filteredAccess(BERTH_MODULE_ID, 'publish') && (
          <>
            <Row className="add-berth-section-header mb-3 mt-3">
              <Col xs={12}>
                <h4 className="mb-0" ref={issBerthNotesRef}>
                  <FormattedMessage {...messages.issBerthNotes} />
                </h4>
              </Col>
            </Row>
            <Row>
              <Col xs={12}>
                {readOnly && (
                  <Input
                    type="textarea"
                    name="internalCommentsNotes"
                    id="internalCommentsNotes"
                    value={data.internalCommentsNotes}
                    onChange={handleBerthInputChange}
                    readOnly
                    rows={10}
                  />
                )}
                {!readOnly && (
                  <Input
                    type="textarea"
                    name="internalCommentsNotes"
                    id="internalCommentsNotes"
                    value={data.internalCommentsNotes}
                    onChange={handleBerthInputChange}
                    readOnly={readOnly}
                    rows={10}
                  />
                )}
              </Col>
            </Row>
          </>
        )}

        {/* Choose Customer */}
        <ChooseCustomer
          passedRef={chooseCustomerRef}
          users={metaUsers}
          onChange={handleBerthInputChange}
          name="berthClientFeedAccess"
          selected={data.berthClientFeedAccess}
          readOnly={readOnly}
          yssTransfer={berthIssTransfer}
          yssTransferType="berthIssTransfer"
          inLegacySystem={data.isCreateInLegacy}
          dhandleYssTransferCheck={dhandleYssTransferCheck}
          statusText={data.status}
          formType={formType}
        />
        {isBerthClientAccessNotSelected && (
          <Row>
            {' '}
            <Col xs={6} md />
            <Col xs={4} md>
              <p className="errorMsg">
                <FormattedMessage {...messages.berthClientAccessMsg} />
              </p>
            </Col>
          </Row>
        )}
        {berthValidationStatus.legacyClient && (
          <Row>
            <Col xs={6} md />
            <Col xs={4} md>
              <p className="errorMsg">
                Please select atleast one Legacy Client to procced.
              </p>
            </Col>
          </Row>
        )}

        {/* Audit Details */}
        {formType.toLowerCase() !== 'add' && (
          <PtbAuditDetails
            auditDetailsRef={auditDetailsRef}
            formType={formType}
            selectedPortData={data}
            formName="Berth"
            isPublish={isPublish}
            handleBerthInputChange={handleBerthInputChange}
          />
        )}
        {formType.toLowerCase() === 'view' && (
          <Row>
            <Col xs={3}>
              <h4>Verified by PTB Admin: </h4>
            </Col>
            <Col>{data.isPublish ? 'Yes' : 'No'}</Col>
          </Row>
        )}
      </Container>
    </>
  );
}

BerthAddViewUpdate.propTypes = {
  metaData: PropTypes.object,
  data: PropTypes.object,
  berthValidationStatus: PropTypes.object,
  handleBerthInputChange: PropTypes.func,
  ptbImage: PropTypes.array,
  updateImageData: PropTypes.func,
  uploadStatus: PropTypes.string,
  dPortImagesData: PropTypes.func,
  dHandleFileUpload: PropTypes.func,
  dHandleFileDownload: PropTypes.func,
  dGetVessels: PropTypes.func,
  dGetUserDetails: PropTypes.func,
  vessels: PropTypes.array,
  dUpdateBerthDataCargoHandled: PropTypes.func,
  dDeleteBerthDataCargoHandled: PropTypes.func,
  dHandleCargoTypeChange: PropTypes.func,
  vesselClassification: PropTypes.array,
  dberthUpdateImageData: PropTypes.func,
  getGeoFencingData: PropTypes.func,
  finalGeoFenceData: PropTypes.object,
  selectedGeoFenceData: PropTypes.object,
  portViewData: PropTypes.object,
  moduleType: PropTypes.string,
  formType: PropTypes.string,
  countryList: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  regionList: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  portsList: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  terminalsList: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  dGetPortsList: PropTypes.func,
  dGetTerminalsList: PropTypes.func,
  berthValidationMessages: PropTypes.object,
  berthImages: PropTypes.array,
  berthimageinfo: PropTypes.array,
  dstoreimageinformation: PropTypes.func,
  dselectedTerminalBerthimageinfo: PropTypes.func,
  storeselectedberthimagefile: PropTypes.array,
  confirmBerthImageDeleteModalOpen: PropTypes.bool,
  dopenberthimagepopupconfirmation: PropTypes.func,
  dclsoeberthimagepopupconfirmation: PropTypes.func,
  ddeleteTerminalBerthSelectedImages: PropTypes.func,
  berthdocumenttype: PropTypes.array,
  numberOfCopies: PropTypes.array,
  berthptbDocument: PropTypes.array,
  dberthDocumentsData: PropTypes.func,
  dvalidatedocumnet: PropTypes.func,
  dsetDocumentName: PropTypes.func,
  dsetDocumentType: PropTypes.func,
  dvalidatedfileuploaddocument: PropTypes.func,
  dselectedDocumentInformation: PropTypes.func,
  berthselecteddocument: PropTypes.array,
  confirmBerthDocumentDeleteModalOpen: PropTypes.bool,
  dopenberthdocumentpopupconfirmation: PropTypes.func,
  dcloseberthdocumentpopupconfirmation: PropTypes.func,
  dberthDeleteSelectDocumentInformation: PropTypes.func,
  dHandleUpdateBerthInputChange: PropTypes.func,
  dremoveFromCollection: PropTypes.func,
  berthIssTransfer: PropTypes.bool,
  dhandleYssTransferCheck: PropTypes.func,
  dGetCountryList: PropTypes.func,
  typeAheadDropdownBerth: PropTypes.oneOfType([
    PropTypes.array,
    PropTypes.object,
  ]),
  geoSelectedTerminalId: PropTypes.string,
  isLoading: PropTypes.bool,
  isBerthClientAccessNotSelected: PropTypes.bool,
  dgetAllPortsDataForMapByPortId: PropTypes.func,
  linkedWithLegacy: PropTypes.object,
  ptbStatus: PropTypes.object,
  isMapRefresh: PropTypes.bool,
  isNotPublishedPTB: PropTypes.bool,
  isPublish: PropTypes.any,
  dsetNewLatLong: PropTypes.func,
  dlocateLatLong: PropTypes.func,
  ptbMapCoordinates: PropTypes.object,
  ptbSelectedCoordinates: PropTypes.object,
  isLocateClicked: PropTypes.bool,
  dDisableLocate: PropTypes.func,
  isInValidLatLng: PropTypes.bool,
  dcloseLocateDialog: PropTypes.func,
};

export default BerthAddViewUpdate;
