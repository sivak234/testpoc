/*
 * BerthAddViewUpdate Messages
 *
 * This contains all the text for the BerthAddViewUpdate component.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.components.BerthAddViewUpdate';

export default defineMessages({
  region: {
    id: `${scope}.region`,
    defaultMessage: 'Region',
  },
  country: {
    id: `${scope}.country`,
    defaultMessage: 'Country',
  },
  portName: {
    id: `${scope}.portName`,
    defaultMessage: 'Port',
  },
  terminal: {
    id: `${scope}.terminal`,
    defaultMessage: 'Terminal',
  },
  berthClientAccessMsg: {
    id: `${scope}.berthClientAccessMsg`,
    defaultMessage: 'Choose one or more Customer',
  },
  issBerthNotes: {
    id: `${scope}.issBerthNotes`,
    defaultMessage: 'ISS Internal Berth Notes',
  },
  isHaveNonPublishedData: {
    id: `${scope}.isHaveNonPublishedData`,
    defaultMessage:
      'There are non-published data saved by other users. Please verify in PTB Status.',
  },
});
