export function getAvaClientUsers(type, metaData) {
  let metaUsers;
  switch (type) {
    case 'Dry':
      metaUsers =
        metaData && metaData.dryUsers.length > 0 ? metaData.dryUsers : [];
      break;
    case 'Wet':
      metaUsers =
        metaData && metaData.wetUsers.length > 0 ? metaData.wetUsers : [];
      break;
    default:
      metaUsers = metaData && metaData.users.length > 0 ? metaData.users : [];
      break;
  }
  return metaUsers;
}
