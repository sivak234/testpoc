/*
 * AccountManagerView Messages
 *
 * This contains all the text for the AccountManagerView component.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.components.AccountManagerView';

export default defineMessages({
  plan: {
    id: `${scope}.plan`,
    defaultMessage: 'Plan',
  },
  duration: {
    id: `${scope}.duration`,
    defaultMessage: 'Duration',
  },
  numberOfLicenses: {
    id: `${scope}.numberOfLicenses`,
    defaultMessage: 'Number of Licenses',
  },
  emailAddress: {
    id: `${scope}.emailAddress`,
    defaultMessage: 'Email Address',
  },
  wopUserName: {
    id: `${scope}.wopUserName`,
    defaultMessage: 'World of Ports User Name',
  },
  upgradeButtonLabel: {
    id: `${scope}.upgradeButtonLabel`,
    defaultMessage: 'Upgrade Plan',
  },
  renewButtonLabel: {
    id: `${scope}.renewButtonLabel`,
    defaultMessage: 'Renew Plan',
  },
  singleUserNoofLicencse: {
    id: `${scope}.singleUserNoofLicencse`,
    defaultMessage: 'Single',
  },

  endson: {
    id: `${scope}.endson`,
    defaultMessage: 'Ends on',
  },

  manageusers: {
    id: `${scope}.manageusers`,
    defaultMessage: 'Manage Users',
  },
});
