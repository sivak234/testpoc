/**
 *
 * AccountManagerView
 *
 */
import React, { memo, useState } from 'react';
import { Redirect, Link } from 'react-router-dom';
import PropTypes from 'prop-types';
import { Row, Col, Button } from 'reactstrap';

import { FormattedMessage } from 'react-intl';
import messages from './messages';
import './index.scss';
import DataTableList from '../DataTableList/Loadable';
import { getDayMonthYearDateFormat } from '../../utils/dataModification';
function AccountManagerView({
  mysubdetail,
  dchangeUpgradePlan,
  isRenewal,
  isRollExpiredEXT,
}) {
  const header = [
    { title: 'Subscription ID', prop: 'subid' },
    { title: 'Transaction ID', prop: 'tid' },
    { title: 'Transaction Date', prop: 'date' },
    { title: 'Payment Mode', prop: 'paymentMode' },
    { title: 'Payment Status', prop: 'paymentStatus' },
    { title: 'Amount', prop: 'amount' },
    { title: 'Currency', prop: 'currency' },
    { title: 'Remarks', prop: 'remarks' },
    {
      title: 'Invoice',
      prop: 'invoice',
      cell: row => <Button className="no-padd" color="link" id={row.invoice} />,
    },
    {
      title: 'Receipt',
      prop: 'receipt',
      cell: row => <Button className="no-padd" color="link" id={row.receipt} />,
    },
  ];

  const subhistoryheader = [
    { title: 'Subscription ID', prop: 'subid' },
    { title: 'Plan Name', prop: 'pname' },
    { title: 'Duration', prop: 'duration' },
    { title: 'Number of Licenses', prop: 'nooflicenses' },
    { title: 'Start Date', prop: 'sdate' },
    { title: 'End Date', prop: 'edate' },
    { title: 'Subscription Fee', prop: 'subAmt' },
    { title: 'Status', prop: 'subStatus' },
  ];
  const [upgrade, setUpgradePlan] = useState(false);
  const [renewal, setRenewalPlan] = useState(false);
  const upgradePlanData = data => {
    dchangeUpgradePlan();
    sessionStorage.setItem('upgradeplan', data);
    sessionStorage.setItem(
      'subscriptionId',
      mysubdetail.mySubscriptionViewModel.subscriptionId,
    );
    sessionStorage.setItem(
      'periodSettingName',
      mysubdetail.mySubscriptionViewModel.periodSettingName,
    );
    sessionStorage.setItem(
      'planTypeName',
      mysubdetail.mySubscriptionViewModel.planTypeName,
    );
    sessionStorage.setItem('renewalType', data);
    sessionStorage.setItem(
      'userGroupId',
      mysubdetail.mySubscriptionViewModel.userGroupId,
    );
    sessionStorage.setItem(
      'subscriberUserEmail',
      mysubdetail.mySubscriptionViewModel.subscriberUserEmail,
    );
    sessionStorage.setItem(
      'subscriberName',
      mysubdetail.mySubscriptionViewModel.subscriberName,
    );
    if (data === 'upgrade') {
      setUpgradePlan(true);
    } else {
      setRenewalPlan(true);
    }
  };

  let paymentDataList = [];
  let subhistorylist = [];
  const primaryProp = 'srNo';
  if (
    mysubdetail.mySubscriptionViewModel !== undefined &&
    mysubdetail.mySubscriptionViewModel !== null
  ) {
    if (
      mysubdetail.mySubscriptionViewModel.subscriptionPaymentDetails !==
        undefined &&
      mysubdetail.mySubscriptionViewModel.subscriptionPaymentDetails !== null
    ) {
      paymentDataList = mysubdetail.mySubscriptionViewModel.subscriptionPaymentDetails.map(
        payObj => ({
          subid: mysubdetail.mySubscriptionViewModel.subscriberId,
          tid: payObj.paymentTransactionNumber,
          date: getDayMonthYearDateFormat(payObj.effectiveDate),
          paymentMode: payObj.paymentModeName,
          paymentStatus: 'Payment Done',
          amount: payObj.subscriptionAmount,
          currency: payObj.currencyCode,
          remarks: payObj.paymentRemarks,
          invoice: payObj.invoice,
          receipt: payObj.receipt,
        }),
      );
    }
  }

  if (
    mysubdetail.mySubscriptionHistoryViewModel !== null &&
    mysubdetail.mySubscriptionHistoryViewModel !== undefined
  ) {
    subhistorylist = mysubdetail.mySubscriptionHistoryViewModel.map(subObj => ({
      subid: subObj.subscriberId,
      pname: subObj.planTypeName,
      duration: subObj.periodSettingName,
      nooflicenses: subObj.noOfLicences,
      sdate: getDayMonthYearDateFormat(subObj.effectiveDate),
      edate: getDayMonthYearDateFormat(subObj.expiryDate),
      subAmt:
        subObj.subscriptionAmount === null ? 0 : subObj.subscriptionAmount,
      subStatus: subObj.priceBandStatus,
    }));
  }

  // subscripton Email
  const isUpgradeExistsAlready =
    !!mysubdetail && !!mysubdetail.mySubscriptionViewModel
      ? mysubdetail.mySubscriptionViewModel.isUpgradeExistsAlready
      : false;

  const isRenewalExistsAlready = isRenewal
    ? true
    : mysubdetail &&
      mysubdetail.mySubscriptionViewModel &&
      mysubdetail.mySubscriptionViewModel.isRenewalExistsAlready;

  let subemail = null;
  let name = null;
  let noOfLicences = null;
  let licencesUsed = null;
  let pricingModuleName = null;
  let planTypeName = null;
  let periodSettingName = null;
  let expiryDate = null;
  const responsive = true;
  let planProgress = '';

  if (
    mysubdetail.mySubscriptionViewModel !== undefined &&
    mysubdetail.mySubscriptionViewModel !== null
  ) {
    subemail = mysubdetail.mySubscriptionViewModel.subscriberUserEmail;
    name = mysubdetail.mySubscriptionViewModel.userLogin;
    noOfLicences = [mysubdetail.mySubscriptionViewModel.noOfLicences];
    licencesUsed = [mysubdetail.mySubscriptionViewModel.licencesUsed];
    pricingModuleName = [mysubdetail.mySubscriptionViewModel.pricingModuleName];
    planTypeName = [mysubdetail.mySubscriptionViewModel.planTypeName];
    periodSettingName = [mysubdetail.mySubscriptionViewModel.periodSettingName];
    expiryDate = [mysubdetail.mySubscriptionViewModel.expiryDate];
    planProgress = mysubdetail.mySubscriptionViewModel.upgradeRenewDescription;
  }

  // Check Account Manager
  let blnaccountmanager;
  let blnsingleuser;

  if (
    mysubdetail.mySubscriptionViewModel !== undefined &&
    mysubdetail.mySubscriptionViewModel !== null &&
    mysubdetail.mySubscriptionViewModel.isAccountManager !== undefined &&
    mysubdetail.mySubscriptionViewModel.isAccountManager !== null
  ) {
    blnaccountmanager = mysubdetail.mySubscriptionViewModel.isAccountManager;
  }

  if (
    mysubdetail.mySubscriptionViewModel !== undefined &&
    mysubdetail.mySubscriptionViewModel !== null &&
    mysubdetail.mySubscriptionViewModel.isSingle !== undefined &&
    mysubdetail.mySubscriptionViewModel.isSingle !== null
  ) {
    blnsingleuser = mysubdetail.mySubscriptionViewModel.isSingle;
  }

  const endson = <FormattedMessage {...messages.endson} />;
  const endsoninfo = endson.props.defaultMessage;
  const isPriceBandStatus =
    mysubdetail.mySubscriptionViewModel !== undefined &&
    mysubdetail.mySubscriptionViewModel !== null &&
    mysubdetail.mySubscriptionViewModel.priceBandStatus !== undefined;
  const loginEmail = localStorage.getItem('email');
  const loginUserName = localStorage.getItem('userName');
  let planStatus = '';
  if (isPriceBandStatus) {
    planStatus = mysubdetail.mySubscriptionViewModel.priceBandStatus;
    if (planProgress !== '') planStatus = `${planStatus} - ${planProgress}`;
  }
  return (
    <>
      {upgrade && sessionStorage.getItem('upgradeplan') === 'upgrade' ? (
        <Redirect to="/upgrade-plan" />
      ) : null}
      {renewal && sessionStorage.getItem('upgradeplan') === 'renewal' ? (
        <Redirect to="/upgrade-plan" />
      ) : null}
      {isPriceBandStatus && (
        <Row>
          <Col className="accountManagerView">
            <Button
              className={
                mysubdetail.mySubscriptionViewModel.priceBandStatus ===
                'Subscription Active'
                  ? 'btnactive'
                  : 'btninactive'
              }
            >
              {planStatus}
            </Button>
          </Col>
        </Row>
      )}
      {planTypeName !== null ? (
        <Row>
          <Col>
            <div className="inner-container mt-0 mb-3">
              <Row className="counter-inner-container">
                <Col xs={12} md={3} className="separated-block">
                  <div className={`${planTypeName} plan-title p-3`}>
                    {planTypeName}
                  </div>
                  <div className="p-3">
                    {pricingModuleName && pricingModuleName.join()}
                  </div>
                </Col>
                <Col xs={12} md>
                  <Row>
                    <Col sm={3} xs={12}>
                      <h5>
                        <FormattedMessage {...messages.duration} />
                      </h5>
                    </Col>
                  </Row>
                  <Row className="gaprow">
                    <Col sm={3} xs={6}>
                      {periodSettingName}
                    </Col>
                    <Col sm={5} xs={6}>
                      {expiryDate !== null && (
                        <>
                          {endsoninfo} {getDayMonthYearDateFormat(expiryDate)}
                        </>
                      )}
                    </Col>
                  </Row>
                  <Row>
                    <Col xs={12}>
                      <h5>
                        <FormattedMessage {...messages.emailAddress} />
                      </h5>
                    </Col>
                  </Row>
                  <Row className="gaprow">
                    <Col>
                      {loginEmail && loginEmail !== '' ? loginEmail : subemail}
                    </Col>
                  </Row>
                </Col>
                <Col xs={12} md>
                  {blnaccountmanager && (
                    <>
                      <Row>
                        <Col>
                          <h5>
                            <FormattedMessage {...messages.numberOfLicenses} />
                          </h5>
                        </Col>
                      </Row>
                      <Row className="gaprow">
                        {!blnsingleuser ? (
                          <>
                            <Col sm={4} xs={6}>
                              {licencesUsed} of {noOfLicences} User
                            </Col>
                            {!isRollExpiredEXT && (
                              <Col sm={5} xs={6}>
                                <Link
                                  to="/subscription-manage-user"
                                  className="manageuser"
                                >
                                  <FormattedMessage {...messages.manageusers} />
                                </Link>
                              </Col>
                            )}
                          </>
                        ) : null}
                      </Row>
                      <Row>
                        {blnsingleuser ? (
                          <>
                            <Col xs={8} className="single-user-detail-info">
                              <FormattedMessage
                                {...messages.singleUserNoofLicencse}
                              />
                            </Col>
                          </>
                        ) : null}
                      </Row>
                    </>
                  )}
                  <Row>
                    <Col>
                      <h5>
                        <FormattedMessage {...messages.wopUserName} />
                      </h5>
                    </Col>
                  </Row>
                  <Row className="gaprow">
                    <Col>
                      {loginUserName && loginUserName !== ''
                        ? loginUserName
                        : name}
                    </Col>
                  </Row>
                </Col>
              </Row>
            </div>
          </Col>
        </Row>
      ) : null}
      {blnaccountmanager || blnsingleuser ? (
        <>
          <Row className="my-3">
            <Col xs={12}>
              <h4>Payment Information</h4>
            </Col>
            <Col xs={12}>
              <DataTableList
                primaryProp={primaryProp}
                tableHeader={header}
                tableBody={paymentDataList}
                rowsPerPage={10}
                responsive={responsive}
                textAreaLength={50}
              />
            </Col>
          </Row>
          <Row id="subhistory">
            <Col xs={12}>
              <h4>Subscription History</h4>
            </Col>
            <Col xs={12}>
              <DataTableList
                primaryProp={primaryProp}
                tableHeader={subhistoryheader}
                tableBody={subhistorylist}
                rowsPerPage={10}
                responsive={responsive}
              />
            </Col>
          </Row>
        </>
      ) : null}
      {blnaccountmanager ? (
        <>
          <Row>
            <Col xs="hide" md />
            {!isRollExpiredEXT ? (
              <Col xs md="auto">
                <Button
                  color="primary"
                  disabled={isUpgradeExistsAlready}
                  type="button"
                  onClick={() => upgradePlanData('upgrade')}
                >
                  <FormattedMessage {...messages.upgradeButtonLabel} />
                </Button>
              </Col>
            ) : null}

            <Col xs md="auto">
              <Button
                color="primary"
                disabled={isRenewalExistsAlready}
                type="button"
                onClick={() => upgradePlanData('renewal')}
              >
                <FormattedMessage {...messages.renewButtonLabel} />
              </Button>
            </Col>
          </Row>
        </>
      ) : null}
    </>
  );
}

AccountManagerView.propTypes = {
  userid: PropTypes.string,
  mysubdetail: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  upgradePlan: PropTypes.any,
  isRenewal: PropTypes.bool,
  dchangeUpgradePlan: PropTypes.any,
  isRollExpiredEXT: PropTypes.bool,
};

export default memo(AccountManagerView);
