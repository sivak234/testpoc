/*
 *
 * AccountManagerView helper
 *
 */
export const paymentResponseObj = [
  {
    tid: '1002927378',
    date: '2019-08-23T10:04:57.481Z',
    paymentMode: 'Credit Card',
    amount: '3,177.27',
    currency: 'USD',
    remarks: 'Payment Successful',
    invoice: 'Download',
    receipt: 'Download',
  },
];

export const subhistoryResponseObj = [
  {
    pname: 'Bronze',
    duration: 'Yearly',
    nooflicenses: '2 to 5',
    sdate: '01-01-2019',
    edate: '31-12-2019',
    tid: '0019275644213',
    tdate: '31-12-2018',
  },
];
