/**
 *
 * Asynchronously loads the component for AccountManagerView
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
