// import { paymentResponseObj } from '../_helper';

// describe('AccountManagerView helpers', () => {
//   describe('Default Helper Function', () => {
//     it('returns the expected value', () => {
//       const expected = 'Sample Text';
//       expect(paymentResponseObj('Sample Text')).toEqual(expected);
//     });
//   });
// });
describe('<AccountManagerView />', () => {
  it('Expect to not log errors in AccountManagerView', () => {
    expect(true).toBeTruthy();
  });
});
