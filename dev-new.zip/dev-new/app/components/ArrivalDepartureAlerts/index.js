/**
 *
 * ArrivalDepartureAlerts
 *
 */

import React, { memo, useEffect } from 'react';
import PropTypes from 'prop-types';

import {
  Row,
  Col,
  FormGroup,
  Input,
  Label,
  Button,
  CustomInput,
} from 'reactstrap';
import { FormattedMessage } from 'react-intl';
import messages from './messages';
import DataTableList from '../DataTableList/Loadable';
import {
  getHeaders,
  getArrivalDepartureAlertForm,
  getSelectedDocumentList,
  getAlertType,
} from './_helper';
import Popup from '../Popup/Loadable';
import './index.scss';
import {
  RenderCommonAlertInputs,
  updateFormValues,
  getSelectedRecord,
  getFormToPost,
  validateForm,
} from '../../containers/MyAlerts/_helper';
import { ARRIVAL_DEPARTURE_ALERT_MODULE_ID } from '../../utils/constants';
import { filteredAccess } from '../../utils/rbac';
function ArrivalDepartureAlerts({
  alerts,
  dGetData,
  dGetEditArrivalDepartureAlert,
  dToggleEditPopup,
  arrivalAndDepartureAlertForm,
  dSetArrivalDepartureAlertForm,
  dGetPortsList,
  dGetTerminalsList,
  countryList,
  portsList,
  terminalsList,
  alertTypeList,
  masterData,
  dGetDocumentList,
  arrivalAndDepartureAlertPopup,
  dToggleDeletePopup,
  selectedAlert,
  dUpdateAlert,
  dAddAlert,
  dToggleInfoPopup,
  vesselListByName,
  dGetVesselByName,
  moduleId,
}) {
  useEffect(() => {
    if (alertTypeList && alerts && alerts.length === 0) {
      dGetData([alertTypeList.Arrival, alertTypeList.Departure]);
    }
  }, [alertTypeList]);

  const handleDelete = id => {
    const updateSelectedAlert = { ...selectedAlert };
    updateSelectedAlert.selectedAlertId = id;
    updateSelectedAlert.selectedAlertType = 'Arrival';
    dToggleDeletePopup(true, updateSelectedAlert);
  };

  const handleEdit = id => {
    const updateSelectedAlert = { ...selectedAlert };
    updateSelectedAlert.selectedAlertId = id;
    updateSelectedAlert.selectedAlertType = 'Arrival';
    dGetEditArrivalDepartureAlert(id, updateSelectedAlert);
  };

  const onHandleChage = el => {
    let form = { ...arrivalAndDepartureAlertForm };
    form = getArrivalDepartureAlertForm(
      [],
      masterData.defaultNotificationList[el.target.getAttribute('data-item')],
    );
    updateFormValues(
      el,
      form,
      dSetArrivalDepartureAlertForm,
      'arrivalAndDepartureAlertForm',
    );
  };

  const handleDocChange = (e, item) => {
    const form = { ...arrivalAndDepartureAlertForm };
    Object.keys(form.documentList).forEach(key => {
      const doc = form.documentList[key];
      if (doc.ptbDocumentId === item.ptbDocumentId) {
        form.documentList[key].isChecked = !doc.isChecked;
      }
    });
    dSetArrivalDepartureAlertForm(form);
  };

  const onAddAlert = () => {
    if (alerts && alerts.length >= 40) {
      dToggleInfoPopup(true, 'arrivalDepartureInfo');
      return;
    }

    const form = getArrivalDepartureAlertForm(
      [],
      masterData.defaultNotificationList.Arrival,
    );
    form.alertType.value = alertTypeList.Arrival;
    dSetArrivalDepartureAlertForm(form);
    dToggleEditPopup('arrivalAndDepartureAlertPopup', true);
  };

  const setFormOtherFields = formData => {
    const form = { ...formData };
    if (form.portId) {
      const port = getSelectedRecord(portsList, 'portId', form.portId);
      if (port) {
        [form.portName, form.portCode] = [
          port.portName.replace(`${port.unlocode}-`, ''),
          port.unlocode,
        ];
      }
    }
    if (form.terminalId) {
      const terminal = getSelectedRecord(
        terminalsList,
        'terminalId',
        form.terminalId,
      );
      if (terminal) {
        [form.terminalName, form.terminalCode] = [
          terminal.terminalName.replace(`${terminal.unlocode}-`, ''),
          terminal.unlocode,
        ];
      }
    }

    if (form.countryId) {
      const country = getSelectedRecord(
        countryList,
        'countryID',
        parseInt(form.countryId, 10),
      );
      form.countryName = country.countryName;
    }
    if (form.vesselId && vesselListByName.data) {
      const vessel = getSelectedRecord(
        vesselListByName.data,
        'vesselId',
        form.vesselId,
      );
      if (vessel) {
        [form.vesselName, form.vesselIMO] = [
          vessel.vesselIMOName.replace(`${vessel.imoNumber}-`, ''),
          vessel.imoNumber,
        ];
      }
    }
    if (form.alertNotificationDurationId) {
      const notification = getSelectedRecord(
        masterData.alertNotificationDurationList,
        'alertNotificationDurationId',
        form.alertNotificationDurationId,
      );
      if (notification) {
        form.alertNotificationDurationDesc =
          notification.alertNotificationDurationDesc;
      }
    }
    if (form.documentList.length > 0) {
      form.documentList = getSelectedDocumentList(form);
    }
    return form;
  };
  const dAddEditAlert = () => {
    const isFormValid = validateForm(arrivalAndDepartureAlertForm);
    if (isFormValid.isValid && isFormValid.isValid === true) {
      const form = setFormOtherFields(
        getFormToPost(arrivalAndDepartureAlertForm),
      );
      if (form.alertCompositeConfigId !== '') {
        dUpdateAlert(form, ARRIVAL_DEPARTURE_ALERT_MODULE_ID);
      } else {
        delete form.alertCompositeConfigId;
        dAddAlert(form, ARRIVAL_DEPARTURE_ALERT_MODULE_ID);
      }
    } else {
      dSetArrivalDepartureAlertForm(isFormValid.form);
    }
  };
  const header = getHeaders(alertTypeList);
  const primaryProp = 'alertCompositeConfigId';
  let docList = <></>;

  if (
    arrivalAndDepartureAlertForm.documentList &&
    arrivalAndDepartureAlertForm.documentList.length > 0
  ) {
    docList = arrivalAndDepartureAlertForm.documentList.map(item => (
      <div key={item.ptbDocumentId}>
        <CustomInput
          type="checkbox"
          data-value={item.ptbDocumentId}
          name={`${item.ptbDocumentId}`}
          label={item.documentName}
          id={`${item.ptbDocumentId}`}
          checked={item.isChecked}
          onChange={e => handleDocChange(e, item)}
        />
      </div>
    ));
  }

  return (
    <>
      <Row>
        <Col>
          <h5 className="m-1">
            <FormattedMessage {...messages.header} />
            {filteredAccess(moduleId, 'add') && (
              <Button
                color="link"
                className="filter pull-right p-0"
                size="md"
                onClick={onAddAlert}
              >
                <FormattedMessage {...messages.addAlert} />
              </Button>
            )}
          </h5>
        </Col>
      </Row>

      <Row>
        <Col className="cardtextdata">
          <DataTableList
            tableHeader={header}
            tableBody={alerts}
            rowsPerPage={20}
            isEditGrid
            fixedColumn
            totalRecords={alerts ? alerts.length : 0}
            moduleId={moduleId}
            editType={['customEdit', 'customDelete']}
            handleCustomDelete={id => handleDelete(id)}
            handleCustomUpdate={id => handleEdit(id)}
            primaryProp={primaryProp}
          />
        </Col>
      </Row>

      <Popup
        size="xl"
        showFooter={false}
        show={arrivalAndDepartureAlertPopup}
        close={() => {
          dToggleEditPopup('arrivalAndDepartureAlertPopup', false);
        }}
        title={
          arrivalAndDepartureAlertForm.alertCompositeConfigId !== ''
            ? messages.editArrivalDepartureAlert.defaultMessage
            : messages.addArrivalDepartureAlert.defaultMessage
        }
        keyboard={false}
      >
        {Object.keys(arrivalAndDepartureAlertForm).length > 0 && (
          <Row className="text-left">
            <Col md={3} sm={12}>
              <Label for="alertType" className="mandate">
                <FormattedMessage {...messages.arrivalType} />
              </Label>
              <div>
                <FormGroup check inline>
                  <Label check>
                    <Input
                      disabled={
                        arrivalAndDepartureAlertForm.alertCompositeConfigId !==
                        ''
                      }
                      type="radio"
                      value={alertTypeList.Arrival}
                      name="alertType"
                      data-item="Arrival"
                      checked={
                        arrivalAndDepartureAlertForm.alertType &&
                        arrivalAndDepartureAlertForm.alertType.value ===
                          alertTypeList.Arrival
                      }
                      onChange={onHandleChage}
                    />
                    <FormattedMessage {...messages.arrival} />
                  </Label>
                </FormGroup>
                <FormGroup check inline>
                  <Label check>
                    <Input
                      disabled={
                        arrivalAndDepartureAlertForm.alertCompositeConfigId !==
                        ''
                      }
                      type="radio"
                      value={alertTypeList.Departure}
                      name="alertType"
                      data-item="Departure"
                      checked={
                        arrivalAndDepartureAlertForm.alertType &&
                        arrivalAndDepartureAlertForm.alertType.value ===
                          alertTypeList.Departure
                      }
                      onChange={onHandleChage}
                    />
                    <FormattedMessage {...messages.departure} />
                  </Label>
                </FormGroup>
              </div>
            </Col>

            <RenderCommonAlertInputs
              isEditMode={
                arrivalAndDepartureAlertForm.alertCompositeConfigId !== ''
              }
              formName={arrivalAndDepartureAlertForm}
              countryList={countryList}
              portsList={portsList}
              dGetDocumentList={dGetDocumentList}
              vesselListByName={vesselListByName}
              dGetVesselByName={dGetVesselByName}
              dGetPortsList={dGetPortsList}
              dGetTerminalsList={dGetTerminalsList}
              dFormUpdate={dSetArrivalDepartureAlertForm}
              terminalsList={terminalsList}
              masterData={masterData}
              notificationType={getAlertType(
                arrivalAndDepartureAlertForm,
                alertTypeList,
              )}
              notificationDurationLabel={
                arrivalAndDepartureAlertForm.alertType &&
                arrivalAndDepartureAlertForm.alertType.value ===
                  alertTypeList.Arrival
                  ? messages.notificationDurationBeforeArrival.defaultMessage
                  : messages.notificationDurationAfterDeparture.defaultMessage
              }
            />
            <Col md={3} sm={12}>
              <Label for="documentList">
                <FormattedMessage {...messages.documentList} />
              </Label>
              <FormGroup>{docList}</FormGroup>
            </Col>
          </Row>
        )}
        <Row className="text-center">
          <Col>
            <Button
              className="mr-2"
              color="primary"
              onClick={() => {
                dAddEditAlert();
              }}
            >
              {arrivalAndDepartureAlertForm.alertCompositeConfigId !== '' ? (
                <FormattedMessage {...messages.updateAlert} />
              ) : (
                <FormattedMessage {...messages.addAlert} />
              )}
            </Button>
            <Button
              color="primary"
              outline
              onClick={() => {
                dToggleEditPopup('arrivalAndDepartureAlertPopup', false);
              }}
            >
              <FormattedMessage {...messages.cancel} />
            </Button>
          </Col>
        </Row>
      </Popup>
    </>
  );
}

ArrivalDepartureAlerts.propTypes = {
  alerts: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  dGetData: PropTypes.func,
  dGetEditArrivalDepartureAlert: PropTypes.func,
  dToggleEditPopup: PropTypes.func,
  arrivalAndDepartureAlertRecord: PropTypes.oneOfType([
    PropTypes.array,
    PropTypes.object,
  ]),
  arrivalAndDepartureAlertForm: PropTypes.oneOfType([
    PropTypes.array,
    PropTypes.object,
  ]),
  dSetArrivalDepartureAlertForm: PropTypes.func,
  dGetPortsList: PropTypes.func,
  dGetTerminalsList: PropTypes.func,
  dToggleDeletePopup: PropTypes.func,
  countryList: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  portsList: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  terminalsList: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  alertTypeList: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  masterData: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  dGetDocumentList: PropTypes.func,
  arrivalAndDepartureAlertPopup: PropTypes.bool,
  selectedAlert: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  dUpdateAlert: PropTypes.func,
  dAddAlert: PropTypes.func,
  dSetPopupMessage: PropTypes.func,
  dToggleInfoPopup: PropTypes.func,
  vesselListByName: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  dGetVesselByName: PropTypes.func,
  moduleId: PropTypes.any,
};

export default memo(ArrivalDepartureAlerts);
