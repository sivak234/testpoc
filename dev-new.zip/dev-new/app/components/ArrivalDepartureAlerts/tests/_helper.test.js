// import { defaultFunction } from '../_helper';

// describe('ArrivalDepartureAlerts helpers', () => {
//   describe('Default Helper Function', () => {
//     it('returns the expected value', () => {
//       const expected = 'Sample Text';
//       expect('Sample Text').toEqual(expected);
//     });
//   });
// });
describe('<ArrivalDepartureAlerts />', () => {
  it('Expect to not log errors in ArrivalDepartureAlerts', () => {
    expect(true).toBeTruthy();
  });
});
