/**
 *
 * Asynchronously loads the component for ArrivalDepartureAlerts
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
