/*
 * ArrivalDepartureAlerts Messages
 *
 * This contains all the text for the ArrivalDepartureAlerts component.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.components.ArrivalDepartureAlerts';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'Arrival & Departure Alerts',
  },
  deleteSearch: {
    id: `${scope}.deleteSearch`,
    defaultMessage: 'Delete Search',
  },
  confirmDeleteMessage: {
    id: `${scope}.deleteSearch`,
    defaultMessage: 'Are you sure you want to delete this saved search?',
  },
  labelYes: {
    id: `${scope}.labelYes`,
    defaultMessage: 'Yes',
  },
  labelNo: {
    id: `${scope}.labelNo`,
    defaultMessage: 'No',
  },
  deleteSuccessMessage: {
    id: `${scope}.deleteSuccessMessage`,
    defaultMessage: 'Record Deleted Successfully!',
  },
  labelOk: {
    id: `${scope}.labelOk`,
    defaultMessage: 'Ok',
  },
  alertType: {
    id: `${scope}.alertType`,
    defaultMessage: 'Alert Type',
  },

  country: {
    id: `${scope}.country`,
    defaultMessage: 'Country',
  },
  portName: {
    id: `${scope}.portName`,
    defaultMessage: 'Port Name',
  },
  portCode: {
    id: `${scope}.portCode`,
    defaultMessage: 'Port Code',
  },
  terminal: {
    id: `${scope}.terminal`,
    defaultMessage: 'Terminal',
  },
  monitorFrom: {
    id: `${scope}.monitorFrom`,
    defaultMessage: 'Monitor From',
  },

  monitorTo: {
    id: `${scope}.monitorTo`,
    defaultMessage: 'Monitor To',
  },

  imoNumber: {
    id: `${scope}.imoNumber`,
    defaultMessage: 'IMO Number',
  },
  notificationDurationBeforeArrivalOrDeparture: {
    id: `${scope}.notificationDurationBeforeArrivalOrDeparture`,
    defaultMessage: 'Notification Duration Before Arrival / After Departure',
  },
  emailId: {
    id: `${scope}.emailId`,
    defaultMessage: 'Email ID',
  },
  attachedDocuments: {
    id: `${scope}.attachedDocuments`,
    defaultMessage: 'Attached Documents',
  },
  editArrivalDepartureAlert: {
    id: `${scope}.editArrivalDepartureAlert`,
    defaultMessage: 'Edit Arrival/Departure Alert',
  },
  addArrivalDepartureAlert: {
    id: `${scope}.addArrivalDepartureAlert`,
    defaultMessage: 'Add Arrival/Departure Alert',
  },
  arrivalType: {
    id: `${scope}.arrivalType`,
    defaultMessage: 'Arrival Type',
  },
  arrival: {
    id: `${scope}.arrival`,
    defaultMessage: 'Arrival',
  },
  vesselName: {
    id: `${scope}.vesselName`,
    defaultMessage: 'Vessel Name',
  },
  departure: {
    id: `${scope}.departure`,
    defaultMessage: 'Departure',
  },
  notificationDurationBeforeArrival: {
    id: `${scope}.notificationDurationBeforeArrival`,
    defaultMessage: 'Notification Duration Before Arrival',
  },
  notificationDurationAfterDeparture: {
    id: `${scope}.notificationDurationAfterDeparture`,
    defaultMessage: 'Notification Duration After Departure',
  },
  documentList: {
    id: `${scope}.documentList`,
    defaultMessage: 'Document List',
  },
  editPopupTitle: {
    id: `${scope}.editPopupTitle`,
    defaultMessage: 'Edit Arrival/Departure Alert',
  },
  editSuccessMessage: {
    id: `${scope}.editSuccessMessage`,
    defaultMessage: 'Alert updated successfully',
  },
  addPopupTitle: {
    id: `${scope}.addPopupTitle`,
    defaultMessage: 'Add Arrival/Departure Alert',
  },
  addSuccessMessage: {
    id: `${scope}.addSuccessMessage`,
    defaultMessage: 'Alert added successfully',
  },
  addAlert: {
    id: `${scope}.addAlert`,
    defaultMessage: 'Add Alert',
  },
  updateAlert: {
    id: `${scope}.updateAlert`,
    defaultMessage: 'Update Alert',
  },
  cancel: {
    id: `${scope}.cancel`,
    defaultMessage: 'Cancel',
  },
});
