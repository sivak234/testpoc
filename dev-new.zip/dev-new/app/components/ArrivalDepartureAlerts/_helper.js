/*
 *
 * ArrivalDepartureAlerts helper
 *
 */
import React from 'react';
// import { Button, Row, Col } from 'reactstrap';
// import { FormattedMessage } from 'react-intl';
import messages from './messages';

import { formatAlertsDate } from '../../containers/MyAlerts/_helper';

const getAlertName = (id, alertList) =>
  alertList.Arrival === id ? 'Arrival' : 'Departure';

export function getHeaders(alertList) {
  return [
    {
      title: messages.alertType.defaultMessage,
      prop: '',
      cell: row => <>{getAlertName(row.alertTypeId, alertList)}</>,
    },
    { title: messages.country.defaultMessage, prop: 'countryName' },
    {
      title: messages.portName.defaultMessage,
      prop: 'portName',
    },
    {
      title: messages.portCode.defaultMessage,
      prop: 'portCode',
    },
    { title: messages.terminal.defaultMessage, prop: 'terminalName' },
    {
      title: messages.monitorFrom.defaultMessage,
      prop: '',
      cell: row => <>{formatAlertsDate(row.monitorFrom)}</>,
    },
    {
      title: messages.monitorTo.defaultMessage,
      prop: '',
      cell: row => <>{formatAlertsDate(row.monitorTo)}</>,
    },
    { title: messages.vesselName.defaultMessage, prop: 'vesselName' },
    { title: messages.imoNumber.defaultMessage, prop: 'vesselIMO' },
    {
      title:
        messages.notificationDurationBeforeArrivalOrDeparture.defaultMessage,
      prop: 'alertNotificationDurationDesc',
    },
    { title: messages.emailId.defaultMessage, prop: 'emailRecipient' },
  ];
}

export function getArrivalDepartureAlertForm(data, defaultNotification = '') {
  return {
    alertCompositeConfigId: data.alertCompositeConfigId
      ? data.alertCompositeConfigId
      : '',
    alertType: {
      value: data.alertTypeId ? data.alertTypeId : '',
    },
    country: {
      value: data.countryId ? data.countryId : '',
      isInvalid: false,
      // regularExp: /^([a-zA-Z0-9 _-]){1,100}$/,
    },
    portId: {
      value: data.portId ? data.portId : '',
      isInvalid: false,
      regularExp: /^.{1,200}$/,
    },
    terminalId: {
      value: data.terminalId ? data.terminalId : '',
    },
    monitorFrom: {
      value: data.monitorFrom ? new Date(data.monitorFrom) : '',
      isInvalid: false,
      regularExp: /^.{1,200}$/,
    },
    monitorTo: {
      value: data.monitorTo ? new Date(data.monitorTo) : '',
      isInvalid: false,
      regularExp: /^.{1,200}$/,
    },
    vesselName: {
      value: data.vesselId ? data.vesselId : '',
      isInvalid: false,
      regularExp: /^.{1,200}$/,
    },
    vesselNameImoText: {
      value: [
        {
          vesselIMOName: data.vesselName
            ? `${data.vesselIMO}-${data.vesselName}`
            : '',
        },
      ],
    },
    alertNotificationDurationId: {
      value: data.alertNotificationDurationId
        ? data.alertNotificationDurationId
        : defaultNotification,
    },
    emailSignature: {
      value: data.emailSignature ? data.emailSignature : '',
    },
    emailRecipient: {
      value: data.emailRecipient
        ? data.emailRecipient
        : localStorage.getItem('email'),
      isInvalid: false,
      regularExp: /^([\w+-.%]+@[\w-.]+\.[A-Za-z]{2,4})(;[\w+-.%]+@[\w-.]+\.[A-Za-z]{2,4}){0,4}$/,
    },
    documentList: data.documentList ? data.documentList : [],
  };
}

export function setDocumentList(data, selectedDocuments) {
  const documentList = [];
  data.forEach(item => {
    let isChecked = false;
    let selectedDoc = {};
    if (selectedDocuments.length > 0) {
      for (let i = 0; i < selectedDocuments.length; i += 1) {
        if (selectedDocuments[i].ptbDocumentId === item.ptbDocumentId) {
          isChecked = true;
          selectedDoc = { ...selectedDocuments[i] };
        }
      }
    }
    documentList.push({ ...item, isChecked, ...selectedDoc });
  });
  return documentList;
}

export const getSelectedDocumentList = form => {
  const documents = [];
  form.documentList.forEach(item => {
    if (item.isChecked === true) {
      documents.push({
        ...item,
        ptbDocumentId: item.ptbDocumentId,
        wopDocumentName: item.documentName,
      });
    }
  });
  return documents;
};

export const getAlertType = (arrivalAndDepartureAlertForm, alertTypeList) => {
  if (!arrivalAndDepartureAlertForm.alertType) return 'isArrival';

  return arrivalAndDepartureAlertForm.alertType.value === alertTypeList.Arrival
    ? 'isArrival'
    : 'isDeparture';
};
