/*
 * AdvanceSearchFilter Messages
 *
 * This contains all the text for the AdvanceSearchFilter component.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.components.AdvanceSearchFilter';

export default defineMessages({
  filters: {
    id: `${scope}.filters`,
    defaultMessage: 'Filters',
  },
  vesselsTurnAroundTime: {
    id: `${scope}.vesselsTurnAroundTime`,
    defaultMessage: 'Vessel Turn Around Time',
  },
  mainCargoType: {
    id: `${scope}.mainCargoType`,
    defaultMessage: 'Cargo',
  },
  clearAll: {
    id: `${scope}.clearAll`,
    defaultMessage: 'Clear All',
  },

  regions: {
    id: `${scope}.regions`,
    defaultMessage: 'Region',
  },

  countries: {
    id: `${scope}.countries`,
    defaultMessage: 'Country',
  },
  cargoType: {
    id: `${scope}.cargoType`,
    defaultMessage: 'Cargo Type',
  },
  shipType: {
    id: `${scope}.shipType`,
    defaultMessage: 'Ship Type',
  },
  shipSize: {
    id: `${scope}.shipSize`,
    defaultMessage: 'Ship Size',
  },
  productType: {
    id: `${scope}.productType`,
    defaultMessage: 'Grade',
  },
  berthStyle: {
    id: `${scope}.berthStyle`,
    defaultMessage: 'Berth Style',
  },
  apply: {
    id: `${scope}.apply`,
    defaultMessage: 'Apply',
  },
});
