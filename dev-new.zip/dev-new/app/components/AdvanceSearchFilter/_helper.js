/*
 *
 * AdvanceSearchFilter helper
 *
 */
import { getPostFilters } from '../AdvanceSearchPage/_helper';
export function defaultFunction(text) {
  return text;
}

function updateChild(data, selectedParents) {
  const modifiedData = data.filter(item =>
    selectedParents.includes(item.foreginKey),
  );
  return modifiedData.length === 0 ? data : [data[0], ...modifiedData];
}

function updateParent(rawData, key, state, entireFilter) {
  let parent;
  const data = [...rawData];
  data.forEach(item => {
    if (item.entityId === key) {
      parent = item;
    }
  });

  if (!state) {
    let i = 0;
    entireFilter[parent.child].forEach(item => {
      if (item.foreginKey === key && item.isChecked) i += 1;
    });
    if (i < 1)
      data.forEach(item => {
        const modifiedItem = item;
        if (modifiedItem.entityId === key) modifiedItem.isChecked = state;
      });
  } else {
    data.forEach(item => {
      const modifiedItem = item;
      if (modifiedItem.entityId === key) modifiedItem.isChecked = state;
    });
  }
  return data;
}

export function mapParentChild(data, modifiedData, key, initData) {
  const mappedData = { ...data };
  try {
    // If parent is checked
    if (modifiedData.isParent) {
      const selectedParents = data[key]
        .filter(item => item.isChecked === true)
        .map(i => i.entityId);

      mappedData[modifiedData.child] = updateChild(
        initData[modifiedData.child],
        selectedParents,
      );
    } else if (!modifiedData.isParent) {
      mappedData[modifiedData.parent] = updateParent(
        data[modifiedData.parent],
        modifiedData.foreginKey,
        modifiedData.isChecked,
        data,
      );
    }

    // If a fiter is both a parent as well as child
    if (modifiedData.isBoth) {
      mappedData[modifiedData.parent] = updateParent(
        data[modifiedData.parent],
        modifiedData.foreginKey,
        modifiedData.isChecked,
        data,
      );
    }

    // If grade is selected then select till level 2 i.e.; cargos
    if (key.toLowerCase() === 'producttype') {
      mappedData.cargoType = updateParent(
        data.cargoType,
        modifiedData.rootKey,
        modifiedData.isChecked,
        data,
      );
    }
  } catch (error) {
    // console.log(error);
  }
  return mappedData;
}

export function clearSearchSelection(rawData, dClearFilter, dGetPortList) {
  const data = { ...rawData };
  Object.keys(data).forEach(item => {
    data[item].forEach(row => {
      const modifiedItem = row;
      modifiedItem.isChecked = false;
    });
  });
  dClearFilter(data);
  dGetPortList({
    page: 1,
    pageSize: 10,
    filters: getPostFilters(rawData),
  });
}

export function updateDropdown(value, key, modifiedData) {
  const data = { ...modifiedData };
  try {
    data[key].forEach(row => {
      const modifiedItem = row;
      modifiedItem.isChecked = false;
      if (modifiedItem.entityId.toString() === value)
        modifiedItem.isChecked = true;
    });
  } catch (error) {
    // console.log(error);
  }
  return data;
}

export function selectAll(rawData, key, state) {
  const data = { ...rawData };
  try {
    data[key].forEach(row => {
      const modifiedItem = row;
      modifiedItem.isChecked = state;
    });
  } catch (error) {
    // console.log(error);
  }
  return data;
}

export function getFilteredCountries(data, query) {
  const modifiedData = { ...data };
  try {
    const selectedParents = data.regions
      .filter(item => item.isChecked === true)
      .map(i => i.entityId);

    if (selectedParents.length !== 0)
      modifiedData.countries = data.countries.filter(item =>
        selectedParents.includes(item.foreginKey),
      );

    if (query !== '')
      modifiedData.countries = modifiedData.countries.filter(el => {
        if (el.entityId !== -1) {
          const searchValue = el.entityName.toLowerCase();
          return searchValue.indexOf(query.toLowerCase()) !== -1;
        }
        return true;
      });
  } catch (error) {
    // console.log(error);
  }

  if (modifiedData.countries.filter(i => i.entityId === -1).length === 0) {
    return [data.countries[0], ...modifiedData.countries];
  }
  return [...modifiedData.countries];
}
export function getFilterdCargoValues(data, query) {
  const modifiedData = { ...data };
  try {
    const selectedParents = data.cargoType
      .filter(item => item.isChecked === true)
      .map(i => i.entityId);

    if (selectedParents.length !== 0)
      modifiedData.mainCargoType = data.mainCargoType.filter(item =>
        selectedParents.includes(item.foreginKey),
      );

    if (query !== '')
      modifiedData.mainCargoType = modifiedData.mainCargoType.filter(el => {
        if (el.entityId !== -1) {
          const searchValue = el.entityName.toLowerCase();
          return searchValue.indexOf(query.toLowerCase()) !== -1;
        }
        return true;
      });
  } catch (error) {
    // console.log(error);
  }

  if (modifiedData.mainCargoType.filter(i => i.entityId === -1).length === 0) {
    return [data.mainCargoType[0], ...modifiedData.mainCargoType];
  }
  return [...modifiedData.mainCargoType];
}

export function getFilterdProductType(data, query) {
  const modifiedData = { ...data };
  try {
    const selectedParents = data.mainCargoType
      .filter(item => item.isChecked === true)
      .map(i => i.entityId);

    if (selectedParents.length !== 0)
      modifiedData.productType = data.productType.filter(item =>
        selectedParents.includes(item.foreginKey),
      );

    if (query !== '')
      modifiedData.productType = modifiedData.productType.filter(el => {
        if (el.entityId !== -1) {
          const searchValue = el.entityName.toLowerCase();
          return searchValue.indexOf(query.toLowerCase()) !== -1;
        }
        return true;
      });
  } catch (error) {
    // console.log(error);
  }

  if (modifiedData.productType.filter(i => i.entityId === -1).length === 0) {
    return [data.productType[0], ...modifiedData.productType];
  }
  return [...modifiedData.productType];
}

export function getFilterdShipSize(data, query) {
  const modifiedData = { ...data };
  try {
    const selectedParents = data.shipType
      .filter(item => item.isChecked === true)
      .map(i => i.entityId);

    if (selectedParents.length !== 0)
      modifiedData.shipSize = data.shipSize.filter(item =>
        selectedParents.includes(item.foreginKey),
      );

    if (query !== '')
      modifiedData.shipSize = modifiedData.shipSize.filter(el => {
        if (el.entityId !== -1) {
          const searchValue = el.entityName.toLowerCase();
          return searchValue.indexOf(query.toLowerCase()) !== -1;
        }
        return true;
      });
  } catch (error) {
    // console.log(error);
  }

  if (modifiedData.shipSize.filter(i => i.entityId === -1).length === 0) {
    return [data.shipSize[0], ...modifiedData.shipSize];
  }
  return [...modifiedData.shipSize];
}
