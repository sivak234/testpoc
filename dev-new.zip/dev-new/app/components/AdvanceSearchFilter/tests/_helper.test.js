// import { defaultFunction } from '../_helper';

// describe('AdvanceSearchFilter helpers', () => {
//   describe('Default Helper Function', () => {
//     it('returns the expected value', () => {
//       const expected = 'Sample Text';
//       expect(defaultFunction('Sample Text')).toEqual(expected);
//     });
//   });
// });
describe('<AdvanceSearchFilter />', () => {
  it('Expect to not log errors in AdvanceSearchFilter', () => {
    expect(true).toBeTruthy();
  });
});
