/**
 *
 * AdvanceSearchFilter
 *
 */

import React, { useState } from 'react';
import { FormattedMessage } from 'react-intl';
import {
  Row,
  Col,
  Input,
  Button,
  CustomInput,
  TabPane,
  ListGroup,
  ListGroupItem,
  TabContent,
  Popover,
  PopoverBody,
} from 'reactstrap';
import PropTypes from 'prop-types';
import messages from './messages';
import Dropdown from '../Dropdown';
import {
  mapParentChild,
  clearSearchSelection,
  selectAll,
  updateDropdown,
  getFilteredCountries,
  getFilterdCargoValues,
  getFilterdProductType,
  getFilterdShipSize,
} from './_helper';

import { getPostFilters } from '../AdvanceSearchPage/_helper';

import './index.scss';

function AdvanceSearchFilter({
  data,
  initData,
  dUpdateFilter,
  dClearFilter,
  dGetPortList,
  dResetGrid,
  countrySearchValue,
  dSetAdvanceFilterData,
}) {
  const element = [];
  const userAgent = navigator.userAgent || navigator.vendor || window.opera;
  const isMobile = /iPhone|iPad|iPod|Android/i.test(userAgent);
  const [activeTab, setActiveTab] = useState('regions');
  const [isOpen, setIsOpen] = useState(false);

  const tooglePopover = () => {
    setIsOpen(!isOpen);
  };

  const selectionCallback = (modifiedData, key) => {
    const newData = mapParentChild(data, modifiedData, key, initData);
    if (key.toLowerCase() === 'cargotype') {
      const filteredMainCargo = [...newData.mainCargoType.map(j => j.entityId)];
      const newProducts = [
        ...initData.productType.filter(i =>
          filteredMainCargo.includes(i.foreginKey),
        ),
      ];
      if (newProducts.length !== 0)
        newData.productType = [
          {
            entityId: -1,
            entityName: 'All',
            isChecked: false,
          },
          ...newProducts,
        ];
    }
    newData[key][0].isChecked = false;
    dUpdateFilter(newData);
  };

  const selectionAllCallback = (key, state) => {
    try {
      let newData = selectAll(data, key, state);
      if (newData[key][1].isParent)
        newData = mapParentChild(newData, newData[key][1], key, initData);
      dUpdateFilter(newData);
    } catch (err) {
      // console.log(err);
    }
  };

  const clearFilter = () => {
    clearSearchSelection(data, dClearFilter, dGetPortList);
    dResetGrid();
  };

  const onApplyFilter = e => {
    /* This is to store filter data in application level state */
    if (data && data !== null) {
      dSetAdvanceFilterData(data);
    }
    /* This is to store filter data in application level state */
    if (document.getElementById('popover-filter'))
      document.getElementById('popover-filter').click();
    dGetPortList({
      page: 1,
      pageSize: 10,
      filters: getPostFilters(data),
    });
    dResetGrid();
    e.preventDefault();
  };
  const dropDownCallback = (evt, key) => {
    const newData = updateDropdown(evt.target.value, key, data);
    dUpdateFilter(newData);
  };

  const refreshSection = e => {
    const newData = { ...data };
    dUpdateFilter(newData, e.target.value);
  };

  let countries = [];
  if (Object.keys(initData).length !== 0)
    countries = [
      ...getFilteredCountries(
        initData,
        document.getElementById('query')
          ? document.getElementById('query').value
          : '',
      ),
    ];

  let mainCargoType = [];
  if (Object.keys(initData).length !== 0)
    mainCargoType = [
      ...getFilterdCargoValues(
        initData,
        document.getElementById('query')
          ? document.getElementById('query').value
          : '',
      ),
    ];

  let productType = [];
  if (Object.keys(initData).length !== 0)
    productType = [
      ...getFilterdProductType(
        initData,
        document.getElementById('query')
          ? document.getElementById('query').value
          : '',
      ),
    ];

  let shipSize = [];
  if (Object.keys(initData).length !== 0)
    shipSize = [
      ...getFilterdShipSize(
        initData,
        document.getElementById('query')
          ? document.getElementById('query').value
          : '',
      ),
    ];

  Object.keys(data).forEach(item => {
    switch (item) {
      case 'berthStyle':
        element.push(
          generateDropdown(data[item], item, dropDownCallback, false, isMobile),
        );
        break;
      case 'vesselsTurnAroundTime':
        {
          const select = data.shipType
            ? isShipTypeAndSizeSelected(data.shipType, data.shipSize)
            : false;
          element.push(
            generateDropdown(
              data[item],
              item,
              dropDownCallback,
              select,
              isMobile,
            ),
          );
        }
        break;
      case 'countries':
        element.push(
          <GenerateCountryList
            data={countries}
            selectionCallback={selectionCallback}
            selectionAllCallback={selectionAllCallback}
            refreshSection={refreshSection}
            isMobile={isMobile}
            countrySearchValue={countrySearchValue}
          />,
        );
        break;
      case 'mainCargoType':
        element.push(
          generateCheckList(
            mainCargoType,
            item,
            selectionCallback,
            selectionAllCallback,
            isMobile,
            selectVal,
            data,
          ),
        );
        break;
      case 'productType':
        element.push(
          generateCheckList(
            productType,
            item,
            selectionCallback,
            selectionAllCallback,
            isMobile,
            selectVal,
            data,
          ),
        );
        break;
      case 'shipSize':
        element.push(
          generateCheckList(
            shipSize,
            item,
            selectionCallback,
            selectionAllCallback,
            isMobile,
            selectVal,
            data,
          ),
        );
        break;
      default:
        // eslint-disable-next-line no-case-declarations
        let selectVal = data.shipType ? getTypeAndTimeVal(data) : false;
        if (selectVal && item === 'shipSize') {
          selectVal = true;
        } else {
          selectVal = false;
        }
        element.push(
          generateCheckList(
            data[item],
            item,
            selectionCallback,
            selectionAllCallback,
            isMobile,
            selectVal,
            data,
          ),
        );
    }
  });

  let displayedFilter = <></>;
  if (isMobile) {
    displayedFilter = (
      <div className="scroll-mobile-filter d-md-none d-lg-none d-xl-none d-sm-block">
        <Row>
          <Col xs="4">
            <ListGroup id="list-tab" role="tablist">
              {Object.keys(data).map(item => (
                <ListGroupItem
                  onClick={() => setActiveTab(item)}
                  action
                  active={activeTab === item}
                >
                  <FormattedMessage {...messages[item]} />
                </ListGroupItem>
              ))}
            </ListGroup>
          </Col>
          <Col xs="8">
            <TabContent activeTab={activeTab}>{element}</TabContent>
          </Col>
        </Row>
      </div>
    );
  } else {
    displayedFilter = <div className="d-none d-sm-block">{element}</div>;
  }

  const innerContent = (
    <>
      <div className="filter-container">
        <Row>
          <Col xs="12" sm="12" className="filter-popover-header">
            <h4 className="title float-left p-0 m-0">
              <FormattedMessage {...messages.filters} />
            </h4>

            <Button
              color="link"
              className="filter float-right p-0 m-0"
              size="md"
              onClick={clearFilter}
            >
              <FormattedMessage {...messages.clearAll} />
            </Button>
          </Col>
        </Row>
        {displayedFilter}
      </div>
      <Row>
        <Col>
          <Button
            onClick={e => onApplyFilter(e)}
            className="pull-right mt-3 btn-block ml-1"
            color="primary"
            type="button"
            size="md"
          >
            <FormattedMessage {...messages.apply} />
          </Button>
        </Col>
      </Row>
    </>
  );

  let finalContent = <></>;
  if (isMobile)
    finalContent = (
      <Popover
        placement="bottom-end"
        isOpen={isOpen}
        target="popover-filter"
        toggle={tooglePopover}
        trigger="legacy"
        delay={{ show: 200, hide: 200 }}
        className="popover-adv-search"
      >
        <PopoverBody>{innerContent}</PopoverBody>
      </Popover>
    );
  else finalContent = innerContent;
  return <>{finalContent}</>;
}

AdvanceSearchFilter.propTypes = {
  data: PropTypes.oneOfType([PropTypes.array, PropTypes.object]).isRequired,
  initData: PropTypes.oneOfType([PropTypes.array, PropTypes.object]).isRequired,
  dUpdateFilter: PropTypes.func,
  dClearFilter: PropTypes.func,
  dGetPortList: PropTypes.func,
  dResetGrid: PropTypes.func,
  countrySearchValue: PropTypes.string,
  dSetAdvanceFilterData: PropTypes.func,
};

function getTypeAndTimeVal(typeAndTimeData) {
  let typeTimeVal = false;
  const getTypeSize = data => data.some(item => item.isChecked);
  const shipSelected = getTypeSize(typeAndTimeData.shipType);
  const sizeSelected = getTypeSize(typeAndTimeData.shipSize);
  const tatSelected = getTypeSize(typeAndTimeData.vesselsTurnAroundTime);
  if (tatSelected && sizeSelected) {
    const selectedValue = [
      ...typeAndTimeData.vesselsTurnAroundTime.filter(item => item.isChecked),
    ];
    selectedValue[0].isChecked = false;
    updateDropdown(selectedValue, 'vesselsTurnAroundTime', typeAndTimeData);
  }

  if (shipSelected && tatSelected && !sizeSelected) {
    typeTimeVal = true;
  }
  return typeTimeVal;
}
const generateCheckList = (
  data,
  key,
  selectionCallback,
  selectionAllCallback,
  isMobile,
  readOnly = false,
  allFiltersData,
) => {
  const handleChange = (event, item, modifiedKey) => {
    const selectedItem = item;
    selectedItem.isChecked = event.target.checked;

    if (parseInt(event.target.getAttribute('data-value'), 10) === -1) {
      selectionAllCallback(modifiedKey, item.isChecked);
    } else {
      selectionCallback(item, modifiedKey);
    }
    const getTAT = timeData => timeData.some(dataItem => dataItem.isChecked);
    if (allFiltersData.vesselsTurnAroundTime) {
      const tataVal = getTAT(allFiltersData.vesselsTurnAroundTime);
      if (tataVal && !selectedItem.isChecked && modifiedKey === 'shipType') {
        const selectedValue = [
          ...allFiltersData.vesselsTurnAroundTime.filter(rec => rec.isChecked),
        ];
        selectedValue[0].isChecked = false;
        updateDropdown(selectedValue, 'vesselsTurnAroundTime', allFiltersData);
      }
    }
  };

  const className = key === 'regions' ? 'section-reigion' : 'section';
  let list = <></>;
  if (data) {
    list = data.map(item => (
      <li key={item.entityId}>
        <CustomInput
          type="checkbox"
          data-value={item.entityId}
          name={`${key}${item.entityId}`}
          label={item.entityName}
          id={`${key}${item.entityId}`}
          checked={item.isChecked}
          onChange={e => handleChange(e, item, key)}
          disabled={readOnly}
        />
      </li>
    ));
  }

  let clEl = <></>;
  if (isMobile)
    clEl = (
      <TabPane tabId={key} className="d-md-none d-lg-none d-xl-none d-sm-block">
        <hr />
        <ul className={className}>{list}</ul>
      </TabPane>
    );
  else
    clEl = (
      <>
        <hr className="d-none d-sm-block" />
        <Row className="d-none d-sm-block">
          <Col>
            <h4>
              <FormattedMessage {...messages[key]} />
            </h4>
          </Col>
        </Row>
        <Row className="d-none d-sm-block">
          <Col xs="12">
            <ul className={className}>{list}</ul>
          </Col>
        </Row>
      </>
    );
  return <>{clEl}</>;
};
const getTypeSize = data => data.some(item => item.isChecked);
// const isShipTypeAndSizeSelected = data => data.some(item => item.isChecked);

function isShipTypeAndSizeSelected(typeData, sizeData) {
  let check = false;
  // const sizeAndTypeData = [...typeData, ...sizeData];
  // const typeSize = getTypeSize(sizeAndTypeData);
  const typecChecked = getTypeSize(typeData);
  const sizeCheked = getTypeSize(sizeData);
  if (typecChecked && sizeCheked) {
    check = true;
  }
  return check;
}
const generateDropdown = (
  data,
  key,
  handleChangeCallBack,
  readOnly = false,
  isMobile,
) => {
  function getSelectedEntity() {
    const selectedValue = [...data.filter(item => item.isChecked)];
    if (selectedValue.length !== 0) return selectedValue[0].entityId;
    return '';
  }

  if (!data) return <></>;
  const options = data.map(item => (
    <option key={item.entityId} value={item.entityId}>
      {item.entityName}
    </option>
  ));

  let ddEl = <></>;
  if (isMobile)
    ddEl = (
      <TabPane tabId={key} className="d-md-none d-lg-none d-xl-none d-sm-block">
        <hr />
        <Dropdown
          label={<FormattedMessage {...messages[key]} />}
          selected={getSelectedEntity()}
          options={options}
          onChange={e => handleChangeCallBack(e, key)}
          isDisabled={readOnly}
        />
      </TabPane>
    );
  else
    ddEl = (
      <>
        <hr className="d-none d-sm-block" />
        <Row className="d-none d-sm-block">
          <Col xs="12" className="advance-search-dynamic-dropdown">
            <Dropdown
              label={<FormattedMessage {...messages[key]} />}
              selected={getSelectedEntity()}
              options={options}
              onChange={e => handleChangeCallBack(e, key)}
              isDisabled={readOnly}
            />
          </Col>
        </Row>
      </>
    );
  return <>{ddEl}</>;
};

function GenerateCountryList({
  data,
  selectionCallback,
  selectionAllCallback,
  refreshSection,
  isMobile,
  countrySearchValue,
}) {
  const newData = data;
  const handleChange = (event, item, modifiedKey) => {
    const selectedKey = item;
    selectedKey.isChecked = event.target.checked;
    if (parseInt(event.target.name, 10) === -1) {
      newData.map(row => {
        const modifiedRow = row;
        modifiedRow.isChecked = item.isChecked;
        return modifiedRow;
      });
      selectionAllCallback(modifiedKey, item.isChecked);
    } else {
      selectionCallback(item, modifiedKey);
    }
  };

  const generateList = () =>
    newData.map(item => (
      <li key={item.entityId}>
        <CustomInput
          type="checkbox"
          label={item.entityName}
          data-value={item.entityId}
          id={`country${item.entityId}`}
          name={item.entityId}
          checked={item.isChecked}
          onChange={e => handleChange(e, item, 'countries')}
        />
      </li>
    ));

  const list = generateList();

  const searchBox = (
    <div>
      <Input
        type="text"
        size="sm"
        name="countrySearch"
        onChange={e => refreshSection(e)}
        placeholder="Search Country..."
        id="query"
        value={countrySearchValue}
      />
      <div className="search-icon">
        <i className="fa fa-search" aria-hidden="true" />
      </div>
    </div>
  );

  let countryListEl;
  if (isMobile)
    countryListEl = (
      <TabPane
        tabId="countries"
        className="d-md-none d-lg-none d-xl-none d-sm-block"
      >
        <hr />
        <Row>
          <Col xs="12">{searchBox}</Col>
          <Col xs="12">
            <ul className="section">{list}</ul>
          </Col>
        </Row>
      </TabPane>
    );
  else
    countryListEl = (
      <>
        <Row className="d-none d-sm-block">
          <Col>
            <hr />
          </Col>
        </Row>
        <Row className="section-filter-header d-none d-sm-block">
          <Col xs="12">
            <h4>
              <FormattedMessage {...messages.countries} />
            </h4>
          </Col>
          <Col xs="12">{searchBox}</Col>
        </Row>
        <Row className="d-none d-sm-block">
          <Col xs="12">
            <ul className="section">{list}</ul>
          </Col>
        </Row>
      </>
    );

  return <>{countryListEl}</>;
}
GenerateCountryList.propTypes = {
  data: PropTypes.oneOfType([PropTypes.array, PropTypes.object]).isRequired,
  selectionCallback: PropTypes.func,
  selectionAllCallback: PropTypes.func,
  refreshSection: PropTypes.func,
  dResetGrid: PropTypes.func,
  isMobile: PropTypes.any,
  countrySearchValue: PropTypes.string,
};

export default AdvanceSearchFilter;
