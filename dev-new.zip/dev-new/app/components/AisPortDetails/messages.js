/*
 * AisPortDetails Messages
 *
 * This contains all the text for the AisPortDetails component.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.components.AisPortDetails';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'VIEW PORT MOVEMENT',
  },
  portDetail: {
    id: `${scope}.portDetail`,
    defaultMessage: 'Port Details',
  },
  portStatistics: {
    id: `${scope}.portStatistics`,
    defaultMessage: 'Port Statistics',
  },
  region: {
    id: `${scope}.region`,
    defaultMessage: 'Region',
  },
  country: {
    id: `${scope}.country`,
    defaultMessage: 'Country',
  },
  numberofTerminal: {
    id: `${scope}.numberofTerminal`,
    defaultMessage: 'Number of Terminals',
  },
  numberofBerth: {
    id: `${scope}.numberofBerth`,
    defaultMessage: 'Number of Berths',
  },
  latitude: {
    id: `${scope}.latitude`,
    defaultMessage: 'Latitude',
  },
  longitude: {
    id: `${scope}.longitude`,
    defaultMessage: 'Longitude',
  },
  vesselinPort: {
    id: `${scope}.vesselinPort`,
    defaultMessage: 'Vessels at Port',
  },
  vesselatBerth: {
    id: `${scope}.vesselatBerth`,
    defaultMessage: 'Vessels at Berth',
  },
  vesselatAnchorage: {
    id: `${scope}.vesselatAnchorage`,
    defaultMessage: 'Vessels at Anchorage',
  },
  vesselDeparted: {
    id: `${scope}.vesselDeparted`,
    defaultMessage: 'Vessels Departed Last 24 Hours',
  },
  vesselArrivedLast: {
    id: `${scope}.vesselArrivedLast`,
    defaultMessage: 'Vessels Arrived Last 24 Hours',
  },
  vesselArrivedNext: {
    id: `${scope}.vesselArrivedNext`,
    defaultMessage: 'Vessels Arriving Next 24 Hours',
  },
  portVesselMovementTitle: {
    id: `${scope}.portVesselMovementTitle`,
    defaultMessage: 'Vessel Movement',
  },
  portVesselMovementBackNavBtn: {
    id: `${scope}.portVesselMovementBackNavBtn`,
    defaultMessage: 'Back',
  },
});
