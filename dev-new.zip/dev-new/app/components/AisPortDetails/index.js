/**
 *
 * AisPortDetails
 *
 */

import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import {
  Button,
  Col,
  CustomInput,
  Input,
  Label,
  FormGroup,
  Row,
  Popover,
  PopoverBody,
} from 'reactstrap';
import { FormattedMessage } from 'react-intl';
import _ from 'lodash';
import messages from './messages';
import { FETCH_RECORD_COUNT } from '../../utils/constants';
import AisReportExport from '../AisReportExport/Loadable';
import AisPortSearch from '../AisPortSearch/Loadable';
import DialogBox from '../DialogBox/Loadable';
import AisMap from '../AisMap/Loadable';
import AisVesselPortSearch from '../AisVesselPortSearch/Loadable';

function AisPortDetails({
  moduleId,
  fetchSearchVessel,
  fetchFromDate,
  fetchToDate,
  fromDate,
  fetchTerminalCheckboxUpdate,
  fetchBerthCheckboxUpdate,
  toDate,
  portVesselData,
  portMovementMapData,
  vesselTypeOptions,
  handleExportPortData,
  handleAddRow,
  mainCargoTypeList,
  cargoTypeList,
  terminalsList,
  berthsList,
  terminalChecked,
  berthChecked,
  operation,
  nextPortsList,
  preiousPortsList,
  charterersList,
  shippersList,
  receiversList,
  agentsList,
  handleVesselItemChanged,
  handlePortBackLanding,
  handleAddVesselMovement,
  hanldeUpdateVesselMovement,
  hanldeDeleteVesselMovement,
  isModelOpen,
  handleModelClose,
  portStatisticDetails,
  portDetailsValue,
  handleCancelVesselMovement,
  portTypeFilterOption,
  commodityList,
  fetchVesselData,
  changeFieldName,
  modelMessage,
  handleSelectedRowData,
  totalRecords,
  dshowLocalTime,
  isShowLocaltime,
  isShowLocalTimeMsg,
  berthsData,
  mainCargoTypeData,
  cargoTypeData,
  commodityData,
  fetchVesselName,
  vesselName,
  fetchPortName,
  portName,
  dAutoCompletePopover,
  isShowAutoCompletepopOver,
  dTerminalBerthLoadOnEdit,
  vesselOperation,
  showVesselPopOver,
  dToggleVesselPopOver,
  portDetailsCounts,
  mapRefresh,
  countryName,
  vesselDetails,
  fetchAisVesselVoyageDetails,
  fetchAisVesselDetails,
  fetchAisVesselData,
  fetchselectedImoData,
  fetchNearestRangeVesselsByImo,
  portDetails,
  fetchPortDetails,
  fetchPortStatisticDetails,
  fetchPortMoveMapData,
  fetchTerminalCodeNames,
}) {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  const portIdvalue = portDetailsValue ? portDetailsValue.portId : '';
  const fgetSearchVessel = e => {
    const option = e.target.value;
    fetchSearchVessel(option);
    const options = {
      portId: portIdvalue,
      pageNo: 0,
      fetchRecordCount: FETCH_RECORD_COUNT,
    };
    fetchVesselData(options);
  };
  const onTerminalCheckBoxClicked = evt => {
    fetchTerminalCheckboxUpdate({
      type: evt.target.id,
      terminalChecked: evt.target.checked,
    });
  };
  const onBerthCheckBoxClicked = evt => {
    fetchBerthCheckboxUpdate({
      type: evt.target.id,
      berthChecked: evt.target.checked,
    });
  };
  const handleLocaltime = evt => {
    dshowLocalTime(evt.target.checked);
    const options = {
      portId: portIdvalue,
      pageNo: 0,
      fetchRecordCount: FETCH_RECORD_COUNT,
    };
    fetchVesselData(options);
  };
  const getVesselData = value => {
    const options = {
      portId: portIdvalue,
      pageNo: value.pageNo,
      fetchRecordCount: value.fetchRecordCount,
    };
    fetchVesselData(options);
  };
  const handleExport = () => {
    const options = {
      portId: portIdvalue,
      pageNo: 0,
      fetchRecordCount: 100000,
    };
    handleExportPortData(options);
  };
  let latitude = '';
  let longitude = '';
  if (portDetailsValue !== undefined && portDetailsValue.portCoordinates) {
    const index = 0;
    const { coordinates } = JSON.parse(portDetailsValue.portCoordinates);
    latitude = coordinates[index + 1];
    longitude = coordinates[index];
  }
  let portVesselDataFilter = portVesselData;
  if (portTypeFilterOption.length > 0) {
    portVesselDataFilter = portVesselData.filter(item =>
      portTypeFilterOption.includes(item.wopvesseltypeId),
    );
  }

  const [panel, setPanel] = useState(false);

  const toggleButton = () => {
    if (!panel) {
      setPanel(true);
    } else {
      setPanel(false);
    }
  };
  const hanldecheckbox = value => {
    let ischeck = false;
    if (_.includes(portTypeFilterOption, value)) {
      ischeck = true;
    }
    return ischeck;
  };

  const vesselPortPopOver = () => {
    if (!showVesselPopOver) {
      dToggleVesselPopOver(true);
    } else {
      dToggleVesselPopOver(false);
    }
  };
  return (
    <>
      <AisVesselPortSearch
        vesselName={vesselName}
        vesselDetails={vesselDetails}
        fetchVesselName={fetchVesselName}
        fetchAisVesselVoyageDetails={fetchAisVesselVoyageDetails}
        fetchAisVesselDetails={fetchAisVesselDetails}
        fetchAisVesselData={fetchAisVesselData}
        fetchselectedImoData={fetchselectedImoData}
        fetchNearestRangeVesselsByImo={fetchNearestRangeVesselsByImo}
        portName={portName}
        portDetails={portDetails}
        fetchPortName={fetchPortName}
        fetchPortDetails={fetchPortDetails}
        fetchPortStatisticDetails={fetchPortStatisticDetails}
        fetchVesselData={fetchVesselData}
        fetchPortMoveMapData={fetchPortMoveMapData}
        fetchTerminalCodeNames={fetchTerminalCodeNames}
      />
      <Row className="port-movement-section-card">
        <Col>
          <Row className="mb-3">
            <Col xs="10">
              <h4 className="mt-1 mb-1">
                {portDetailsValue ? portDetailsValue.portName : ''} |{' '}
                {portDetailsValue ? portDetailsValue.unlocode : ''}
              </h4>
            </Col>
            <Col xs="2" className="text-right">
              <Button
                color="primary"
                size="sm"
                onClick={e => handlePortBackLanding(e)}
              >
                <FormattedMessage {...messages.portVesselMovementBackNavBtn} />
              </Button>
            </Col>
          </Row>
          <Row className="port-details-section">
            <Col xs="1">
              <Button outline color="success" size="sm" onClick={toggleButton}>
                <span className="menu-toggler-icon" />
                <span className="menu-toggler-icon" />
                <span className="menu-toggler-icon" />
              </Button>
            </Col>
            {panel ? (
              <Col xs="5">
                <Row>
                  <Col xs="12">
                    <Row className="ais-management-container-search-header mb-4">
                      <Col xs="12">
                        <h4 className="mb-0">
                          <FormattedMessage {...messages.portDetail} />
                        </h4>
                      </Col>
                    </Row>
                    <Row className="ais-port-movement-label-container">
                      <Col xs="4">
                        <Label>
                          <FormattedMessage {...messages.region} />
                        </Label>
                      </Col>
                      <Col xs="4">
                        <Label>
                          <FormattedMessage {...messages.country} />
                        </Label>
                      </Col>
                      <Col xs="4">
                        <Label>
                          <FormattedMessage {...messages.numberofTerminal} />
                        </Label>
                      </Col>
                    </Row>
                    <Row>
                      <Col xs="4">
                        <Label>
                          {portDetailsValue ? portDetailsValue.regionName : ''}
                        </Label>
                      </Col>
                      <Col xs="4">
                        <Label>
                          {portDetailsValue ? portDetailsValue.countryName : ''}
                        </Label>
                      </Col>
                      <Col xs="4">
                        <Label>
                          {portDetailsCounts
                            ? portDetailsCounts.noOfTerminals
                            : ''}
                        </Label>
                      </Col>
                    </Row>

                    <Row className="mt-2 ais-port-movement-label-container">
                      <Col xs="4">
                        <Label>
                          <FormattedMessage {...messages.numberofBerth} />
                        </Label>
                      </Col>
                      <Col xs="4">
                        <Label>
                          <FormattedMessage {...messages.latitude} />
                        </Label>
                      </Col>
                      <Col xs="4">
                        <Label>
                          <FormattedMessage {...messages.longitude} />
                        </Label>
                      </Col>
                    </Row>
                    <Row>
                      <Col xs="4">
                        <Label>
                          {portDetailsCounts
                            ? portDetailsCounts.noOfBerths
                            : ''}
                        </Label>
                      </Col>
                      <Col xs="4">
                        <Label>{latitude}</Label>
                      </Col>
                      <Col xs="4">
                        <Label>{longitude}</Label>
                      </Col>
                    </Row>
                  </Col>
                </Row>
                <Row className="mt-4">
                  <Col xs="12">
                    <Row className="port-statistics-section">
                      <Col xs="12">
                        <Row className="ais-management-container-search-header mb-4">
                          <Col xs="12">
                            <h4 className="mb-0">
                              <FormattedMessage {...messages.portStatistics} />
                            </h4>
                          </Col>
                        </Row>
                        <Row className="ais-port-movement-label-container">
                          <Col xs="4">
                            <Label>
                              <FormattedMessage {...messages.vesselinPort} />
                            </Label>
                          </Col>
                          <Col xs="4">
                            <Label>
                              <FormattedMessage {...messages.vesselatBerth} />
                            </Label>
                          </Col>
                          <Col xs="4">
                            <Label>
                              <FormattedMessage
                                {...messages.vesselatAnchorage}
                              />
                            </Label>
                          </Col>
                        </Row>

                        <Row>
                          <Col xs="4">
                            <Label>
                              {portStatisticDetails !== null
                                ? portStatisticDetails.vesselsInPorts
                                : ''}
                            </Label>
                          </Col>
                          <Col xs="4">
                            <Label>
                              {portStatisticDetails !== null
                                ? portStatisticDetails.vesselsAtBerth
                                : ''}
                            </Label>
                          </Col>
                          <Col xs="4">
                            <Label>
                              {portStatisticDetails !== null
                                ? portStatisticDetails.vesselsAtAnchorage
                                : ''}
                            </Label>
                          </Col>
                        </Row>

                        <Row className="mt-2 ais-port-movement-label-container">
                          <Col xs="4">
                            <Label>
                              <FormattedMessage {...messages.vesselDeparted} />
                            </Label>
                          </Col>
                          <Col xs="4">
                            <Label>
                              <FormattedMessage
                                {...messages.vesselArrivedLast}
                              />
                            </Label>
                          </Col>
                          <Col xs="4">
                            <Label>
                              <FormattedMessage
                                {...messages.vesselArrivedNext}
                              />
                            </Label>
                          </Col>
                        </Row>

                        <Row>
                          <Col xs="4">
                            <Label>
                              {portStatisticDetails !== null
                                ? portStatisticDetails.vesselsDeparted
                                : ''}
                            </Label>
                          </Col>
                          <Col xs="4">
                            <Label>
                              {portStatisticDetails !== null
                                ? portStatisticDetails.vesselsArrived
                                : ''}
                            </Label>
                          </Col>
                          <Col xs="4">
                            <Label>
                              {portStatisticDetails !== null
                                ? portStatisticDetails.vesselsArriving
                                : ''}
                            </Label>
                          </Col>
                        </Row>
                      </Col>
                    </Row>
                  </Col>
                </Row>
              </Col>
            ) : (
              ''
            )}
            <Col xs={panel ? '6' : '11'}>
              <Row>
                <Col xs={12}>
                  <div
                    className="inner-container p-0 mt-0"
                    style={{ display: 'flex' }}
                  >
                    <Col xs={10}>
                      <FormGroup className="mt-0 mb-0 pb-3 pt-3 d-flex form-container">
                        <CustomInput
                          type="checkbox"
                          id="PORT_POLYGON"
                          name="showPort"
                          label="Terminal"
                          className="pr-3"
                          checked={terminalChecked}
                          onClick={evt => onTerminalCheckBoxClicked(evt)}
                        />
                        <CustomInput
                          type="checkbox"
                          id="TERMINAL_POLYGON"
                          name="showTerminal"
                          label="Berth"
                          className="pr-3"
                          checked={berthChecked}
                          onClick={evt => onBerthCheckBoxClicked(evt)}
                        />
                      </FormGroup>
                    </Col>
                    <Col xs={2} className="text-right pt-1">
                      <Button
                        id="shiptTypeShow"
                        color="link"
                        onClick={() => vesselPortPopOver()}
                      >
                        <i className="fa fa-info color-primary fa-lg" />
                      </Button>
                      <Popover
                        placement="bottom"
                        isOpen={showVesselPopOver}
                        target="shiptTypeShow"
                      >
                        <PopoverBody>
                          <Col xs={12} className="pl-0 pr-0">
                            <h4 className="mb-2">Ship Type</h4>
                          </Col>
                          <Col xs={12} className="pl-0 pr-0">
                            <div className="mb-1">
                              <span className="color vessel-marker-red mr-2 mt-1" />
                              Bulk Carrier
                            </div>
                            <div className="mb-1">
                              <span className="color vessel-marker-paleorange mr-2 mt-1" />
                              Gas Carrier
                            </div>
                            <div className="mb-1">
                              <span className="color vessel-marker-pink mr-2 mt-1" />
                              General Cargo
                            </div>
                            <div className="mb-1">
                              <span className="color vessel-marker-light-blue mr-2 mt-1" />
                              Passenger
                            </div>
                            <div className="mb-1">
                              <span className="color vessel-marker-orange mr-2 mt-1" />
                              Container
                            </div>
                            <div className="mb-1">
                              <span className="color vessel-marker-green mr-2 mt-1" />
                              Tanker
                            </div>
                            <div className="mb-1">
                              <span className="color vessel-marker-brawn mr-2 mt-1" />
                              RoRo
                            </div>
                            <div className="mb-1">
                              <span className="color vessel-marker-grey mr-2 mt-1" />
                              Others
                            </div>
                            <div className="mb-1">
                              <span className="color vessel-marker-black mr-2 mt-1 text-center">
                                <span className="ballast-color ballast-marker-white" />
                              </span>
                              Ballast
                            </div>
                          </Col>
                        </PopoverBody>
                      </Popover>
                    </Col>
                  </div>
                </Col>
              </Row>

              <AisMap
                mapScreenView="AISPortMovementMap"
                terminalChecked={terminalChecked}
                berthChecked={berthChecked}
                portMovementMapData={portMovementMapData}
                mapHeight="700px"
                mapElementHeight="90%"
                mapRefresh={mapRefresh}
                countryName={countryName}
              />
            </Col>
          </Row>
          <Row className="mb-3 mt-3">
            <Col>
              <h4 className="ais-management-container-search-header mb-0">
                <FormattedMessage {...messages.portVesselMovementTitle} />
              </h4>
            </Col>
          </Row>
          <Row>
            <Col
              xs="12"
              className="vessel-movement-check"
              style={{ marginLeft: '6px' }}
            >
              {vesselTypeOptions.map(item => (
                <FormGroup check className="custom-control custom-checkbox">
                  <Input
                    type="checkbox"
                    id={item.wopVesselDesc}
                    className="custom-control-input"
                    key={Math.random()}
                    name={item.wopVesselDesc}
                    checked={hanldecheckbox(item.mstWopVesselTypeId)}
                    value={item.mstWopVesselTypeId}
                    onChange={e => fgetSearchVessel(e)}
                  />
                  <Label
                    check
                    for={item.wopVesselDesc}
                    className="custom-control-label"
                  >
                    {item.wopVesselDesc}
                  </Label>
                </FormGroup>
              ))}
            </Col>
            <Col xs="7" className="mt-3">
              <AisReportExport
                fetchFromDate={fetchFromDate}
                fetchToDate={fetchToDate}
                fromDate={fromDate}
                toDate={toDate}
                portVesselData={portVesselData}
                handleExportPortData={handleExport}
              />
            </Col>
          </Row>
          <Row>
            <Col>
              <AisPortSearch
                moduleId={moduleId}
                portVesselData={portVesselDataFilter}
                handleAddRow={handleAddRow}
                mainCargoTypeList={mainCargoTypeList}
                cargoTypeList={cargoTypeList}
                terminalsList={terminalsList}
                berthsList={berthsList}
                operation={operation}
                nextPortsList={nextPortsList}
                preiousPortsList={preiousPortsList}
                charterersList={charterersList}
                shippersList={shippersList}
                receiversList={receiversList}
                agentsList={agentsList}
                handleVesselItemChanged={handleVesselItemChanged}
                handleAddVesselMovement={handleAddVesselMovement}
                hanldeUpdateVesselMovement={hanldeUpdateVesselMovement}
                hanldeDeleteVesselMovement={hanldeDeleteVesselMovement}
                handleCancelVesselMovement={handleCancelVesselMovement}
                commodityList={commodityList}
                portId={portIdvalue}
                changeFieldName={changeFieldName}
                handleSelectedRowData={handleSelectedRowData}
                fetchVesselData={getVesselData}
                totalRecords={totalRecords}
                handleLocaltime={handleLocaltime}
                isShowLocaltime={isShowLocaltime}
                isShowLocalTimeMsg={isShowLocalTimeMsg}
                berthsData={berthsData}
                mainCargoTypeData={mainCargoTypeData}
                cargoTypeData={cargoTypeData}
                commodityData={commodityData}
                fetchVesselName={fetchVesselName}
                vesselName={vesselName}
                fetchPortName={fetchPortName}
                portName={portName}
                dAutoCompletePopover={dAutoCompletePopover}
                isShowAutoCompletepopOver={isShowAutoCompletepopOver}
                dTerminalBerthLoadOnEdit={dTerminalBerthLoadOnEdit}
                vesselOperation={vesselOperation}
              />
            </Col>
          </Row>
          {isModelOpen && (
            <DialogBox
              show={isModelOpen}
              fetchModelClose={handleModelClose}
              title={modelMessage.modelTitle}
              statusCode=""
              content={modelMessage.modelContent}
            />
          )}
        </Col>
      </Row>
    </>
  );
}

AisPortDetails.propTypes = {
  moduleId: PropTypes.number.isRequired,
  fetchSearchVessel: PropTypes.func.isRequired,
  fetchFromDate: PropTypes.func.isRequired,
  fetchToDate: PropTypes.func.isRequired,
  fromDate: PropTypes.object,
  fetchTerminalCheckboxUpdate: PropTypes.func.isRequired,
  fetchBerthCheckboxUpdate: PropTypes.func.isRequired,
  toDate: PropTypes.object,
  portVesselData: PropTypes.array.isRequired,
  portMovementMapData: PropTypes.object.isRequired,
  terminalChecked: PropTypes.bool.isRequired,
  berthChecked: PropTypes.bool.isRequired,
  handleVesselGridItemChanged: PropTypes.func,
  vesselTypeOptions: PropTypes.array.isRequired,
  handleExportPortData: PropTypes.func.isRequired,
  handleAddRow: PropTypes.func.isRequired,
  mainCargoTypeList: PropTypes.array.isRequired,
  cargoTypeList: PropTypes.array.isRequired,
  terminalsList: PropTypes.array.isRequired,
  berthsList: PropTypes.array.isRequired,
  operation: PropTypes.array.isRequired,
  nextPortsList: PropTypes.array.isRequired,
  preiousPortsList: PropTypes.array.isRequired,
  charterersList: PropTypes.array.isRequired,
  shippersList: PropTypes.array.isRequired,
  receiversList: PropTypes.array.isRequired,
  agentsList: PropTypes.array.isRequired,
  handleVesselItemChanged: PropTypes.func.isRequired,
  handlePortBackLanding: PropTypes.func.isRequired,
  handleAddVesselMovement: PropTypes.func.isRequired,
  hanldeUpdateVesselMovement: PropTypes.func.isRequired,
  hanldeDeleteVesselMovement: PropTypes.func.isRequired,
  isModelOpen: PropTypes.bool.isRequired,
  handleModelClose: PropTypes.func.isRequired,
  portStatisticDetails: PropTypes.object.isRequired,
  portDetailsValue: PropTypes.object,
  handleCancelVesselMovement: PropTypes.func.isRequired,
  portTypeFilterOption: PropTypes.array.isRequired,
  commodityList: PropTypes.array.isRequired,
  portId: PropTypes.string,
  changeFieldName: PropTypes.string.isRequired,
  modelMessage: PropTypes.object.isRequired,
  handleSelectedRowData: PropTypes.func.isRequired,
  fetchVesselData: PropTypes.func.isRequired,
  totalRecords: PropTypes.number.isRequired,
  dshowLocalTime: PropTypes.func.isRequired,
  isShowLocaltime: PropTypes.bool.isRequired,
  isShowLocalTimeMsg: PropTypes.bool.isRequired,
  berthsData: PropTypes.array.isRequired,
  mainCargoTypeData: PropTypes.array.isRequired,
  cargoTypeData: PropTypes.array.isRequired,
  commodityData: PropTypes.array.isRequired,
  fetchVesselName: PropTypes.func,
  vesselName: PropTypes.array.isRequired,
  fetchPortName: PropTypes.func,
  portName: PropTypes.array.isRequired,
  dAutoCompletePopover: PropTypes.func,
  isShowAutoCompletepopOver: PropTypes.bool.isRequired,
  dTerminalBerthLoadOnEdit: PropTypes.func.isRequired,
  vesselOperation: PropTypes.array.isRequired,
  showVesselPopOver: PropTypes.bool,
  dToggleVesselPopOver: PropTypes.func,
  portDetailsCounts: PropTypes.object,
  mapRefresh: PropTypes.bool,
  countryName: PropTypes.string,
  vesselDetails: PropTypes.object,
  fetchAisVesselVoyageDetails: PropTypes.func,
  fetchAisVesselDetails: PropTypes.func,
  fetchAisVesselData: PropTypes.func,
  fetchselectedImoData: PropTypes.func,
  fetchNearestRangeVesselsByImo: PropTypes.func,
  portDetails: PropTypes.object,
  fetchPortDetails: PropTypes.func,
  fetchPortStatisticDetails: PropTypes.func,
  fetchPortMoveMapData: PropTypes.func,
  fetchTerminalCodeNames: PropTypes.func,
};
export default AisPortDetails;
