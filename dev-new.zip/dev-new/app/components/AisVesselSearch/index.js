/**
 *
 * AisVesselSearch
 *
 */

import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { FormattedMessage } from 'react-intl';
import { Button, Row, Col, CustomInput } from 'reactstrap';
import messages from './messages';
import DataTableList from '../DataTableList/Loadable';
import DeleteModal from '../DeleteModal/Loadable';
import { portHeader, primaryProp, emptyRow, fixedColumns } from './_helper';
import './index.scss';

function AisVesselSearch({
  moduleId,
  portVesselData,
  handleAddRow,
  mainCargoTypeList,
  cargoTypeList,
  vesselsList,
  terminalsList,
  berthsList,
  operation,
  nextPortsList,
  previousPortsList,
  charterersList,
  shippersList,
  receiversList,
  agentsList,
  handleVesselItemChanged,
  handleAddVesselMovement,
  handleUpdateVesselMovement,
  handleDeleteVesselMovement,
  handleCancelVesselMovement,
  vesselImo,
  commodityList,
  changeFieldName,
  handleSelectedRowData,
  fetchAisVesselData,
  totalRecords,
  handleLocaltime,
  isShowLocaltime,
  isShowLocalTimeMsg,
  berthsData,
  mainCargoTypeData,
  cargoTypeData,
  commodityData,
  fetchVesselName,
  vesselName,
  fetchPortName,
  portName,
  dAutoCompletePopover,
  isShowAutoCompletepopOver,
  dTerminalBerthLoadOnEdit,
  vesselOperation,
  currentpage,
}) {
  const [isShowDeleteModel, handleShowDeleteModel] = useState(false);
  const [selectedDeleteRow, handleSelectedDeleteRow] = useState(null);
  const changeHandler = data => {
    handleVesselItemChanged(data);
  };
  const dropdownData = {
    mainCargoTypeList,
    cargoTypeList,
    vesselsList,
    terminalsList,
    berthsList,
    operation,
    nextPortsList,
    previousPortsList,
    charterersList,
    shippersList,
    receiversList,
    agentsList,
    handleVesselItemChanged,
    commodityList,
    berthsData,
    mainCargoTypeData,
    cargoTypeData,
    commodityData,
    vesselOperation,
  };
  const header = portHeader(dropdownData);

  const handleAddVessel = objData => {
    const data = { objAdd: objData, page: 'vessel' };
    handleAddVesselMovement(data);
  };
  const hanldeUpdateVessel = objData => {
    const data = { objUpdate: objData, page: 'vessel' };
    handleUpdateVesselMovement(data);
  };
  const handleSelectedRow = data => {
    handleSelectedRowData(data);
    const options = { portId: data.portId, page: 'vessel' };
    dTerminalBerthLoadOnEdit(options);
  };
  const handleShowDeleteRow = data => {
    handleShowDeleteModel(true);
    handleSelectedDeleteRow(data);
  };
  const handleDelete = () => {
    handleDeleteVesselMovement(selectedDeleteRow, 'vessel');
    handleShowDeleteModel(false);
    handleSelectedDeleteRow(null);
  };
  const handleCancelDelete = () => {
    handleShowDeleteModel(false);
    handleSelectedDeleteRow(null);
  };
  const handleAddPortLog = () => {
    handleAddRow(0, emptyRow(vesselImo));
  };
  let isUTCDate = false;
  if (isShowLocaltime && portVesselData && portVesselData.length > 0) {
    const chkdate = portVesselData.filter(x => x.portArrivalDate === null);
    if (chkdate.length > 0) isUTCDate = true;
  }
  let isNewRow = false;
  if (portVesselData.length === 1) {
    const chkAddedData = portVesselData.filter(
      x => x.vesselPortCallLogId === '',
    );
    if (chkAddedData.length > 0) {
      isNewRow = true;
    }
  }
  return (
    <>
      <div className="vessel-movement-table-container">
        <div className="ais-management-container-search-header mb-3 mt-3">
          <Row>
            <Col md={2}>
              <h4 className="mb-0">
                <FormattedMessage {...messages.header} />: ({totalRecords})
              </h4>
            </Col>

            {totalRecords > 0 && (
              <Col md={3}>
                <CustomInput
                  type="checkbox"
                  id="vesselshowlocal"
                  name="vesselshowlocal"
                  label={<FormattedMessage {...messages.showLocalCheck} />}
                  className="pr-2"
                  onClick={evt => handleLocaltime(evt)}
                  value={isShowLocaltime}
                />
              </Col>
            )}
            <Col md={3} id="vesselLocaltime">
              {currentpage === 'vessel' && isShowLocalTimeMsg && (
                <FormattedMessage {...messages.showLocaltime} />
              )}
            </Col>
          </Row>
          {currentpage === 'vessel' && isUTCDate && (
            <Row id="vesselLocal">
              <Col md={2} />
              <Col md={5}>
                <FormattedMessage {...messages.noLocaltime} />
              </Col>
            </Row>
          )}
        </div>
        {portVesselData.length === 0 && (
          <div>
            <Row>
              <Col md={10} />
              <Col md={2}>
                <Button color="primary" onClick={() => handleAddPortLog()}>
                  <i className="fa fa-plus mr-1" />
                  <FormattedMessage {...messages.addPortLog} />
                </Button>
              </Col>
            </Row>
          </div>
        )}
        <DataTableList
          moduleId={moduleId}
          primaryProp={primaryProp}
          tableHeader={header}
          tableBody={portVesselData}
          rowsPerPage={10}
          isEditGrid
          editType={!isNewRow ? ['add', 'edit', 'delete'] : ['add']}
          handleAddRow={handleAddRow}
          emptyRow={emptyRow(vesselImo)}
          handleItemChanged={changeHandler}
          handleAdd={handleAddVessel}
          handleUpdate={hanldeUpdateVessel}
          handleDelete={handleShowDeleteRow}
          fixedColumn={fixedColumns}
          handleCancel={handleCancelVesselMovement}
          changeFieldName={changeFieldName}
          handleSelectedRow={handleSelectedRow}
          fetchTableData={fetchAisVesselData}
          totalRecords={totalRecords}
          fixedHeader
          isCustom
          fetchVesselName={fetchVesselName}
          vesselName={vesselName}
          fetchPortName={fetchPortName}
          portName={portName}
          dAutoCompletePopover={dAutoCompletePopover}
          isShowAutoCompletepopOver={isShowAutoCompletepopOver}
          dTerminalBerthLoadOnEdit={dTerminalBerthLoadOnEdit}
        />
      </div>
      {isShowDeleteModel && (
        <DeleteModal
          deleteModalShow={isShowDeleteModel}
          deleteModalCloseTrigger={handleCancelDelete}
          handleDelete={handleDelete}
          statusCode="delete"
          content="Are you sure want to delete "
        />
      )}
    </>
  );
}

AisVesselSearch.propTypes = {
  moduleId: PropTypes.number.isRequired,
  portVesselData: PropTypes.array.isRequired,
  handleAddRow: PropTypes.func.isRequired,
  mainCargoTypeList: PropTypes.array.isRequired,
  cargoTypeList: PropTypes.array.isRequired,
  vesselsList: PropTypes.array,
  terminalsList: PropTypes.array.isRequired,
  berthsList: PropTypes.array.isRequired,
  operation: PropTypes.array.isRequired,
  nextPortsList: PropTypes.array,
  previousPortsList: PropTypes.array.isRequired,
  charterersList: PropTypes.array.isRequired,
  shippersList: PropTypes.array.isRequired,
  receiversList: PropTypes.array.isRequired,
  agentsList: PropTypes.array.isRequired,
  handleVesselItemChanged: PropTypes.func.isRequired,
  handleAddVesselMovement: PropTypes.func.isRequired,
  handleUpdateVesselMovement: PropTypes.func.isRequired,
  handleDeleteVesselMovement: PropTypes.func.isRequired,
  handleCancelVesselMovement: PropTypes.func.isRequired,
  vesselImo: PropTypes.any,
  commodityList: PropTypes.array.isRequired,
  changeFieldName: PropTypes.string.isRequired,
  handleSelectedRowData: PropTypes.func.isRequired,
  fetchAisVesselData: PropTypes.func.isRequired,
  totalRecords: PropTypes.number.isRequired,
  handleLocaltime: PropTypes.func.isRequired,
  isShowLocaltime: PropTypes.bool.isRequired,
  isShowLocalTimeMsg: PropTypes.bool.isRequired,
  berthsData: PropTypes.array.isRequired,
  mainCargoTypeData: PropTypes.array.isRequired,
  cargoTypeData: PropTypes.array.isRequired,
  commodityData: PropTypes.array.isRequired,
  fetchVesselName: PropTypes.func,
  vesselName: PropTypes.array.isRequired,
  fetchPortName: PropTypes.func,
  portName: PropTypes.array.isRequired,
  dAutoCompletePopover: PropTypes.func.isRequired,
  isShowAutoCompletepopOver: PropTypes.bool.isRequired,
  dTerminalBerthLoadOnEdit: PropTypes.func.isRequired,
  vesselOperation: PropTypes.array.isRequired,
  currentpage: PropTypes.string,
};

export default AisVesselSearch;
