// // import { defaultFunction } from '../_helper';
// import AisVesselSearch from '../index';

// describe('AisVesselSearch helpers', () => {
//   describe('Default Helper Function', () => {
//     it('returns the expected value', () => {
//       const expected = 'Sample Text';
//       expect(AisVesselSearch('Sample Text')).toEqual(expected);
//     });
//   });
// });
describe('<AisVesselSearch />', () => {
  it('Expect to not log errors in AisVesselSearch', () => {
    expect(true).toBeTruthy();
  });
});
