/*
 * AisVesselSearch Messages
 *
 * This contains all the text for the AisVesselSearch component.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.components.AisVesselSearch';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'Port Log',
  },
  showLocaltime: {
    id: `${scope}.showLocaltime`,
    defaultMessage: 'Please enter local date and time',
  },
  showLocalCheck: {
    id: `${scope}.showLocalCheck`,
    defaultMessage: 'Show Local Time',
  },
  noLocaltime: {
    id: `${scope}.noLocaltime`,
    defaultMessage: `Local time conversion is not available for port`,
  },
  addPortLog: {
    id: `${scope}.addPortLog`,
    defaultMessage: `Add Port Log`,
  },
});
