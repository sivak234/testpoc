/**
 *
 * Asynchronously loads the component for AisVesselSearch
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
