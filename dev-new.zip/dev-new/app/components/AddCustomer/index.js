/**
 *
 * AddCustomer
 *
 */

import React from 'react';
// import PropTypes from 'prop-types';

import './_helper';

function AddCustomer() {
  return <></>;
}

AddCustomer.propTypes = {};

export default AddCustomer;
