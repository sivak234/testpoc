/**
 *
 * Asynchronously loads the component for AddCustomer
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
