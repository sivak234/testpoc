/*
 *
 * ApiManagement helper
 *
 */
export function defaultFunction(text) {
  return text;
}

export const primaryProp = 'apiParameterDetailID';
export const fixedColumns = true;
export const changeHandler = () => {};

export const emptyRow = {
  apiName: '',
  baseAPIName: '',
  paramValue: '',
};

export function portHeader() {
  const header = [
    {
      title: 'API Name',
      prop: 'apiName',
    },
    {
      title: 'Base API',
      prop: 'baseAPIName',
    },
    {
      title: 'Parameter Value',
      prop: 'paramValue',
    },
  ];

  return header;
}
