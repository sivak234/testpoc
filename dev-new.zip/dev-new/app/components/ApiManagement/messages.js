/*
 * ApiManagement Messages
 *
 * This contains all the text for the ApiManagement component.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.components.ApiManagement';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'Compose API',
  },
  searchResults: {
    id: `${scope}.searchResults`,
    defaultMessage: 'Search Results',
  },
  deleteApi: {
    id: `${scope}.deleteApi`,
    defaultMessage: 'Delete API',
  },
  deleteApiContentNo: {
    id: `${scope}.deleteApiContentNo`,
    defaultMessage: 'API is assigned to user, you cannot delete this API',
  },
  deleteApiContentYes: {
    id: `${scope}.deleteApiContentYes`,
    defaultMessage: 'Are you sure you want to delete this API?',
  },
  deleteSuccessMsg: {
    id: `${scope}.deleteSuccessMsg`,
    defaultMessage: 'is deleted successfully.',
  },
});
