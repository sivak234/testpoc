/**
 *
 * ApiManagement
 *
 */

import React, { memo, useState } from 'react';
import PropTypes from 'prop-types';
import { FormattedMessage, injectIntl, intlShape } from 'react-intl';
import { Row, Col } from 'reactstrap';
import messages from './messages';
import ComposeApi from '../ComposeApi/Loadable';
import SearchApi from '../SearchApi/Loadable';
import ComposehApiModal from '../ComposehApiModal/Loadable';
import DataTableList from '../DataTableList/Loadable';
import DeleteApiModal from '../DeleteApiModal/Loadable';
import AddUserSuccessMsgModal from '../AddUserSuccessMsgModal/Loadable';
import LoadingIndicator from '../LoadingIndicator';

import { portHeader, primaryProp, fixedColumns, emptyRow } from './_helper';
import { filteredAccess } from '../../utils/rbac';
import './index.scss';
import { FETCH_RECORD_COUNT } from '../../utils/constants';

function ApiManagement({
  composeApiModal,
  handleComposeApiModal,
  composeApiModalClose,
  onbaseApiSelected,
  onParameterListSelected,
  onFilterValueSelected,
  baseApiOptions,
  apiListsFilter,
  parameterListOptions,
  onComposeApiDetails,
  filterValueOptions,
  handleSearchApiTrigger,
  handleClearApiTrigger,
  isSearchApiList,
  searchApiData,
  nodesVal,
  checkedApiList,
  expandedApiList,
  filterText,
  nodesFiltered,
  hanldeViewApi,
  viewApiData,
  handleFilterValue,
  apiOptions,
  handleSaveApi,
  handleApiSuccessModelClose,
  composeSuccessMsgModal,
  apiName,
  handleApiListFilter,
  onApiListSelected,
  hanldeDeleteSearchApi,
  handleDeleteApiModelClose,
  handleDeleteApiModelOpen,
  deleteApiModal,
  onCheckApi,
  fetchApiList,
  fetchUserApiList,
  fetchApiFileMappings,
  hanldeCheckDeleteApi,
  isLoading,
  hasError,
  error,
  handleDeleteSuccessModalClose,
  intl,
  selected,
}) {
  const pageDetails = {
    pageNo: 1,
    FETCH_RECORD_COUNT,
  };
  const [content, setContent] = useState('');
  const [apiContent, setApiContent] = useState('');
  const [successMsgModal, setSuccessMsgModal] = useState(false);
  const dropdownData = {
    baseApiOptions,
  };
  const hanldeDeleteSearchTrigger = () => {
    if (apiOptions.checkDeleteApi) {
      setSuccessMsgModal(true);
      const deletecontent = intl.formatMessage({
        ...messages.deleteApiContentNo,
      });
      setContent(deletecontent);
    } else {
      handleDeleteApiModelOpen(deleteApiModal);
      const deletecontent = intl.formatMessage({
        ...messages.deleteApiContentYes,
      });
      const deleteApiContent = `${apiName.apiName} ${intl.formatMessage({
        ...messages.deleteSuccessMsg,
      })}`;
      setContent(deletecontent);
      setApiContent(deleteApiContent);
    }
  };
  const successModalCloseTrigger = () => {
    setSuccessMsgModal(false);
  };
  const deleteModalCloseTrigger = () => {
    handleDeleteApiModelClose(deleteApiModal);
    handleSearchApiTrigger(pageDetails, true);
  };
  const header = portHeader(dropdownData);
  const handleViewApiTrigger = apiid => {
    hanldeCheckDeleteApi(composeApiModal, viewApiData, apiid);
    hanldeViewApi(composeApiModal, viewApiData, apiid);
  };
  const ApiSuccessModalClose = () => {
    handleApiSuccessModelClose(composeSuccessMsgModal);
  };
  const checkAdd = filteredAccess(42, 'add');
  return (
    <>
      {checkAdd && (
        <ComposeApi
          composeApiModel={composeApiModal}
          handleComposeApiModal={handleComposeApiModal}
        />
      )}
      <SearchApi
        baseApiOptions={baseApiOptions}
        apiListsFilter={apiListsFilter}
        onbaseApiSelected={onbaseApiSelected}
        onApiListSelected={onApiListSelected}
        isSearchApiList={isSearchApiList}
        handleSearchApiTrigger={handleSearchApiTrigger}
        handleClearApiTrigger={handleClearApiTrigger}
        handleApiListFilter={handleApiListFilter}
        apiOptions={apiOptions}
        fetchApiFileMappings={fetchApiFileMappings}
      />
      <ComposehApiModal
        show={composeApiModal}
        content="Success"
        UserComposeApiModalClose={composeApiModalClose}
        onbaseApiSelected={onbaseApiSelected}
        onParameterListSelected={onParameterListSelected}
        onFilterValueSelected={onFilterValueSelected}
        baseApiOptions={baseApiOptions}
        parameterListOptions={parameterListOptions}
        onComposeApiDetails={onComposeApiDetails}
        filterValueOptions={filterValueOptions}
        nodesVal={nodesVal}
        checkedApiList={checkedApiList}
        expandedApiList={expandedApiList}
        filterText={filterText}
        nodesFiltered={nodesFiltered}
        handleFilterValue={handleFilterValue}
        apiOptions={apiOptions}
        handleSaveApi={handleSaveApi}
        ApiSuccessModalClose={ApiSuccessModalClose}
        composeSuccessMsgModal={composeSuccessMsgModal}
        viewApiData={viewApiData}
        apiName={apiName}
        hanldeDeleteSearchTrigger={hanldeDeleteSearchTrigger}
        onCheckApi={onCheckApi}
        fetchApiList={fetchApiList}
        fetchUserApiList={fetchUserApiList}
        handleSearchApiTrigger={handleSearchApiTrigger}
        isSearchApiList={isSearchApiList}
        fetchApiFileMappings={fetchApiFileMappings}
        intl={intl}
        selected={selected}
      />
      <DeleteApiModal
        deleteModalShow={deleteApiModal}
        content={content}
        statusCode="delete"
        apiName={apiContent}
        deleteModalCloseTrigger={deleteModalCloseTrigger}
        hanldeDeleteSearchApi={hanldeDeleteSearchApi}
        isSearchApiList={isSearchApiList}
        handleSearchApiTrigger={handleSearchApiTrigger}
        apiOptions={apiOptions}
        handleDeleteSuccessModalClose={handleDeleteSuccessModalClose}
      />
      <AddUserSuccessMsgModal
        show={successMsgModal}
        content={content}
        statusCode="delete"
        header={<FormattedMessage {...messages.deleteApi} />}
        successModalCloseTrigger={successModalCloseTrigger}
      />
      <Row>
        <Col>
          <LoadingIndicator
            isLoading={isLoading}
            hasError={hasError}
            error={error}
          />
        </Col>
      </Row>
      {isSearchApiList && (
        <>
          <hr />
          <h3 className="paddingLeft Compose-API-Header">
            <FormattedMessage {...messages.searchResults} /> (
            {searchApiData.totalRecords})
          </h3>
        </>
      )}
      {isSearchApiList && (
        <div className="Api-Management">
          <DataTableList
            moduleId={42}
            primaryProp={primaryProp}
            tableHeader={header}
            tableBody={searchApiData.data}
            rowsPerPage={10}
            isEditGrid
            editType={['customView']}
            emptyRow={emptyRow}
            handleCustomView={data => handleViewApiTrigger(data)}
            fixedColumn={fixedColumns}
            fetchTableData={handleSearchApiTrigger}
            totalRecords={searchApiData.totalRecords}
            fixedHeader
            isCustom
          />
        </div>
      )}
    </>
  );
}

ApiManagement.propTypes = {
  composeApiModalClose: PropTypes.func,
  composeApiModal: PropTypes.bool,
  onComposeApiDetails: PropTypes.func,
  onbaseApiSelected: PropTypes.func.isRequired,
  onParameterListSelected: PropTypes.func.isRequired,
  baseApiOptions: PropTypes.array.isRequired,
  apiListsFilter: PropTypes.array.isRequired,
  onFilterValueSelected: PropTypes.func.isRequired,
  parameterListOptions: PropTypes.array.isRequired,
  filterValueOptions: PropTypes.array.isRequired,
  handleComposeApiModal: PropTypes.func.isRequired,
  handleSearchApiTrigger: PropTypes.func.isRequired,
  handleClearApiTrigger: PropTypes.func.isRequired,
  isSearchApiList: PropTypes.bool.isRequired,
  searchApiData: PropTypes.array.isRequired,
  nodesVal: PropTypes.array.isRequired,
  checkedApiList: PropTypes.array.isRequired,
  expandedApiList: PropTypes.array.isRequired,
  filterText: PropTypes.string.isRequired,
  nodesFiltered: PropTypes.array.isRequired,
  hanldeViewApi: PropTypes.func.isRequired,
  hanldeCheckDeleteApi: PropTypes.func.isRequired,
  viewApiData: PropTypes.array.isRequired,
  handleFilterValue: PropTypes.func.isRequired,
  apiOptions: PropTypes.object.isRequired,
  handleSaveApi: PropTypes.func.isRequired,
  composeSuccessMsgModal: PropTypes.bool.isRequired,
  handleApiSuccessModelClose: PropTypes.func.isRequired,
  handleApiListFilter: PropTypes.func.isRequired,
  apiName: PropTypes.object.isRequired,
  onApiListSelected: PropTypes.func.isRequired,
  deleteApiModal: PropTypes.bool.isRequired,
  hanldeDeleteSearchApi: PropTypes.func.isRequired,
  handleDeleteApiModelClose: PropTypes.func.isRequired,
  handleDeleteApiModelOpen: PropTypes.func.isRequired,
  onCheckApi: PropTypes.func.isRequired,
  fetchApiList: PropTypes.func.isRequired,
  fetchUserApiList: PropTypes.func.isRequired,
  fetchApiFileMappings: PropTypes.func.isRequired,
  isLoading: PropTypes.oneOfType([PropTypes.bool, PropTypes.string]),
  hasError: PropTypes.oneOfType([PropTypes.bool, PropTypes.string]),
  error: PropTypes.oneOfType([
    PropTypes.array,
    PropTypes.object,
    PropTypes.string,
  ]),
  handleDeleteSuccessModalClose: PropTypes.func.isRequired,
  intl: intlShape.isRequired,
  selected: PropTypes.object.isRequired,
};

export default memo(injectIntl(ApiManagement));
