/**
 *
 * AuditHistoryModal
 *
 */

import React, { memo, useState } from 'react';
import PropTypes from 'prop-types';

import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';

import {
  Row,
  Col,
  Label,
  Button,
  Modal,
  ModalHeader,
  ModalBody,
} from 'reactstrap';
import { FormattedMessage } from 'react-intl';
import messages from './messages';

import './_helper';

import './index.scss';

function AuditHistoryModal({
  show,
  closeModal,
  dGetAuditReport,
  exportListError,
}) {
  const [fromDate, setChoosenFromDate] = useState();
  const [toDate, setChoosenToDate] = useState();
  const [isExportClicked, setExportClicked] = useState(false);

  if (exportListError === false) {
    closeModal({ value: false });
  }

  const choosenFromDateOptions = dateValue => {
    setChoosenFromDate(dateValue);
  };
  const choosenToDateOptions = dateValue => {
    setChoosenToDate(dateValue);
  };

  const getExportList = () => {
    setExportClicked(true);
    const isValid = validateDateFields();
    if (isValid) dGetAuditReport(fromDate, toDate);
  };
  const validateDateFields = () => {
    let valid = false;
    if (fromDate < toDate) {
      valid = true;
    }
    return valid;
  };
  return (
    <>
      <Modal
        isOpen={show}
        toggle={() => closeModal({ value: false })}
        className="custom-modal-claims"
        backdrop="static"
      >
        <ModalHeader toggle={() => closeModal({ value: false })}>
          <FormattedMessage {...messages.header} />
        </ModalHeader>
        <ModalBody>
          <Row className="my-3">
            <Col>
              <Label className="mandate">
                <FormattedMessage {...messages.from} />
              </Label>

              <DatePicker
                selected={fromDate}
                value={fromDate}
                defaultValue={new Date()}
                id="fromDate"
                name="fromDate"
                dateFormat="dd-MM-yyyy"
                onChange={choosenFromDateOptions}
                required
                placeholderText="Choose Date"
                maxDate={toDate}
                showDisabledMonthNavigation
                excludeDates={[toDate]}
              />
              {isExportClicked && fromDate === undefined && (
                <p className="errorMsg">
                  <FormattedMessage {...messages.fromDateRequiredMsg} />
                </p>
              )}
            </Col>
            <Col>
              <Label className="mandate">
                <FormattedMessage {...messages.to} />
              </Label>

              <DatePicker
                selected={toDate}
                value={toDate}
                defaultValue={new Date()}
                id="toDate"
                name="toDate"
                dateFormat="dd-MM-yyyy"
                onChange={choosenToDateOptions}
                required
                placeholderText="Choose Date"
                minDate={fromDate}
                showDisabledMonthNavigation
                excludeDates={[fromDate]}
              />
              {isExportClicked && toDate === undefined && (
                <p className="errorMsg">
                  <FormattedMessage {...messages.toDateRequiredMsg} />
                </p>
              )}
            </Col>

            <Col className="pt-4 mt-1">
              <Button color="primary" onClick={getExportList}>
                <FormattedMessage {...messages.exportList} />
              </Button>
            </Col>
          </Row>
          <Row>
            <Col>
              {exportListError && (
                <p className="errorMsg">
                  <FormattedMessage {...messages.noRecords} />
                </p>
              )}
            </Col>
          </Row>
        </ModalBody>
      </Modal>
    </>
  );
}

AuditHistoryModal.propTypes = {
  show: PropTypes.bool,
  closeModal: PropTypes.func,
  dGetAuditReport: PropTypes.func,
  exportListError: PropTypes.bool,
};

export default memo(AuditHistoryModal);
