/*
 * AuditHistoryModal Messages
 *
 * This contains all the text for the AuditHistoryModal component.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.components.AuditHistoryModal';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'Export List',
  },
  exportList: {
    id: `${scope}.exportList`,
    defaultMessage: 'Export List',
  },
  from: {
    id: `${scope}.from`,
    defaultMessage: 'From',
  },
  to: {
    id: `${scope}.to`,
    defaultMessage: 'To',
  },
  responseHeader: {
    id: `${scope}.responseHeader`,
    defaultMessage: 'Audit Reports History',
  },
  noRecords: {
    id: `${scope}.noRecords`,
    defaultMessage: 'No data exists for selected date range',
  },
  ok: {
    id: `${scope}.ok`,
    defaultMessage: 'Ok',
  },
  fromDateRequiredMsg: {
    id: `${scope}.fromDateRequiredMsg`,
    defaultMessage: 'From Date is Required',
  },
  toDateRequiredMsg: {
    id: `${scope}.toDateRequiredMsg`,
    defaultMessage: 'To Date is Required',
  },
});
