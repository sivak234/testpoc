/**
 *
 * Asynchronously loads the component for AddBerth
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
