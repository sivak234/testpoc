/**
 *
 * AddBerth
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import {
  Container,
  Row,
  Col,
  Button,
  Modal,
  ModalHeader,
  ModalBody,
  Label,
} from 'reactstrap';
import PtbImport from '../PtbImport/Loadable';
import Popup from '../Popup/Loadable';
import BerthAddViewUpdate from '../BerthAddViewUpdate/Loadable';
import { buttons, viewButtons } from './_helper';
import { filteredAccess } from '../../utils/rbac';

function AddBerth({
  isLoading,
  metaData,
  isBerthAddOpen,
  berthData,
  berthValidationStatus,
  handleModalOpen,
  handleModalClose,
  resetBerthData,
  handleBerthInputChange,
  validateBerthData,
  validateBerthDataPublish,
  isCheckLegacy,
  formType,
  // Upload
  onFileChangeHandler,
  ptbImage,
  updateImageData,
  uploadStatus,
  dPortImagesData,
  dHandleFileUpload,
  dHandleFileDownload,
  ptbDocumentsList,
  dPtbDocumentsData,
  updateDocumentData,
  // Vessels by cargo type
  dGetVessels,
  vessels,
  vesselClassification,
  dUpdateBerthDataCargoHandled,
  dDeleteBerthDataCargoHandled,
  dHandleCargoTypeChange,
  dberthUpdateImageData,
  dshowModel,
  importPtb,
  dshandleImportChanged,
  getbtpLogResults,
  logResult,
  islogResult,
  totalRecords,
  getGeoFencingData,
  finalGeoFenceData,
  selectedGeoFenceData,
  portViewData,
  moduleType,
  dValidateBerthDataUpdate,
  dValidateBerthDataPublishUpdate,
  berthValidationMessages,
  regionList,
  countryList,
  portsList,
  terminalsList,
  dGetPortsList,
  dGetTerminalsList,
  berthImages,
  berthimageinfo,
  dstoreimageinformation,
  dselectedTerminalBerthimageinfo,
  storeselectedberthimagefile,
  confirmBerthImageDeleteModalOpen,
  dopenberthimagepopupconfirmation,
  dclsoeberthimagepopupconfirmation,
  ddeleteTerminalBerthSelectedImages,
  berthdocumenttype,
  numberOfCopies,
  berthptbDocument,
  dberthDocumentsData,
  dvalidatedocumnet,
  dsetDocumentName,
  dsetDocumentType,
  dvalidatedfileuploaddocument,
  dselectedDocumentInformation,
  berthselecteddocument,
  confirmBerthDocumentDeleteModalOpen,
  dopenberthdocumentpopupconfirmation,
  dcloseberthdocumentpopupconfirmation,
  dberthDeleteSelectDocumentInformation,
  dHandleUpdateBerthInputChange,
  dremoveFromCollection,
  dOpenUpdateBerthModal,
  dHandleDelete,
  dgetAllPortsDataForMapByCountryId,
  berthIssTransfer,
  dhandleYssTransferCheck,
  searchParam,
  dGetCountryList,
  typeAheadDropdownBerth,
  geoSelectedTerminalId,
  dGetUserDetails,
  moduleId,
  isBerthClientAccessNotSelected,
  dgetAllPortsDataForMapByPortId,
  linkedWithLegacy,
  ptbStatus,
  isNotPublishedPTB,
  isMapRefresh,
  dsetNewLatLong,
  ptbMapCoordinates,
  dlocateLatLong,
  ptbSelectedCoordinates,
  isLocateClicked,
  dDisableLocate,
  isInValidLatLng,
  dcloseLocateDialog,
}) {
  let footerButtons = [];
  let popupTitle = '';
  if (formType.toLowerCase() === 'view') {
    popupTitle = 'View Berth';
    const handleViewUpdate = () => {
      dOpenUpdateBerthModal({
        berthId: berthData.berthId,
        currentPage: searchParam.currentPage,
      });
    };
    const handleViewDelete = () => {
      dHandleDelete({
        berthId: berthData.berthId,
        berthName: berthData.berthName,
        currentPage: searchParam.currentPage,
      });
    };
    footerButtons = viewButtons(
      handleModalClose,
      handleViewUpdate,
      handleViewDelete,
      moduleId,
      berthData,
    );
  } else if (formType.toLowerCase() === 'update') {
    popupTitle = 'Update Berth';
    footerButtons = buttons(
      dValidateBerthDataUpdate,
      dValidateBerthDataPublishUpdate,
      resetBerthData,
      handleModalClose,
      formType,
      moduleId,
      berthData.isCreateInLegacy,
      berthData,
    );
  } else {
    popupTitle = 'Add Berth';
    footerButtons = buttons(
      validateBerthData,
      validateBerthDataPublish,
      resetBerthData,
      handleModalClose,
      '',
      moduleId,
      berthData.isCreateInLegacy,
    );
  }

  const isOrVisible =
    filteredAccess(moduleId, 'add') && filteredAccess(moduleId, 'publish');
  return (
    <>
      <Container>
        <Row>
          <Col>
            {(filteredAccess(moduleId, 'add') ||
              filteredAccess(moduleId, 'publish')) && (
              <h4 className="mt-3">Add Berth</h4>
            )}
          </Col>
          <Col xs="auto" className="align-self-center">
            {filteredAccess(moduleId, 'publish') && (
              <Button
                color="link"
                onClick={() => dshowModel({ show: true, showOn: 'Berth' })}
              >
                Import
              </Button>
            )}
            {isOrVisible && <Label className="mr-3 ml-1"> OR </Label>}

            {filteredAccess(moduleId, 'add') && (
              <Button color="primary" onClick={handleModalOpen}>
                <i className="fa fa-plus mr-1" /> Add Berth
              </Button>
            )}
          </Col>
        </Row>
      </Container>

      {(filteredAccess(moduleId, 'add') ||
        filteredAccess(moduleId, 'publish')) && <hr />}
      <Popup
        size="xl"
        className="ptbModal_form"
        show={isBerthAddOpen}
        close={handleModalClose}
        title={popupTitle}
        buttons={footerButtons}
        center={false}
        keyboard={false}
      >
        <BerthAddViewUpdate
          metaData={metaData}
          data={berthData}
          berthValidationStatus={berthValidationStatus}
          handleBerthInputChange={handleBerthInputChange}
          isCheckLegacy={isCheckLegacy}
          onFileChangeHandler={onFileChangeHandler}
          ptbImage={ptbImage}
          dPortImagesData={dPortImagesData}
          updateImageData={updateImageData}
          uploadStatus={uploadStatus}
          dHandleFileUpload={dHandleFileUpload}
          dHandleFileDownload={dHandleFileDownload}
          ptbDocumentsList={ptbDocumentsList}
          dPtbDocumentsData={dPtbDocumentsData}
          updateDocumentData={updateDocumentData}
          dGetVessels={dGetVessels}
          vessels={vessels}
          vesselClassification={vesselClassification}
          dUpdateBerthDataCargoHandled={dUpdateBerthDataCargoHandled}
          dDeleteBerthDataCargoHandled={dDeleteBerthDataCargoHandled}
          dHandleCargoTypeChange={dHandleCargoTypeChange}
          dberthUpdateImageData={dberthUpdateImageData}
          getGeoFencingData={getGeoFencingData}
          finalGeoFenceData={finalGeoFenceData}
          selectedGeoFenceData={selectedGeoFenceData}
          portViewData={portViewData}
          moduleType={moduleType}
          formType={formType}
          berthValidationMessages={berthValidationMessages}
          regionList={regionList}
          countryList={countryList}
          portsList={portsList}
          terminalsList={terminalsList}
          dGetPortsList={dGetPortsList}
          dGetTerminalsList={dGetTerminalsList}
          berthImages={berthImages}
          berthimageinfo={berthimageinfo}
          dstoreimageinformation={dstoreimageinformation}
          dselectedTerminalBerthimageinfo={dselectedTerminalBerthimageinfo}
          storeselectedberthimagefile={storeselectedberthimagefile}
          confirmBerthImageDeleteModalOpen={confirmBerthImageDeleteModalOpen}
          dopenberthimagepopupconfirmation={dopenberthimagepopupconfirmation}
          dclsoeberthimagepopupconfirmation={dclsoeberthimagepopupconfirmation}
          ddeleteTerminalBerthSelectedImages={
            ddeleteTerminalBerthSelectedImages
          }
          berthdocumenttype={berthdocumenttype}
          numberOfCopies={numberOfCopies}
          berthptbDocument={berthptbDocument}
          dberthDocumentsData={dberthDocumentsData}
          dvalidatedocumnet={dvalidatedocumnet}
          dsetDocumentName={dsetDocumentName}
          dsetDocumentType={dsetDocumentType}
          dvalidatedfileuploaddocument={dvalidatedfileuploaddocument}
          dselectedDocumentInformation={dselectedDocumentInformation}
          berthselecteddocument={berthselecteddocument}
          confirmBerthDocumentDeleteModalOpen={
            confirmBerthDocumentDeleteModalOpen
          }
          dopenberthdocumentpopupconfirmation={
            dopenberthdocumentpopupconfirmation
          }
          dcloseberthdocumentpopupconfirmation={
            dcloseberthdocumentpopupconfirmation
          }
          dberthDeleteSelectDocumentInformation={
            dberthDeleteSelectDocumentInformation
          }
          dHandleUpdateBerthInputChange={dHandleUpdateBerthInputChange}
          dremoveFromCollection={dremoveFromCollection}
          dgetAllPortsDataForMapByCountryId={dgetAllPortsDataForMapByCountryId}
          berthIssTransfer={berthIssTransfer}
          dhandleYssTransferCheck={dhandleYssTransferCheck}
          dGetCountryList={dGetCountryList}
          typeAheadDropdownBerth={typeAheadDropdownBerth}
          geoSelectedTerminalId={geoSelectedTerminalId}
          isLoading={isLoading}
          dGetUserDetails={dGetUserDetails}
          isBerthClientAccessNotSelected={isBerthClientAccessNotSelected}
          dgetAllPortsDataForMapByPortId={dgetAllPortsDataForMapByPortId}
          linkedWithLegacy={linkedWithLegacy}
          ptbStatus={ptbStatus}
          isMapRefresh={isMapRefresh}
          isNotPublishedPTB={isNotPublishedPTB}
          isPublish={filteredAccess(moduleId, 'publish')}
          dsetNewLatLong={dsetNewLatLong}
          ptbMapCoordinates={ptbMapCoordinates}
          dlocateLatLong={dlocateLatLong}
          ptbSelectedCoordinates={ptbSelectedCoordinates}
          isLocateClicked={isLocateClicked}
          dDisableLocate={dDisableLocate}
          isInValidLatLng={isInValidLatLng}
          dcloseLocateDialog={dcloseLocateDialog}
        />
      </Popup>
      {importPtb.btpType === 'Berth' ? (
        <Modal
          isOpen={importPtb.isShowModel}
          toggle={() => dshowModel({ show: false, showOn: 'Port' })}
          className="custom-modal-claims"
        >
          <ModalHeader
            className="modelheader"
            toggle={() => dshowModel({ show: false, showOn: 'Port' })}
          >
            {importPtb.btpType} Import
          </ModalHeader>
          <ModalBody>
            <PtbImport
              importPtb={importPtb}
              dshandleImportChanged={dshandleImportChanged}
              getbtpLogResults={getbtpLogResults}
              logResult={logResult}
              islogResult={islogResult}
              btpName={importPtb.btpType}
              totalRecords={totalRecords}
            />
          </ModalBody>
        </Modal>
      ) : (
        ''
      )}
    </>
  );
}

AddBerth.propTypes = {
  metaData: PropTypes.object,
  isBerthAddOpen: PropTypes.bool,
  berthData: PropTypes.object,
  berthValidationStatus: PropTypes.object,
  handleModalOpen: PropTypes.func,
  handleModalClose: PropTypes.func,
  dGetUserDetails: PropTypes.func,
  resetBerthData: PropTypes.func,
  handleBerthInputChange: PropTypes.func,
  validateBerthData: PropTypes.func,
  validateBerthDataPublish: PropTypes.func,
  isCheckLegacy: PropTypes.bool,
  formType: PropTypes.string,
  // Upload
  onFileChangeHandler: PropTypes.func,
  ptbImage: PropTypes.array,
  updateImageData: PropTypes.func,
  uploadStatus: PropTypes.string,
  dPortImagesData: PropTypes.func,
  dHandleFileUpload: PropTypes.func,
  dHandleFileDownload: PropTypes.func,
  ptbDocumentsList: PropTypes.array,
  dPtbDocumentsData: PropTypes.func,
  updateDocumentData: PropTypes.func,
  dGetVessels: PropTypes.func,
  vessels: PropTypes.array,
  dUpdateBerthDataCargoHandled: PropTypes.func,
  dDeleteBerthDataCargoHandled: PropTypes.func,
  dHandleCargoTypeChange: PropTypes.func,
  vesselClassification: PropTypes.array,
  dberthUpdateImageData: PropTypes.func,
  dshowModel: PropTypes.func,
  importPtb: PropTypes.object,
  dshandleImportChanged: PropTypes.func,
  getbtpLogResults: PropTypes.func,
  logResult: PropTypes.array,
  islogResult: PropTypes.bool,
  totalRecords: PropTypes.number,
  getGeoFencingData: PropTypes.func,
  finalGeoFenceData: PropTypes.object,
  selectedGeoFenceData: PropTypes.object,
  portViewData: PropTypes.object,
  moduleType: PropTypes.string,
  countryList: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  regionList: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  portsList: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  terminalsList: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  dGetPortsList: PropTypes.func,
  dGetTerminalsList: PropTypes.func,
  dValidateBerthDataUpdate: PropTypes.func,
  dValidateBerthDataPublishUpdate: PropTypes.func,
  berthValidationMessages: PropTypes.object,
  berthImages: PropTypes.array,
  berthimageinfo: PropTypes.array,
  dstoreimageinformation: PropTypes.func,
  dselectedTerminalBerthimageinfo: PropTypes.func,
  storeselectedberthimagefile: PropTypes.array,
  confirmBerthImageDeleteModalOpen: PropTypes.bool,
  dopenberthimagepopupconfirmation: PropTypes.func,
  dclsoeberthimagepopupconfirmation: PropTypes.func,
  ddeleteTerminalBerthSelectedImages: PropTypes.func,
  berthdocumenttype: PropTypes.array,
  numberOfCopies: PropTypes.array,
  berthptbDocument: PropTypes.array,
  dberthDocumentsData: PropTypes.func,
  dvalidatedocumnet: PropTypes.func,
  dsetDocumentName: PropTypes.func,
  dsetDocumentType: PropTypes.func,
  dvalidatedfileuploaddocument: PropTypes.func,
  dselectedDocumentInformation: PropTypes.func,
  berthselecteddocument: PropTypes.array,
  confirmBerthDocumentDeleteModalOpen: PropTypes.bool,
  dopenberthdocumentpopupconfirmation: PropTypes.func,
  dcloseberthdocumentpopupconfirmation: PropTypes.func,
  dberthDeleteSelectDocumentInformation: PropTypes.func,
  dHandleUpdateBerthInputChange: PropTypes.func,
  dremoveFromCollection: PropTypes.func,
  dOpenUpdateBerthModal: PropTypes.func,
  dHandleDelete: PropTypes.func,
  isLoading: PropTypes.bool,
  dgetAllPortsDataForMapByCountryId: PropTypes.func,
  berthIssTransfer: PropTypes.bool,
  dhandleYssTransferCheck: PropTypes.func,
  searchParam: PropTypes.object,
  dGetCountryList: PropTypes.func,
  typeAheadDropdownBerth: PropTypes.oneOfType([
    PropTypes.array,
    PropTypes.object,
  ]),
  geoSelectedTerminalId: PropTypes.string,
  moduleId: PropTypes.any,
  isBerthClientAccessNotSelected: PropTypes.bool,
  dgetAllPortsDataForMapByPortId: PropTypes.func,
  linkedWithLegacy: PropTypes.object,
  ptbStatus: PropTypes.object,
  isNotPublishedPTB: PropTypes.bool,
  isMapRefresh: PropTypes.bool,
  dsetNewLatLong: PropTypes.func,
  dlocateLatLong: PropTypes.func,
  ptbMapCoordinates: PropTypes.object,
  ptbSelectedCoordinates: PropTypes.object,
  isLocateClicked: PropTypes.bool,
  dDisableLocate: PropTypes.func,
  isInValidLatLng: PropTypes.bool,
  dcloseLocateDialog: PropTypes.func,
};

export default AddBerth;
