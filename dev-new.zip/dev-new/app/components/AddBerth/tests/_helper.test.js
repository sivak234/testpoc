// import { buttons } from '../_helper';

// describe('AddTerminal helpers', () => {
//   describe('Default Helper Function', () => {
//     it('returns the expected value', () => {
//       const expected = 'Sample Text';
//       expect(buttons('Sample Text')).toEqual(expected);
//     });
//   });
// });
describe('<AddBerth />', () => {
  it('Expect to not log errors in AddBerth', () => {
    expect(true).toBeTruthy();
  });
});
