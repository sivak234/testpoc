/*
 *
 * AddBerth helper
 *
 */

import { filteredAccess, checkNLevelAccess } from '../../utils/rbac';

export function buttons(
  save,
  publish,
  reset,
  close,
  formType = '',
  moduleId,
  isCheckLegacy,
  data,
) {
  const filteredButtons = [];
  const ptbstatusNotification = 'ptb-management?notification';
  const cameFromPTBStatus = window.location.href.includes(
    ptbstatusNotification,
  );
  if (
    formType.toLowerCase() !== 'update' &&
    filteredAccess(moduleId, 'add') &&
    !isCheckLegacy
  ) {
    filteredButtons.push({
      title: 'Add Berth',
      action: () => save(),
    });
  }

  if (
    formType.toLowerCase() !== 'update' &&
    filteredAccess(moduleId, 'publish') &&
    !cameFromPTBStatus
  ) {
    filteredButtons.push({
      title: 'Add and Publish',
      action: () => publish(),
    });
  }
  if (
    formType.toLowerCase() === 'update' &&
    checkNLevelAccess(moduleId, 'edit', data)
  ) {
    filteredButtons.push({
      title: 'Save',
      action: () => save(),
    });
  }

  if (
    formType.toLowerCase() === 'update' &&
    checkNLevelAccess(moduleId, 'publish', data)
  ) {
    filteredButtons.push({
      title: 'Save and Publish',
      action: () => publish(),
    });
  }

  filteredButtons.push({
    title: 'Cancel',
    action: close,
    id: 'btncancelid',
  });

  return filteredButtons;
}

export function viewButtons(
  close,
  dHandleUpdateOpen,
  dHandleDelete,
  moduleId,
  data,
) {
  const viewFilteredButtons = [];
  if (checkNLevelAccess(moduleId, 'delete', data)) {
    viewFilteredButtons.push({
      title: 'Delete',
      action: dHandleDelete,
      id: 'btnDeleteBerth',
    });
  }

  if (checkNLevelAccess(moduleId, 'edit', data)) {
    viewFilteredButtons.push({
      title: 'Update',
      action: dHandleUpdateOpen,
      id: 'btnOpenUpdateBerth',
    });
  }

  viewFilteredButtons.push({
    title: 'Close',
    action: close,
    id: 'btncancelid',
  });

  return viewFilteredButtons;
}

export const validateField = (formFields, validations) => {
  const inValidFields = {};
  const messages = {};
  const validatorRules = {};
  Object.keys(validations).forEach(field => {
    const validationRules = validations[field];
    let rule = {};
    if (formFields[field] && formFields[field] !== '') {
      const objectLength = Object.keys(validationRules.rules).length;
      for (let index = 0; index < objectLength; index += 1) {
        rule = validationRules.rules[index];
        const fieldValidationStatus = validateFieldObj(
          formFields[field],
          rule,
          formFields,
          validations,
        );
        inValidFields[field] = fieldValidationStatus.inValidField;
        validatorRules[field] = {
          ...fieldValidationStatus.validatorRule,
        };
        messages[field] = fieldValidationStatus.message;
        if (fieldValidationStatus.inValidField === true) break;
      }
    }
  });

  return { inValidFields, messages, validatorRules };
};

const validateFieldObj = (value, rule, formFields, validations) => {
  let inValidField = false;
  const message = '';
  const validatorRule = {};
  let validationResult;
  switch (rule.operator) {
    case '<':
    case '>':
      if (formFields[rule.field] && formFields[rule.field] !== '') {
        validationResult = isFieldValid(
          rule.operator,
          value,
          formFields[rule.field],
          validations[rule.field].label,
        );
      }
      break;
    case 'sum':
      validationResult = doSum(value, rule, validations, formFields);
      break;
    default:
      break;
  }

  if (
    validationResult &&
    {}.hasOwnProperty.call(validationResult, 'valid') &&
    validationResult.valid === false
  ) {
    inValidField = true;
  }

  return { inValidField, message, validatorRule, ...validationResult };
};

const doSum = (val1, rule, validations, formFields) => {
  let value = 0;
  let valid;
  const operatedfields = [];
  for (let index = 0; index < rule.field.length; index += 1) {
    const field = rule.field[index];
    if (
      formFields[field] === '' ||
      formFields[field] === undefined ||
      formFields[field] === null ||
      parseFloat(formFields[field]) <= 0
    ) {
      valid = true;
      break;
    }
    value += parseFloat(formFields[field]);
    operatedfields.push(validations[field].label);
  }

  if (valid === true) return true;

  return isFieldValid(
    rule.operation,
    val1,
    value,
    `sum of ${operatedfields.join(',')}`,
  );
};

const isFieldValid = (type, val1, val2, label) => {
  let valid = true;
  let validatorRule;
  let message;
  switch (type) {
    case '<':
      if (val2 !== '0.00') valid = parseFloat(val1) <= parseFloat(val2);
      validatorRule = { lessThan: val2 };
      message = `This field should be less than ${label}`;
      break;
    case '>':
      if (val1 !== '0.00') valid = parseFloat(val1) >= parseFloat(val2);
      validatorRule = { greaterThan: val2 };
      message = `This field should be greater than ${label}`;
      break;
    default:
      break;
  }
  if (valid === true) {
    return true;
  }
  return {
    valid,
    validatorRule,
    message,
  };
};

export const makeDynamicValidation = (types, vessels) => {
  const vslRules = { oil: [], gas: [], dry: [] };
  types.forEach(type => {
    vslRules[type].push(
      {
        operator: '>',
        field: `${type}MinFreeBoard`,
      },
      {
        operator: '>',
        field: `${type}MaxFreeBoard`,
      },
      {
        operator: '>',
        field: `${type}MaxHeightManifoldAWL`,
      },
      {
        operator: '>',
        field: `${type}MinHeightManifoldAWL`,
      },
    );
  });
  const vesselRestrictionValidation = {};
  const airDraughtRule = { oil: [], gas: [], dry: [] };
  if (vessels.length > 0) {
    vessels.forEach(vessel => {
      const name = vessel.wopVesselDesc.replace(/[#_ ]/g, '');
      if (name.toLowerCase() === 'tanker') {
        vesselRestrictionValidation[`airDraught-${name}`] = {
          label: `Air Draught - ${vessel.wopVesselDesc}`,
          rules: vslRules.oil,
        };
        airDraughtRule.oil.push({
          operator: '<',
          field: `airDraught-${name}`,
        });
      } else if (name.toLowerCase() === 'gascarrier') {
        vesselRestrictionValidation[`airDraught-${name}`] = {
          label: `Air Draught - ${vessel.wopVesselDesc}`,
          rules: vslRules.gas,
        };
        airDraughtRule.gas.push({
          operator: '<',
          field: `airDraught-${name}`,
        });
      } else {
        vesselRestrictionValidation[`airDraught-${name}`] = {
          label: `Air Draught - ${vessel.wopVesselDesc}`,
          rules: vslRules.dry,
        };
        airDraughtRule.dry.push({
          operator: '<',
          field: `airDraught-${name}`,
        });
      }

      vesselRestrictionValidation[`maxDraftAtApproaches-${name}`] = {
        label: `Maximum Draught at Approaches (m) - ${vessel.wopVesselDesc}`,
        rules: [
          {
            operator: '<',
            field: `depthAtApproaches-${name}`,
          },
        ],
      };

      vesselRestrictionValidation[`depthAtApproaches-${name}`] = {
        label: `Depth at Approaches - ${vessel.wopVesselDesc}`,
        rules: [
          {
            operator: '>',
            field: `maxDraftAtApproaches-${name}`,
          },
        ],
      };
    });
  }
  types.forEach(type => {
    vesselRestrictionValidation[`${type}MinFreeBoard`] = {
      label: 'Minimum Freeboard (m)',
      rules: [
        ...airDraughtRule[type],
        {
          operator: '<',
          field: `${type}MaxFreeBoard`,
        },
        {
          operator: '<',
          field: `${type}MaxHeightManifoldAWL`,
        },
        {
          operator: '<',
          field: `${type}MinHeightManifoldAWL`,
        },
      ],
    };
    vesselRestrictionValidation[`${type}MaxFreeBoard`] = {
      label: 'Maximum Freeboard (m)',
      rules: [
        ...airDraughtRule[type],
        {
          operator: '>',
          field: `${type}MinFreeBoard`,
        },
        {
          operator: '<',
          field: `${type}MaxHeightManifoldAWL`,
        },
        {
          operator: '<',
          field: `${type}MinHeightManifoldAWL`,
        },
      ],
    };
    vesselRestrictionValidation[`${type}MaxHeightManifoldAWL`] = {
      label: 'Maximum Height Manifold AWL (m)',
      rules: [
        ...airDraughtRule[type],
        {
          operator: '>',
          field: `${type}MinFreeBoard`,
        },
        {
          operator: '>',
          field: `${type}MaxFreeBoard`,
        },
        {
          operator: '>',
          field: `${type}MinHeightManifoldAWL`,
        },
      ],
    };
    vesselRestrictionValidation[`${type}MinHeightManifoldAWL`] = {
      label: 'Minimum Height Manifold AWL (m)',
      rules: [
        ...airDraughtRule[type],
        {
          operator: '>',
          field: `${type}MinFreeBoard`,
        },

        {
          operator: '<',
          field: `${type}MaxHeightManifoldAWL`,
        },
      ],
    };
  });
  return vesselRestrictionValidation;
};

export const makeValidationArray = type => ({
  [`${type}MinLengthOverAllLOA`]: {
    label: 'Minimum Length Overall (m)',
    rules: [
      {
        operator: '<',
        field: `${type}MaxLengthOverAllLOA`,
      },
      {
        operator: '>',
        field: `${type}MinPMB`,
      },
      {
        operator: '>',
        field: `${type}MinPMBForwardOfShipsManiFold`,
      },
      {
        operator: '>',
        field: `${type}MinPMBAftOfShipsManiFold`,
      },
      {
        operator: '>',
        field: `${type}MinSCM`,
      },
      {
        operator: '>',
        field: `${type}MinBCM`,
      },
      {
        operator: '>',
        field: `${type}MinBowManiFoldDistance`,
      },
      {
        operator: '>',
        field: `${type}MinSternManifoldDistance`,
      },
      {
        operator: '>',
        field: `${type}MaxBowManiFoldDistance`,
      },
      {
        operator: '>',
        field: `${type}MaxSternManifoldDistance`,
      },
      {
        operator: 'sum',
        operation: '<',
        field: [
          `${type}MaxSternManifoldDistance`,
          `${type}MaxBowManiFoldDistance`,
        ],
      },
      {
        operator: 'sum',
        operation: '>',
        field: [`${type}MinSCM`, `${type}MinBCM`],
      },
    ],
  },
  [`${type}MaxLengthOverAllLOA`]: {
    label: 'Maximum Length Overall (m)',
    rules: [
      {
        operator: '>',
        field: `${type}MinLengthOverAllLOA`,
      },
      {
        operator: '>',
        field: `${type}MinPMB`,
      },
      {
        operator: '>',
        field: `${type}MinPMBForwardOfShipsManiFold`,
      },
      {
        operator: '>',
        field: `${type}MinPMBAftOfShipsManiFold`,
      },

      {
        operator: '>',
        field: `${type}MinSCM`,
      },
      {
        operator: '>',
        field: `${type}MinBCM`,
      },
      {
        operator: '>',
        field: `${type}MaxBowManiFoldDistance`,
      },
      {
        operator: '>',
        field: `${type}MaxSternManifoldDistance`,
      },
      {
        operator: 'sum',
        operation: '<',
        field: [
          `${type}MaxSternManifoldDistance`,
          `${type}MaxBowManiFoldDistance`,
        ],
      },
      {
        operator: 'sum',
        operation: '>',
        field: [`${type}MinBCM`, `${type}MinSCM`],
      },
      {
        operator: '>',
        field: `${type}MaxBowManiFoldDistance`,
      },
      {
        operator: '>',
        field: `${type}MaxSternManifoldDistance`,
      },
    ],
  },
  [`${type}MinPMB`]: {
    label: 'Minimum PMB (m)',
    rules: [
      {
        operator: '<',
        field: `${type}MinLengthOverAllLOA`,
      },
      {
        operator: '<',
        field: `${type}MaxLengthOverAllLOA`,
      },
      {
        operator: '>',
        field: `${type}MinPMBAftOfShipsManiFold`,
      },
      {
        operator: '>',
        field: `${type}MinPMBForwardOfShipsManiFold`,
      },
      {
        operator: 'sum',
        operation: '<',
        field: [
          `${type}MaxSternManifoldDistance`,
          `${type}MaxBowManiFoldDistance`,
        ],
      },
    ],
  },
  [`${type}MinPMBForwardOfShipsManiFold`]: {
    label: "Minimum PMB Forward of Ship's Manifold (m)",
    rules: [
      {
        operator: '<',
        field: `${type}MinLengthOverAllLOA`,
      },
      {
        operator: '<',
        field: `${type}MaxLengthOverAllLOA`,
      },
      {
        operator: '<',
        field: `${type}MinPMB`,
      },
      {
        operator: 'sum',
        operation: '<',
        field: [
          `${type}MaxSternManifoldDistance`,
          `${type}MaxBowManiFoldDistance`,
        ],
      },
    ],
  },
  [`${type}MinPMBAftOfShipsManiFold`]: {
    label: "Minimum PMB Aft of Ship's Manifold (m)",
    rules: [
      {
        operator: '<',
        field: `${type}MinLengthOverAllLOA`,
      },
      {
        operator: '<',
        field: `${type}MaxLengthOverAllLOA`,
      },
      {
        operator: '<',
        field: `${type}MinPMB`,
      },
      {
        operator: 'sum',
        operation: '<',
        field: [
          `${type}MaxSternManifoldDistance`,
          `${type}MaxBowManiFoldDistance`,
        ],
      },
    ],
  },
  [`${type}MinSCM`]: {
    label: 'Minimum Stern to Centre of Manifold Distance (m)',
    rules: [
      {
        operator: '<',
        field: `${type}MaxSternManifoldDistance`,
      },
      {
        operator: '<',
        field: `${type}MaxLengthOverAllLOA`,
      },
      {
        operator: '<',
        field: `${type}MinLengthOverAllLOA`,
      },
      {
        operator: '>',
        field: `${type}MinPMB`,
      },
      {
        operator: '<',
        field: `${type}MaxBowManiFoldDistance`,
      },
      {
        operator: 'sum',
        operation: '<',
        field: [`${type}MinBCM`, `${type}MinSCM`],
      },
      {
        operator: 'sum',
        operation: '<',
        field: [
          `${type}MaxSternManifoldDistance`,
          `${type}MaxBowManiFoldDistance`,
        ],
      },
    ],
  },
  [`${type}MinBCM`]: {
    label: 'Minimum Bow to Centre of Manifold Distance (m)',
    rules: [
      {
        operator: '<',
        field: `${type}MaxLengthOverAllLOA`,
      },
      {
        operator: '<',
        field: `${type}MinLengthOverAllLOA`,
      },
      {
        operator: '>',
        field: `${type}MinPMB`,
      },
      {
        operator: '<',
        field: `${type}MaxBowManiFoldDistance`,
      },
      {
        operator: 'sum',
        operation: '<',
        field: [`${type}MinBCM`, `${type}MinSCM`],
      },
      {
        operator: 'sum',
        operation: '<',
        field: [
          `${type}MaxSternManifoldDistance`,
          `${type}MaxBowManiFoldDistance`,
        ],
      },
    ],
  },
  [`${type}MaxBowManiFoldDistance`]: {
    label: 'Maximum Bow to Centre of Manifold Distance (m)',
    rules: [
      {
        operator: '<',
        field: `${type}MaxLengthOverAllLOA`,
      },
      {
        operator: '>',
        field: `${type}MinPMBForwardOfShipsManiFold`,
      },

      {
        operator: '>',
        field: `${type}MinBCM`,
      },
      {
        operator: 'sum',
        operation: '<',
        field: [
          `${type}MaxSternManifoldDistance`,
          `${type}MaxBowManiFoldDistance`,
        ],
      },
    ],
  },

  [`${type}MaxSternManifoldDistance`]: {
    label: 'Maximum Stern to Centre of Manifold Distance',
    rules: [
      {
        operator: '>',
        field: `${type}MinSCM`,
      },
      {
        operator: '<',
        field: `${type}MaxLengthOverAllLOA`,
      },
      {
        operator: '>',
        field: `${type}MinPMBAftOfShipsManiFold`,
      },

      {
        operator: '>',
        field: `${type}MinSternManifoldDistance`,
      },
      {
        operator: 'sum',
        operation: '<',
        field: [
          `${type}MaxSternManifoldDistance`,
          `${type}MaxBowManiFoldDistance`,
        ],
      },
    ],
  },

  [`${type}MaxBeamWidth`]: {
    label: 'Maximum Beam (m)',
    rules: [
      {
        operator: '>',
        field: `${type}MinDistanceSideRail`,
      },
      {
        operator: '>',
        field: `${type}MaxDistanceSideRail`,
      },
      {
        operator: '>',
        field: `${type}MinBeam`,
      },
    ],
  },
  [`${type}MinBeam`]: {
    label: 'Minimum Beam (m)',
    rules: [
      {
        operator: '<',
        field: `${type}MaxBeamWidth`,
      },
    ],
  },
  [`${type}MaxDraftAtApproaches`]: {
    label: 'Maximum Draught at Approaches (m)',
    rules: [
      {
        operator: '<',
        field: `${type}DepthAtApproaches`,
      },
    ],
  },
  [`${type}DepthAtApproaches`]: {
    label: 'Depth at Approaches (m)',
    rules: [
      {
        operator: '>',
        field: `${type}MaxDraftAtApproaches`,
      },
    ],
  },
  // [`${type}minUKCAtApproaches`]: {
  //   label: 'Minimum UKC at Approaches (%)',
  //   rules: [],
  // },
  [`${type}MaxDisplacementAlongSide`]: {
    label: 'Maximum Displacement Alongside (mt)',
    rules: [
      {
        operator: '>',
        field: `${type}MinDisplacementAlongSide`,
      },
      {
        operator: '>',
        field: `${type}MaxDeadWeightDWT`,
      },
      {
        operator: '>',
        field: `${type}MinDeadWeightDWT`,
      },
      // {
      //   operator: '>',
      //   field: `${type}MaxArrivalDisplacement`,
      // },
    ],
  },
  [`${type}MinDisplacementAlongSide`]: {
    label: 'Minimum Displacement Alongside (m)',
    rules: [
      {
        operator: '<',
        field: `${type}MaxDisplacementAlongSide`,
      },
    ],
  },
  [`${type}MaxArrivalDisplacement`]: {
    label: 'Maximum Arrival Displacement (mt)',
    rules: [
      {
        operator: '<',
        field: `${type}MaxDisplacementAlongSide`,
      },
    ],
  },
  [`${type}MaxDeadWeightDWT`]: {
    label: 'Maximum Deadweight (mt)',
    rules: [
      {
        operator: '>',
        field: `${type}MinDeadWeightDWT`,
      },
      {
        operator: '<',
        field: `${type}MaxDisplacementAlongSide`,
      },
    ],
  },
  [`${type}MinDeadWeightDWT`]: {
    label: 'Minimum Deadweight (mt)',
    rules: [
      {
        operator: '<',
        field: `${type}MaxDeadWeightDWT`,
      },
      {
        operator: '<',
        field: `${type}MaxDisplacementAlongSide`,
      },
      {
        operator: '<',
        field: `${type}MinDisplacementAlongSide`,
      },
    ],
  },

  // [`${type}MinHeightAboveDeck`]: {
  //   label: 'Minimum Height of Manifold Above Deck',
  //   rules: [],
  // },
  [`${type}MinDistanceSideRail`]: {
    label: 'Minimum Distance from Manifold to Ship Side Rail (m)',
    rules: [
      {
        operator: '<',
        field: `${type}MaxBeamWidth`,
      },
      {
        operator: '<',
        field: `${type}MaxDistanceSideRail`,
      },
    ],
  },
  [`${type}MaxDistanceSideRail`]: {
    label: 'Maximum Distance from Manifold to Ship Side Rail (m)',
    rules: [
      {
        operator: '<',
        field: `${type}MaxBeamWidth`,
      },
      {
        operator: '>',
        field: `${type}MinDistanceSideRail`,
      },
    ],
  },
  // [`${type}HoseDerrickMinSWL`]: {
  //   label: 'Hose Derrick Minimum SWL',
  //   rules: [
  //     {
  //       operator: '>',
  //       field: `${type}MaxDraftAlongSide`,
  //     },
  //   ],
  // },
  [`${type}DepthAlongSide`]: {
    label: 'Depth Alongside (m)',
    rules: [
      {
        operator: '>',
        field: `${type}MaxDraftAlongSide`,
      },
    ],
  },
  [`${type}MaxDraftAlongSide`]: {
    label: 'Maximum Draught Alongside (mt)',
    rules: [
      {
        operator: '<',
        field: `${type}DepthAlongSide`,
      },
    ],
  },
  [`${type}MaximumHeightDripTray`]: {
    label: 'Maximum Height of Manifold Above Deck or Drip Tray (m)',
    rules: [
      {
        operator: '>',
        field: `${type}MinimumHeightDripTray`,
      },
    ],
  },
  [`${type}MinimumHeightDripTray`]: {
    label: 'Minimum Height of Manifold Above Deck or Drip Tray (m)',
    rules: [
      {
        operator: '<',
        field: `${type}MaximumHeightDripTray`,
      },
    ],
  },

  [`${type}MaximumManifoldSpacing`]: {
    label: 'Maximum Manifold Spacing (m)',
    rules: [
      {
        operator: '>',
        field: `${type}MinimumManifoldSpacing`,
      },
    ],
  },
  [`${type}MinimumManifoldSpacing`]: {
    label: 'Minimum Manifold Spacing (m)',
    rules: [
      {
        operator: '<',
        field: `${type}MaximumManifoldSpacing`,
      },
    ],
  },

  [`${type}MaximumManifoldSetBack`]: {
    label: 'Maximum Manifold Setback (m)',
    rules: [
      {
        operator: '>',
        field: `${type}MinimumManifoldSetBack`,
      },
    ],
  },
  [`${type}MinimumManifoldSetBack`]: {
    label: 'Minimum Manifold Setback (m)',
    rules: [
      {
        operator: '<',
        field: `${type}MaximumManifoldSetBack`,
      },
    ],
  },
  [`${type}CubicCapacityGasCarriersMaximum`]: {
    label: 'Cubic Capacity (Gas Carriers) Maximum (m3)',
    rules: [
      {
        operator: '>',
        field: `${type}CubicCapacityGasCarriersMinimum`,
      },
    ],
  },
  [`${type}CubicCapacityGasCarriersMinimum`]: {
    label: 'Cubic Capacity (Gas Carriers) Minimum (m3)',
    rules: [
      {
        operator: '<',
        field: `${type}CubicCapacityGasCarriersMaximum`,
      },
    ],
  },
});

//   [`${type}MinBowManiFoldDistance`]: 'Minimum Bow to Centre of Manifold Distance', // not found on ui
//   [`${type}MinSternManifoldDistance`]: 'Minimum Stern to Centre of Manifold Distance', // not found on ui
//   [`${type}MaxSCM`]: 'Maximum SCM', // missing
//   [`${type}MaxBCM`]: 'Maximum BCM', // missing
