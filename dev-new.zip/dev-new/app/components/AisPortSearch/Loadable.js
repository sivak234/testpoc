/**
 *
 * Asynchronously loads the component for AisPortSearch
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
