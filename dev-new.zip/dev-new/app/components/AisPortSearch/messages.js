/*
 * AisPortSearch Messages
 *
 * This contains all the text for the AisPortSearch component.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.components.AisPortSearch';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'Vessel List',
  },
  showLocaltime: {
    id: `${scope}.showLocaltime`,
    defaultMessage: 'Please enter local date and time',
  },
  noLocaltime: {
    id: `${scope}.noLocaltime`,
    defaultMessage: `Local time conversion is not available for port`,
  },
  showLocalCheck: {
    id: `${scope}.showLocalCheck`,
    defaultMessage: 'Show Local Time',
  },
  addPortLog: {
    id: `${scope}.addPortLog`,
    defaultMessage: `Add Port Log`,
  },
});
