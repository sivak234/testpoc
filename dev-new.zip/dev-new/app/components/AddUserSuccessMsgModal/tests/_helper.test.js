// import { defaultFunction } from '../_helper';

// describe('AddUserSuccessMsgModal helpers', () => {
//   describe('Default Helper Function', () => {
//     it('returns the expected value', () => {
//       const expected = 'Sample Text';
//       expect(defaultFunction('Sample Text')).toEqual(expected);
//     });
//   });
// });
describe('<AddUserSuccessMsgModal />', () => {
  it('Expect to not log errors in AddUserSuccessMsgModal', () => {
    expect(true).toBeTruthy();
  });
});
