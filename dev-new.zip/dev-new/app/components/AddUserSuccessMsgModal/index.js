/**
 *
 * AddUserSuccessMsgModal
 *
 */

import React, { memo } from 'react';
import PropTypes from 'prop-types';
import { Button, Modal, ModalHeader, ModalBody } from 'reactstrap';

import './_helper';

import './index.scss';

function AddUserSuccessMsgModal({
  show,
  successModalCloseTrigger,
  content,
  statusCode,
  header,
  closeVesselForm,
}) {
  return (
    <>
      <Modal
        isOpen={show}
        toggle={() => successModalCloseTrigger({ value: false })}
      >
        <ModalHeader toggle={() => successModalCloseTrigger({ value: false })}>
          {header}
        </ModalHeader>
        <ModalBody className="text-center">
          <div>
            <span
              className={
                statusCode === 'delete'
                  ? 'delete-xclaim-icon'
                  : 'deleteRoleIconBg'
              }
            >
              {statusCode === 'delete' ? (
                '!'
              ) : (
                <i className="fa fa-check Ellipse-1909" />
              )}{' '}
            </span>
            <span className="delete-user-msg textSpace">{content}</span>
          </div>
          <br />
          <Button
            color="primary"
            onClick={() => {
              successModalCloseTrigger({ value: false });
              closeVesselForm();
            }}
          >
            OK
          </Button>
        </ModalBody>
      </Modal>
    </>
  );
}

AddUserSuccessMsgModal.propTypes = {
  successModalCloseTrigger: PropTypes.func,
  show: PropTypes.bool.isRequired,
  content: PropTypes.string.isRequired,
  statusCode: PropTypes.any,
  header: PropTypes.string.isRequired,
  closeVesselForm: PropTypes.func,
};

export default memo(AddUserSuccessMsgModal);
