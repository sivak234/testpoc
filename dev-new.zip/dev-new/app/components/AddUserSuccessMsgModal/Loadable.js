/**
 *
 * Asynchronously loads the component for AddUserSuccessMsgModal
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
