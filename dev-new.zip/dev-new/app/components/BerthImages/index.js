/**
 *
 * BerthImages
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { Row, Col } from 'reactstrap';
import PtbImagesUpload from '../PtbImagesUpload/Loadable';
function BerthImages({
  passedref,
  ptbImage,
  updateImageData,
  uploadStatus,
  dHandleFileUpload,
  dHandleFileDownload,
  viewupdateptbImage,
  formType,
  berthimageinfo,
  dstoreimageinformation,
  dselectedTerminalBerthimageinfo,
  storeselectedberthimagefile,
  confirmBerthImageDeleteModalOpen,
  dopenberthimagepopupconfirmation,
  dclsoeberthimagepopupconfirmation,
  ddeleteTerminalBerthSelectedImages,
  dremoveFromCollection,
  isLoading,
}) {
  return (
    <>
      <Row className="add-berth-section-header mb-3 mt-3">
        <Col xs={12}>
          <h4 className="mb-0" ref={passedref}>
            Images
          </h4>
        </Col>
      </Row>
      <Row>
        <Col xs={12} md>
          <PtbImagesUpload
            title="Berth"
            ptbImage={ptbImage}
            updateImageData={updateImageData}
            uploadStatus={uploadStatus}
            dHandleFileUpload={dHandleFileUpload}
            dHandleFileDownload={dHandleFileDownload}
            viewupdateptbImage={viewupdateptbImage}
            formType={formType}
            terrminalimageinfo={berthimageinfo}
            dstoreimageinformation={dstoreimageinformation}
            dselectedTerminalBerthimageinfo={dselectedTerminalBerthimageinfo}
            storeselectedterminalimagefile={storeselectedberthimagefile}
            confirmImageDeleteModalOpen={confirmBerthImageDeleteModalOpen}
            ddeletemapimageconfirmation={dopenberthimagepopupconfirmation}
            dclsoeimagepopupconfirmation={dclsoeberthimagepopupconfirmation}
            ddeleteTerminalBerthSelectedImages={
              ddeleteTerminalBerthSelectedImages
            }
            dremoveFromCollection={dremoveFromCollection}
            isLoading={isLoading}
          />
        </Col>
      </Row>
    </>
  );
}

BerthImages.propTypes = {
  passedref: PropTypes.any,
  ptbImage: PropTypes.array,
  updateImageData: PropTypes.func,
  uploadStatus: PropTypes.string,
  dHandleFileUpload: PropTypes.func,
  dHandleFileDownload: PropTypes.func,
  viewupdateptbImage: PropTypes.array,
  formType: PropTypes.string,
  berthimageinfo: PropTypes.array,
  dstoreimageinformation: PropTypes.func,
  dselectedTerminalBerthimageinfo: PropTypes.func,
  storeselectedberthimagefile: PropTypes.array,
  confirmBerthImageDeleteModalOpen: PropTypes.bool,
  dopenberthimagepopupconfirmation: PropTypes.func,
  dclsoeberthimagepopupconfirmation: PropTypes.func,
  ddeleteTerminalBerthSelectedImages: PropTypes.func,
  dremoveFromCollection: PropTypes.func,
  isLoading: PropTypes.bool,
};

export default BerthImages;
