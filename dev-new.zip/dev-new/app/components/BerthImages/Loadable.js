/**
 *
 * Asynchronously loads the component for BerthImages
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
