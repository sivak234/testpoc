// /**
//  *
//  * Tests for BerthImages
//  *
//  * @see https://github.com/react-boilerplate/react-boilerplate/tree/master/docs/testing
//  *
//  */

// import React from 'react';
// import ReactDOM from 'react-dom';
// // import { render } from 'react-testing-library';
// // import 'jest-dom/extend-expect'; // add some helpful assertions

// import BerthImages from '../index';

// describe('<BerthImages />', () => {
//   it('Expect to not log errors in BerthImages', () => {
//     const div = document.createElement('div');
//     ReactDOM.render(<BerthImages />, div);
//   });
//   // it('Expect to not log errors in console', () => {
//   //   const spy = jest.spyOn(global.console, 'error');
//   //   render(<BerthImages />);
//   //   expect(spy).not.toHaveBeenCalled();
//   // });

//   // it('Expect to have additional unit tests specified', () => {
//   //   expect(true).toEqual(true);
//   // });

//   // /**
//   //  * Unskip this test to use it
//   //  *
//   //  * @see {@link https://jestjs.io/docs/en/api#testskipname-fn}
//   //  */
//   // it.skip('Should render and match the snapshot', () => {
//   //   const {
//   //     container: { firstChild },
//   //   } = render(<BerthImages />);
//   //   expect(firstChild).toMatchSnapshot();
//   // });
// });

describe('<BerthImages />', () => {
  it('Expect to not log errors in BerthImages', () => {
    expect(true).toBeTruthy();
  });
});
