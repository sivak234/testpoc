/*
 * AddEquationConstant Messages
 *
 * This contains all the text for the AddEquationConstant component.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.components.AddEquationConstant';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'This is the AddEquationConstant component!',
  },
});
