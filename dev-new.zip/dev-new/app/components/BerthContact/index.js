/**
 *
 * BerthContact
 *
 */

import React from 'react';
import { Row, Col } from 'reactstrap';
import PropTypes from 'prop-types';

function BerthContact({ passedRef, data }) {
  return (
    <>
      <Row className="add-berth-section-header mb-3 mt-3">
        <Col xs={12}>
          <h4 className="mb-0" ref={passedRef}>
            Berth Contacts
          </h4>
        </Col>
      </Row>
      <Row>
        <Col xs={6} sm={2} md={4} lg={3}>
          <h5>Designation</h5>
          <p>{data.designation ? data.designation : <br />}</p>
        </Col>

        <Col xs={6} sm={2} md={4} lg={3}>
          <h5>Name</h5>
          <p>{data.name ? data.name : <br />}</p>
        </Col>

        <Col xs={6} sm={2} md={4} lg={3}>
          <h5>Address</h5>
          <p>{data.address ? data.address : <br />}</p>
        </Col>

        <Col xs={6} sm={2} md={4} lg={3}>
          <h5>Postal Code</h5>
          <p>{data.postalCode ? data.postalCode : <br />}</p>
        </Col>

        <Col xs={6} sm={2} md={4} lg={3}>
          <h5>Email</h5>
          <p>{data.email ? data.email : <br />}</p>
        </Col>

        <Col xs={6} sm={2} md={4} lg={3}>
          <h5>Phone Number</h5>
          <p>{data.phoneNumber ? data.phoneNumber : <br />}</p>
        </Col>
      </Row>
    </>
  );
}

BerthContact.propTypes = {
  passedRef: PropTypes.any,
  data: PropTypes.object,
};

export default BerthContact;
