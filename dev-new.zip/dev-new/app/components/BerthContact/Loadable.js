/**
 *
 * Asynchronously loads the component for BerthContact
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
