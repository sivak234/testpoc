/**
 *
 * AisVesselDetails
 *
 */

import React, { memo, useState, useEffect } from 'react';
import {
  Label,
  Row,
  Col,
  Button,
  CustomInput,
  FormGroup,
  Popover,
  PopoverBody,
} from 'reactstrap';
import PropTypes from 'prop-types';
import { FormattedMessage } from 'react-intl';
import messages from './messages';
import { FETCH_RECORD_COUNT } from '../../utils/constants';
import AisMap from '../AisMap/Loadable';
import AisVesselSearch from '../AisVesselSearch/Loadable';
import Export from '../AisReportExport/Loadable';
import DialogBox from '../DialogBox/Loadable';
import DropDown from '../Dropdown';
import AutoComplete from '../AutoCompleteTextBox/Loadable';
import { getVesselByFilter } from './_helper';
import { dateTimeConversion } from '../../utils/dataModification';
import AisVesselPortSearch from '../AisVesselPortSearch/Loadable';
import './index.scss';

function AisVesselDetails({
  moduleId,
  fetchFromDate,
  fetchToDate,
  fromDate,
  toDate,
  aisVesselData,
  handleExportPortData,
  handleAddRow,
  mainCargoTypeList,
  cargoTypeList,
  vesselsList,
  terminalsList,
  berthsList,
  operation,
  nextPortsList,
  previousPortsList,
  charterersList,
  shippersList,
  receiversList,
  agentsList,
  handleVesselItemChanged,
  handlePortBackLanding,
  handleAddVesselMovement,
  handleUpdateVesselMovement,
  handleDeleteVesselMovement,
  isModelOpen,
  handleModelClose,
  handleCancelVesselMovement,
  regionOptions,
  onRegionSelected,
  selected,
  onCountrySelected,
  countryOptions,
  nextPortSelected,
  selectedSearch,
  vvd,
  vesselDetails,
  commodityList,
  changeFieldName,
  modelMessage,
  portChecked,
  handleSelectedRowData,
  fetchAisVesselData,
  fetchPortCheckboxUpdate,
  fetchAllPortsMapData,
  portMapData,
  portMapModifiedData,
  vesselsNearestData,
  totalRecords,
  dshowLocalTime,
  isShowLocaltime,
  isShowLocalTimeMsg,
  berthsData,
  mainCargoTypeData,
  cargoTypeData,
  commodityData,
  fetchVesselName,
  vesselName,
  fetchPortName,
  portName,
  dAutoCompletePopover,
  isShowAutoCompletepopOver,
  dTerminalBerthLoadOnEdit,
  vesselOperation,
  portDetails,
  showVesselPopOver,
  dToggleVesselPopOver,
  mapRefresh,
  fetchAisVesselVoyageDetails,
  fetchAisVesselDetails,
  fetchselectedImoData,
  fetchNearestRangeVesselsByImo,
  fetchPortDetails,
  fetchPortStatisticDetails,
  fetchPortMoveMapData,
  fetchTerminalCodeNames,
  fetchVesselData,
  dvesselDetails,
}) {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  const regionSelector = evt => {
    onRegionSelected(evt.target.value, evt.target.selectedOptions[0].text);
    const options = {
      imo: vesselDetails.imo,
      pageNo: 0,
      fetchRecordCount: FETCH_RECORD_COUNT,
    };
    fetchAisVesselData(options);
  };
  const onPortCheckBoxClicked = evt => {
    fetchPortCheckboxUpdate({
      type: evt.target.id,
      portChecked: evt.target.checked,
    });
    if (!portMapData || portMapData.length === 0) {
      fetchAllPortsMapData(false);
    }
  };
  const countrySelector = evt => {
    onCountrySelected(evt.target.value, evt.target.selectedOptions[0].text);
    const options = {
      imo: vesselDetails.imo,
      pageNo: 0,
      fetchRecordCount: FETCH_RECORD_COUNT,
    };
    fetchAisVesselData(options);
  };

  const onNextPortSelected = evt => {
    nextPortSelected(evt.split('^')[0], evt.split('^')[1]);
    const options = {
      imo: vesselDetails.imo,
      pageNo: 0,
      fetchRecordCount: FETCH_RECORD_COUNT,
    };
    fetchAisVesselData(options);
  };
  const handleLocaltime = evt => {
    dshowLocalTime(evt.target.checked);
    const options = {
      imo: vesselDetails.imo,
      pageNo: 0,
      fetchRecordCount: FETCH_RECORD_COUNT,
    };
    fetchAisVesselData(options);
  };
  const getAisVesselData = value => {
    const options = {
      imo: vesselDetails.imo,
      pageNo: value.pageNo,
      fetchRecordCount: value.fetchRecordCount,
    };
    fetchAisVesselData(options);
  };
  let latd = '';
  let langd = '';
  const index = 0;
  let coordinate = [];
  const mapData = [];
  if (vvd && vvd.vesselLatLng) {
    coordinate = JSON.parse(vvd.vesselLatLng);
    if (coordinate.coordinates) {
      latd = coordinate.coordinates[index + 1];
      langd = coordinate.coordinates[index];
    }
    const obj = {
      vesselBreadth: vvd.vesselBreadth,
      vesselHeading: vvd.vesselHeading ? vvd.vesselHeading : 50,
      vesselLatLng: vvd.vesselLatLng,
      vesselLength: vvd.vesselLength,
      vesselName: vvd.vesselName,
      vesselSpeed: vvd.vesselSpeed,
      vesselType: vvd.vesselType,
      latitude: latd,
      longitude: langd,
    };
    mapData.push(obj);
  }
  const aisVesselDataFilter = getVesselByFilter(
    aisVesselData,
    selected,
    selectedSearch,
  );
  const vesselImo = vesselDetails ? vesselDetails.imo : '';

  const [panel, setPanel] = useState(false);

  const toggleButton = () => {
    if (!panel) {
      setPanel(true);
    } else {
      setPanel(false);
    }
  };
  const handleExport = () => {
    const options = {
      imo: vvd.imo,
      pageNo: 0,
      fetchRecordCount: 100000,
    };
    handleExportPortData(options);
  };
  const veselundefined = vvd.vesselNavigationalStatus !== undefined;
  let isfilterApply = false;
  if (
    selectedSearch.regionId !== '' ||
    selectedSearch.countryId !== '' ||
    selectedSearch.nextPortId !== ''
  ) {
    isfilterApply = true;
  }
  let selectVesselName = null;
  let selectVesselImo = null;
  let selectVesselStatus = null;
  if (
    vesselDetails &&
    vesselDetails.vesselName !== undefined &&
    selectVesselName === null
  ) {
    selectVesselName = vesselDetails.vesselName;
    selectVesselImo = vesselDetails.imo;
    selectVesselStatus = vesselDetails.vesselStatus;
  }
  if (vvd && vvd.vesselName !== undefined && selectVesselName === null) {
    selectVesselName = vvd.vesselName;
    selectVesselImo = vvd.imo;
  }

  const vesselMovePopOver = () => {
    if (!showVesselPopOver) {
      dToggleVesselPopOver(true);
    } else {
      dToggleVesselPopOver(false);
    }
  };
  let showVesselStatus = false;
  if (
    selectVesselStatus === 'Dead' ||
    selectVesselStatus === 'Existence in doubt'
  ) {
    showVesselStatus = true;
  }
  return (
    <>
      <AisVesselPortSearch
        vesselName={vesselName}
        vesselDetails={dvesselDetails}
        fetchVesselName={fetchVesselName}
        fetchAisVesselVoyageDetails={fetchAisVesselVoyageDetails}
        fetchAisVesselDetails={fetchAisVesselDetails}
        fetchAisVesselData={fetchAisVesselData}
        fetchselectedImoData={fetchselectedImoData}
        fetchNearestRangeVesselsByImo={fetchNearestRangeVesselsByImo}
        portName={portName}
        portDetails={portDetails}
        fetchPortName={fetchPortName}
        fetchPortDetails={fetchPortDetails}
        fetchPortStatisticDetails={fetchPortStatisticDetails}
        fetchVesselData={fetchVesselData}
        fetchPortMoveMapData={fetchPortMoveMapData}
        fetchTerminalCodeNames={fetchTerminalCodeNames}
      />
      <Row className="vessel-movement-section-card">
        <Col>
          <Row className="mb-3">
            <Col sm={10} xs="8">
              <h4 className="mt-1 mb-1">
                {selectVesselName !== null ? selectVesselName : ''} |{' '}
                {selectVesselImo !== null ? selectVesselImo : ''} |{' '}
                {selectVesselStatus !== null ? selectVesselStatus : '-'}
              </h4>
            </Col>
            <Col sm={2} xs="4" className="text-right">
              <Button
                color="success"
                size="sm"
                onClick={e => handlePortBackLanding(e)}
              >
                <FormattedMessage
                  {...messages.vesselDetailMovementBackNavBtn}
                />
              </Button>
            </Col>
          </Row>
          <Row className="port-details-section">
            <Col xs="1" sm="1" className="mb-2">
              <Button outline color="success" size="sm" onClick={toggleButton}>
                <span className="menu-toggler-icon" />
                <span className="menu-toggler-icon" />
                <span className="menu-toggler-icon" />
              </Button>
            </Col>
            {panel ? (
              <Col xs="12" sm="5">
                <Row>
                  <Col xs="12">
                    <Row className="ais-management-container-search-header mb-4">
                      <Col xs="12">
                        <h4 className="mb-0">
                          <FormattedMessage {...messages.vesselDetail} />
                        </h4>
                      </Col>
                    </Row>

                    <Row className="ais-vessel-movement-label-container">
                      <Col xs="4">
                        <Label>
                          <FormattedMessage {...messages.vesselType} />
                        </Label>
                      </Col>
                      <Col xs="4">
                        <Label>
                          <FormattedMessage
                            {...messages.vesselClassification}
                          />
                        </Label>
                      </Col>
                      <Col xs="4">
                        <Label>
                          <FormattedMessage {...messages.vesselSubType} />
                        </Label>
                      </Col>
                    </Row>
                    <Row>
                      <Col xs="4">
                        {vesselDetails ? (
                          <Label>{vesselDetails.wopVesselType}</Label>
                        ) : (
                          ''
                        )}
                      </Col>
                      <Col xs="4">
                        {vesselDetails ? (
                          <Label>
                            {vesselDetails.wopVesselSizeClassification}
                          </Label>
                        ) : (
                          ''
                        )}
                      </Col>
                      <Col xs="4">
                        {vesselDetails ? (
                          <Label>{vesselDetails.subType}</Label>
                        ) : (
                          ''
                        )}
                      </Col>
                    </Row>

                    <Row className="mt-2 ais-vessel-movement-label-container">
                      <Col xs="4">
                        <Label>
                          <FormattedMessage {...messages.grt} />
                        </Label>
                      </Col>
                      <Col xs="4">
                        <Label>
                          <FormattedMessage {...messages.dwt} />
                        </Label>
                      </Col>
                      <Col xs="4">
                        <Label>
                          <FormattedMessage {...messages.loa} />
                        </Label>
                      </Col>
                    </Row>

                    <Row>
                      <Col xs="4">
                        {vesselDetails ? (
                          <Label>{vesselDetails.gross}</Label>
                        ) : (
                          ''
                        )}
                      </Col>
                      <Col xs="4">
                        {vesselDetails ? (
                          <Label>{vesselDetails.dwt}</Label>
                        ) : (
                          ''
                        )}
                      </Col>
                      <Col xs="4">
                        {vesselDetails ? (
                          <Label>{vesselDetails.loa}</Label>
                        ) : (
                          ''
                        )}
                      </Col>
                    </Row>
                  </Col>
                </Row>
                <Row className="mt-4">
                  <Col xs="12">
                    <Row className="port-statistics-section">
                      <Col xs="12">
                        <Row className="ais-management-container-search-header mb-4">
                          <Col xs="12">
                            <h4 className="mb-0">
                              <FormattedMessage {...messages.voyageDetails} />
                            </h4>
                          </Col>
                        </Row>

                        <Row className="ais-vessel-movement-label-container">
                          <Col xs="4">
                            <Label>
                              <FormattedMessage
                                {...messages.lastPositionReportDate}
                              />
                            </Label>
                          </Col>
                          <Col xs="4">
                            <Label>
                              <FormattedMessage {...messages.previousPort} />
                            </Label>
                          </Col>
                          <Col xs="4">
                            <Label>
                              <FormattedMessage {...messages.latitude} />
                            </Label>
                          </Col>
                        </Row>
                        <Row>
                          <Col xs="4">
                            {vesselDetails ? (
                              <Label>{vvd.recordedDate}</Label>
                            ) : (
                              ''
                            )}
                          </Col>
                          <Col xs="4">
                            {vesselDetails ? (
                              <Label>{vvd.previousePortName}</Label>
                            ) : (
                              ''
                            )}
                          </Col>
                          <Col xs="4">
                            <Label>{latd}</Label>
                          </Col>
                        </Row>

                        <Row className="mt-2 ais-vessel-movement-label-container">
                          <Col xs="4">
                            <Label>
                              <FormattedMessage {...messages.nextPort} />
                            </Label>
                          </Col>
                          <Col xs="4">
                            <Label>
                              <FormattedMessage {...messages.eta} />
                            </Label>
                          </Col>
                          <Col xs="4">
                            <Label>
                              <FormattedMessage {...messages.longitude} />
                            </Label>
                          </Col>
                        </Row>

                        <Row>
                          <Col xs="4">
                            <Label>
                              {!showVesselStatus ? vvd.nextPortName : '-'}
                            </Label>
                          </Col>
                          <Col xs="4">
                            <Label>
                              {!showVesselStatus
                                ? dateTimeConversion(vvd.nextPorteta)
                                : '-'}
                            </Label>
                          </Col>
                          <Col xs="4">
                            <Label>{langd}</Label>
                          </Col>
                        </Row>

                        <Row className="mt-2 ais-vessel-movement-label-container">
                          <Col xs="4">
                            <Label>
                              <FormattedMessage {...messages.draught} />
                            </Label>
                          </Col>
                          <Col xs="4">
                            <Label>
                              <FormattedMessage {...messages.mooringStatus} />
                            </Label>
                          </Col>
                          <Col xs="4">
                            <Label>
                              <FormattedMessage
                                {...messages.navigationalStatus}
                              />
                            </Label>
                          </Col>
                        </Row>
                        <Row>
                          <Col xs="4">
                            <Label>{vvd.vesselDraught}</Label>
                          </Col>
                          <Col xs="4">
                            <Label>
                              {!showVesselStatus
                                ? vvd.vesselMooringStatus
                                : '-'}
                            </Label>
                          </Col>
                          <Col xs="4">
                            {veselundefined ? (
                              <Label>
                                {vvd.vesselNavigationalStatus !== 'undefined' &&
                                !showVesselStatus
                                  ? vvd.vesselNavigationalStatus
                                  : '-'}
                              </Label>
                            ) : (
                              ''
                            )}
                          </Col>
                        </Row>

                        <Row className="mt-2 ais-vessel-movement-label-container">
                          <Col xs="4">
                            <Label>
                              <FormattedMessage
                                {...messages.vesselLoadCondition}
                              />
                            </Label>
                          </Col>
                          <Col xs="4">
                            <Label>
                              <FormattedMessage {...messages.cargoType} />
                            </Label>
                          </Col>
                          <Col xs="4">
                            <Label>
                              <FormattedMessage {...messages.commodity} />
                            </Label>
                          </Col>
                        </Row>

                        <Row>
                          <Col xs="4">
                            <Label>
                              {!showVesselStatus
                                ? vvd.vesselLoadCondition
                                : '-'}
                            </Label>
                          </Col>
                          <Col xs="4">
                            <Label>
                              {!showVesselStatus ? vvd.cargoType : '-'}
                            </Label>
                          </Col>
                          <Col xs="4">
                            <Label>
                              {!showVesselStatus ? vvd.commodity : '-'}
                            </Label>
                          </Col>
                        </Row>

                        <Row className="mt-2 ais-vessel-movement-label-container">
                          <Col xs="4">
                            <Label>
                              <FormattedMessage {...messages.quantityOnboard} />
                            </Label>
                          </Col>
                          <Col xs="4">
                            <Label>
                              <FormattedMessage {...messages.speed} />
                            </Label>
                          </Col>
                          <Col xs="4">
                            <Label>
                              <FormattedMessage {...messages.course} />
                            </Label>
                          </Col>
                        </Row>
                        <Row>
                          <Col xs="4">
                            <Label>
                              {!showVesselStatus
                                ? vvd.vesselQuantityOnboard
                                : '-'}
                            </Label>
                          </Col>
                          <Col xs="4">
                            <Label>
                              {!showVesselStatus ? vvd.vesselSpeed : '-'}
                            </Label>
                          </Col>
                          <Col xs="4">
                            <Label>
                              {!showVesselStatus ? vvd.vesselCourse : '-'}
                            </Label>
                          </Col>
                        </Row>
                      </Col>
                    </Row>
                  </Col>
                </Row>
              </Col>
            ) : (
              ''
            )}
            <Col sm={panel ? '6' : '11'} xs="12">
              <Row>
                <Col xs={12}>
                  <div
                    className="inner-container p-0 mt-0"
                    style={{ display: 'flex' }}
                  >
                    <Col xs={10}>
                      <FormGroup className="mt-0 mb-0 pb-3 pt-3 d-flex form-container">
                        <CustomInput
                          type="checkbox"
                          id="PORT_POLYGON"
                          name="showPort"
                          label="Port"
                          className="pr-3"
                          onClick={evt => onPortCheckBoxClicked(evt)}
                        />
                      </FormGroup>
                    </Col>
                    <Col xs={2} className="text-right pt-1">
                      <Button
                        id="vesselTypeShow"
                        color="link"
                        onClick={() => vesselMovePopOver()}
                      >
                        <i className="fa fa-info color-primary fa-lg" />
                      </Button>
                      <Popover
                        placement="bottom"
                        isOpen={showVesselPopOver}
                        target="vesselTypeShow"
                      >
                        <PopoverBody>
                          <Col xs={12} className="pl-0 pr-0">
                            <h4 className="mb-2">Ship Type</h4>
                          </Col>
                          <Col xs={12} className="pl-0 pr-0">
                            <div className="mb-1">
                              <div className="color vessel-marker-red mr-2 mt-1" />
                              Bulk Carrier
                            </div>
                            <div className="mb-1">
                              <div className="color vessel-marker-paleorange mr-2 mt-1" />
                              Gas Carrier
                            </div>
                            <div className="mb-1">
                              <div className="color vessel-marker-pink mr-2 mt-1" />
                              General Cargo
                            </div>
                            <div className="mb-1">
                              <div className="color vessel-marker-light-blue mr-2 mt-1" />
                              Passenger
                            </div>
                            <div className="mb-1">
                              <div className="color vessel-marker-orange mr-2 mt-1" />
                              Container
                            </div>
                            <div className="mb-1">
                              <div className="color vessel-marker-green mr-2 mt-1" />
                              Tanker
                            </div>
                            <div className="mb-1">
                              <div className="color vessel-marker-brawn mr-2 mt-1" />
                              RoRo
                            </div>
                            <div className="mb-1">
                              <div className="color vessel-marker-grey mr-2 mt-1" />
                              Others
                            </div>
                            <div className="mb-1">
                              <div className="color vessel-marker-black mr-2 mt-1 text-center">
                                <span className="ballast-color ballast-marker-white" />
                              </div>
                              Ballast
                            </div>
                          </Col>
                        </PopoverBody>
                      </Popover>
                    </Col>
                  </div>
                </Col>
              </Row>
              <AisMap
                mapScreenView="AISVesselMovementMap"
                portChecked={portChecked}
                portMapData={portMapModifiedData}
                vesselsNearestData={vesselsNearestData}
                vesselDetails={vvd}
                mapHeight="550px"
                mapElementHeight="90%"
                mapRefresh={mapRefresh}
              />
            </Col>
          </Row>
          <Row className="mb-3 mt-3">
            <Col>
              <h4 className="ais-management-container-search-header mb-0">
                <FormattedMessage {...messages.vesselDetailMovementTitle} />
              </h4>
            </Col>
          </Row>
          <Row>
            <Col
              xs="12"
              sm="7"
              className="vessel-movement-check ais-vessel-movement-label-container"
            >
              <Row className="mgtop20">
                <Col sm={4} xs="12">
                  <DropDown
                    label={<FormattedMessage {...messages.region} />}
                    options={regionOptions}
                    onChange={evt => regionSelector(evt)}
                    selected={selected.regionId}
                  />
                </Col>
                <Col sm={4} xs="12">
                  <DropDown
                    label={<FormattedMessage {...messages.country} />}
                    options={countryOptions}
                    onChange={evt => countrySelector(evt)}
                    selected={selected.countryId}
                  />
                </Col>
                <Col sm={4} xs="12">
                  <AutoComplete
                    label={<FormattedMessage {...messages.port} />}
                    suggestions={portName}
                    type="nextPort"
                    portDetails={portDetails}
                    fetchPortName={fetchPortName}
                    onNextPortSelected={onNextPortSelected}
                  />
                </Col>
              </Row>
            </Col>
            <Col sm="7" xs="12" className="mt-3">
              <Export
                fetchFromDate={fetchFromDate}
                fetchToDate={fetchToDate}
                fromDate={fromDate}
                toDate={toDate}
                portVesselData={aisVesselDataFilter}
                handleExportPortData={handleExport}
              />
            </Col>
          </Row>
          <Row>
            <Col>
              <AisVesselSearch
                moduleId={moduleId}
                portVesselData={aisVesselDataFilter}
                handleAddRow={handleAddRow}
                mainCargoTypeList={mainCargoTypeList}
                cargoTypeList={cargoTypeList}
                vesselsList={vesselsList}
                terminalsList={terminalsList}
                berthsList={berthsList}
                operation={operation}
                nextPortsList={nextPortsList}
                previousPortsList={previousPortsList}
                charterersList={charterersList}
                shippersList={shippersList}
                receiversList={receiversList}
                agentsList={agentsList}
                handleVesselItemChanged={handleVesselItemChanged}
                handleAddVesselMovement={handleAddVesselMovement}
                handleUpdateVesselMovement={handleUpdateVesselMovement}
                handleDeleteVesselMovement={handleDeleteVesselMovement}
                handleCancelVesselMovement={handleCancelVesselMovement}
                vesselImo={vesselImo}
                commodityList={commodityList}
                changeFieldName={changeFieldName}
                handleSelectedRowData={handleSelectedRowData}
                fetchAisVesselData={getAisVesselData}
                totalRecords={
                  isfilterApply ? aisVesselDataFilter.length : totalRecords
                }
                handleLocaltime={handleLocaltime}
                isShowLocaltime={isShowLocaltime}
                isShowLocalTimeMsg={isShowLocalTimeMsg}
                berthsData={berthsData}
                mainCargoTypeData={mainCargoTypeData}
                cargoTypeData={cargoTypeData}
                commodityData={commodityData}
                fetchVesselName={fetchVesselName}
                vesselName={vesselName}
                fetchPortName={fetchPortName}
                portName={portName}
                dAutoCompletePopover={dAutoCompletePopover}
                isShowAutoCompletepopOver={isShowAutoCompletepopOver}
                dTerminalBerthLoadOnEdit={dTerminalBerthLoadOnEdit}
                vesselOperation={vesselOperation}
              />
            </Col>
          </Row>
          {isModelOpen && (
            <DialogBox
              show={isModelOpen}
              fetchModelClose={handleModelClose}
              title={modelMessage.modelTitle}
              statusCode=""
              content={modelMessage.modelContent}
            />
          )}
        </Col>
      </Row>
    </>
  );
}

AisVesselDetails.propTypes = {
  moduleId: PropTypes.number.isRequired,
  fetchFromDate: PropTypes.func.isRequired,
  fetchToDate: PropTypes.func.isRequired,
  fromDate: PropTypes.object,
  toDate: PropTypes.object,
  aisVesselData: PropTypes.array.isRequired,
  vesselList: PropTypes.array.isRequired,
  handleExportPortData: PropTypes.func.isRequired,
  handleAddRow: PropTypes.func.isRequired,
  mainCargoTypeList: PropTypes.array.isRequired,
  cargoTypeList: PropTypes.array.isRequired,
  vesselsList: PropTypes.array,
  terminalsList: PropTypes.array.isRequired,
  berthsList: PropTypes.array.isRequired,
  operation: PropTypes.array.isRequired,
  nextPortsList: PropTypes.array,
  previousPortsList: PropTypes.array.isRequired,
  charterersList: PropTypes.array.isRequired,
  shippersList: PropTypes.array.isRequired,
  receiversList: PropTypes.array.isRequired,
  agentsList: PropTypes.array.isRequired,
  handleVesselItemChanged: PropTypes.func.isRequired,
  handlePortBackLanding: PropTypes.func.isRequired,
  handleAddVesselMovement: PropTypes.func.isRequired,
  handleUpdateVesselMovement: PropTypes.func.isRequired,
  handleDeleteVesselMovement: PropTypes.func.isRequired,
  isModelOpen: PropTypes.bool.isRequired,
  handleModelClose: PropTypes.func.isRequired,
  handleCancelVesselMovement: PropTypes.func.isRequired,
  regionOptions: PropTypes.array.isRequired,
  onRegionSelected: PropTypes.func.isRequired,
  selected: PropTypes.object.isRequired,
  countryOptions: PropTypes.array.isRequired,
  onCountrySelected: PropTypes.func.isRequired,
  nextPortSelected: PropTypes.func.isRequired,
  selectedSearch: PropTypes.object.isRequired,
  vvd: PropTypes.object.isRequired,
  vesselDetails: PropTypes.object,
  commodityList: PropTypes.array.isRequired,
  changeFieldName: PropTypes.string.isRequired,
  handleSelectedRowData: PropTypes.func.isRequired,
  modelMessage: PropTypes.object.isRequired,
  fetchAisVesselData: PropTypes.func.isRequired,
  fetchPortCheckboxUpdate: PropTypes.func.isRequired,
  totalRecords: PropTypes.number.isRequired,
  portChecked: PropTypes.bool.isRequired,
  fetchAllPortsMapData: PropTypes.func.isRequired,
  portMapData: PropTypes.array.isRequired,
  portMapModifiedData: PropTypes.array,
  vesselsNearestData: PropTypes.array.isRequired,
  dshowLocalTime: PropTypes.func.isRequired,
  isShowLocaltime: PropTypes.bool.isRequired,
  isShowLocalTimeMsg: PropTypes.bool.isRequired,
  berthsData: PropTypes.array.isRequired,
  mainCargoTypeData: PropTypes.array.isRequired,
  cargoTypeData: PropTypes.array.isRequired,
  commodityData: PropTypes.array.isRequired,
  fetchVesselName: PropTypes.func,
  vesselName: PropTypes.array.isRequired,
  fetchPortName: PropTypes.func,
  portName: PropTypes.array.isRequired,
  dAutoCompletePopover: PropTypes.func.isRequired,
  isShowAutoCompletepopOver: PropTypes.bool.isRequired,
  dTerminalBerthLoadOnEdit: PropTypes.func.isRequired,
  vesselOperation: PropTypes.array.isRequired,
  portDetails: PropTypes.func.isRequired,
  showVesselPopOver: PropTypes.bool,
  dToggleVesselPopOver: PropTypes.func,
  mapRefresh: PropTypes.bool,
  fetchAisVesselVoyageDetails: PropTypes.func,
  fetchAisVesselDetails: PropTypes.func,
  fetchselectedImoData: PropTypes.func,
  fetchNearestRangeVesselsByImo: PropTypes.func,
  fetchPortDetails: PropTypes.func,
  fetchPortStatisticDetails: PropTypes.func,
  fetchPortMoveMapData: PropTypes.func,
  fetchTerminalCodeNames: PropTypes.func,
  fetchVesselData: PropTypes.func.isRequired,
  dvesselDetails: PropTypes.func,
};

export default memo(AisVesselDetails);
