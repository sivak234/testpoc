export const getVesselByFilter = (aisVesselData, selected, selectedSearch) => {
  let aisVesselDataFilter = aisVesselData;
  const { regionId, countryId } = selected;
  const { nextPortId } = selectedSearch;
  if (regionId !== '') {
    aisVesselDataFilter = aisVesselData.filter(
      x => x.regionId === parseInt(regionId, 10),
    );
  }
  if (countryId !== '') {
    aisVesselDataFilter = aisVesselData.filter(
      x => x.countryId === parseInt(countryId, 10),
    );
  }
  if (selectedSearch.nextPortId !== '') {
    aisVesselDataFilter = aisVesselData.filter(x => x.portId === nextPortId);
  }
  return aisVesselDataFilter;
};
