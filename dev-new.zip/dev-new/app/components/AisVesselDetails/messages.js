/*
 * AisVesselDetails Messages
 *
 * This contains all the text for the AisVesselDetails component.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.components.AisVesselDetails';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'VIEW VESSEL MOVEMENT',
  },
  vesselDetail: {
    id: `${scope}.vesselDetail`,
    defaultMessage: 'Vessel Details',
  },
  vesselType: {
    id: `${scope}.vesselType`,
    defaultMessage: 'Vessel Type',
  },
  vesselClassification: {
    id: `${scope}.vesselClassification`,
    defaultMessage: 'Vessel Classification',
  },
  vesselSubType: {
    id: `${scope}.vesselSubType`,
    defaultMessage: 'Vessel Sub-Type',
  },
  grt: {
    id: `${scope}.grt`,
    defaultMessage: 'GRT',
  },
  dwt: {
    id: `${scope}.dwt`,
    defaultMessage: 'DWT',
  },
  loa: {
    id: `${scope}.loa`,
    defaultMessage: 'LOA',
  },
  voyageDetails: {
    id: `${scope}.voyageDetails`,
    defaultMessage: 'Voyage Details',
  },
  lastPositionReportDate: {
    id: `${scope}.lastPositionReportDate`,
    defaultMessage: 'Last Position Report Date',
  },
  previousPort: {
    id: `${scope}.previousPort`,
    defaultMessage: 'Previous Port',
  },
  latitude: {
    id: `${scope}.latitude`,
    defaultMessage: 'Latitude',
  },
  nextPort: {
    id: `${scope}.nextPort`,
    defaultMessage: 'Next Port',
  },
  eta: {
    id: `${scope}.eta`,
    defaultMessage: 'ETA',
  },
  longitude: {
    id: `${scope}.longitude`,
    defaultMessage: 'Longitude',
  },
  draught: {
    id: `${scope}.draught`,
    defaultMessage: 'Draught',
  },
  mooringStatus: {
    id: `${scope}.mooringStatus`,
    defaultMessage: 'Mooring Status',
  },
  navigationalStatus: {
    id: `${scope}.navigationalStatus`,
    defaultMessage: 'Navigational Status',
  },
  vesselLoadCondition: {
    id: `${scope}.vesselLoadCondition`,
    defaultMessage: 'Vessel Load Condition',
  },
  cargoType: {
    id: `${scope}.cargoType`,
    defaultMessage: 'Cargo',
  },
  commodity: {
    id: `${scope}.commodity`,
    defaultMessage: 'Grade',
  },
  quantityOnboard: {
    id: `${scope}.quantityOnboard`,
    defaultMessage: 'Quantity Onboard',
  },
  speed: {
    id: `${scope}speed`,
    defaultMessage: 'Speed',
  },
  course: {
    id: `${scope}.course`,
    defaultMessage: 'Course',
  },
  region: {
    id: `${scope}.region`,
    defaultMessage: 'Region',
  },
  country: {
    id: `${scope}.country`,
    defaultMessage: 'Country',
  },
  port: {
    id: `${scope}.port`,
    defaultMessage: 'Port',
  },
  vesselDetailMovementTitle: {
    id: `${scope}.vesselDetailMovementTitle`,
    defaultMessage: 'Vessel Movement',
  },
  vesselDetailMovementBackNavBtn: {
    id: `${scope}.vesselDetailMovementBackNavBtn`,
    defaultMessage: 'Back',
  },
});
