describe('<AisVesselDetails />', () => {
  it('Expect to not log errors in AisVesselDetails', () => {
    expect(true).toBeTruthy();
  });
});
