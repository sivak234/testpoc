/**
 *
 * AdvertisementCmp
 *
 */

import React from 'react';
import './index.scss';
import PropTypes from 'prop-types';
// import styled from 'styled-components';

// import { FormattedMessage } from 'react-intl';
// import messages from './messages';
// import advertisementImg from '../../assets/images/Advertisement-top-bottom-img.png';

function AdvertisementCmp({ src, cssClass }) {
  return (
    <div className={cssClass}>
      <img src={src} alt="adv_img" />
      {/* <h4>
        <FormattedMessage {...messages.header} />
      </h4> */}
    </div>
  );
}

AdvertisementCmp.propTypes = {
  src: PropTypes.string,
  cssClass: PropTypes.string,
};

export default AdvertisementCmp;
