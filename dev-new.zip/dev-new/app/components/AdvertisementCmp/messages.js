/*
 * AdvertisementCmp Messages
 *
 * This contains all the text for the AdvertisementCmp component.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.components.AdvertisementCmp';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'Advertisement',
  },
});
