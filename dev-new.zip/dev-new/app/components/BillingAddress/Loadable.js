/**
 *
 * Asynchronously loads the component for BillingAddress
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
