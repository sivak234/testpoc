/*
 * BillingAddress Messages
 *
 * This contains all the text for the BillingAddress component.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.components.BillingAddress';

export default defineMessages({
  update: {
    id: `${scope}.update`,
    defaultMessage: 'Save',
  },
  cancel: {
    id: `${scope}.cancel`,
    defaultMessage: 'Cancel',
  },
  header: {
    id: `${scope}.header`,
    defaultMessage: 'Billing Address',
  },
  edit: {
    id: `${scope}.edit`,
    defaultMessage: 'Edit',
  },
  address1: {
    id: `${scope}.address1`,
    defaultMessage: 'Address 1',
  },
  address1RequiredMsg: {
    id: `${scope}.address1RequiredMsg`,
    defaultMessage: 'Please enter address',
  },
  address2: {
    id: `${scope}.address2`,
    defaultMessage: 'Address 2',
  },
  address2RequiredMsg: {
    id: `${scope}.address2RequiredMsg`,
    defaultMessage: 'Please enter valid address 2',
  },
  address3: {
    id: `${scope}.address3`,
    defaultMessage: 'Address 3',
  },
  address3RequiredMsg: {
    id: `${scope}.address3RequiredMsg`,
    defaultMessage: 'Please enter valid address 3',
  },
  city: {
    id: `${scope}.city`,
    defaultMessage: 'City',
  },
  cityRequiredMsg: {
    id: `${scope}.cityRequiredMsg`,
    defaultMessage: 'Please enter city',
  },
  country: {
    id: `${scope}.country`,
    defaultMessage: 'Country',
  },
  countryRequiredMsg: {
    id: `${scope}.countryRequiredMsg`,
    defaultMessage: 'Please enter country',
  },
  postcode: {
    id: `${scope}.postcode`,
    defaultMessage: 'Postal Code',
  },
  postcodeRequiredMsg: {
    id: `${scope}.postcodeRequiredMsg`,
    defaultMessage: 'Please enter valid postal code',
  },
  email: {
    id: `${scope}.email`,
    defaultMessage: 'Email',
  },
  emailIdRequiredMsg: {
    id: `${scope}.emailIdRequiredMsg`,
    defaultMessage: 'Please enter valid email',
  },
  phoneNumber: {
    id: `${scope}.phoneNumber`,
    defaultMessage: 'Phone',
  },
  phoneNumberRequiredMsg: {
    id: `${scope}.phoneNumberRequiredMsg`,
    defaultMessage: 'Please enter valid phone',
  },
  newsLetter: {
    id: `${scope}.newsLetter`,
    defaultMessage:
      'I would like to stay up-to-date with the latest news and special offers by subscribing to the user news letters.',
  },
});
