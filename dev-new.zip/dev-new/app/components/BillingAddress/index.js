/**
 *
 * BillingAddress
 *
 */

import React, { memo } from 'react';
import PropTypes from 'prop-types';
import {
  Row,
  Col,
  CustomInput,
  FormGroup,
  Input,
  Label,
  Form,
  FormFeedback,
  Button,
} from 'reactstrap';
import { FormattedMessage } from 'react-intl';
import messages from './messages';

import { setBillingDetailForm, getBillingDetailePostData } from './_helper';
import {
  getCountryName,
  getCountryOptions,
  validateForm,
} from '../PersonalDetails/_helper';
import DropDown from '../Dropdown';
import './index.scss';

function BillingAddress({
  billingDetailFrom,
  dUpdateBillingAddress,
  dToggleEditBillingDetailFlag,
  billingDetail,
  dSetBillingDetailForm,
  editBillingDetail,
  countryOptionsList,
  isRollExpiredEXT,
}) {
  const onHandleChage = el => {
    const formValue = { ...billingDetailFrom };
    formValue[el.target.name].value = el.target.value;

    if ({}.hasOwnProperty.call(formValue[el.target.name], 'isInvalid')) {
      formValue[el.target.name].isInvalid = false;
      if ({}.hasOwnProperty.call(formValue[el.target.name], 'regularExp')) {
        formValue[el.target.name].isInvalid = !formValue[
          el.target.name
        ].regularExp.test(formValue[el.target.name].value);
      } else if (formValue[el.target.name].value === '') {
        formValue[el.target.name].isInvalid = true;
      }
    }
    dSetBillingDetailForm(formValue);
  };
  const countrySelector = evt => {
    const formValue = { ...billingDetailFrom };
    if (evt.target.value === '') {
      formValue.subscriberCountryId.isInvalid = true;
    } else {
      formValue.subscriberCountryId.isInvalid = false;
    }
    formValue.subscriberCountryId.value = evt.target.value;
    dSetBillingDetailForm(formValue);
  };
  const resetForm = () => {
    const details = setBillingDetailForm(billingDetail);
    dSetBillingDetailForm(details);
    dToggleEditBillingDetailFlag(false);
  };
  const updateProfile = () => {
    const details = getBillingDetailePostData(billingDetail, billingDetailFrom);

    const checkForm = validateForm(billingDetailFrom);
    if (checkForm.isValid) {
      dUpdateBillingAddress(details);
    } else {
      dSetBillingDetailForm(checkForm.form);
    }
  };

  const onSubscribeNewsLetter = evt => {
    const formValue = { ...billingDetailFrom };
    formValue.isNewsLetter.value = evt.target.checked;
    dSetBillingDetailForm(formValue);
  };

  if (!billingDetailFrom || !billingDetailFrom.subscriberAddress1) {
    return <></>;
  }
  return (
    <>
      <Col>
        <Form autoComplete="off">
          <Row>
            <Col>
              <h4>
                <FormattedMessage {...messages.header} />
                {!isRollExpiredEXT && (
                  <Button
                    color="link"
                    onClick={() => dToggleEditBillingDetailFlag(true)}
                  >
                    <FormattedMessage {...messages.edit} />
                  </Button>
                )}
              </h4>
            </Col>
          </Row>
          <Row>
            <Col md={3} sm={12}>
              <Label
                for="subscriberAddress1"
                className={
                  editBillingDetail === true ? 'mandate' : 'profileLabel'
                }
              >
                <FormattedMessage {...messages.address1} />
              </Label>
              {!editBillingDetail && (
                <FormGroup>
                  <label>{billingDetailFrom.subscriberAddress1.value}</label>
                </FormGroup>
              )}
              {editBillingDetail && (
                <FormGroup>
                  <Input
                    type="text"
                    placeholder={messages.address1.defaultMessage}
                    value={billingDetailFrom.subscriberAddress1.value}
                    name="subscriberAddress1"
                    onChange={onHandleChage}
                    invalid={billingDetailFrom.subscriberAddress1.isInvalid}
                  />
                  {billingDetailFrom.subscriberAddress1.isInvalid && (
                    <FormFeedback>
                      <FormattedMessage {...messages.address1RequiredMsg} />
                    </FormFeedback>
                  )}
                </FormGroup>
              )}
            </Col>
            <Col md={3} sm={12}>
              <Label
                for="subscriberAddress2"
                className={editBillingDetail === true ? '' : 'profileLabel'}
              >
                <FormattedMessage {...messages.address2} />
              </Label>
              {!editBillingDetail && (
                <FormGroup>
                  <label>{billingDetailFrom.subscriberAddress2.value}</label>
                </FormGroup>
              )}
              {editBillingDetail && (
                <FormGroup>
                  <Input
                    type="text"
                    placeholder={messages.address2.defaultMessage}
                    value={billingDetailFrom.subscriberAddress2.value}
                    name="subscriberAddress2"
                    onChange={onHandleChage}
                  />
                  {billingDetailFrom.subscriberAddress2.isInvalid && (
                    <FormFeedback>
                      <FormattedMessage {...messages.address2RequiredMsg} />
                    </FormFeedback>
                  )}
                </FormGroup>
              )}
            </Col>
            <Col md={3} sm={12}>
              <Label
                for="subscriberAddress3"
                className={editBillingDetail === true ? '' : 'profileLabel'}
              >
                <FormattedMessage {...messages.address3} />
              </Label>
              {!editBillingDetail && (
                <FormGroup>
                  <label>{billingDetailFrom.subscriberAddress3.value}</label>
                </FormGroup>
              )}
              {editBillingDetail && (
                <FormGroup>
                  <Input
                    type="text"
                    placeholder={messages.address3.defaultMessage}
                    value={billingDetailFrom.subscriberAddress3.value}
                    name="subscriberAddress3"
                    onChange={onHandleChage}
                  />
                  {billingDetailFrom.subscriberAddress3.isInvalid && (
                    <FormFeedback>
                      <FormattedMessage {...messages.address3RequiredMsg} />
                    </FormFeedback>
                  )}
                </FormGroup>
              )}
            </Col>

            <Col md={3} sm={12}>
              <Label
                for="subscriberCity"
                className={
                  editBillingDetail === true ? 'mandate' : 'profileLabel'
                }
              >
                <FormattedMessage {...messages.city} />
              </Label>
              {!editBillingDetail && (
                <FormGroup>
                  <label>{billingDetailFrom.subscriberCity.value}</label>
                </FormGroup>
              )}
              {editBillingDetail && (
                <FormGroup>
                  <Input
                    type="text"
                    placeholder={messages.city.defaultMessage}
                    value={billingDetailFrom.subscriberCity.value}
                    name="subscriberCity"
                    onChange={onHandleChage}
                    invalid={billingDetailFrom.subscriberCity.isInvalid}
                  />
                  {billingDetailFrom.subscriberCity.isInvalid && (
                    <FormFeedback>
                      <FormattedMessage {...messages.cityRequiredMsg} />
                    </FormFeedback>
                  )}
                </FormGroup>
              )}
            </Col>

            <Col md={3} sm={12}>
              <Label
                for="country"
                className={
                  editBillingDetail === true ? 'mandate' : 'profileLabel'
                }
              >
                <FormattedMessage {...messages.country} />
              </Label>
              {!editBillingDetail && (
                <FormGroup>
                  <label>
                    {getCountryName(
                      billingDetailFrom.subscriberCountryId.value,
                      countryOptionsList,
                    )}
                  </label>
                </FormGroup>
              )}
              {editBillingDetail && (
                <FormGroup>
                  <DropDown
                    options={getCountryOptions(countryOptionsList)}
                    onChange={evt => countrySelector(evt)}
                    selected={billingDetailFrom.subscriberCountryId.value}
                    invalid={billingDetailFrom.subscriberCountryId.isInvalid}
                  />

                  {billingDetailFrom.subscriberCountryId.isInvalid && (
                    <FormFeedback>
                      <FormattedMessage {...messages.countryRequiredMsg} />
                    </FormFeedback>
                  )}
                </FormGroup>
              )}
            </Col>

            <Col md={3} sm={12}>
              <Label
                for="subscriberPostcode"
                className={
                  editBillingDetail === true ? 'mandate' : 'profileLabel'
                }
              >
                <FormattedMessage {...messages.postcode} />
              </Label>
              {!editBillingDetail && (
                <FormGroup>
                  <label>{billingDetailFrom.subscriberPostcode.value}</label>
                </FormGroup>
              )}
              {editBillingDetail && (
                <FormGroup>
                  <Input
                    type="text"
                    placeholder={messages.postcode.defaultMessage}
                    value={billingDetailFrom.subscriberPostcode.value}
                    name="subscriberPostcode"
                    invalid={billingDetailFrom.subscriberPostcode.isInvalid}
                    onChange={onHandleChage}
                    maxLength="30"
                  />
                  {billingDetailFrom.subscriberPostcode.isInvalid && (
                    <FormFeedback>
                      <FormattedMessage {...messages.postcodeRequiredMsg} />
                    </FormFeedback>
                  )}
                </FormGroup>
              )}
            </Col>
          </Row>
          <Row>
            <Col>
              {!editBillingDetail && (
                <CustomInput
                  type="checkbox"
                  disabled
                  label={messages.newsLetter.defaultMessage}
                  id="newsLetter"
                  checked={billingDetailFrom.isNewsLetter.value}
                />
              )}
              {editBillingDetail && (
                <CustomInput
                  type="checkbox"
                  label={messages.newsLetter.defaultMessage}
                  id="newsLetter"
                  checked={billingDetailFrom.isNewsLetter.value}
                  onClick={onSubscribeNewsLetter}
                />
              )}
            </Col>
          </Row>
          {editBillingDetail && (
            <Row>
              <Col className="text-right">
                <Button
                  color="primary"
                  className="mr-2"
                  onClick={updateProfile}
                >
                  <FormattedMessage {...messages.update} />
                </Button>
                <Button color="primary" outline onClick={resetForm}>
                  <FormattedMessage {...messages.cancel} />
                </Button>
              </Col>
            </Row>
          )}
        </Form>
      </Col>
    </>
  );
}

BillingAddress.propTypes = {
  billingDetailFrom: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  dUpdateBillingAddress: PropTypes.func,
  dToggleEditBillingDetailFlag: PropTypes.func,
  billingDetail: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  dSetBillingDetailForm: PropTypes.func,
  editBillingDetail: PropTypes.bool,
  countryOptionsList: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  isRollExpiredEXT: PropTypes.bool,
};

export default memo(BillingAddress);
