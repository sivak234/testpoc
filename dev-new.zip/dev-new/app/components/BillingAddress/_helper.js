/*
 *
 * BillingAddress helper
 *
 */

export function defaultFunction(text) {
  return text;
}

export function setBillingDetailForm(data) {
  return {
    subscriberAddress1: {
      value: data.subscriberAddress1,
      isInvalid: '',
      regularExp: /^([a-zA-Z0-9 -_@./#&+,]){3,100}$/,
    },
    subscriberAddress2: {
      value: data.subscriberAddress2,
      isInvalid: '',
      regularExp: /^([a-zA-Z0-9 -_@./#&+,]){0,100}$/,
    },
    subscriberAddress3: {
      value: data.subscriberAddress3,
      isInvalid: '',
      regularExp: /^([a-zA-Z0-9 -_@./#&+,]){0,100}$/,
    },
    subscriberCity: {
      value: data.subscriberCity,
      isInvalid: '',
      regularExp: /^([a-zA-Z0-9 _-]){3,32}$/,
    },
    subscriberCountryId: {
      value: data.subscriberCountryId,
      isInvalid: '',
      regularExp: /^([a-zA-Z0-9 _-]){1,32}$/,
    },
    subscriberPostcode: {
      value: data.subscriberPostcode,
      isInvalid: '',
      regularExp: /^([a-zA-Z0-9 _-]){3,32}$/,
    },

    isNewsLetter: {
      value: data.isNewsLetter ? data.isNewsLetter : false,
    },
  };
}

export const getBillingDetailePostData = (rawData, billingDetail) => ({
  subscriptionUserAddressDetailsId: rawData.subscriptionUserAddressDetailsId,
  subscriberAddress1: billingDetail.subscriberAddress1.value,
  subscriberAddress2: billingDetail.subscriberAddress2.value,
  subscriberAddress3: billingDetail.subscriberAddress3.value,
  subscriberCity: billingDetail.subscriberCity.value,
  subscriberCountryId: billingDetail.subscriberCountryId.value,
  subscriberPostcode: billingDetail.subscriberPostcode.value,
  isNewsLetter: billingDetail.isNewsLetter.value,
});
