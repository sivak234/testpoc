/*
 *
 * ApiListDetails helper
 *
 */

export function defaultFunction(text) {
  return text;
}

export const primaryProp = 'apiParameterDetailIDInfo';
export const fixedColumns = true;
export const changeHandler = () => {};

export const emptyRow = {
  apiName: '',
  baseAPIName: '',
  paramValue: '',
};

export function portHeader() {
  const header = [
    {
      title: 'Field Name',
      prop: 'field_field_name',
    },
    {
      title: 'Field Value',
      prop: 'field_field_value',
    },
    {
      title: 'Field Type',
      prop: 'field_field_type',
    },
    {
      title: 'Field Description',
      prop: 'field_field_description',
    },
  ];

  return header;
}
