/*
 * ApiListDetails Messages
 *
 * This contains all the text for the ApiListDetails component.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.components.ApiListDetails';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'This is the ApiListDetails component!',
  },
  back: {
    id: `${scope}.back`,
    defaultMessage: '<< Back',
  },
  apiServices: {
    id: `${scope}.apiServices`,
    defaultMessage: 'API SERVICES',
  },
  apiList: {
    id: `${scope}.apiList`,
    defaultMessage: 'API List',
  },
  description: {
    id: `${scope}.description`,
    defaultMessage: 'Description',
  },
  ptbInfo: {
    id: `${scope}.ptbInfo`,
    defaultMessage: 'This provides the complete port terminal and Berth info',
  },
  endUrl: {
    id: `${scope}.endUrl`,
    defaultMessage: 'End Point URL',
  },
  parameters: {
    id: `${scope}.parameters`,
    defaultMessage: 'Parameters',
  },
  jsonPortData: {
    id: `${scope}.jsonPortData`,
    defaultMessage: 'Json Port Data Sample',
  },
});
