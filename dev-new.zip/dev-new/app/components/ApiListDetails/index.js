/**
 *
 * ApiListDetails
 *
 */

import React, { memo, useState } from 'react';
import {
  Row,
  Col,
  Card,
  Input,
  CardImg,
  Badge,
  Button,
  Collapse,
  Navbar,
} from 'reactstrap';
import { FormattedMessage } from 'react-intl';
import PropTypes from 'prop-types';
import { Link } from 'react-router-dom';
import messages from './messages';
import { portHeader, primaryProp, emptyRow, fixedColumns } from './_helper';
import './index.scss';
import DataTableList from '../DataTableList/Loadable';
import { FETCH_RECORD_COUNT } from '../../utils/constants';

function ApiListDetails({
  apiData,
  dmoreButtonTriggered,
  dfetchApiListNid,
  dbackButtonTriggered,
}) {
  const pageDetails = {
    pageNo: 1,
    FETCH_RECORD_COUNT,
  };
  const back = () => {
    dbackButtonTriggered(false);
  };
  const [collapsed, setCollapsed] = useState(true);
  const toggleNavbar = () => setCollapsed(!collapsed);
  const moreTriggered = event => {
    const nid = event.target.id;
    const portData = event.target.text;
    dmoreButtonTriggered(true, nid, portData, pageDetails);
    dfetchApiListNid();
  };
  const dropdownData =
    apiData.apiListNidData.length >= 1 ? apiData.apiListNidData[0].view : [];
  let jsonData = '';
  if (apiData.apiListNidData.length >= 1) {
    const jsonVal = apiData.apiListNidData[0].field_json_sample.replace(
      /&quot;/g,
      '"',
    );
    jsonData = jsonVal.replace(/<\/?br[^<]*>/g, '');
  }
  const header = portHeader(dropdownData);
  const apiListHeight =
    apiData &&
    apiData.apiListNidData[0] &&
    apiData.apiListNidData[0].view &&
    apiData.apiListNidData[0].view.length;
  return (
    <>
      <Row className="Api_Container">
        <Col xs={8} md={10}>
          <h1 className="title-bg-blue">
            <FormattedMessage {...messages.apiServices} />
          </h1>
        </Col>
        <Col xs={4} md={2}>
          <Button
            onClick={back}
            color="link"
            style={{ color: '#fff', fontSize: '14px' }}
          >
            <FormattedMessage {...messages.back} />
          </Button>
        </Col>
      </Row>
      <div className="ApiListContainer ApiList_Detail_MarginTop">
        {apiData.apiListNidData.length >= 1 && (
          <>
            <Row>
              <Col xs={12} md={3} className="d-md-none d-xs-block">
                <Navbar
                  color="faded"
                  light
                  onClick={toggleNavbar}
                  className="Arrow_Icon"
                >
                  <Input type="text" value={apiData.portData} />

                  <Collapse
                    isOpen={!collapsed}
                    navbar
                    className="Api_Navbar_items"
                  >
                    {apiData.apiListNidData[0].view_1.map(item => (
                      <>
                        {item.view.map(detail => (
                          <ul className="detailSection">
                            <li>
                              <Badge
                                href="#"
                                onClick={e => {
                                  moreTriggered(e);
                                }}
                                id={detail.nid}
                                color="white"
                                style={{ color: '#000' }}
                              >
                                {detail.field_id} | {detail.title}
                              </Badge>
                            </li>
                          </ul>
                        ))}
                      </>
                    ))}
                  </Collapse>
                </Navbar>
              </Col>
              <Col xs={12} md={3} className="d-none d-lg-block">
                <ul className="mainHeader">
                  <li>
                    <FormattedMessage {...messages.apiList} />
                  </li>
                </ul>
                {apiData.apiListNidData[0].view_1.map(item => (
                  <>
                    <ul
                      className="headerSection"
                      style={{ backgroundColor: item.field_background_color }}
                    >
                      <li>{item.name}</li>
                    </ul>
                    {item.view.map(detail => (
                      <ul className="detailSection">
                        <li>
                          <Link
                            to="/api-service-details"
                            onClick={e => {
                              moreTriggered(e);
                            }}
                            id={detail.nid}
                            color="white"
                            style={{ color: '#000' }}
                          >
                            {detail.field_id} | {detail.title}
                          </Link>
                        </li>
                      </ul>
                    ))}
                  </>
                ))}
              </Col>
              <Col xs={12} md={9}>
                <Row
                  className="headerDesc"
                  style={{
                    backgroundColor:
                      apiData.apiListNidData[0].view_2[0]
                        .field_background_color,
                  }}
                >
                  <Col xs={6} md={2}>
                    <Card
                      style={{ width: '95px', height: '95px', float: 'right' }}
                    >
                      <CardImg
                        style={{
                          backgroundColor:
                            apiData.apiListNidData[0].view_2[0]
                              .field_background_color,
                        }}
                        src={apiData.apiListNidData[0].field_api_icon}
                        alt="Card image cap"
                      />
                    </Card>
                  </Col>
                  <Col xs={6} md={10}>
                    <h2>{apiData.apiListNidData[0].field_id}</h2>
                    <p style={{ fontSize: '18px' }}>
                      {apiData.apiListNidData[0].field_port_model}
                    </p>
                  </Col>
                </Row>
                <Row>
                  <Col xs={12} md={12} className="ApiList_Detail_Desc">
                    <p style={{ display: 'flex' }}>
                      <b>
                        <FormattedMessage {...messages.description} />
                      </b>
                      :<span style={{ marginLeft: '3px' }}> </span>{' '}
                      {React.createElement('span', {
                        dangerouslySetInnerHTML: {
                          __html: apiData.apiListNidData[0].field_description,
                        },
                      })}
                    </p>
                  </Col>
                  <Col xs={12} md={12} className="ApiList_Detail_Desc">
                    <p>
                      <b>
                        <FormattedMessage {...messages.endUrl} />:
                      </b>{' '}
                      {apiData.apiListNidData[0].field_end_point_url}
                    </p>
                  </Col>
                  <Col xs={12} md={12} className="ApiList_Detail_Desc">
                    <h3>
                      <FormattedMessage {...messages.parameters} />
                    </h3>
                  </Col>
                  <Col xs={12} md={12}>
                    <div
                      className={
                        apiListHeight > 4 ? 'apiList heightapiList' : 'apiList'
                      }
                    >
                      <DataTableList
                        primaryProp={primaryProp}
                        tableBody={apiData.apiListNidData[0].view}
                        rowsPerPage={apiData.apiListNidData[0].view.length}
                        emptyRow={emptyRow}
                        fixedColumn={fixedColumns}
                        moduleId={42}
                        tableHeader={header}
                        fetchTableData={dmoreButtonTriggered}
                      />
                    </div>
                  </Col>
                  <Col xs={12} md={12} className="ApiList_Detail_Desc">
                    <h3>
                      <FormattedMessage {...messages.jsonPortData} />
                    </h3>
                  </Col>
                  <Col xs={12} md={12}>
                    {apiData.apiListNidData.length >= 1 && (
                      <>
                        {apiData.apiListNidData[0].field_json_sample && (
                          <Input
                            type="textarea"
                            name="text"
                            id="jsonText"
                            value={jsonData}
                            rows={10}
                            placeholder="placeholder"
                          />
                        )}
                      </>
                    )}
                  </Col>
                  <Col
                    xs={12}
                    md={12}
                    className="ApiList_Detail_Desc Comments_Section"
                  >
                    {React.createElement('div', {
                      dangerouslySetInnerHTML: {
                        __html: apiData.apiListNidData[0].field_comments,
                      },
                    })}
                  </Col>
                </Row>
              </Col>
            </Row>
          </>
        )}
      </div>
    </>
  );
}

ApiListDetails.propTypes = {
  apiData: PropTypes.object.isRequired,
  dmoreButtonTriggered: PropTypes.func.isRequired,
  dbackButtonTriggered: PropTypes.func.isRequired,
  dfetchApiListNid: PropTypes.func.isRequired,
};

export default memo(ApiListDetails);
