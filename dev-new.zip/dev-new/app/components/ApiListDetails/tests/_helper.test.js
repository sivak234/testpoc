// import { defaultFunction } from '../_helper';

// describe('ApiListDetails helpers', () => {
//   describe('Default Helper Function', () => {
//     it('returns the expected value', () => {
//       const expected = 'Sample Text';
//       expect(defaultFunction('Sample Text')).toEqual(expected);
//     });
//   });
// });
describe('<ApiListDetails />', () => {
  it('Expect to not log errors in ApiListDetails', () => {
    expect(true).toBeTruthy();
  });
});
