/**
 *
 * Asynchronously loads the component for CargoHandledComponent
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
