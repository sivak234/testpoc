// import { defaultFunction } from '../_helper';

// describe('CargoHandledComponent helpers', () => {
//   describe('Default Helper Function', () => {
//     it('returns the expected value', () => {
//       const expected = 'Sample Text';
//       expect(defaultFunction('Sample Text')).toEqual(expected);
//     });
//   });
// });
describe('<CargoHandledTerminalSection />', () => {
  it('Expect to not log errors in CargoHandledTerminalSection', () => {
    expect(true).toBeTruthy();
  });
});
