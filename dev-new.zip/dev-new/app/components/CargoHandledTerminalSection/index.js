/**
 *
 * CargoHandledComponent
 *
 */

import React from 'react';
import PropTypes from 'prop-types';

import { FormattedMessage } from 'react-intl';
import { Table, Col, Row } from 'reactstrap';
import messages from './messages';

import './_helper';

function CargoHandledTerminalSection({ data, passedRef }) {
  const cargoHandleData = [];
  try {
    if (data) {
      if (data && data.length > 0) {
        data.map(item => {
          const productHandles =
            item.productHandles && item.productHandles.length !== 0
              ? item.productHandles.map(x => x.cargoProduct).join(', ')
              : '';
          cargoHandleData.push(
            <tr key={item[0]}>
              <td>{item.cargoType}</td>
              <td>{productHandles}</td>
            </tr>,
          );
          return cargoHandleData;
        });
      } else {
        cargoHandleData.push(
          <tr key="some-key">
            <td>--</td>
            <td>--</td>
          </tr>,
        );
      }
    }
  } catch (e) {
    // console.log(e.messages);
  }

  return (
    <>
      <Row className="port_overview_row_cls">
        <Col className="port-dashboard-section-header-port pt-1">
          <a href name="cargo-handled" className="part">
            <h4 className="mb-0" ref={passedRef}>
              <FormattedMessage {...messages.header} />
            </h4>
          </a>
        </Col>
      </Row>

      <Row
        className="port_overview_row_cls"
        style={{ width: '100%', overflow: 'auto' }}
      >
        <Col>
          <Table className="table">
            <thead className="table-head">
              <tr>
                <th width="33.33%">
                  <FormattedMessage {...messages.cargoType} />
                </th>
                <th width="73.33%">
                  <FormattedMessage {...messages.productHandles} />
                </th>
              </tr>
            </thead>
            <tbody>{cargoHandleData}</tbody>
          </Table>
        </Col>
      </Row>
    </>
  );
}

CargoHandledTerminalSection.propTypes = {
  data: PropTypes.object,
  passedRef: PropTypes.func,
};

export default CargoHandledTerminalSection;
