/*
 * CargoHandledComponent Messages
 *
 * This contains all the text for the CargoHandledComponent component.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.components.CargoHandledComponent';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'Cargo Handled',
  },
  cargoType: {
    id: `${scope}.header`,
    defaultMessage: 'Cargo Types',
  },
  productHandles: {
    id: `${scope}.productHandles`,
    defaultMessage: 'Commodities',
  },
});
