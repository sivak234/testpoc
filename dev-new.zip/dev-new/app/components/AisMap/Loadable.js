/**
 *
 * Asynchronously loads the component for AisMap
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
