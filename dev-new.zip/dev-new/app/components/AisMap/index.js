/* eslint-disable func-names */
/**
 *
 * AisMap
 *
 */

import React, { memo } from 'react';
import L from 'leaflet';
import 'leaflet.gridlayer.googlemutant/Leaflet.GoogleMutant';
import 'leaflet-fullscreen';
import 'leaflet.markercluster';
import PropTypes from 'prop-types';
import { dateTimeConversion } from '../../utils/dataModification';
import {
  DEFAULT_ZOOM_LEVEL,
  DISABLE_CLUSTER_ZOOM_LEVEL,
  AIS_LANDING_ZOOM_COORDINATES,
  AIS_LANDING_ZOOM_LEVEL,
  PORTMOVEMENT_ZOOM_LEVEL,
} from '../../utils/constants';
function AisMap({
  vesselMapData,
  portMapData,
  mapScreenView,
  vesselDetails,
  vesselsNearestData,
  portChecked,
  portMovementMapData,
  terminalChecked,
  berthChecked,
  mapRefresh,
  countryName,
  aisLandingScreenCenterPosition,
  aisLandingPortSelectedZoomLevel,
}) {
  const mapRef = React.useRef(null);
  let latlanText = React.useRef(null);
  const clusterLayerGroupRef = React.useRef(null);
  const clusterLayerGroupRefOne = React.useRef(null);
  const portPolygonRef = React.useRef(null);
  const terminalPolygonRef = React.useRef(null);
  const berthPolygonRef = React.useRef(null);
  const layerMarkersAroundRef = React.useRef(null);
  const vesselMarkersRef = React.useRef(null);
  const layerMarkerRef = React.useRef(null);
  // eslint-disable-next-line no-multi-assign
  const google = (window.google = window.google ? window.google : {});
  React.useEffect(() => {
    const container = L.DomUtil.get('map');
    if (container != null) {
      // eslint-disable-next-line no-underscore-dangle
      container._leaflet_id = null;
    }
    mapRef.current = L.map('map', {
      maxZoom: 22,
      zoomControl: true,
      fullscreenControl: {
        position: 'topright',
        pseudoFullscreen: false,
      },
    }).setView(AIS_LANDING_ZOOM_COORDINATES, AIS_LANDING_ZOOM_LEVEL);
    mapRef.current.options.minZoom = 2;
    mapRef.current.zoomControl.setPosition('bottomright');
    const roadMutant = L.gridLayer
      .googleMutant({
        type: 'roadmap',
      })
      .addTo(mapRef.current);

    const satMutant = L.gridLayer.googleMutant({
      type: 'satellite',
    });

    L.control
      .layers(
        {
          Roadmap: roadMutant,
          Satellite: satMutant,
        },
        {},
        {
          collapsed: true,
        },
      )
      .addTo(mapRef.current);
    mapRef.current.on('baselayerchange', e => {
      let element = null;
      if (e.name === 'Roadmap') {
        element = [document.getElementsByClassName('latlan-text-satellite')[0]];
      } else {
        element = [document.getElementsByClassName('latlan-text-roadmap')[0]];
      }
      if (element && element.length >= 0 && e.name === 'Roadmap') {
        element[0].classList.remove('latlan-text-satellite');
        element[0].classList.add('latlan-text-roadmap');
      } else if (element && element.length >= 0) {
        element[0].classList.remove('latlan-text-roadmap');
        element[0].classList.add('latlan-text-satellite');
      }
    });
    latlanText = L.control({
      position: 'topleft',
    });

    latlanText.onAdd = function add() {
      this.div = L.DomUtil.create('div', 'latlan-text-roadmap');
      const imgLog = `<div id='lanLat'></div>`;
      this.div.innerHTML = imgLog;
      this.update();
      return this.div;
    };
    latlanText.update = function update(ev) {
      if (ev !== undefined) {
        const dmsCoords = ddToDms(ev.latlng.lat, ev.latlng.lng);
        this.div.innerHTML = `<div id='lanLat'>${dmsCoords}<br/>
        (${ev.latlng.lat.toFixed(4)}, ${ev.latlng.lng.toFixed(4)})</div>`;
      }
    };
    latlanText.addTo(mapRef.current);
    mapRef.current.on('mousemove', function onmapmovuseover(ev) {
      latlanText.update(ev);
    });
  }, []);
  React.useEffect(() => {
    clusterLayerGroupRef.current = L.markerClusterGroup({
      spiderfyOnMaxZoom: false,
      disableClusteringAtZoom: DISABLE_CLUSTER_ZOOM_LEVEL,
    }).addTo(mapRef.current);
    clusterLayerGroupRefOne.current = L.markerClusterGroup({
      spiderfyOnMaxZoom: false,
      disableClusteringAtZoom: DISABLE_CLUSTER_ZOOM_LEVEL,
    }).addTo(mapRef.current);
  }, []);

  React.useEffect(() => {
    if (mapScreenView === 'AISLandingScreenMap') {
      if (portChecked && portMapData !== undefined && portMapData.length > 0) {
        if (clusterLayerGroupRef.current !== null) {
          clusterLayerGroupRef.current.clearLayers();
          mapRef.current.removeLayer(clusterLayerGroupRef.current);
          mapRef.current.removeLayer(clusterLayerGroupRefOne.current);
        }
        if (layerMarkerRef.current !== null) {
          mapRef.current.removeLayer(layerMarkerRef.current);
        }
        layerMarkerRef.current = L.layerGroup(portMapData);
        layerMarkerRef.current.addTo(mapRef.current);
      } else if (layerMarkerRef.current !== null) {
        layerMarkerRef.current.clearLayers();
      }
      if (
        !portChecked &&
        vesselMapData !== undefined &&
        vesselMapData.length > 0
      ) {
        if (clusterLayerGroupRef.current !== null) {
          clusterLayerGroupRef.current.clearLayers();
          mapRef.current.removeLayer(clusterLayerGroupRef.current);
          mapRef.current.removeLayer(clusterLayerGroupRefOne.current);
        }
        clusterLayerGroupRef.current.addLayers(vesselMapData);
        mapRef.current.addLayer(clusterLayerGroupRef.current);
        mapRef.current.setView(
          aisLandingScreenCenterPosition,
          aisLandingPortSelectedZoomLevel,
        );
      } else if (clusterLayerGroupRef.current !== null) {
        mapRef.current.setView(
          aisLandingScreenCenterPosition,
          aisLandingPortSelectedZoomLevel,
        );
        clusterLayerGroupRef.current.clearLayers();
        mapRef.current.removeLayer(clusterLayerGroupRef.current);
        mapRef.current.removeLayer(clusterLayerGroupRefOne.current);
      }
    }
  }, [mapRefresh]);

  React.useEffect(() => {
    let pt = {};
    if (layerMarkersAroundRef.current !== null) {
      mapRef.current.removeLayer(layerMarkersAroundRef.current);
    }
    if (vesselMarkersRef.current !== null) {
      mapRef.current.removeLayer(vesselMarkersRef.current);
    }
    if (mapScreenView === 'AISVesselMovementMap') {
      if (vesselDetails !== undefined) {
        const vessel = vesselDetails;
        if (vessel && vessel.vesselLatLng) {
          let cssClass = `vessel-icon-tug`;
          if (vessel.vesselType !== undefined)
            cssClass = `vessel-icon-${vessel.vesselType
              .toLowerCase()
              .replace(/\s/g, '')}`;

          if (
            vessel.vesselLoadCondition &&
            vessel.vesselLoadCondition === 'Ballast'
          ) {
            cssClass = `${cssClass}-${vessel.vesselLoadCondition.toLowerCase()}`;
          }
          const markerPosition = [
            parseFloat(JSON.parse(vessel.vesselLatLng).coordinates[1]),
            parseFloat(JSON.parse(vessel.vesselLatLng).coordinates[0]),
          ];
          const divIcon = L.divIcon({
            className: 'my-div-icon',
            html: `<div class="vessel-border-dottedred" ><p   class="${cssClass}"
          style="-webkit-transform:
          rotate(${vessel.vesselHeading}deg);
          -moz-transform:rotate(${vessel.vesselHeading}deg);"></p></div>`,
            iconSize: [20, 20],
          });
          vesselMarkersRef.current = L.marker(markerPosition, {
            icon: divIcon,
          })
            .addTo(mapRef.current)
            .bindPopup();
          pt = new L.LatLng(
            parseFloat(JSON.parse(vessel.vesselLatLng).coordinates[1]),
            parseFloat(JSON.parse(vessel.vesselLatLng).coordinates[0]),
          );
          mapRef.current.setView(pt, 11);
          vesselMarkersRef.current.on('mouseover', function onmouseover() {
            // eslint-disable-next-line no-underscore-dangle
            vesselMarkersRef.current._popup.setContent(`<div id="mapOverPStyle">
                  <p className="pStyle">
                  IMO<span> : </span>  ${vessel.imo}</p>
                  <p className="pStyle">
                  Name<span> : </span>  ${vessel.vesselName}</p>
                <p className="pStyle">
                  Vessel Type<span> : </span> ${vessel.vesselType} </p>
                <p className="pStyle">
                  Vessel Heading<span> : </span> ${vessel.vesselHeading} </p>
                  <p className="pStyle">
                  Port Name<span> : </span> ${vessel.nextPortName} </p>
                <p className="pStyle">
                <p className="pStyle">
                Load Condition<span> :
                </span> ${vessel.vesselLoadCondition} </p>
                  <p className="pStyle">
                  Course<span> : </span> ${vessel.vesselCourse} </p>
                <p className="pStyle">
                  Vessel Speed<span> : </span> ${vessel.vesselSpeed} </p>
                  <p className="pStyle">
                Last Received<span> : </span>
                ${dateTimeConversion(vessel.recordedDate)} </p>
            </div>`);
            vesselMarkersRef.current.openPopup();
          });

          vesselMarkersRef.current.on('mouseout', function onmouseout() {
            vesselMarkersRef.current.closePopup();
          });
          layerMarkersAroundRef.current = L.layerGroup(vesselsNearestData);
          layerMarkersAroundRef.current.addTo(mapRef.current);
        }
      }
      if (portChecked && portMapData && portMapData.length > 0) {
        mapRef.current.setView(pt, 2);

        if (layerMarkerRef.current !== null) {
          mapRef.current.removeLayer(layerMarkerRef.current);
        }

        layerMarkerRef.current = L.layerGroup(portMapData);
        layerMarkerRef.current.addTo(mapRef.current);
      } else if (layerMarkerRef.current !== null) {
        mapRef.current.removeLayer(layerMarkerRef.current);
      }
    }
  }, [mapRefresh]);

  React.useEffect(() => {
    if (mapScreenView === 'AISPortMovementMap') {
      const vesselMarkerList =
        portMovementMapData && portMovementMapData.vesselMarkerList
          ? portMovementMapData.vesselMarkerList
          : [];
      const portPolygon =
        portMovementMapData && portMovementMapData.portPolygon
          ? portMovementMapData.portPolygon
          : null;
      const terminalPolygon =
        portMovementMapData && portMovementMapData.terminalPolygon
          ? portMovementMapData.terminalPolygon
          : null;
      const berthPolygon =
        portMovementMapData && portMovementMapData.berthPolygon
          ? portMovementMapData.berthPolygon
          : null;

      if (
        portPolygon &&
        portPolygon.length > 0 &&
        portPolygon[0].polygonArr.length > 0
      ) {
        const pt = new L.LatLng(
          parseFloat(portPolygon[0].lat),
          parseFloat(portPolygon[0].lng),
        );
        mapRef.current.setView(pt, PORTMOVEMENT_ZOOM_LEVEL);
        if (portPolygonRef.current !== null) {
          mapRef.current.removeLayer(portPolygonRef.current);
        }
        portPolygonRef.current = L.layerGroup(portPolygon[0].polygonArr);
        portPolygonRef.current.addTo(mapRef.current);
      } else if (portPolygonRef.current !== null) {
        mapRef.current.removeLayer(portPolygonRef.current);
        const geocoder = new google.maps.Geocoder();
        geocoder.geocode({ address: countryName }, function(results, status) {
          if (status === google.maps.GeocoderStatus.OK) {
            const pt = new L.LatLng(
              results[0].geometry.location.lat(),
              results[0].geometry.location.lng(),
            );
            mapRef.current.setView(pt, DEFAULT_ZOOM_LEVEL);
          }
        });
      }
      if (
        vesselMarkerList !== null &&
        vesselMarkerList !== undefined &&
        vesselMarkerList.length > 0
      ) {
        if (layerMarkerRef.current !== null) {
          mapRef.current.removeLayer(layerMarkerRef.current);
        }
        layerMarkerRef.current = L.layerGroup(vesselMarkerList);
        layerMarkerRef.current.addTo(mapRef.current);
      } else if (layerMarkerRef.current !== null) {
        mapRef.current.removeLayer(layerMarkerRef.current);
      }
      if (
        terminalPolygon !== undefined &&
        terminalPolygon !== null &&
        terminalPolygon.length > 0 &&
        vesselMarkerList.length > 0 &&
        terminalChecked
      ) {
        terminalPolygonRef.current = L.layerGroup(terminalPolygon);
        terminalPolygonRef.current.addTo(mapRef.current);
        const pt = new L.LatLng(
          parseFloat(portPolygon[0].lat),
          parseFloat(portPolygon[0].lng),
        );
        mapRef.current.setView(pt, 12);
      } else if (
        terminalPolygonRef.current !== null &&
        vesselMarkerList.length === 0
      ) {
        mapRef.current.removeLayer(terminalPolygonRef.current);
        const geocoder = new google.maps.Geocoder();
        geocoder.geocode({ address: countryName }, function(results, status) {
          if (status === google.maps.GeocoderStatus.OK) {
            const pt = new L.LatLng(
              results[0].geometry.location.lat(),
              results[0].geometry.location.lng(),
            );
            mapRef.current.setView(pt, DEFAULT_ZOOM_LEVEL);
          }
        });
      }

      if (
        berthPolygon !== undefined &&
        berthPolygon !== null &&
        berthPolygon.length > 0 &&
        berthChecked
      ) {
        berthPolygonRef.current = L.layerGroup(berthPolygon);
        berthPolygonRef.current.addTo(mapRef.current);
        const pt = new L.LatLng(
          parseFloat(portPolygon[0].lat),
          parseFloat(portPolygon[0].lng),
        );
        mapRef.current.setView(pt, 14);
      } else if (
        berthPolygonRef.current !== null &&
        vesselMarkerList.length === 0
      ) {
        mapRef.current.removeLayer(berthPolygonRef.current);
        const geocoder = new google.maps.Geocoder();
        geocoder.geocode({ address: countryName }, function(results, status) {
          if (status === google.maps.GeocoderStatus.OK) {
            const pt = new L.LatLng(
              results[0].geometry.location.lat(),
              results[0].geometry.location.lng(),
            );
            mapRef.current.setView(pt, DEFAULT_ZOOM_LEVEL);
          }
        });
      }
    }
  }, [mapRefresh]);

  function ddToDms(lt, lg) {
    let lat = lt;
    let lng = lg;
    let latResult;
    let lngResult;
    let dmsResult = '';
    lat = parseFloat(lat);
    lng = parseFloat(lng);
    latResult = lat >= 0 ? 'N' : 'S';
    // Call to getDms(lat) function for the coordinates of Latitude in DMS.
    // The result is stored in latResult letiable.
    latResult += getDms(lat);
    lngResult = lng >= 0 ? 'E' : 'W';
    // Call to getDms(lng) function for the coordinates of Longitude in DMS.
    // The result is stored in lngResult letiable.
    lngResult += getDms(lng);
    // Joining both letiables and separate them with a space.
    dmsResult = `${latResult}'</br>'${lngResult}`;
    // Return the resultant string
    return dmsResult;
  }

  function getDms(val) {
    let valDeg = '';
    let valMin = '';
    let valSec = '';
    let result = '';
    valDeg = Math.floor(Math.abs(val));
    result = `${valDeg}º`;
    valMin = Math.floor((Math.abs(val) - valDeg) * 60);
    result += `${valMin}'`;
    valSec =
      Math.round((Math.abs(val) - valDeg - valMin / 60) * 3600 * 1000) / 1000;
    result += `${valSec}"`;
    return result;
  }
  return (
    <>
      <div
        id="map"
        style={{
          height: '390px',
          width: '100%',
          zIndex: 4,
        }}
      />{' '}
    </>
  );
}

AisMap.propTypes = {
  vesselMapData: PropTypes.array,
  portMapData: PropTypes.array,
  mapScreenView: PropTypes.string,
  vesselDetails: PropTypes.object,
  portChecked: PropTypes.bool,
  vesselsNearestData: PropTypes.array,
  portMovementMapData: PropTypes.array,
  terminalChecked: PropTypes.bool,
  berthChecked: PropTypes.bool,
  mapRefresh: PropTypes.bool,
  countryName: PropTypes.string,
  aisLandingScreenCenterPosition: PropTypes.string,
  aisLandingPortSelectedZoomLevel: PropTypes.string,
};

export default memo(AisMap);
