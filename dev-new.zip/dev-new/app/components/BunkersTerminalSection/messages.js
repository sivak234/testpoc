/*
 * BunkersComponent Messages
 *
 * This contains all the text for the BunkersComponent component.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.components.BunkersComponent';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'Bunkers',
  },
  fuelsHandled: {
    id: `${scope}.fuelsHandled`,
    defaultMessage: 'Fuels Handled',
  },
  supplyTypeforEachBunkes: {
    id: `${scope}.supplyTypeforEachBunkes`,
    defaultMessage: 'Supply Type for Each Bunkes',
  },
  notes: {
    id: `${scope}.notes`,
    defaultMessage: 'Notes',
  },
});
