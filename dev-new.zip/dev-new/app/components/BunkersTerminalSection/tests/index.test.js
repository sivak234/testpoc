// /**
//  *
//  * Tests for BunkersComponent
//  *
//  * @see https://github.com/react-boilerplate/react-boilerplate/tree/master/docs/testing
//  *
//  */

// import React from 'react';
// import ReactDOM from 'react-dom';
// // import { render } from 'react-testing-library';
// // import { IntlProvider } from 'react-intl';
// // import 'jest-dom/extend-expect'; // add some helpful assertions

// import BunkersComponent from '../index';
// // import { DEFAULT_LOCALE } from '../../../i18n';

// describe('<BunkersComponent />', () => {
//   it('Expect to not log errors in BunkersComponent', () => {
//     const div = document.createElement('div');
//     ReactDOM.render(<BunkersComponent />, div);
//   });
//   // it('Expect to not log errors in console', () => {
//   //   const spy = jest.spyOn(global.console, 'error');
//   //   render(
//   //     <IntlProvider locale={DEFAULT_LOCALE}>
//   //       <BunkersComponent />
//   //     </IntlProvider>,
//   //   );
//   //   expect(spy).not.toHaveBeenCalled();
//   // });

//   // it('Expect to have additional unit tests specified', () => {
//   //   expect(true).toEqual(true);
//   // });

//   // /**
//   //  * Unskip this test to use it
//   //  *
//   //  * @see {@link https://jestjs.io/docs/en/api#testskipname-fn}
//   //  */
//   // it.skip('Should render and match the snapshot', () => {
//   //   const {
//   //     container: { firstChild },
//   //   } = render(
//   //     <IntlProvider locale={DEFAULT_LOCALE}>
//   //       <BunkersComponent />
//   //     </IntlProvider>,
//   //   );
//   //   expect(firstChild).toMatchSnapshot();
//   // });
// });

describe('<BunkersTerminalSection />', () => {
  it('Expect to not log errors in BunkersTerminalSection', () => {
    expect(true).toBeTruthy();
  });
});
