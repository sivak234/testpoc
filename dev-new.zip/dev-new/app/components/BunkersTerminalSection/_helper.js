/*
 *
 * BunkersComponent helper
 *
 */

export function defaultFunction(text) {
  return text;
}
