/**
 *
 * Asynchronously loads the component for BunkersComponent
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
