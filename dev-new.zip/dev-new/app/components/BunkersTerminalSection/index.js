/**
 *
 * BunkersComponent
 *
 */

import React from 'react';
import PropTypes from 'prop-types';

import { FormattedMessage } from 'react-intl';
import { Table, Col, Row } from 'reactstrap';
import messages from './messages';

import './_helper';

function BunkersTerminalSection({ notes, data, passedRef }) {
  const bunkerData = [];
  try {
    if (data) {
      if (data && data.length > 0) {
        data.map(item => {
          const supplyTypeforEachBunkes =
            item.supplyTypeforEachBunkes &&
            item.supplyTypeforEachBunkes.length !== 0
              ? item.supplyTypeforEachBunkes.join(', ')
              : '';
          bunkerData.push(
            <tr key={item[0]}>
              <td>{item.fuelsHandled}</td>
              <td>{supplyTypeforEachBunkes}</td>
            </tr>,
          );
          return bunkerData;
        });
      } else {
        bunkerData.push(
          <tr key="some-key">
            <td>--</td>
            <td>--</td>
          </tr>,
        );
      }
    }
  } catch (e) {
    // console.log(e.messages);
  }

  return (
    <>
      <Row className="port_overview_row_cls">
        <Col className="port-dashboard-section-header-port pt-1">
          <a href name="bunkers" className="part">
            <h4 className="mb-0" ref={passedRef}>
              <FormattedMessage {...messages.header} />
            </h4>
          </a>
        </Col>
      </Row>
      <Row
        className="port_overview_row_cls"
        style={{ width: '100%', overflow: 'auto' }}
      >
        <Col>
          <Table className="table">
            <thead className="table-head">
              <tr>
                <th width="33.33%">
                  <FormattedMessage {...messages.fuelsHandled} />
                </th>
                <th width="33.33%">
                  <FormattedMessage {...messages.supplyTypeforEachBunkes} />
                </th>
              </tr>
            </thead>
            <tbody>{bunkerData}</tbody>
          </Table>
        </Col>
      </Row>
      {notes && notes !== '' && (
        <Row>
          <Col>
            <h5>
              <FormattedMessage {...messages.notes} />
            </h5>
            {notes}
          </Col>
        </Row>
      )}
    </>
  );
}

BunkersTerminalSection.propTypes = {
  data: PropTypes.oneOfType([PropTypes.array, PropTypes.object]).isRequired,
  passedRef: PropTypes.func,
  notes: PropTypes.any,
};

export default BunkersTerminalSection;
