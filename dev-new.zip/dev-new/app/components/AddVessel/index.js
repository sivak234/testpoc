/**
 *
 * AddVessel
 *
 */

import React, { memo } from 'react';
import PropTypes from 'prop-types';

import { Button, Form, Row, Col } from 'reactstrap';
import { FormattedMessage } from 'react-intl';
import messages from './messages';
import './_helper';

import './index.scss';

function AddVessel({ openAddVesselForm }) {
  return (
    <>
      <Form>
        <Row className="buttonLeft">
          <Col className="align-self-center" />
          <Col className="col-auto pr-0">
            <Button color="primary" type="button" onClick={openAddVesselForm}>
              <i className="fa fa-plus mr-1" />{' '}
              <FormattedMessage {...messages.addVessel} />
            </Button>
          </Col>
        </Row>
      </Form>
    </>
  );
}

AddVessel.propTypes = { openAddVesselForm: PropTypes.func.isRequired };

export default memo(AddVessel);
