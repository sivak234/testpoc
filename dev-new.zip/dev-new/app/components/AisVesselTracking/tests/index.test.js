// /**
//  *
//  * Tests for AisVesselTracking
//  *
//  * @see https://github.com/react-boilerplate/react-boilerplate/tree/master/docs/testing
//  *
//  */

/**
 *
 * Tests for LandingPageVesselTracking
 *
 * @see https://github.com/react-boilerplate/react-boilerplate/tree/master/docs/testing
 *
 */

import React from 'react';
import { shallow } from 'enzyme';

import AisVesselTracking from '../index';

import { DEFAULT_LOCALE } from '../../../i18n';
import { testData } from './test-data';

describe('<LandingPageVesselTracking />', () => {
  /**
   * Unskip this test to use it
   *
   * @see {@link https://jestjs.io/docs/en/api#testskipname-fn}
   */

  it('Should render using enzyme', () => {
    const wrapper = shallow(
      <AisVesselTracking locale={DEFAULT_LOCALE} {...testData} />,
    );
    expect(wrapper).toMatchSnapshot();
    const testSelected = {
      countryId: '111',
      nextPortId: '',
      regionId: '',
    };
    wrapper.setProps({ selectedSearch: testSelected });
    expect(wrapper).toMatchSnapshot();
    const setNextPort = {
      countryId: '',
      nextPortId: '1111',
      regionId: '',
    };
    wrapper.setProps({ selectedSearch: setNextPort });
    expect(wrapper).toMatchSnapshot();

    wrapper.setProps({ vesselDetails: '' });
    expect(wrapper).toMatchSnapshot();
    wrapper.update();
    wrapper.setProps({
      isLandingMapPage: true,
      isNewLandingPage: false,
      isPortMapPage: true,
      isVesselMapPage: true,
      isModelOpen: true,
      portDetailsValue: '',
    });

    expect(wrapper).toMatchSnapshot();
  });
});
