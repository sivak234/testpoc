/**
 *
 * Asynchronously loads the component for AisVesselTracking
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
