/* eslint-disable prefer-rest-params */
/* eslint-disable array-callback-return */
/* eslint-disable no-underscore-dangle */
/* eslint-disable no-plusplus */
/* eslint-disable func-names */
/* eslint-disable no-param-reassign */
/* eslint no-underscore-dangle: 0 */
/* eslint-disable no-multi-assign */
/*
 *
 * AisVesselTracking helper
 *
 */

import L from 'leaflet';
import 'leaflet.gridlayer.googlemutant/Leaflet.GoogleMutant';
import 'leaflet-fullscreen';
import 'leaflet.markercluster';
import moment from 'moment';
import ArrowIcon from '../../assets/images/ic_arrow.png';
import {
  DEFAULT_ZOOM_LEVEL,
  DISABLE_CLUSTER_ZOOM_LEVEL,
  AIS_LANDING_ZOOM_COORDINATES,
  AIS_LANDING_ZOOM_LEVEL,
  PORTMOVEMENT_ZOOM_LEVEL,
  MAP_BONDARY_LEFT_TO_RIGHT,
  MAP_BOUNDARY_TOP_TO_BOTTOM,
  SHIP_LENGTH_PX,
  SHIP_WIDTH_PX,
  VESSEL_LOW_ZOOM_LEVEL,
  SHIP_LENGTH_LOW_ZOOM_LEVEL_PX,
  SHIP_WIDTH_LOW_ZOOM_LEVEL_PX,
  VESSEL_ENLARGE_ZOOM_LEVEL,
  MY_ZONE_FILL_COLOR,
  MY_ZONE_BORDER_COLOR,
  HISTORICAL_TOOLTIP_D_FORMAT,
  HISTORICAL_TRACK_SOLID_LINE,
  HISTORICAL_TRACK_DOTTED_LINE,
} from '../../utils/constants';
import { latToLng } from '../MyZoneMap/_helper';
let mapzoom = 3;
export const createMap = (mapRef, latlanText, id) => {
  const container = L.DomUtil.get(id);
  if (container != null) {
    // eslint-disable-next-line no-underscore-dangle
    container._leaflet_id = null;
  }
  if (id === 'map') {
    mapzoom = 3;
  }
  mapRef.current = L.map(id, {
    maxZoom: 22,
    minZoom: 3,
    zoomControl: true,
    noWrap: true,
    worldCopyJump: true, // prevent multiple map fix
    trackResize: id !== 'map2', // grey area fix
    // preferCanvas: id === 'map', // to seggregate the myzone and vessels
    maxBounds: [MAP_BOUNDARY_TOP_TO_BOTTOM, MAP_BONDARY_LEFT_TO_RIGHT],
    fullscreenControl: {
      position: 'topright',
      pseudoFullscreen: false,
    },
  }).setView(AIS_LANDING_ZOOM_COORDINATES, AIS_LANDING_ZOOM_LEVEL);
  // mapRef.current.options.minZoom = 2;
  mapRef.current.zoomControl.setPosition('bottomright');
  if (id === 'map') {
    mapRef.current.on('zoomend', function(e) {
      mapzoom = e.target._zoom;
    });
  }
  // const satellitemap = 'https://{s}.google.com/vt/lyrs=s&x={x}&y={y}&z={z}';
  // const streetmap = 'https://{s}.google.com/vt/lyrs=m&x={x}&y={y}&z={z}';
  // const tileLayer = L.tileLayer(streetmap, {
  //   maxZoom: 22,
  //   minZoom: 3,
  //   subdomains: ['mt0', 'mt1', 'mt2', 'mt3'],
  // }).addTo(mapRef.current);
  // const tileLayer1 = L.tileLayer(satellitemap, {
  //   maxZoom: 22,
  //   minZoom: 3,
  //   subdomains: ['mt0', 'mt1', 'mt2', 'mt3'],
  // });

  const roadMutant = L.gridLayer
    .googleMutant({
      type: 'roadmap',
    })
    .addTo(mapRef.current);

  const satMutant = L.gridLayer.googleMutant({
    type: 'satellite',
  });

  // mapRef.current.addLayer(tileLayer);
  mapRef.current.fitWorld();
  L.control
    .layers(
      {
        Roadmap: roadMutant,
        Satellite: satMutant,
      },
      {},
      {
        collapsed: true,
      },
    )
    .addTo(mapRef.current);
  mapRef.current.on('baselayerchange', e => {
    let element = null;
    if (e.name === 'Roadmap') {
      element = [document.getElementsByClassName('latlan-text-satellite')[0]];
    } else {
      element = [document.getElementsByClassName('latlan-text-roadmap')[0]];
    }
    if (element && element.length >= 0 && e.name === 'Roadmap') {
      element[0].classList.remove('latlan-text-satellite');
      element[0].classList.add('latlan-text-roadmap');
    } else if (element && element.length >= 0) {
      element[0].classList.remove('latlan-text-roadmap');
      element[0].classList.add('latlan-text-satellite');
    }
  });
  latlanText = L.control({
    position: 'bottomleft',
  });
  latlanText.onAdd = function add() {
    this.div = L.DomUtil.create('div', 'latlan-text-roadmap');
    const imgLog = `<div id='lanLat'></div>`;
    this.div.innerHTML = imgLog;
    this.update();
    return this.div;
  };
  latlanText.update = function update(ev) {
    if (ev !== undefined) {
      const dmsCoords = ddToDms(ev.latlng.lat, ev.latlng.lng);
      this.div.innerHTML = `<div id='lanLat'>${dmsCoords}<br/>
        (${ev.latlng.lat.toFixed(4)}, ${ev.latlng.lng.toFixed(4)})</div>`;
    }
  };
  latlanText.addTo(mapRef.current);
  mapRef.current.on('mousemove', function onmapmovuseover(ev) {
    latlanText.update(ev);
  });

  // Canvas added for vessel rendering  - de-clustering start
  L.Canvas.include({
    _updateVessel(layer) {
      if (!this._drawing || layer._empty() || !(mapRef && mapRef.current)) {
        return;
      }

      const p = layer._point;
      const ctx = this._ctx;
      const yaw = layer._heading + 270;
      const course = layer._course + 270;
      let length = SHIP_LENGTH_PX;
      let halfWidth = SHIP_WIDTH_PX;
      const speed = layer._speed;
      const zoomLevel = mapRef && mapRef.current ? mapzoom : 2;
      let vesselCoordinates = [];

      if (zoomLevel < VESSEL_LOW_ZOOM_LEVEL) {
        length = SHIP_LENGTH_LOW_ZOOM_LEVEL_PX;
        halfWidth = SHIP_WIDTH_LOW_ZOOM_LEVEL_PX;
      }

      if (zoomLevel < VESSEL_ENLARGE_ZOOM_LEVEL) {
        vesselCoordinates = getVesselCoordinates(p, length, halfWidth);
      } else {
        vesselCoordinates = getEnlargedVesselCoordinates(p, length, halfWidth);
      }

      ctx.beginPath();
      const angle = yaw * (Math.PI / 180);
      const cosValue = Math.cos(angle);
      const sinValue = Math.sin(angle);
      let p1;
      let p2;
      for (let i = 0; i < vesselCoordinates.length; i++) {
        p1 = new L.Point(vesselCoordinates[i][0], vesselCoordinates[i][1]);
        p2 = new L.Point(
          cosValue * (p1.x - p.x) - sinValue * (p1.y - p.y) + p.x,
          sinValue * (p1.x - p.x) + cosValue * (p1.y - p.y) + p.y,
        );
        if (i === 0) {
          ctx.moveTo(p2.x, p2.y);
        } else {
          ctx.lineTo(p2.x, p2.y);
        }
      }
      ctx.closePath();
      this._fillStroke(ctx, layer);

      if (zoomLevel >= VESSEL_ENLARGE_ZOOM_LEVEL && speed > 0) {
        vesselCoordinates = getEnlargedVesselCourseCoordinates(
          p,
          length,
          halfWidth,
          speed,
        );

        ctx.beginPath();
        const angleCourse = course * (Math.PI / 180);
        const cosValueCourse = Math.cos(angleCourse);
        const sinValueCourse = Math.sin(angleCourse);
        let p3;
        let p4;
        for (let i = 0; i < vesselCoordinates.length; i++) {
          p3 = new L.Point(vesselCoordinates[i][0], vesselCoordinates[i][1]);
          p4 = new L.Point(
            cosValueCourse * (p3.x - p.x) - sinValueCourse * (p3.y - p.y) + p.x,
            sinValueCourse * (p3.x - p.x) + cosValueCourse * (p3.y - p.y) + p.y,
          );
          if (i === 0) {
            ctx.moveTo(p4.x, p4.y);
          } else {
            ctx.lineTo(p4.x, p4.y);
          }
        }
        ctx.closePath();
        this._fillStroke(ctx, layer);
      }
    },
  });
  // Canvas added for vessel rendering  - de-clustering end

  window.scrollTo(0, 0);

  return mapRef.current;
};

export const AISLandingScreenMap = (
  mapRef,
  // clusterLayerGroupRef,
  vesselMapData,
  CenterPosition,
  ZoomLevel,
  stroogClusterLayerGroupRef,
  portLayerMarkerRef,
) => {
  let vesselMarkerInstance = '';
  // if (portLayerMarkerRef && portLayerMarkerRef.current !== null) {

  //   portLayerMarkerRef.current.clearLayers();
  //   mapRef.current.removeLayer(portLayerMarkerRef.current);
  // }
  if (
    stroogClusterLayerGroupRef &&
    stroogClusterLayerGroupRef.current !== null
  ) {
    stroogClusterLayerGroupRef.current.clearLayers();
    mapRef.current.removeLayer(stroogClusterLayerGroupRef.current);
  }
  // if (cargoClusterLayerGroupRef && cargoClusterLayerGroupRef.current !== null) {
  //   cargoClusterLayerGroupRef.current.clearLayers();
  //   mapRef.current.removeLayer(cargoClusterLayerGroupRef.current);
  // }

  // if (bulkClusterLayerGroupRef && bulkClusterLayerGroupRef.current !== null) {
  //   bulkClusterLayerGroupRef.current.clearLayers();
  //   mapRef.current.removeLayer(bulkClusterLayerGroupRef.current);
  // }
  // if (
  //   tankerClusterLayerGroupRef &&
  //   tankerClusterLayerGroupRef.current !== null
  // ) {
  //   tankerClusterLayerGroupRef.current.clearLayers();
  //   mapRef.current.removeLayer(tankerClusterLayerGroupRef.current);
  // }

  // if (clusterLayerGroupRef.current !== null) {
  //   clusterLayerGroupRef.current.clearLayers();
  //   mapRef.current.removeLayer(clusterLayerGroupRef.current);
  // }

  // if (vesselMapData !== undefined && vesselMapData.length > 0) {
  //   console.log('unknown inside');
  //   if (clusterLayerGroupRef && clusterLayerGroupRef.current === null) {
  //     clusterLayerGroupRef.current = L.markerClusterGroup({
  //       spiderfyOnMaxZoom: false,
  //       disableClusteringAtZoom: DISABLE_CLUSTER_ZOOM_LEVEL,
  //     }).addTo(mapRef.current);
  //   }
  //   clusterLayerGroupRef.current.addLayers(vesselMapData);
  //   mapRef.current.addLayer(clusterLayerGroupRef.current);
  //   mapRef.current.invalidateSize();
  //   vesselMarkerInstance = clusterLayerGroupRef.current.addTo(mapRef.current);
  //   let markZoom = ZoomLevel;
  //   let centerPos = CenterPosition;
  //   if (vesselMapData.length === 1) {
  //     markZoom = 3;
  //     // eslint-disable-next-line no-underscore-dangle
  //     centerPos = vesselMapData[0]._latlng;
  //   }
  //   mapRef.current.setView(centerPos, markZoom);
  // } else if (clusterLayerGroupRef.current !== null) {
  //   mapRef.current.setView(CenterPosition, ZoomLevel);
  //   clusterLayerGroupRef.current.clearLayers();
  //   mapRef.current.removeLayer(clusterLayerGroupRef.current);
  // }
  // return vesselMarkerInstance;

  if (vesselMapData !== undefined && vesselMapData.length > 0) {
    if (portLayerMarkerRef && portLayerMarkerRef.current !== null) {
      mapRef.current.removeLayer(portLayerMarkerRef.current);
    }
    portLayerMarkerRef.current = L.layerGroup(vesselMapData);
    vesselMarkerInstance = portLayerMarkerRef.current.addTo(mapRef.current);
    let markZoom = ZoomLevel;
    let centerPos = CenterPosition;
    if (vesselMapData.length === 1) {
      markZoom = 3;
      // eslint-disable-next-line no-underscore-dangle
      centerPos = vesselMapData[0]._latlng;
    }
    mapRef.current.setView(centerPos, markZoom);
  } else if (portLayerMarkerRef.current !== null) {
    portLayerMarkerRef.current.clearLayers();
    mapRef.current.removeLayer(portLayerMarkerRef.current);
  }
  return vesselMarkerInstance;
};

export function defaultFunction(text) {
  return text;
}

export const ddToDms = (lt, lg) => {
  let lat = lt;
  let lng = lg;
  let latResult;
  let lngResult;
  let dmsResult = '';
  lat = parseFloat(lat);
  lng = parseFloat(lng);
  latResult = lat >= 0 ? 'N' : 'S';
  // Call to getDms(lat) function for the coordinates of Latitude in DMS.
  // The result is stored in latResult letiable.
  latResult += getDms(lat);
  lngResult = lng >= 0 ? 'E' : 'W';
  // Call to getDms(lng) function for the coordinates of Longitude in DMS.
  // The result is stored in lngResult letiable.
  lngResult += getDms(lng);
  // Joining both letiables and separate them with a space.
  dmsResult = `${latResult}'</br>'${lngResult}`;
  // Return the resultant string
  return dmsResult;
};
export const AISLandingPortMap = (
  mapRef2,
  portLayerMarkerRef,
  portMapData,
  // clusterLayerGroupRef,
  stroogClusterLayerGroupRef,
) => {
  // if (clusterLayerGroupRef && clusterLayerGroupRef.current !== null) {
  //   clusterLayerGroupRef.current.clearLayers();
  //   mapRef2.current.removeLayer(clusterLayerGroupRef.current);
  // }
  if (
    stroogClusterLayerGroupRef &&
    stroogClusterLayerGroupRef.current !== null
  ) {
    stroogClusterLayerGroupRef.current.clearLayers();
    mapRef2.current.removeLayer(stroogClusterLayerGroupRef.current);
  }
  let portmarkers = null;
  if (portMapData.length === 1 && portMapData[0].norecord !== undefined) {
    if (portLayerMarkerRef.current !== null) {
      portLayerMarkerRef.current.clearLayers();
      mapRef2.current.removeLayer(portLayerMarkerRef.current);
    }
  } else if (portMapData !== undefined && portMapData.length > 0) {
    if (portLayerMarkerRef.current !== null) {
      mapRef2.current.removeLayer(portLayerMarkerRef.current);
    }
    portLayerMarkerRef.current = L.layerGroup(portMapData);
    mapRef2.current.setView(new L.LatLng(0, 0), AIS_LANDING_ZOOM_LEVEL);
    portmarkers = portLayerMarkerRef.current.addTo(mapRef2.current);
  } else if (portLayerMarkerRef.current !== null) {
    portLayerMarkerRef.current.clearLayers();
    mapRef2.current.removeLayer(portLayerMarkerRef.current);
  }
  return portmarkers;
};

export const getDms = val => {
  let valDeg = '';
  let valMin = '';
  let valSec = '';
  let result = '';
  valDeg = Math.floor(Math.abs(val));
  result = `${valDeg}º`;
  valMin = Math.floor((Math.abs(val) - valDeg) * 60);
  result += `${valMin}'`;
  valSec =
    Math.round((Math.abs(val) - valDeg - valMin / 60) * 3600 * 1000) / 1000;
  result += `${valSec}"`;
  return result;
};

export const AISPortMovementMap = (
  mapRef3,
  vesselLayerMarkerRef,
  terminalPolygonRef,
  berthPolygonRef,
  portMovementMapData,
  portPolygonRef,
  berthChecked,
  terminalChecked,
  countryName,
) => {
  // eslint-disable-next-line no-multi-assign
  const google = (window.google = window.google ? window.google : {});
  const vesselMarkerList =
    portMovementMapData && portMovementMapData.vesselMarkerList
      ? portMovementMapData.vesselMarkerList
      : [];
  const portPolygon =
    portMovementMapData && portMovementMapData.portPolygon
      ? portMovementMapData.portPolygon
      : null;
  const terminalPolygon =
    portMovementMapData && portMovementMapData.terminalPolygon
      ? portMovementMapData.terminalPolygon
      : null;
  const berthPolygon =
    portMovementMapData && portMovementMapData.berthPolygon
      ? portMovementMapData.berthPolygon
      : null;

  if (
    portPolygon &&
    portPolygon.length > 0 &&
    portPolygon[0].polygonArr.length > 0
  ) {
    const pt = new L.LatLng(
      parseFloat(portPolygon[0].lat),
      parseFloat(portPolygon[0].lng),
    );
    mapRef3.current.setView(pt, PORTMOVEMENT_ZOOM_LEVEL);
    if (portPolygonRef.current !== null) {
      mapRef3.current.removeLayer(portPolygonRef.current);
    }
    portPolygonRef.current = L.layerGroup(portPolygon[0].polygonArr);
    portPolygonRef.current.addTo(mapRef3.current);
  } else if (portPolygonRef.current !== null) {
    mapRef3.current.removeLayer(portPolygonRef.current);
    const geocoder = new google.maps.Geocoder();
    geocoder.geocode({ address: countryName }, function(results, status) {
      if (status === google.maps.GeocoderStatus.OK) {
        const pt = new L.LatLng(
          results[0].geometry.location.lat(),
          results[0].geometry.location.lng(),
        );
        mapRef3.current.setView(pt, DEFAULT_ZOOM_LEVEL);
      }
    });
  }
  if (
    vesselMarkerList !== null &&
    vesselMarkerList !== undefined &&
    vesselMarkerList.length > 0
  ) {
    if (vesselLayerMarkerRef.current !== null) {
      mapRef3.current.removeLayer(vesselLayerMarkerRef.current);
    }
    vesselLayerMarkerRef.current = L.layerGroup(vesselMarkerList);
    vesselLayerMarkerRef.current.addTo(mapRef3.current);
  } else if (vesselLayerMarkerRef.current !== null) {
    mapRef3.current.removeLayer(vesselLayerMarkerRef.current);
  }
  if (
    terminalPolygon !== undefined &&
    terminalPolygon !== null &&
    terminalPolygon.length > 0 &&
    vesselMarkerList.length > 0 &&
    terminalChecked
  ) {
    terminalPolygonRef.current = L.layerGroup(terminalPolygon);
    terminalPolygonRef.current.addTo(mapRef3.current);
    const pt = new L.LatLng(
      parseFloat(portPolygon[0].lat),
      parseFloat(portPolygon[0].lng),
    );
    mapRef3.current.setView(pt, 12);
  } else if (
    terminalPolygonRef.current !== null
    // && vesselMarkerList.length === 0
  ) {
    mapRef3.current.removeLayer(terminalPolygonRef.current);
    if (vesselMarkerList.length === 0) {
      const geocoder = new google.maps.Geocoder();
      geocoder.geocode({ address: countryName }, function(results, status) {
        if (status === google.maps.GeocoderStatus.OK) {
          const pt = new L.LatLng(
            results[0].geometry.location.lat(),
            results[0].geometry.location.lng(),
          );
          mapRef3.current.setView(pt, DEFAULT_ZOOM_LEVEL);
        }
      });
    }
  }

  if (
    berthPolygon !== undefined &&
    berthPolygon !== null &&
    berthPolygon.length > 0 &&
    berthChecked
  ) {
    berthPolygonRef.current = L.layerGroup(berthPolygon);
    berthPolygonRef.current.addTo(mapRef3.current);
    const pt = new L.LatLng(
      parseFloat(portPolygon[0].lat),
      parseFloat(portPolygon[0].lng),
    );
    mapRef3.current.setView(pt, 14);
  } else if (
    berthPolygonRef.current !== null
    // &&  vesselMarkerList.length === 0
  ) {
    mapRef3.current.removeLayer(berthPolygonRef.current);
    if (vesselMarkerList.length === 0) {
      const geocoder = new google.maps.Geocoder();
      geocoder.geocode({ address: countryName }, function(results, status) {
        if (status === google.maps.GeocoderStatus.OK) {
          const pt = new L.LatLng(
            results[0].geometry.location.lat(),
            results[0].geometry.location.lng(),
          );
          mapRef3.current.setView(pt, DEFAULT_ZOOM_LEVEL);
        }
      });
    }
  }
};

export const getVesselByFilter = (aisVesselData, selected, selectedSearch) => {
  let aisVesselDataFilter = aisVesselData;
  const { regionId, countryId } = selected;
  const { nextPortId } = selectedSearch;
  if (regionId !== '') {
    aisVesselDataFilter = aisVesselData.filter(
      x => x.regionId === parseInt(regionId, 10),
    );
  }
  if (countryId !== '') {
    aisVesselDataFilter = aisVesselData.filter(
      x => x.countryId === parseInt(countryId, 10),
    );
  }
  if (selectedSearch.nextPortId !== '') {
    aisVesselDataFilter = aisVesselData.filter(x => x.portId === nextPortId);
  }
  return aisVesselDataFilter;
};

export const AISVesselMovementMap = (
  mapRef4,
  vesselMarkersRef,
  layerMarkersAroundRef,
  vesselPortLayerMarkerRef,
  vesselDetails,
  vesselsNearestData,
  portMapData,
  portChecked,
) => {
  let pt = {};
  if (vesselDetails !== undefined) {
    const vessel = vesselDetails;
    if (vessel && vessel.vesselLatLng && vessel.vesselLatLng !== '') {
      let cssClass = `vessel-icon-tug`;
      if (vessel.vesselType !== undefined)
        cssClass = `vessel-icon-${vessel.vesselType
          .toLowerCase()
          .replace(/\s/g, '')}`;

      if (
        vessel.vesselLoadCondition &&
        vessel.vesselLoadCondition === 'Ballast'
      ) {
        cssClass = `${cssClass}-${vessel.vesselLoadCondition.toLowerCase()}`;
      }
      const markerPosition = [
        parseFloat(JSON.parse(vessel.vesselLatLng).coordinates[1]),
        parseFloat(JSON.parse(vessel.vesselLatLng).coordinates[0]),
      ];
      const divIcon = L.divIcon({
        className: 'my-div-icon',
        html: `<div class="vessel-border-dottedred" ><p   class="${cssClass}"
          style="-webkit-transform:
          rotate(${vessel.vesselHeading}deg);
          -ms-transform:rotate(${vessel.vesselHeading}deg);
          -moz-transform:rotate(${vessel.vesselHeading}deg);"></p></div>`,
        iconSize: [20, 20],
      });

      const marker = L.marker(markerPosition, {
        icon: divIcon,
      }).bindPopup();
      marker.on('mouseover', function onmouseover() {
        // eslint-disable-next-line no-underscore-dangle
        marker._popup.setContent(`<div id="mapOverPStyle">
                  <p className="pStyle">
                  IMO<span> : </span>  ${vessel.imo}</p>
                  <p className="pStyle">
                  Name<span> : </span>  ${vessel.vesselName}</p>
                <p className="pStyle">
                  Vessel Type<span> : </span> ${vessel.vesselType} </p>
                <p className="pStyle">
                  Vessel Heading<span> : </span> ${vessel.vesselHeading} </p>
                  <p className="pStyle">
                  Port Name<span> : </span> ${vessel.nextPortName} </p>
                <p className="pStyle">
                <p className="pStyle">
                Load Condition<span> :
                </span> ${vessel.vesselLoadCondition} </p>
                  <p className="pStyle">
                  Course<span> : </span> ${vessel.vesselCourse} </p>
                <p className="pStyle">
                  Vessel Speed<span> : </span> ${vessel.vesselSpeed} </p>
                  <p className="pStyle">
                Last Received<span> : </span>
                ${vessel.recordedDate} </p>
            </div>`);
        marker.openPopup();
      });

      marker.on('mouseout', function onmouseout() {
        marker.closePopup();
      });
      const vesselMapData = [];
      vesselMapData.push(marker);
      if (mapRef4 && mapRef4.current !== null) {
        if (vesselMarkersRef.current !== null) {
          mapRef4.current.removeLayer(vesselMarkersRef.current);
        }
        if (layerMarkersAroundRef.current !== null) {
          mapRef4.current.removeLayer(layerMarkersAroundRef.current);
        }
      }
      vesselMarkersRef.current = L.layerGroup(vesselMapData);
      vesselMarkersRef.current.addTo(mapRef4.current);

      pt = new L.LatLng(
        parseFloat(JSON.parse(vessel.vesselLatLng).coordinates[1]),
        parseFloat(JSON.parse(vessel.vesselLatLng).coordinates[0]),
      );
      mapRef4.current.setView(pt, 11);

      layerMarkersAroundRef.current = L.layerGroup(vesselsNearestData);
      layerMarkersAroundRef.current.addTo(mapRef4.current);
    }
  }
  if (portChecked && portMapData && portMapData.length > 0) {
    mapRef4.current.setView(pt, 2);
    if (vesselPortLayerMarkerRef.current !== null) {
      mapRef4.current.removeLayer(vesselPortLayerMarkerRef.current);
    }
    vesselPortLayerMarkerRef.current = L.layerGroup(portMapData);
    vesselPortLayerMarkerRef.current.addTo(mapRef4.current);
  } else if (vesselPortLayerMarkerRef.current !== null) {
    mapRef4.current.removeLayer(vesselPortLayerMarkerRef.current);
  }
};

// lazzy loading

// export const AISTankerDataMarker = (
//   mapRef,
//   tankerClusterLayerGroupRef,
//   mapTankerDataMarker,
//   CenterPosition,
//   ZoomLevel,
//   clusterLayerGroupRef,
//   portLayerMarkerRef,
// ) => {
//   if (clusterLayerGroupRef && clusterLayerGroupRef.current !== null) {
//     clusterLayerGroupRef.current.clearLayers();
//     mapRef.current.removeLayer(clusterLayerGroupRef.current);
//   }
//   if (portLayerMarkerRef && portLayerMarkerRef.current !== null) {
//     portLayerMarkerRef.current.clearLayers();
//     mapRef.current.removeLayer(portLayerMarkerRef.current);
//   }
//   if (mapTankerDataMarker !== undefined && mapTankerDataMarker.length > 0) {
//     if (
//       tankerClusterLayerGroupRef &&
//       tankerClusterLayerGroupRef.current === null
//     ) {
//       tankerClusterLayerGroupRef.current = L.markerClusterGroup({
//         spiderfyOnMaxZoom: false,
//         disableClusteringAtZoom: DISABLE_CLUSTER_ZOOM_LEVEL,
//       }).addTo(mapRef.current);
//     }
//     // commented this code for future reference
//     // if (
//     //   // tankerClusterLayerGroupRef.current !== null ||
//     //   showMyFleet || isVesselFilterApplied
//     // ) {
//     //   tankerClusterLayerGroupRef.current.clearLayers();
//     //   mapRef.current.removeLayer(tankerClusterLayerGroupRef.current);
//     // }
//     tankerClusterLayerGroupRef.current.addLayers(mapTankerDataMarker);
//     mapRef.current.addLayer(tankerClusterLayerGroupRef.current);
//     mapRef.current.setView(CenterPosition, ZoomLevel);
//   } else if (tankerClusterLayerGroupRef.current !== null) {
//     mapRef.current.setView(CenterPosition, ZoomLevel);
//     tankerClusterLayerGroupRef.current.clearLayers();
//     mapRef.current.removeLayer(tankerClusterLayerGroupRef.current);
//   }
// };
// export const DrawMyZoneAndPolygon = (
//   mapRef,
//   zoneClusterLayerGroupRef,
//   zoneGroupData,
//   CenterPosition,
//   ZoomLevel,
//   clusterLayerGroupRef,
//   vesselDataList,
//   isSingleVesselSearch,
//   isSingleSearchPort,
//   isValidFilter,
//   isShowPoiFilterModal,
//   vesselCanvasRenderer,
// ) => {
//   const polyLayers = [];
//   if (
//     clusterLayerGroupRef &&
//     clusterLayerGroupRef.current !== null &&
//     (!isValidFilter &&
//       !isShowPoiFilterModal &&
//       !isSingleVesselSearch &&
//       !isSingleSearchPort)
//   ) {
//     clusterLayerGroupRef.current.clearLayers();
//     mapRef.current.removeLayer(clusterLayerGroupRef.current);
//   }
//   if (zoneClusterLayerGroupRef && zoneClusterLayerGroupRef.current !== null) {
//     zoneClusterLayerGroupRef.current.clearLayers();
//     mapRef.current.removeLayer(zoneClusterLayerGroupRef.current);
//     zoneClusterLayerGroupRef.current = null;
//   }
//   if (zoneClusterLayerGroupRef && zoneClusterLayerGroupRef.current === null) {
//     zoneClusterLayerGroupRef.current = new L.FeatureGroup({
//       spiderfyOnMaxZoom: false,
//       disableClusteringAtZoom: DISABLE_CLUSTER_ZOOM_LEVEL,
//     }).addTo(mapRef.current);
//     zoneClusterLayerGroupRef.current.bringToBack();

//     zoneGroupData.map(valArray => {
//       const { geoZoneGroupDetails, zoneGroupName } = valArray;

//       if (geoZoneGroupDetails.length > 0) {
//         geoZoneGroupDetails.map(coord => {
//           let count = 0;
//           const { geoZoneGroupDetailName } = coord;
//           const groupName = `${zoneGroupName}:${geoZoneGroupDetailName}`;
//           if (coord) {
//             const geoFencePolygon =
//               coord.geoFencePolygon && JSON.parse(coord.geoFencePolygon);
//             if (!isSingleSearchPort) {
//               Object.values(vesselDataList).forEach(vessels => {
//                 vessels.value.forEach(vessel => {
//                   const latlangval = [vessel.g, vessel.l];
//                   const isCoordite = isMarkerInsidePolygon(
//                     latlangval,
//                     geoFencePolygon.coordinates[0],
//                   );
//                   if (isCoordite && vessel.g !== 0 && vessel.l !== 0) {
//                     count++;
//                   }
//                 });
//               });
//             }
//             const vesselCount =
//               count > 0 ? ` ${count} ${count > 1 ? 'Vessels' : 'Vessel'}` : '';
//             const createPolyLayer = L.polygon(
//               latToLng(geoFencePolygon.coordinates),
//               { renderer: vesselCanvasRenderer.current },
//             )
//               .setStyle({
//                 color: '#FF0000',
//                 fillColor: '#FF0000',
//               })
//               .bindTooltip(
//                 `<div'>${groupName}  ${
//                   count > 0
//                     ? `<br/><span class="vesselcountlbl">${vesselCount}</span>`
//                     : ''
//                 }</div>`,
//                 {
//                   permanent: true,
//                   direction: 'center',
//                 },
//               );
//             polyLayers.push(
//               zoneClusterLayerGroupRef.current.addLayer(createPolyLayer),
//             );
//           }
//           return polyLayers;
//         });
//       }
//       return polyLayers;
//     });
//     mapRef.current.addLayer(zoneClusterLayerGroupRef.current);
//     mapRef.current.setView(CenterPosition, mapRef.current.getZoom());
//   }
// };
export const isMarkerInsidePolygon = (marker, poly) => {
  const polyPoints = poly;
  const markerlatx = marker[0];
  const markerlangy = marker[1];
  let inside = false;
  if (Array.isArray(polyPoints)) {
    for (let i = 0, j = polyPoints.length - 1; i < polyPoints.length; j = i++) {
      const xi = polyPoints[i][0];
      const yi = polyPoints[i][1];
      const xj = polyPoints[j][0];
      const yj = polyPoints[j][1];

      const intersect =
        // eslint-disable-next-line eqeqeq
        yi > markerlangy != yj > markerlangy &&
        markerlatx < ((xj - xi) * (markerlangy - yi)) / (yj - yi) + xi;

      if (intersect) {
        inside = !inside;
      }
    }
    return inside;
  }
  return inside;
};
export const DrawMyZoneAndPolygonPort = (
  mapRef2,
  zoneClusterLayerGroupRefPort,
  zoneGroupData,
  CenterPosition,
  ZoomLevel,
) => {
  const polyLayers = [];
  if (
    zoneClusterLayerGroupRefPort &&
    zoneClusterLayerGroupRefPort.current !== null
  ) {
    zoneClusterLayerGroupRefPort.current.clearLayers();
    mapRef2.current.removeLayer(zoneClusterLayerGroupRefPort.current);
    zoneClusterLayerGroupRefPort.current = null;
  }
  zoneClusterLayerGroupRefPort.current = new L.FeatureGroup({
    spiderfyOnMaxZoom: false,
    disableClusteringAtZoom: DISABLE_CLUSTER_ZOOM_LEVEL,
  }).addTo(mapRef2.current);

  zoneGroupData.map(valArray => {
    const { geoZoneGroupDetails, zoneGroupName } = valArray;

    if (geoZoneGroupDetails.length > 0) {
      geoZoneGroupDetails.map(coord => {
        const { geoZoneGroupDetailName } = coord;
        const groupName = `${zoneGroupName}:${geoZoneGroupDetailName}`;
        if (coord) {
          const geoFencePolygon =
            coord.geoFencePolygon && JSON.parse(coord.geoFencePolygon);
          const createPolyLayer = L.polygon(
            latToLng(geoFencePolygon.coordinates),
          ).bindTooltip(groupName, {
            permanent: true,
            direction: 'center',
          });
          polyLayers.push(
            zoneClusterLayerGroupRefPort.current.addLayer(createPolyLayer),
          );
        }
        return polyLayers;
      });
    }
    return polyLayers;
  });
  mapRef2.current.addLayer(zoneClusterLayerGroupRefPort.current);
  mapRef2.current.setView(CenterPosition, ZoomLevel);
};
// export const AISStroogDataMarker = (
//   mapRef,
//   stroogClusterLayerGroupRef,
//   mapStroogDataMarker,
//   CenterPosition,
//   ZoomLevel,
//   showMyFleet,
//   isVesselFilterApplied,
//   clusterLayerGroupRef,
//   zoneClusterLayerGroupRef,
//   showMyZoneGroup,
//   portLayerMarkerRef,
// ) => {
//   let markerInstance = '';
//   if (clusterLayerGroupRef && clusterLayerGroupRef.current !== null) {
//     clusterLayerGroupRef.current.clearLayers();
//     mapRef.current.removeLayer(clusterLayerGroupRef.current);
//   }
//   if (portLayerMarkerRef && portLayerMarkerRef.current !== null) {
//     portLayerMarkerRef.current.clearLayers();
//     mapRef.current.removeLayer(portLayerMarkerRef.current);
//   }

//   if (
//     stroogClusterLayerGroupRef &&
//     stroogClusterLayerGroupRef.current !== null
//   ) {
//     stroogClusterLayerGroupRef.current.clearLayers();
//     mapRef.current.removeLayer(stroogClusterLayerGroupRef.current);
//   }
//   // added the code for mutual exclusive when zone applied.
//   if (!(showMyFleet || isVesselFilterApplied)) {
//     if (!showMyZoneGroup) {
//       if (
//         zoneClusterLayerGroupRef &&
//         zoneClusterLayerGroupRef.current !== null
//       ) {
//         zoneClusterLayerGroupRef.current.clearLayers();
//         mapRef.current.removeLayer(zoneClusterLayerGroupRef.current);
//         zoneClusterLayerGroupRef.current = null;
//       }
//     }
//   }

//   if (mapStroogDataMarker !== undefined && mapStroogDataMarker.length > 0) {
//     if (
//       stroogClusterLayerGroupRef &&
//       stroogClusterLayerGroupRef.current === null
//     ) {
//       stroogClusterLayerGroupRef.current = L.markerClusterGroup({
//         spiderfyOnMaxZoom: false,
//         disableClusteringAtZoom: DISABLE_CLUSTER_ZOOM_LEVEL,
//       }).addTo(mapRef.current);
//     }

//     if (
//       stroogClusterLayerGroupRef.current !== null ||
//       (showMyFleet || isVesselFilterApplied)
//     ) {
//       stroogClusterLayerGroupRef.current.clearLayers();
//       mapRef.current.removeLayer(stroogClusterLayerGroupRef.current);
//     }
//     // commented this code for future reference
//     // if (stroogClusterLayerGroupRef.current !== null) {
//     //   stroogClusterLayerGroupRef.current.clearLayers();
//     //   mapRef.current.removeLayer(stroogClusterLayerGroupRef.current);
//     // }
//     markerInstance = stroogClusterLayerGroupRef.current.addLayers(
//       mapStroogDataMarker,
//     );
//     mapRef.current.addLayer(stroogClusterLayerGroupRef.current);
//     mapRef.current.setView(CenterPosition, ZoomLevel);
//   } else if (stroogClusterLayerGroupRef.current !== null) {
//     mapRef.current.setView(CenterPosition, ZoomLevel);
//     stroogClusterLayerGroupRef.current.clearLayers();
//     mapRef.current.removeLayer(stroogClusterLayerGroupRef.current);
//   }
//   return markerInstance;
// };

// export const AISBulkDataMarker = (
//   mapRef,
//   bulkClusterLayerGroupRef,
//   mapBulkgDataMarker,
//   CenterPosition,
//   ZoomLevel,
//   cargoClusterLayerGroupRef,
//   stroogClusterLayerGroupRef,
//   tankerClusterLayerGroupRef,
//   clusterLayerGroupRef,
//   portLayerMarkerRef,
// ) => {
//   if (clusterLayerGroupRef && clusterLayerGroupRef.current !== null) {
//     clusterLayerGroupRef.current.clearLayers();
//     mapRef.current.removeLayer(clusterLayerGroupRef.current);
//   }
//   if (portLayerMarkerRef && portLayerMarkerRef.current !== null) {
//     portLayerMarkerRef.current.clearLayers();
//     mapRef.current.removeLayer(portLayerMarkerRef.current);
//   }
//   if (cargoClusterLayerGroupRef && cargoClusterLayerGroupRef.current !== null) {
//     cargoClusterLayerGroupRef.current.clearLayers();
//     mapRef.current.removeLayer(cargoClusterLayerGroupRef.current);
//   }

//   if (
//     stroogClusterLayerGroupRef &&
//     stroogClusterLayerGroupRef.current !== null
//   ) {
//     stroogClusterLayerGroupRef.current.clearLayers();
//     mapRef.current.removeLayer(stroogClusterLayerGroupRef.current);
//   }
//   if (
//     tankerClusterLayerGroupRef &&
//     tankerClusterLayerGroupRef.current !== null
//   ) {
//     tankerClusterLayerGroupRef.current.clearLayers();
//     mapRef.current.removeLayer(tankerClusterLayerGroupRef.current);
//   }
//   if (mapBulkgDataMarker !== undefined && mapBulkgDataMarker.length > 0) {
//     if (bulkClusterLayerGroupRef && bulkClusterLayerGroupRef.current === null) {
//       bulkClusterLayerGroupRef.current = L.markerClusterGroup({
//         spiderfyOnMaxZoom: false,
//         disableClusteringAtZoom: DISABLE_CLUSTER_ZOOM_LEVEL,
//       }).addTo(mapRef.current);
//     }
//     // commented this code for future reference
//     // if (bulkClusterLayerGroupRef.current !== null) {
//     //   bulkClusterLayerGroupRef.current.clearLayers();
//     //   mapRef.current.removeLayer(bulkClusterLayerGroupRef.current);
//     // }
//     bulkClusterLayerGroupRef.current.addLayers(mapBulkgDataMarker);
//     mapRef.current.addLayer(bulkClusterLayerGroupRef.current);
//     mapRef.current.setView(CenterPosition, ZoomLevel);
//   } else if (bulkClusterLayerGroupRef.current !== null) {
//     mapRef.current.setView(CenterPosition, ZoomLevel);
//     bulkClusterLayerGroupRef.current.clearLayers();
//     mapRef.current.removeLayer(bulkClusterLayerGroupRef.current);
//   }
// };
// export const AISCargoDataMarker = (
//   mapRef,
//   cargoClusterLayerGroupRef,
//   mapCargoDataMarker,
//   CenterPosition,
//   ZoomLevel,
//   zoneClusterLayerGroupRef,
//   clusterLayerGroupRef,
//   portLayerMarkerRef,
//   showMyZoneGroup,
// ) => {
//   if (clusterLayerGroupRef && clusterLayerGroupRef.current !== null) {
//     clusterLayerGroupRef.current.clearLayers();
//     mapRef.current.removeLayer(clusterLayerGroupRef.current);
//   }
//   if (portLayerMarkerRef && portLayerMarkerRef.current !== null) {
//     portLayerMarkerRef.current.clearLayers();
//     mapRef.current.removeLayer(portLayerMarkerRef.current);
//   }
//   if (
//     zoneClusterLayerGroupRef &&
//     zoneClusterLayerGroupRef.current !== null &&
//     !showMyZoneGroup
//   ) {
//     zoneClusterLayerGroupRef.current.clearLayers();
//     mapRef.current.removeLayer(zoneClusterLayerGroupRef.current);
//     zoneClusterLayerGroupRef.current = null;
//   }
//   if (mapCargoDataMarker !== undefined && mapCargoDataMarker.length > 0) {
//     if (
//       cargoClusterLayerGroupRef &&
//       cargoClusterLayerGroupRef.current === null
//     ) {
//       cargoClusterLayerGroupRef.current = L.markerClusterGroup({
//         spiderfyOnMaxZoom: false,
//         disableClusteringAtZoom: DISABLE_CLUSTER_ZOOM_LEVEL,
//       }).addTo(mapRef.current);
//     }
//     // commented this code for future reference
//     // if (cargoClusterLayerGroupRef.current !== null) {
//     //   cargoClusterLayerGroupRef.current.clearLayers();
//     //   mapRef.current.removeLayer(cargoClusterLayerGroupRef.current);
//     // }
//     cargoClusterLayerGroupRef.current.addLayers(mapCargoDataMarker);
//     mapRef.current.addLayer(cargoClusterLayerGroupRef.current);
//     mapRef.current.setView(CenterPosition, ZoomLevel);
//   } else if (cargoClusterLayerGroupRef.current !== null) {
//     mapRef.current.setView(CenterPosition, ZoomLevel);
//     cargoClusterLayerGroupRef.current.clearLayers();
//     mapRef.current.removeLayer(cargoClusterLayerGroupRef.current);
//   }
// };

export const handleMapZoomEvent = (mapInstance, flag) => {
  if (mapInstance) {
    if (flag) {
      mapInstance.doubleClickZoom.disable();
      mapInstance.scrollWheelZoom.disable();
      mapInstance.dragging.disable();
    } else {
      mapInstance.doubleClickZoom.enable();
      mapInstance.scrollWheelZoom.enable();
      mapInstance.dragging.enable();
    }
  }
};
// Vessel polygon creation - de-clustering start
export function getVesselCoordinates(point, length, halfWidth) {
  return [
    [point.x, point.y],
    [point.x - 0.4 * length, point.y + halfWidth],
    [point.x + length, point.y + halfWidth],
    [point.x + 1.6 * length, point.y],
    [point.x + length, point.y - halfWidth],
    [point.x - 0.4 * length, point.y - halfWidth],
  ];
}

export function getEnlargedVesselCoordinates(point, length, halfWidth) {
  return [
    [point.x + 2.6 * length, point.y],
    [point.x + 2 * length, point.y - halfWidth],
    [point.x - 2.2 * length, point.y - halfWidth],
    [point.x - 2.2 * length, point.y + halfWidth],
    [point.x + 2 * length, point.y + halfWidth],
  ];
}

export function getEnlargedVesselCourseCoordinates(
  point,
  length,
  halfWidth,
  speed,
) {
  const courseLength = halfWidth + (9 * speed) / 30;
  return [
    [point.x, point.y],
    [point.x + courseLength * length, point.y],
    [point.x + (courseLength - 0.4) * length, point.y - 0.6 * halfWidth],
    [point.x + (courseLength - 0.4) * length, point.y + 0.6 * halfWidth],
    [point.x + courseLength * length, point.y],
  ];
}

export function getArrowPointCoordinates(point, length) {
  return [
    [point.x, point.y],
    [point.x + length, point.y + 2 * length],
    [point.x, point.y + 2 * length - 3],
    [point.x - length, point.y + 2 * length],
    [point.x, point.y],
  ];
}

export const getToolTip = vessel => {
  const tooltip = `IMO: ${vessel.i}<br> Name: ${vessel.n}<br>Vessel Type: ${
    vessel.t
  }<br>Vessel Heading: ${vessel.h}<br>Port Name: ${
    vessel.pn
  }<br>Load Condition: ${vessel.lc}<br>Course: ${vessel.c}<br>Vessel Speed: ${
    vessel.s
  }<br>Last Received: ${vessel.d}`;
  return tooltip;
};

/* export const getToolTip = vessel => {
  const tooltip = `IMO: ${vessel.i}<br> Name: ${vessel.n}<br>Vessel Type: ${
    vessel.t
  }`;
  return tooltip;
};
*/

// Vessel polygon creation - de-clustering end

export const DrawMyZoneAndPolygonV1 = (
  mapRef,
  zoneGroupData,
  myZoneLayer,
  vesselDataList,
  isSingleSearchPort,
) => {
  if (myZoneLayer && myZoneLayer.current !== null) {
    myZoneLayer.current.clearLayers();
    mapRef.current.removeLayer(myZoneLayer.current);
  }
  if (zoneGroupData && zoneGroupData.length === 0) return;

  myZoneLayer.current = new L.FeatureGroup().addTo(mapRef.current);
  myZoneLayer.current.bringToBack();
  // myZoneLayer
  const polyLayers = [];

  let vesselList = [];
  if (!isSingleSearchPort && vesselDataList) {
    vesselList = vesselDataList;
  }
  zoneGroupData.map(valArray => {
    const { geoZoneGroupDetails, zoneGroupName } = valArray;
    if (geoZoneGroupDetails.length > 0) {
      geoZoneGroupDetails.map(coord => {
        let count = 0;
        const { geoZoneGroupDetailName } = coord;
        const groupName = `${zoneGroupName}:${geoZoneGroupDetailName}`;
        if (coord) {
          const geoFencePolygon =
            coord.geoFencePolygon && JSON.parse(coord.geoFencePolygon);
          vesselList.forEach(vessel => {
            const latlangval = [vessel.g, vessel.l];
            const isCoordite = isMarkerInsidePolygon(
              latlangval,
              geoFencePolygon.coordinates[0],
            );
            if (isCoordite && vessel.g !== 0 && vessel.l !== 0) {
              count++;
            }
          });
          const vesselCount =
            count > 0 ? ` ${count} ${count > 1 ? 'Vessels' : 'Vessel'}` : '';
          polyLayers.push(
            L.polygon(latToLng(geoFencePolygon.coordinates))
              .setStyle({
                color: MY_ZONE_FILL_COLOR,
                fillColor: MY_ZONE_BORDER_COLOR,
              })
              .bindTooltip(
                `<div>${groupName}  ${
                  count > 0
                    ? `<br/><span class="vesselcountlbl">${vesselCount}</span>`
                    : ''
                }</div>`,
                {
                  className: 'ZoneToolTipStyle',
                  permanent: true,
                  direction: 'center',
                },
              ),
          );
        }
      });
    }
  });
  // myZoneLayer = new L.FeatureGroup();

  polyLayers.map(layer => {
    myZoneLayer.current.addLayer(layer);
  });
  myZoneLayer.current.bringToBack();
};

export const DrawVesselTrackingLine = (
  mapRef,
  vesselDataList,
  historicalMapRef,
) => {
  vesselDataList.forEach((vesselDetail, idx) => {
    const { l, g, h } = vesselDetail;
    const toolTipInfo = historicalToolTip(vesselDetail);
    const divIcon = L.divIcon({
      className: 'vesselHIcon',
      html: `<div class='iconRotate'
        style="-webkit-transform: rotate(${h}deg) !important;
        -ms-transform: rotate(${h}deg) !important;
        -moz-transform: rotate(${h}deg) !important;">
          <img src=${ArrowIcon} />
        </div>`,
    });

    if (idx < vesselDataList.length - 1) {
      L.marker([Number(l), Number(g)], {
        icon: divIcon,
      })
        .bindTooltip(`<div>${toolTipInfo}</div>`, {
          className: 'trackToolTipStyle',
          direction: 'bottom',
        })
        .addTo(historicalMapRef.current);

      const nextPoint = vesselDataList[idx + 1];
      const lineType = getLineType(nextPoint.lc);
      drawHistoricalLine(
        [[Number(l), Number(g)], [Number(nextPoint.l), Number(nextPoint.g)]],
        lineType,
        historicalMapRef,
        mapRef,
      );
    }
  });
};

const historicalToolTip = vesselDetail => {
  const { i, n, d, l, g, s, h, ca, co, q, e, pn, vd, vm } = vesselDetail;
  /* eslint-disable*/
  const historicalArrowToolTip = `<div class='vesselHTooltip'>
  <table class='hoverTrackData'>
    <tr>
      <td><b>IMO Number:</b>${i === null ? `&nbsp;` : i}</td>
      <td><b>Vessel Name:</b>${n === null ? `&nbsp;` : n}</td>
      <td><b>Received Date:</b>${
        d === null ? `&nbsp;` : moment(d).format(HISTORICAL_TOOLTIP_D_FORMAT)
      }</td>
    </tr>
    <tr>
      <td><b>Latitude:</b>${l === null ? `&nbsp;` : l}</td>
      <td><b>Longitude:</b>${g === null ? `&nbsp;` : g}</td>
      <td><b>Speed (Kn):</b>${s === null ? `&nbsp;` : s}</td>
    </tr>
    <tr>
      <td><b>Direction:</b>${h === null ? `&nbsp;` : h}</td>
      <td><b>Cargo:</b>${ca === null ? `&nbsp;` : ca}</td>
      <td><b>Grade:</b>${co === null ? `&nbsp;` : co}</td>
    </tr>
    <tr>
      <td><b>Quantity:</b>${q === null ? `&nbsp;` : q}</td>
      <td><b>ETA:</b>${
        e === null ? `&nbsp;` : moment(e).format(HISTORICAL_TOOLTIP_D_FORMAT)
      }</td>
      <td><b>Next Port:</b>${pn === null ? `&nbsp;` : pn}</td>
    </tr>
    <tr>
      <td><b>Draught:</b>${vd === null ? `&nbsp;` : vd}</td>
      <td><b>Mooring Status:</b>${vm === null ? `&nbsp;` : vm}</td>
      <td>&nbsp;</td>
    </tr>
  </table>
</div>`;
  /* eslint-enable */
  return historicalArrowToolTip;
};

export const drawHistoricalLine = (
  points,
  lineType,
  historicalMapRef,
  mapRef,
) => {
  let lineValue = 0;
  if (lineType === 'solidLine') {
    lineValue = 1;
  }
  if (lineType === 'dottedLine') {
    lineValue = 10;
  }
  L.polyline(points, {
    className: `my_polyline`,
    weight: lineValue ? 2 : 0,
    // eslint-disable-next-line no-undef
    dashArray:
      lineValue === 1
        ? HISTORICAL_TRACK_SOLID_LINE
        : HISTORICAL_TRACK_DOTTED_LINE,
    lineCap: 'square',
    color: 'white',
  }).addTo(historicalMapRef.current);
  mapRef.current.addLayer(historicalMapRef.current);
};

const getLineType = loadCondition => {
  let lineTypeValue = '';
  const vesselLoadCondition =
    typeof loadCondition === 'string'
      ? loadCondition.toLowerCase()
      : loadCondition;
  if (
    vesselLoadCondition === 'loaded' ||
    vesselLoadCondition === 'part loaded'
  ) {
    lineTypeValue = 'solidLine';
  } else if (vesselLoadCondition === 'ballast') {
    lineTypeValue = 'dottedLine';
  } else if (vesselLoadCondition === null) {
    lineTypeValue = 'noLine';
  }
  return lineTypeValue;
};
