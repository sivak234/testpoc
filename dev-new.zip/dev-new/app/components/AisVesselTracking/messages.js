/*
 * AisVesselTracking Messages
 *
 * This contains all the text for the AisVesselTracking component.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.components.AisVesselTracking';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'This is the AisVesselTracking component!',
  },
  aisAdditionalFilterSectionOneHeading: {
    id: `${scope}.aisAdditionalFilterSectionOneHeading`,
    defaultMessage: 'Additional Filters',
  },
  aisAdditionalFilterSectionOneSubHeading: {
    id: `${scope}.aisAdditionalFilterSectionOneSubHeading`,
    defaultMessage: 'Geography',
  },
  aisAdditionalFilterSectionTwoHeading: {
    id: `${scope}.aisAdditionalFilterSectionTwoHeading`,
    defaultMessage: 'Vessel Dimensions',
  },
  aisAdditionalFilterRegionLabel: {
    id: `${scope}.aisAdditionalFilterRegionLabel`,
    defaultMessage: 'Region',
  },
  aisAdditionalFilterCountryLabel: {
    id: `${scope}.aisAdditionalFilterCountryLabel`,
    defaultMessage: 'Country',
  },
  aisAdditionalFilterDeadWeightLabel: {
    id: `${scope}.aisAdditionalFilterDeadWeightLabel`,
    defaultMessage: 'DeadWeight',
  },
  aisAdditionalFilterLoaLabel: {
    id: `${scope}.aisAdditionalFilterLoaLabel`,
    defaultMessage: 'LOA',
  },
  aisAdditionalFilterDraughtLabel: {
    id: `${scope}.aisAdditionalFilterDraughtLabel`,
    defaultMessage: 'Draught',
  },
  aisAdditionalFilterBeamLabel: {
    id: `${scope}.aisAdditionalFilterBeamLabel`,
    defaultMessage: 'Beam',
  },
  aisAdditionalFilterGrtLabel: {
    id: `${scope}.aisAdditionalFilterGrtLabel`,
    defaultMessage: 'GRT',
  },
  aisAdditionalFilterTeuCapacityLabel: {
    id: `${scope}.aisAdditionalFilterTeuCapacityLabel`,
    defaultMessage: 'TEU Capacity',
  },
  aisAdditionalFilterRegOwnerLabel: {
    id: `${scope}.aisAdditionalFilterRegOwnerLabel`,
    defaultMessage: 'Registered Owner',
  },
  aisAdditionalFilterBenificalOwnerLabel: {
    id: `${scope}.aisAdditionalFilterBenificalOwnerLabel`,
    defaultMessage: 'Beneficial Owner',
  },
  aisAdditionalFilterCommOpeLabel: {
    id: `${scope}.aisAdditionalFilterCommOpeLabel`,
    defaultMessage: 'Commercial Operator',
  },
  aisAdditionalFilterTechMangLabel: {
    id: `${scope}.aisAdditionalFilterTechMangLabel`,
    defaultMessage: 'Technical Manager',
  },
  aisAdditionalFilterApplyBtn: {
    id: `${scope}.aisAdditionalFilterApplyBtn`,
    defaultMessage: 'Apply',
  },
  aisAdditionalFilterFrom: {
    id: `${scope}.aisAdditionalFilterFrom`,
    defaultMessage: 'From',
  },
  aisAdditionalFilterTo: {
    id: `${scope}.aisAdditionalFilterTo`,
    defaultMessage: 'To',
  },
  aisShowPortVesselBtn: {
    id: `${scope}.aisShowPortVesselBtn`,
    defaultMessage: 'Show',
  },
  showPort: {
    id: `${scope}.showPort`,
    defaultMessage: 'Show Ports',
  },
  showVessel: {
    id: `${scope}.showVessel`,
    defaultMessage: 'Show Vessels',
  },
  portVesselMovementBackNavBtn: {
    id: `${scope}.portVesselMovementBackNavBtn`,
    defaultMessage: 'Back',
  },
  portDetail: {
    id: `${scope}.portDetail`,
    defaultMessage: 'Port Details',
  },
  portStatistics: {
    id: `${scope}.portStatistics`,
    defaultMessage: 'Port Statistics',
  },
  region: {
    id: `${scope}.region`,
    defaultMessage: 'Region',
  },
  country: {
    id: `${scope}.country`,
    defaultMessage: 'Country',
  },
  numberofTerminal: {
    id: `${scope}.numberofTerminal`,
    defaultMessage: 'Number of Terminals',
  },
  numberofBerth: {
    id: `${scope}.numberofBerth`,
    defaultMessage: 'Number of Berths',
  },
  latitude: {
    id: `${scope}.latitude`,
    defaultMessage: 'Latitude',
  },
  longitude: {
    id: `${scope}.longitude`,
    defaultMessage: 'Longitude',
  },
  vesselinPort: {
    id: `${scope}.vesselinPort`,
    defaultMessage: 'Vessels at Port',
  },
  vesselatBerth: {
    id: `${scope}.vesselatBerth`,
    defaultMessage: 'Vessels at Berth',
  },
  vesselatAnchorage: {
    id: `${scope}.vesselatAnchorage`,
    defaultMessage: 'Vessels at Anchorage',
  },
  vesselDeparted: {
    id: `${scope}.vesselDeparted`,
    defaultMessage: 'Vessels Departed Last 24 Hours',
  },
  vesselArrivedLast: {
    id: `${scope}.vesselArrivedLast`,
    defaultMessage: 'Vessels Arrived Last 24 Hours',
  },
  vesselArrivedNext: {
    id: `${scope}.vesselArrivedNext`,
    defaultMessage: 'Vessels Arriving Next 24 Hours',
  },
  portVesselMovementTitle: {
    id: `${scope}.portVesselMovementTitle`,
    defaultMessage: 'Vessel Movement',
  },
  vesselDetail: {
    id: `${scope}.vesselDetail`,
    defaultMessage: 'Vessel Details',
  },
  vesselType: {
    id: `${scope}.vesselType`,
    defaultMessage: 'Vessel Type',
  },
  vesselClassification: {
    id: `${scope}.vesselClassification`,
    defaultMessage: 'Vessel Classification',
  },
  vesselSubType: {
    id: `${scope}.vesselSubType`,
    defaultMessage: 'Vessel Sub-Type',
  },
  grt: {
    id: `${scope}.grt`,
    defaultMessage: 'GRT',
  },
  dwt: {
    id: `${scope}.dwt`,
    defaultMessage: 'DWT',
  },
  loa: {
    id: `${scope}.loa`,
    defaultMessage: 'LOA',
  },
  voyageDetails: {
    id: `${scope}.voyageDetails`,
    defaultMessage: 'Voyage Details',
  },
  lastPositionReportDate: {
    id: `${scope}.lastPositionReportDate`,
    defaultMessage: 'Last Position Report Date',
  },
  previousPort: {
    id: `${scope}.previousPort`,
    defaultMessage: 'Previous Port',
  },
  nextPort: {
    id: `${scope}.nextPort`,
    defaultMessage: 'Next Port',
  },
  eta: {
    id: `${scope}.eta`,
    defaultMessage: 'ETA',
  },

  draught: {
    id: `${scope}.draught`,
    defaultMessage: 'Draught',
  },
  mooringStatus: {
    id: `${scope}.mooringStatus`,
    defaultMessage: 'Mooring Status',
  },
  navigationalStatus: {
    id: `${scope}.navigationalStatus`,
    defaultMessage: 'Navigational Status',
  },
  vesselLoadCondition: {
    id: `${scope}.vesselLoadCondition`,
    defaultMessage: 'Vessel Load Condition',
  },
  cargoType: {
    id: `${scope}.cargoType`,
    defaultMessage: 'Cargo',
  },
  commodity: {
    id: `${scope}.commodity`,
    defaultMessage: 'Grade',
  },
  quantityOnboard: {
    id: `${scope}.quantityOnboard`,
    defaultMessage: 'Quantity Onboard',
  },
  speed: {
    id: `${scope}speed`,
    defaultMessage: 'Speed',
  },
  course: {
    id: `${scope}.course`,
    defaultMessage: 'Course',
  },
  port: {
    id: `${scope}.port`,
    defaultMessage: 'Port',
  },
  vesselDetailMovementTitle: {
    id: `${scope}.vesselDetailMovementTitle`,
    defaultMessage: 'Vessel Movement',
  },
  vesselDetailMovementBackNavBtn: {
    id: `${scope}.vesselDetailMovementBackNavBtn`,
    defaultMessage: 'Back',
  },
  vesselInfo: {
    id: `${scope}.vesselInfo`,
    defaultMessage: 'No data is available for the selected vessel.',
  },
  vesselTitleInfo: {
    id: `${scope}.vesselTitleInfo`,
    defaultMessage: 'Search Vessel',
  },
  historicalErrorInfo: {
    id: `${scope}.historicalErrorInfo`,
    defaultMessage: 'No historical data available for the selected vessel.',
  },
  clearTracksLabel: {
    id: `${scope}.clearTracksLabel`,
    defaultMessage: 'Clear Tracks',
  },
  okLabel: {
    id: `${scope}.okLabel`,
    defaultMessage: 'Ok',
  },
});
