/* eslint-disable jsx-a11y/no-static-element-interactions */
/* eslint-disable func-names */
/* eslint-disable no-multi-assign */
/* eslint-disable no-underscore-dangle */
/* eslint-disable react/no-this-in-sfc */
/* eslint-disable no-param-reassign */
/**
 *
 * AisVesselTracking
 *
 */

import React, { memo, useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import L from 'leaflet';
import { FormattedMessage } from 'react-intl';
import {
  FormGroup,
  Row,
  Col,
  Button,
  UncontrolledPopover,
  PopoverBody,
  CustomInput,
  Label,
  Input,
  Modal,
  ModalHeader,
  ModalBody,
  ModalFooter,
  Alert,
} from 'reactstrap';
import _ from 'lodash';
import Export from '../AisReportExport/Loadable';
import AutoComplete from '../AutoCompleteTextBox/Loadable';
import LandingVesselTrackingSearch from '../LandingVesselTrackingSearch/Loadable';
import DropDown from '../Dropdown/Loadable';
import PortModal from '../PortModal/Loadable';
import VesselInfoModal from '../VesselInfoModal/Loadable';
import InfoModal from '../InfoModal/Loadable';
import {
  dateTimeConversion,
  poiSelectedCount,
  getVesselCount,
} from '../../utils/dataModification';
import messages from './messages';
import PortIcon from '../../assets/images/Port.png';
import InfoIcon from '../../assets/icons/iIcon.svg';
import {
  createMap,
  AISLandingScreenMap,
  AISLandingPortMap,
  AISPortMovementMap,
  getVesselByFilter,
  AISVesselMovementMap,
  // AISTankerDataMarker,
  // AISStroogDataMarker,
  // AISCargoDataMarker,
  // AISBulkDataMarker,
  // DrawMyZoneAndPolygon,
  DrawMyZoneAndPolygonV1,
  handleMapZoomEvent,
  DrawVesselTrackingLine,
  // DrawMyZoneAndPolygonPort,
  getToolTip,
} from './_helper';
import {
  /* RORO_VESSEL_FILL_COLOR,
  RORO_VESSEL_BORDER_COLOR,
  PASSENGER_VESSEL_FILL_COLOR,
  PASSENGER_VESSEL_BORDER_COLOR,
  CONTAINER_VESSEL_FILL_COLOR,
  CONTAINER_VESSEL_BORDER_COLOR,
  B_CARRIER_VESSEL_FILL_COLOR,
  B_CARRIER_VESSEL_BORDER_COLOR,
  G_CARRIER_VESSEL_FILL_COLOR,
  G_CARRIER_VESSEL_BORDER_COLOR,
  TANKER_VESSEL_FILL_COLOR,
  TANKER_VESSEL_BORDER_COLOR,
  G_CARGO_VESSEL_FILL_COLOR,
  G_CARGO_VESSEL_BORDER_COLOR,
  OTHER_VESSEL_FILL_COLOR,
  OTHER_VESSEL_BORDER_COLOR,
  */
  FETCH_RECORD_COUNT,
  SINGLEVESSEL_ZOOM_LEVEL,
  MY_ZONE_FILL_COLOR,
} from '../../utils/constants';

import './index.scss';
import AisLandingSearch from '../AisLandingSearch/Loadable';
import AisLandingVesselList from '../AisLandingVesselList/Loadable';
import AisVesselPortSearch from '../AisVesselPortSearch/Loadable';
import AisReportExport from '../AisReportExport';
import AisPortSearch from '../AisPortSearch/Loadable';
import DialogBox from '../DialogBox/Loadable';
import AisVesselSearch from '../AisVesselSearch/Loadable';
function AisVesselTracking({
  isClearTextField,
  getShowMyFleetIdList,
  handleBack,
  isLandingMapPage = true,
  isLandingPortMapPage,
  isVesselMapPage,
  isPortMapPage,
  vesselMapModifiedData,
  // aisLandingScreenCenterPosition,
  // aisLandingPortSelectedZoomLevel,
  loadPortOrVesselData,
  fetchAllPortsMapData,
  portMapData,
  portMapModifiedData,
  vesselName,
  portName,
  vesselTypeOptions,
  vesselSizeOptions,
  vesselConditionOptions,
  vesselStatusOptions,
  selectedSearch,
  vesselTypeSelected,
  vesselSizeSelected,
  vesselConditionSelected,
  vesselStatusSelected,
  nextPortSelected,
  vesselDetails,
  portDetails,
  fetchVesselSize,
  fetchPortName,
  fetchVesselName,
  fetchPortDetails,
  fetchPortStatisticDetails,
  fetchVesselData,
  fetchPortMoveMapData,
  fetchAisVesselVoyageDetails,
  fetchAisVesselDetails,
  fetchAisVesselData,
  fetchselectedImoData,
  fetchNearestRangeVesselsByImo,
  searchAppliedFilter,
  fetchAdditionFilterData,
  additionalFilterObj,
  fetchTerminalCodeNames,
  dCancelSearchApply,
  fetchVesselList,
  fetchTankerMapData,
  fetchStroogMapData,
  fetchCargoCarrierMapData,
  fetchBulkContainerMapData,
  moduleId,
  vesselList,
  totalRecords,
  portMovementMapData,
  berthChecked,
  terminalChecked,
  countryName,
  portDetailsValue,
  portDetailsCounts,
  portTypeFilterOption,
  portVesselData,
  portStatisticDetails,
  fetchTerminalCheckboxUpdate,
  fetchBerthCheckboxUpdate,
  fetchSearchVessel,
  fetchFromDate,
  fetchToDate,
  fromDate,
  toDate,
  handleExportPortData,
  dAddVesselRowTableData,
  mainCargoTypeList,
  cargoTypeList,
  terminalsList,
  berthsList,
  operation,
  preiousPortsList,
  charterersList,
  shippersList,
  receiversList,
  agentsList,
  nextPortsList,
  handleVesselItemChanged,
  handleAddVesselMovement,
  hanldeUpdateVesselMovement,
  hanldeDeleteVesselMovement,
  handleCancelVesselMovement,
  commodityList,
  changeFieldName,
  handleSelectedRowData,
  isShowLocaltime,
  isShowLocalTimeMsg,
  berthsData,
  mainCargoTypeData,
  cargoTypeData,
  commodityData,
  dAutoCompletePopover,
  isShowAutoCompletepopOver,
  dTerminalBerthLoadOnEdit,
  vesselOperation,
  dshowLocalTime,
  isModelOpen,
  handleModelClose,
  modelMessage,
  vesselTypes,
  dvesselDetails,
  vvd,
  aisVesselData,
  vSelectedRegion,
  regionOptions,
  countryOptions,
  onRegionSelected,
  onCountrySelected,
  fetchPortCheckboxUpdate,
  vesselsNearestData,
  portChecked,
  aisVesselDetails,
  vesselTotalCount,
  allVesselsData,
  // mapTankerDataMarker,
  // mapStroogDataMarker,
  // mapCargoDataMarker,
  // mapBulkgDataMarker,
  dLandingMarkerCreation,
  currentGridPage,
  fetchAisVesselDraught,
  currentpage,
  isNewLandingPage,
  showMyFleet,
  showFleetClick,
  isShowPoiFilterModal,
  poiFilterOpenClick,
  poiFilterCloseClick,
  poifilterValues,
  poiFilterData,
  cargoTypeTrigger,
  cargoTrigger,
  gradeTrigger,
  shipTypeTrigger,
  shipSizeTrigger,
  berthStyleTrigger,
  vesselTurnAroundTimeTrigger,
  isLoading,
  vesselFormParams,
  vesselMetadata,
  getVesselApiCallByGUI,
  vesselInfoByGUI,
  getVesselDataApiCall,
  loadVesselDataByIMO,
  servicesAvailableTrigger,
  facilitiesAvailableTrigger,
  clearPoiFiltersTrigger,
  clearVesselPortCallFiltersTrigger,
  onVesseelClick,
  show,
  dHandleVesselCallFilterData,
  vesselCallsFilterSearch,
  vesselCallsInitialsSearchData,
  vesselClassification,
  vesselSubTypes,
  conditionOptions,
  statusOptions,
  technicalOwnerData,
  beneficialOwnerData,
  commercialOperatorData,
  registeredOwnerData,
  dGetRegisteredOwnerDetails,
  dGetBeneficialOwnerDetails,
  dGetCommercialOperatorDetails,
  dGetTechnicalOwnerDetails,
  vesselStatusData,
  vesselTypeFormattedData,
  dCloseVesselPopup,
  dGetLastReceivedVessels,
  vesselportcallsFilterData,
  fetchApplyPoiFilters,
  myFleetVesselListCall,
  getSinglePortDataApiCall,
  getSinglePortData,
  dshowPortModal,
  isShowPortModal,
  selectedPortDetail,
  dHandleOwnerDetailsChange,
  vesselFilterValues,
  dVesselTypeClick,
  dVesselClassficationClick,
  dVesselSubTypeClick,
  dVesselConditionClick,
  dVesselStatusClick,
  poiPortData,
  clearAutoCompleteTextField,
  isVesselFilterApplied,
  isPoiFilter,
  isVesselMsgModelOpen,
  dVesselMsgModelClose,
  vesselMsgModelMsg,
  isShowVesselData,
  dvesseldataModal,
  clearSinglePortField,
  vesselFilterDataMarker,
  isPortMsgModelOpen,
  //  portModelMsg,
  dportMsgModelClose,
  vesselFilterCount,
  disPortModalClick,
  vesselMooringStatusOptions,
  disVesselMooringClick,
  disVesselCargoTypeClick,
  disVesselVoyageFromDate,
  disVesselVoyageToDate,
  isVoyageToDateEnable,
  disVoyageNextPortClick,
  vesselPortFilterCount,
  setRetainPortVal,
  fleetFilter,
  dshowMyfleetModal,
  dgetFleetData,
  fleetDataList,
  selectedFleets,
  dhandleCheckbox,
  isShowFleetMsg,
  showMyFleetInfoMsgCloseAction,
  setVesselVoyageFromDate,
  vesselVoyageFromDate,
  vesselVoyageToDate,
  fleetSearchValue,
  dhandleSearchFleet,
  fleetMsg,
  dshowfleetMsg,
  dShowMyZoneToggle,
  showMyZoneGroup,
  myZoneFilter,
  dgetMyzoneData,
  myZoneDataList,
  dShowMyZoneMsgCloseClick,
  dhandleMyZoneCheckBoxChange,
  selectedMyZones,
  dshowMyzoneFilter,
  isShowMyZoneMsgDisplay,
  dshowMyZoneGroupApplyBtnClick,
  selectedMyZoneGroupList,
  isValidFilter,
  zoneSearchValue,
  dhandleSearchZoneFilter,
  dclearHistoricalVessel,
  fetchVesselHistoricalInfo,
  trackData,
  loadVesselFilterObj,
  setVesselFilterObjParams,
}) {
  const mapRef = React.useRef(null);
  const latlanText = React.useRef(null);
  const mapRef3 = React.useRef(null);
  const latlanText3 = React.useRef(null);
  const mapRef4 = React.useRef(null);
  const latlanText4 = React.useRef(null);
  const portPolygonRef = React.useRef(null);
  /* const mapRef5 = React.useRef(null);
  const latlanText5 = React.useRef(null);
  */
  const terminalPolygonRef = React.useRef(null);
  const berthPolygonRef = React.useRef(null);
  const vesselLayerMarkerRef = React.useRef(null);
  // const clusterLayerGroupRef = React.useRef(null);
  const portLayerMarkerRef = React.useRef(null);
  const vesselMarkersRef = React.useRef(null);
  const layerMarkersAroundRef = React.useRef(null);
  const vesselPortLayerMarkerRef = React.useRef(null);
  const stroogClusterLayerGroupRef = React.useRef(null);
  const zoneClusterLayerGroupRef = React.useRef(null);
  const historicalMapRef = React.useRef(new L.FeatureGroup());
  // const zoneClusterLayerGroupRefPort = React.useRef(null);

  const [isloadingTop, handlerefresh] = useState(false);
  const [isShowModal, setModalStatus] = useState(false);
  const [isshowInfoModal, setInfoModal] = useState(false);
  const [isShowTracking, setTrackingComp] = useState(true);
  const [getImoVesselNumber, setImovesselNumber] = useState('');
  const [mapReference, setMapReference] = useState(null);
  let selectimo = '';
  if (vesselMapModifiedData.length > 0) {
    selectimo = vesselMapModifiedData[0].imoVesselNumber;
  }

  // AISLandingScreenMap
  const showPort = <FormattedMessage {...messages.showPort} />;
  const showVessel = <FormattedMessage {...messages.showVessel} />;

  // de-clustering :  start
  let vesselCanvasRenderer = L.canvas({ padding: 0.5 });

  const onDismiss = data => {
    dclearHistoricalVessel(data);
  };

  const clearAllVesselTrack = () => {
    dclearHistoricalVessel('clearAll');
    removeHistoricalLayer();
  };

  const removeLandingPageVessels = () => {
    if (mapRef.current) {
      mapRef.current.eachLayer(function(layer) {
        if (layer._container) {
          if (
            layer._container.nodeName &&
            layer._container.nodeName === 'CANVAS'
          ) {
            mapRef.current.removeLayer(layer);
          }
        } else if (
          !(
            (layer._layers &&
              Object.values(layer._layers).length !== 0 &&
              Object.values(layer._layers)[0].options &&
              Object.values(layer._layers)[0].options.color ===
                MY_ZONE_FILL_COLOR) ||
            (layer.options &&
              layer.options.className &&
              layer.options.className === 'ZoneToolTipStyle') ||
            (layer.options &&
              layer.options.color &&
              layer.options.color === MY_ZONE_FILL_COLOR)
          )
        ) {
          mapRef.current.removeLayer(layer);
        }
      });
    }
  };

  const removePortAndZone = () => {
    if (portLayerMarkerRef && portLayerMarkerRef.current !== null) {
      portLayerMarkerRef.current.clearLayers();
      mapRef.current.removeLayer(portLayerMarkerRef.current);
    }
    if (!showMyZoneGroup) {
      if (
        zoneClusterLayerGroupRef &&
        zoneClusterLayerGroupRef.current !== null
      ) {
        zoneClusterLayerGroupRef.current.clearLayers();
        mapRef.current.removeLayer(zoneClusterLayerGroupRef.current);
        zoneClusterLayerGroupRef.current = null;
      }
    }
  };
  // eslint-disable-next-line arrow-body-style
  useEffect(() => {
    return () => {
      vesselCanvasRenderer = undefined;
      if (mapRef.current !== null) {
        mapRef.current.eachLayer(function(layer) {
          mapRef.current.removeLayer(layer);
        });
      }
      allVesselsData.length = 0;
      mapRef.current = null;
    };
  }, []);

  // de-clustering end

  useEffect(() => {
    if (mapRef && mapRef.current !== null) {
      mapRef.current.invalidateSize();
    }
    if (isLandingMapPage && !isPortMapPage) {
      if (getSinglePortData.length > 0) {
        return;
      }
      if (mapRef && mapRef.current === null) {
        const mapInstance = createMap(mapRef, latlanText, 'map');
        setMapReference(mapInstance);
      }
      setTrackingComp(true);
    }
  }, [isLandingMapPage]);

  useEffect(() => {
    if (isPortMapPage || isVesselMapPage) {
      return;
    }
    if (mapRef && mapRef.current === null) {
      createMap(mapRef, latlanText, 'map');
    }
    // if (isValidFilter || isShowPoiFilterModal) {
    //   return;
    // }

    if (!showMyZoneGroup) {
      if (
        zoneClusterLayerGroupRef &&
        zoneClusterLayerGroupRef.current !== null
      ) {
        zoneClusterLayerGroupRef.current.clearLayers();
        mapRef.current.removeLayer(zoneClusterLayerGroupRef.current);
        zoneClusterLayerGroupRef.current = null;
      }
      return;
    }

    let isSingleSearchPort = false;

    /* vessel filter */
    if (isVesselFilterApplied) {
      if (vesselFilterDataMarker.length === 0) {
        return;
      }
      // vesselDataList = vesselFilterDataMarker;
    }

    /* Show my fleet */
    // if (showMyFleet) {
    //   vesselDataList = vesselFilterDataMarker;
    // }
    /* Single vessel search */
    /* if (
      !isVesselFilterApplied &&
      !showMyFleet &&
      vesselMapModifiedData.length > 0
    ) {
      // vesselDataList = vesselMapModifiedData;
      // SingleVesselDataList = vesselMapModifiedData;
      isSingleSearchVessel = true;
    }
    */
    /* single Port search */
    if (getSinglePortData.length > 0) {
      allVesselsData = [];
      isSingleSearchPort = true;
    }
    if (isLandingPortMapPage) {
      allVesselsData = [];
    }
    if (selectedMyZoneGroupList && selectedMyZoneGroupList.length === 0) {
      if (
        zoneClusterLayerGroupRef &&
        zoneClusterLayerGroupRef.current !== null
      ) {
        zoneClusterLayerGroupRef.current.clearLayers();
        mapRef.current.removeLayer(zoneClusterLayerGroupRef.current);
        zoneClusterLayerGroupRef.current = null;
      }
      return;
    }

    DrawMyZoneAndPolygonV1(
      mapRef,
      selectedMyZoneGroupList,
      zoneClusterLayerGroupRef,
      allVesselsData,
      isSingleSearchPort,
    );
    if (zoneClusterLayerGroupRef && zoneClusterLayerGroupRef.current !== null) {
      zoneClusterLayerGroupRef.current.bringToBack();
    }
    // DrawMyZoneAndPolygon(
    //   mapRef,
    //   zoneClusterLayerGroupRef,
    //   selectedMyZoneGroupList,
    //   aisLandingScreenCenterPosition,
    //   aisLandingPortSelectedZoomLevel,
    //   clusterLayerGroupRef,
    //   // vesselDataList,
    //   allVesselsData,
    //   isSingleSearchVessel,
    //   isSingleSearchPort,
    //   isValidFilter,
    //   isShowPoiFilterModal,
    //   vesselCanvasRenderer,
    // );
  }, [
    selectedMyZoneGroupList,
    showMyZoneGroup,
    allVesselsData,
    vesselMapModifiedData,
    getSinglePortData,
    isValidFilter,
    isLandingPortMapPage,
  ]);

  useEffect(() => {
    if (!isShowModal) {
      handleMapZoomEvent(mapReference, false);
    }
  }, [isShowModal]);

  useEffect(() => {
    if (mapRef && mapRef.current !== null) {
      mapRef.current.invalidateSize();
    }
    if (
      isLandingPortMapPage ||
      getSinglePortData.length > 0 ||
      isPoiFilter ||
      isPortMapPage
    ) {
      return;
    }
    // if (
    //   isVesselFilterApplied ||
    //   (!isVesselFilterApplied && vesselMapModifiedData.length > 0)
    // ) {
    //   return;
    // }
    if (mapRef && mapRef.current === null) {
      createMap(mapRef, latlanText, 'map');
    }
    handleMapZoomEvent(mapReference, false);
    removePortAndZone();
    removeLandingPageVessels();
    if (allVesselsData.length !== 0) {
      const createFeatureGroup = new L.FeatureGroup();
      // const vesselMap = new Map();
      // vesselMap.set(vessel.i, ship);
      allVesselsData.forEach(vessel => {
        const tooltip = getToolTip(vessel);
        const ship = drawVessel(
          Number(vessel.i),
          Number(vessel.l),
          Number(vessel.g),
          vessel.bc,
          vessel.fc,
          vessel.lc !== 'Ballast' ? 1 : 0.3,
          Number(vessel.h),
          Number(vessel.c),
          Number(vessel.s),
          tooltip,
        );
        ship.bindTooltip(tooltip, { className: 'vesselToolTipStyle' });
        createFeatureGroup.addLayer(ship);
      });
      mapRef.current.addLayer(createFeatureGroup);
    } else {
      removeLandingPageVessels();
    }
    if (getVesselCount(allVesselsData) === 1) {
      allVesselsData.forEach(val => {
        if (val) {
          const pt = new L.LatLng(parseFloat(val.l), parseFloat(val.g));
          mapRef.current.setView(pt, SINGLEVESSEL_ZOOM_LEVEL);
        }
      });
    }
    if (zoneClusterLayerGroupRef && zoneClusterLayerGroupRef.current !== null) {
      zoneClusterLayerGroupRef.current.bringToBack();
    }
    dLandingMarkerCreation();
  }, [allVesselsData, isVesselFilterApplied, isPoiFilter]);

  useEffect(() => {
    if (trackData && trackData.length > 0) {
      removeHistoricalLayer();
      // eslint-disable-next-line array-callback-return
      trackData.map(item => {
        DrawVesselTrackingLine(mapRef, item.data, historicalMapRef);
      });
    } else {
      removeHistoricalLayer();
    }
  }, [trackData]);

  const removeHistoricalLayer = () => {
    historicalMapRef.current.remove();
    historicalMapRef.current.clearLayers();
    mapRef.current.removeLayer(historicalMapRef.current);
  };

  useEffect(() => {
    if (mapRef && mapRef.current !== null) {
      mapRef.current.invalidateSize();
    }
    if (getSinglePortData.length === 0) {
      return;
    }
    if (mapRef && mapRef.current === null) {
      createMap(mapRef, latlanText, 'map');
    }
    const convertArray = Object.assign({}, ...getSinglePortData);
    const { _latlng } = convertArray;
    const portZoomLevel = 9;
    if (!_latlng) {
      // setInfoModal(!isshowInfoModal);
    } else {
      removeLandingPageVessels();
      const getportMarker = AISLandingScreenMap(
        mapRef,
        // clusterLayerGroupRef,
        getSinglePortData,
        _latlng,
        portZoomLevel,
        stroogClusterLayerGroupRef,
        portLayerMarkerRef,
      );
      if (getportMarker) {
        getportMarker.eachLayer(layer => {
          const {
            portid,
            portname,
            unlocode,
            countrycode,
            lat,
            lng,
          } = layer.options.icon.options;
          const options = {
            isShow: true,
            portid,
            portname,
            unlocode,
            countrycode,
            lat,
            lng,
          };
          layer.on('click', e => {
            e.originalEvent.preventDefault();
            e.originalEvent.stopPropagation();
            disPortModalClick(true);
            dshowPortModal(options);
          });
        });
      }
    }
  }, [getSinglePortData]);

  useEffect(() => {
    if (
      isLandingPortMapPage &&
      getSinglePortData.length === 0 &&
      !isPortMapPage
    ) {
      if (mapRef && mapRef.current === null) {
        createMap(mapRef, latlanText, 'map');
      }
      if (isValidFilter) {
        return;
      }
      if (portMapModifiedData && portMapModifiedData.length > 0) {
        removeLandingPageVessels();
        const getportMarker = AISLandingPortMap(
          mapRef,
          portLayerMarkerRef,
          portMapModifiedData,
          // clusterLayerGroupRef,
          stroogClusterLayerGroupRef,
        );
        if (getportMarker) {
          getportMarker.eachLayer(layer => {
            const {
              portid,
              portname,
              unlocode,
              countrycode,
              lat,
              lng,
            } = layer.options.icon.options;
            const options = {
              isShow: true,
              portid,
              portname,
              unlocode,
              countrycode,
              lat,
              lng,
            };
            layer.on('click', e => {
              e.originalEvent.preventDefault();
              e.originalEvent.stopPropagation();
              disPortModalClick(true);
              dshowPortModal(options);
            });
          });
        }
      }
    }
  }, [isLandingPortMapPage, portMapModifiedData]);

  const onOptionChange = event => {
    if (event.target.id === 'ShowVessel') {
      loadPortOrVesselData('vessel');
    } else if (event.target.id === 'ShowPort') {
      if (portMapData && portMapData.length > 0) {
        loadPortOrVesselData('port');
      } else {
        fetchAllPortsMapData(true);
      }
    }
  };

  const showTrackingComponent = () => {
    setTrackingComp(!isShowTracking);
  };
  // AISLandingPortScreenMap
  /*
  useEffect(() => {
    if (isLandingPortMapPage) {
      if (mapRef && mapRef.current !== null) {
        mapRef.current = null;
      }
      if (mapRef && mapRef.current === null) {
        createMap(mapRef, latlanText, 'map');
      }
    }
  }, [isLandingPortMapPage]);

  */
  /*
  useEffect(() => {
    if (getSinglePortData.length > 0) {
      if (mapRef5 && mapRef5.current === null) {
        createMap(mapRef5, latlanText5, 'map5');
      }
    }
  }, [getSinglePortData]);
  */

  // AISPortMovementMap
  useEffect(() => {
    if (isPortMapPage) {
      if (mapRef3 && mapRef3.current === null) {
        createMap(mapRef3, latlanText3, 'map3');
      }
    }
  }, [isPortMapPage]);

  useEffect(() => {
    if (isPortMapPage) {
      if (mapRef3 && mapRef3.current === null) {
        createMap(mapRef3, latlanText3, 'map3');
      }

      if (portMapModifiedData) {
        AISPortMovementMap(
          mapRef3,
          vesselLayerMarkerRef,
          terminalPolygonRef,
          berthPolygonRef,
          portMovementMapData,
          portPolygonRef,
          berthChecked,
          terminalChecked,
          countryName,
        );
      }
      if (currentGridPage === 0 && !isloadingTop) {
        window.scrollTo(0, 0);
      }
    }
  }, [portMovementMapData, berthChecked, terminalChecked]);
  const onTerminalCheckBoxClicked = evt => {
    fetchTerminalCheckboxUpdate({
      type: evt.target.id,
      terminalChecked: evt.target.checked,
    });
  };
  const onBerthCheckBoxClicked = evt => {
    fetchBerthCheckboxUpdate({
      type: evt.target.id,
      berthChecked: evt.target.checked,
    });
  };
  const portIdvalue = portDetailsValue ? portDetailsValue.portId : '';
  const handleExport = () => {
    const options = {
      portId: portIdvalue,
      pageNo: 0,
      fetchRecordCount: 100000,
    };
    handleExportPortData(options);
  };
  const getVesselData = value => {
    const options = {
      portId: portIdvalue,
      pageNo: value.pageNo,
      fetchRecordCount: value.fetchRecordCount,
    };
    fetchVesselData(options);
  };

  const handleLocaltime = evt => {
    dshowLocalTime(evt.target.checked);
    handlerefresh(true);
    const options = {
      portId: portIdvalue,
      pageNo: 0,
      fetchRecordCount: FETCH_RECORD_COUNT,
    };
    fetchVesselData(options);
  };
  let latitude = '';
  let longitude = '';
  if (portDetailsValue !== undefined && portDetailsValue.portCoordinates) {
    const index = 0;
    const { coordinates } = JSON.parse(portDetailsValue.portCoordinates);
    latitude = coordinates[index + 1];
    longitude = coordinates[index];
  }
  let portVesselDataFilter = portVesselData;
  if (portTypeFilterOption.length > 0) {
    portVesselDataFilter = portVesselData.filter(item =>
      portTypeFilterOption.includes(item.wopvesseltypeId),
    );
  }
  const [panel, setPanel] = useState(false);
  const toggleButton = () => {
    if (!panel) {
      setPanel(true);
    } else {
      setPanel(false);
    }
  };
  const hanldecheckbox = value => {
    let ischeck = false;
    if (_.includes(portTypeFilterOption, value)) {
      ischeck = true;
    }
    return ischeck;
  };
  const fgetSearchVessel = e => {
    handlerefresh(true);
    const option = e.target.value;
    fetchSearchVessel(option);
    const options = {
      portId: portIdvalue,
      pageNo: 0,
      fetchRecordCount: FETCH_RECORD_COUNT,
    };
    fetchVesselData(options);
  };
  // AISVesselMovementMap

  useEffect(() => {
    if (isVesselMapPage) {
      if (mapRef4 && mapRef4.current === null) {
        createMap(mapRef4, latlanText4, 'map4');
      }
    }
  }, [isVesselMapPage]);

  useEffect(() => {
    if (isVesselMapPage) {
      if (mapRef4 && mapRef4.current === null) {
        createMap(mapRef4, latlanText4, 'map4');
      }

      if (vvd) {
        AISVesselMovementMap(
          mapRef4,
          vesselMarkersRef,
          layerMarkersAroundRef,
          vesselPortLayerMarkerRef,
          vvd,
          vesselsNearestData,
          portMapModifiedData,
          portChecked,
        );
      }
      if (currentGridPage === 0 && !isloadingTop) {
        window.scrollTo(0, 0);
      }
    }
  }, [vvd, vesselsNearestData, portMapModifiedData, portChecked]);

  const regionSelector = evt => {
    onRegionSelected(evt.target.value, evt.target.selectedOptions[0].text);
    const options = {
      imo: aisVesselDetails.imo,
      pageNo: 0,
      fetchRecordCount: FETCH_RECORD_COUNT,
    };
    fetchAisVesselData(options);
  };
  const onPortCheckBoxClicked = evt => {
    fetchPortCheckboxUpdate({
      type: evt.target.id,
      portChecked: evt.target.checked,
    });
    if (!portMapData || portMapData.length === 0) {
      fetchAllPortsMapData(false);
    }
  };
  const countrySelector = evt => {
    onCountrySelected(evt.target.value, evt.target.selectedOptions[0].text);
    const options = {
      imo: aisVesselDetails.imo,
      pageNo: 0,
      fetchRecordCount: FETCH_RECORD_COUNT,
    };
    fetchAisVesselData(options);
  };

  const onNextPortSelected = (evt, type) => {
    nextPortSelected(evt.split('^')[0], evt.split('^')[1], type);
    const options = {
      imo: aisVesselDetails.imo,
      pageNo: 0,
      fetchRecordCount: FETCH_RECORD_COUNT,
    };
    fetchAisVesselData(options);
  };

  const toggleModalStatus = (getModalStatus, modalType) => {
    if (modalType === 'vesselInfo') {
      setModalStatus(getModalStatus);
    } else if (modalType === 'infoModal') {
      setInfoModal(!isshowInfoModal);
      clearSinglePortField();
    } else if (modalType === 'vesselFilterInfoModal') {
      dVesselMsgModelClose();
    } else if (modalType === 'poiFilterInfoModal') {
      dportMsgModelClose();
    }
  };
  const handlevesselLocaltime = evt => {
    dshowLocalTime(evt.target.checked);
    handlerefresh(true);
    const options = {
      imo: aisVesselDetails.imo,
      pageNo: 0,
      fetchRecordCount: FETCH_RECORD_COUNT,
    };
    fetchAisVesselData(options);
  };
  const getAisVesselData = value => {
    const options = {
      imo: aisVesselDetails.imo,
      pageNo: value.pageNo,
      fetchRecordCount: value.fetchRecordCount,
    };
    fetchAisVesselData(options);
  };
  let latd = '';
  let langd = '';
  const index = 0;
  let coordinate = [];
  const mapData = [];
  if (vvd && vvd.vesselLatLng) {
    coordinate = JSON.parse(vvd.vesselLatLng);
    if (coordinate.coordinates) {
      latd = coordinate.coordinates[index + 1];
      langd = coordinate.coordinates[index];
    }
    const obj = {
      vesselBreadth: vvd.vesselBreadth,
      vesselHeading: vvd.vesselHeading ? vvd.vesselHeading : 50,
      vesselLatLng: vvd.vesselLatLng,
      vesselLength: vvd.vesselLength,
      vesselName: vvd.vesselName,
      vesselSpeed: vvd.vesselSpeed,
      vesselType: vvd.vesselType,
      latitude: latd,
      longitude: langd,
    };
    mapData.push(obj);
  }
  const aisVesselDataFilter = getVesselByFilter(
    aisVesselData,
    vSelectedRegion,
    selectedSearch,
  );
  const vesselImo = vesselDetails ? vesselDetails.imo : '';
  const [vPanel, setVPanel] = useState(false);
  const vToggleButton = () => {
    setVPanel(!vPanel);
  };
  const handleVExport = () => {
    const options = {
      imo: vvd.imo,
      pageNo: 0,
      fetchRecordCount: 100000,
    };
    handleExportPortData(options);
  };
  const handleBackBtn = getVesselBackBtnClicked => {
    handlerefresh(false);
    setTrackingComp(true);
    handleBack();
    if (getVesselBackBtnClicked) {
      setModalStatus(true);
    }
  };
  const showInfoModal = type => (
    <InfoModal type={type} toggleModalStatus={toggleModalStatus} />
  );
  const vesselToggle = () => {
    dvesseldataModal();
  };
  const veselundefined = !!(vvd && vvd.vesselNavigationalStatus !== undefined);
  let selectVesselName = null;
  let selectVesselImo = null;
  let selectVesselStatus = null;
  if (
    vesselDetails &&
    vesselDetails.vesselName !== undefined &&
    selectVesselName === null
  ) {
    selectVesselName = vesselDetails.vesselName;
    selectVesselImo = vesselDetails.imo;
    selectVesselStatus = vesselDetails.vesselStatus;
  }
  if (vvd && vvd.vesselName !== undefined && selectVesselName === null) {
    selectVesselName = vvd.vesselName;
    selectVesselImo = vvd.imo;
  }
  let showVesselStatus = false;
  if (
    selectVesselStatus === 'Dead' ||
    selectVesselStatus === 'Existence in doubt'
  ) {
    showVesselStatus = true;
  }
  const poifilterCount = poiSelectedCount(poifilterValues);

  /* function drawAllVessels(vessel) {
    const vesselMap = new Map();
    const tooltip = getToolTip(vessel);
    const ship = drawVessel(
      Number(vessel.i),
      Number(vessel.l),
      Number(vessel.g),
      vessel.bc,
      vessel.fc,
      vessel.lc !== 'Ballast' ? 1 : 0.3,
      Number(vessel.h),
      Number(vessel.c),
      Number(vessel.s),
      tooltip,
    );
    ship.bindTooltip(tooltip, { className: 'vesselToolTipStyle' });
    vesselMap.set(vessel.i, ship);
    return vesselMap;
  }
  */
  function drawVessel(
    imo,
    lat,
    lon,
    color,
    fillColor,
    fillOpacity,
    heading,
    course,
    speed,
  ) {
    const theVesselMarker = new VesselMarker([lat, lon], {
      color,
      weight: 0.7,
      fill: true,
      fillColor,
      fillOpacity,
      heading,
      course,
      speed,
      renderer: vesselCanvasRenderer,
    });
    theVesselMarker.on('click', function onmouseover() {
      // event.preventDefault();
      // e.originalEvent.stopPropagation();
      disPortModalClick(false);
      setModalStatus(true);
      getVesselDataApiCall(imo);
      setImovesselNumber(imo);
    });
    return theVesselMarker;
  }
  /* function drawAllVesselsV2(vesselMap1, vesseljson, bordercolor, fillcolor) {
    // vesselMap.current.clear();
    const vesselMap = new Map();
    let ship;
    let tooltip;
    // const vesselMap = new Map();
    vesseljson.forEach(vessel => {
      // vessel = vesseljson[i];
      tooltip = getToolTip(vessel);
      ship = drawVessel(
        Number(vessel.i),
        Number(vessel.l),
        Number(vessel.g),
        bordercolor,
        fillcolor,
        vessel.lc !== 'Ballast' ? 1 : 0.3,
        Number(vessel.h),
        Number(vessel.c),
        Number(vessel.s),
        tooltip,
      );
      ship.bindTooltip(tooltip, { className: 'vesselToolTipStyle' });
      vesselMap.set(vessel.i, ship);
    });
    return vesselMap;
  }
  */
  let VesselMarker = L.Path.extend({
    // @section
    // @aka CircleMarker options
    options: {
      fill: true,
      heading: 0,
      course: 0,
      speed: 0,
    },

    initialize(latlng, options) {
      L.Util.setOptions(this, options);
      this._latlng = L.latLng(latlng);
      this._heading = this.options.heading;
      this._course = this.options.course;
      this._speed = this.options.speed;
    },

    // @method setLatLng(latLng: LatLng): this
    // Sets the position of a vessel marker to a new location.
    setLatLng(latlng) {
      const oldLatLng = this._latlng;
      this._latlng = L.latLng(latlng);
      this.redraw();

      // @event move: Event
      // Fired when the marker is moved via [`setLatLng`](#vesselmarker-setlatlng). Old and new coordinates are included in event arguments as `oldLatLng`, `latlng`.
      return this.fire('move', {
        oldLatLng,
        latlng: this._latlng,
      });
    },

    // @method getLatLng(): LatLng
    // Returns the current geographical position of the vessel marker
    getLatLng() {
      return this._latlng;
    },

    // @method setHeading(heading: Number): this
    // Sets the heading of a Vessel marker. Units are in pixels.
    setHeading(heading) {
      this.options.heading = this._heading = heading;
      return this.redraw();
    },

    // @method getHeading(): Number
    // Returns the current heading of the Vessel marker
    getHeading() {
      return this._heading;
    },

    // @method setCourse(course: Number): this
    // Sets the course of a Vessel marker. Units are in pixels.
    setCourse(course) {
      this.options.course = this._course = course;
      return this.redraw();
    },

    // @method getCourse(): Number
    // Returns the current course of the Vessel marker
    getCourse() {
      return this._course;
    },

    // @method setSpeed(speed: Number): this
    // Sets the speed of a Vessel marker. Units are in pixels.
    setSpeed(speed) {
      this.options.speed = this._speed = speed;
      return this.redraw();
    },

    // @method getSpeed(): Number
    // Returns the current speed of the Vessel marker
    getSpeed() {
      return this._speed;
    },

    setStyle(options) {
      const heading = (options && options.heading) || this._heading;
      const course = (options && options.course) || this._course;
      const speed = (options && options.speed) || this._speed;
      L.Path.prototype.setStyle.call(this, options);
      this.setHeading(heading);
      this.setCourse(course);
      this.setSpeed(speed);
      return this;
    },

    _project() {
      this._point = this._map.latLngToLayerPoint(this._latlng);
      this._updateBounds();
    },

    _updateBounds() {
      const r = 5;
      const r2 = r;
      const w = this._clickTolerance();
      const p = [r + w, r2 + w];
      this._pxBounds = new L.Bounds(
        this._point.subtract(p),
        this._point.add(p),
      );
    },

    _update() {
      if (this._map) {
        this._updatePath();
      }
    },

    _updatePath() {
      this._renderer._updateVessel(this);
    },

    _empty() {
      return this._radius && !this._renderer._bounds.intersects(this._pxBounds);
    },

    // Needed by the `Canvas` renderer for interactivity
    _containsPoint(p) {
      return p.distanceTo(this._point) <= 5 + this._clickTolerance();
    },
  });

  // function addBulkCarrierVesselsToLayer(vessel) {
  //   BulkCarrierVessels.current.addLayer(vessel);
  // }
  // function addTankerVesselsToLayer(vessel) {
  //   TankerVessels.current.addLayer(vessel);
  // }
  // function addGeneralCargoVesselsToLayer(vessel) {
  //   GeneralCargoVessels.current.addLayer(vessel);
  // }
  // function addContainersVesselsToLayer(vessel) {
  //   ContainerVessels.current.addLayer(vessel);
  // }
  // // function addOtherVesselsToLayer(vessel) {
  // //   OtherVessels.current.addLayer(vessel);
  // // }
  // function addGasCarrierVesselsToLayer(vessel) {
  //   GasCarrierVessels.current.addLayer(vessel);
  // }
  // // function addRoRoVesselsToLayer(vessel) {
  // //   RoRoVessels.current.addLayer(vessel);
  // // }
  // function addPassengersVesselToLayer(vessel) {
  //   passengerVessels.current.addLayer(vessel);
  // }
  const handleOpenVessel = imo => {
    disPortModalClick(false);
    setModalStatus(true);
    getVesselDataApiCall(imo);
    setImovesselNumber(imo);
  };
  return (
    <>
      <div className="displayNone">
        <Button
          id="vesselId"
          value={`vesselId${selectimo}`}
          onClick={() => handleOpenVessel(selectimo)}
        />
      </div>

      {isshowInfoModal && showInfoModal('portInfo')}

      <Row
        className={!isLandingMapPage || isNewLandingPage ? 'displayNone' : ''}
      >
        <Col xs={10}>
          <FormGroup className="mt-0 mb-0 pb-3 pt-3 d-flex form-container">
            <CustomInput
              label={showVessel}
              className="pr-3"
              type="radio"
              id="ShowVessel"
              name="switchVessel"
              checked={!isLandingPortMapPage}
              onChange={evt => onOptionChange(evt)}
            />

            <CustomInput
              label={showPort}
              className="pr-3"
              type="radio"
              id="ShowPort"
              name="switchView"
              checked={isLandingPortMapPage}
              onChange={evt => onOptionChange(evt)}
            />
          </FormGroup>
        </Col>
        <Col xs={2} className="text-right pt-1">
          <Button id="vessel-info-show" color="link">
            <img
              src={InfoIcon}
              alt="notification-icon"
              width="24px"
              height="24px"
            />
          </Button>
          <UncontrolledPopover
            trigger="focus"
            placement="bottom"
            target="vessel-info-show"
          >
            <PopoverBody>
              <Col xs={12} className="pl-0 pr-0">
                <h4 className="mb-2">Ship Type</h4>
              </Col>
              <Col xs={12} className="pl-0 pr-0">
                <p className="mb-1">
                  <div className="color vessel-marker-red mr-2 mt-1" />
                  Bulk Carrier
                </p>
                <p className="mb-1">
                  <div className="color vessel-marker-paleorange mr-2 mt-1" />
                  Gas Carrier
                </p>
                <p className="mb-1">
                  <div className="color vessel-marker-pink mr-2 mt-1" />
                  General Cargo
                </p>
                <p className="mb-1">
                  <div className="color vessel-marker-light-blue mr-2 mt-1" />
                  Passenger
                </p>
                <p className="mb-1">
                  <div className="color vessel-marker-orange mr-2 mt-1" />
                  Container
                </p>
                <p className="mb-1">
                  <div className="color vessel-marker-green mr-2 mt-1" />
                  Tanker
                </p>
                <p className="mb-1">
                  <div className="color vessel-marker-brawn mr-2 mt-1" />
                  RoRo
                </p>
                <p className="mb-1">
                  <div className="color vessel-marker-grey mr-2 mt-1" />
                  Others
                </p>
                <p className="mb-1">
                  <div className="color vessel-marker-black mr-2 mt-1 text-center">
                    <span className="ballast-color ballast-marker-white" />
                  </div>
                  Ballast
                </p>
              </Col>
              <Col xs={12} className="pl-0 pr-0">
                <h4 className="mb-2">POI Type</h4>
              </Col>
              <Col xs={12} className="pl-0 pr-0">
                <div className="mb-1">
                  <img src={PortIcon} className="poiIcon" alt="Port Icon" />{' '}
                  Port
                </div>
              </Col>
            </PopoverBody>
          </UncontrolledPopover>
        </Col>
      </Row>

      <Row className="mapDiv">
        <Col xs={12} className="mt-1" style={{ padding: '0px' }}>
          <div
            className={!isLandingMapPage ? 'displayNone' : ''}
            style={{ padding: '0px' }}
          >
            <div id="map">
              {isLandingMapPage && (
                <Row
                  xs={12}
                  className={
                    !isLandingMapPage || isNewLandingPage
                      ? 'searchDiv'
                      : 'displayNone'
                  }
                >
                  <LandingVesselTrackingSearch
                    isClearTextField={isClearTextField}
                    vesselVoyageFromDate={vesselVoyageFromDate}
                    vesselVoyageToDate={vesselVoyageToDate}
                    setVesselVoyageFromDate={setVesselVoyageFromDate}
                    showMyFleetInfoMsgCloseAction={
                      showMyFleetInfoMsgCloseAction
                    }
                    isShowFleetMsg={isShowFleetMsg}
                    getShowMyFleetIdList={getShowMyFleetIdList}
                    setRetainPortVal={setRetainPortVal}
                    disVoyageNextPortClick={disVoyageNextPortClick}
                    isVoyageToDateEnable={isVoyageToDateEnable}
                    disVesselVoyageFromDate={disVesselVoyageFromDate}
                    disVesselVoyageToDate={disVesselVoyageToDate}
                    disVesselCargoTypeClick={disVesselCargoTypeClick}
                    cargoTypeData={cargoTypeData}
                    disVesselMooringClick={disVesselMooringClick}
                    vesselMooringStatusOptions={vesselMooringStatusOptions}
                    clearAutoCompleteTextField={clearAutoCompleteTextField}
                    getSinglePortDataApiCall={getSinglePortDataApiCall}
                    vesselName={vesselName}
                    portName={portName}
                    fetchPortName={fetchPortName}
                    fetchVesselName={fetchVesselName}
                    selectedSearch={selectedSearch}
                    searchAppliedFilter={searchAppliedFilter}
                    nextPortSelected={nextPortSelected}
                    isNewLandingPage={isNewLandingPage}
                    showFleetClick={showFleetClick}
                    showMyFleet={showMyFleet}
                    poiFilterOpenClick={poiFilterOpenClick}
                    poiFilterCloseClick={poiFilterCloseClick}
                    isShowPoiFilterModal={isShowPoiFilterModal}
                    regionOptions={regionOptions}
                    onRegionSelected={onRegionSelected}
                    poifilterValues={poifilterValues}
                    countryOptions={countryOptions}
                    onCountrySelected={onCountrySelected}
                    poiFilterData={poiFilterData}
                    cargoTypeTrigger={cargoTypeTrigger}
                    cargoTrigger={cargoTrigger}
                    gradeTrigger={gradeTrigger}
                    shipSizeTrigger={shipSizeTrigger}
                    shipTypeTrigger={shipTypeTrigger}
                    berthStyleTrigger={berthStyleTrigger}
                    vesselTurnAroundTimeTrigger={vesselTurnAroundTimeTrigger}
                    isLoading={isLoading}
                    servicesAvailableTrigger={servicesAvailableTrigger}
                    facilitiesAvailableTrigger={facilitiesAvailableTrigger}
                    clearPoiFiltersTrigger={clearPoiFiltersTrigger}
                    clearVesselPortCallFiltersTrigger={
                      clearVesselPortCallFiltersTrigger
                    }
                    onVesseelClick={onVesseelClick}
                    show={show}
                    vesselTypeFormattedData={vesselTypeFormattedData}
                    dHandleVesselCallFilterData={dHandleVesselCallFilterData}
                    vesselCallsFilterSearch={vesselCallsFilterSearch}
                    vesselCallsInitialsSearchData={
                      vesselCallsInitialsSearchData
                    }
                    vesselClassification={vesselClassification}
                    vesselSubTypes={vesselSubTypes}
                    conditionOptions={conditionOptions}
                    statusOptions={statusOptions}
                    technicalOwnerData={technicalOwnerData}
                    beneficialOwnerData={beneficialOwnerData}
                    commercialOperatorData={commercialOperatorData}
                    registeredOwnerData={registeredOwnerData}
                    dGetRegisteredOwnerDetails={dGetRegisteredOwnerDetails}
                    dGetBeneficialOwnerDetails={dGetBeneficialOwnerDetails}
                    dGetCommercialOperatorDetails={
                      dGetCommercialOperatorDetails
                    }
                    dGetTechnicalOwnerDetails={dGetTechnicalOwnerDetails}
                    vesselStatusData={vesselStatusData}
                    dCloseVesselPopup={dCloseVesselPopup}
                    dGetLastReceivedVessels={dGetLastReceivedVessels}
                    vesselportcallsFilterData={vesselportcallsFilterData}
                    fetchAllPortsMapData={fetchAllPortsMapData}
                    fetchApplyPoiFilters={fetchApplyPoiFilters}
                    loadPortOrVesselData={loadPortOrVesselData}
                    poifilterCount={poifilterCount}
                    myFleetVesselListCall={myFleetVesselListCall}
                    dHandleOwnerDetailsChange={dHandleOwnerDetailsChange}
                    dLandingMarkerCreation={dLandingMarkerCreation}
                    vesselFilterValues={vesselFilterValues}
                    dVesselTypeClick={dVesselTypeClick}
                    dVesselClassficationClick={dVesselClassficationClick}
                    dVesselSubTypeClick={dVesselSubTypeClick}
                    dVesselConditionClick={dVesselConditionClick}
                    dVesselStatusClick={dVesselStatusClick}
                    isVesselMsgModelOpen={isVesselMsgModelOpen}
                    dVesselMsgModelClose={dVesselMsgModelClose}
                    vesselMsgModelMsg={vesselMsgModelMsg}
                    vesselFilterCount={vesselFilterCount}
                    isVesselFilterApplied={isVesselFilterApplied}
                    vesselPortFilterCount={vesselPortFilterCount}
                    myFleetVesselListData={vesselFilterDataMarker}
                    fleetFilter={fleetFilter}
                    dshowMyfleetModal={dshowMyfleetModal}
                    dgetFleetData={dgetFleetData}
                    fleetDataList={fleetDataList}
                    selectedFleets={selectedFleets}
                    dhandleCheckbox={dhandleCheckbox}
                    fleetSearchValue={fleetSearchValue}
                    dhandleSearchFleet={dhandleSearchFleet}
                    dShowMyZoneToggle={dShowMyZoneToggle}
                    showMyZoneGroup={showMyZoneGroup}
                    myZoneFilter={myZoneFilter}
                    dgetMyzoneData={dgetMyzoneData}
                    myZoneDataList={myZoneDataList}
                    dShowMyZoneMsgCloseClick={dShowMyZoneMsgCloseClick}
                    dhandleMyZoneCheckBoxChange={dhandleMyZoneCheckBoxChange}
                    selectedMyZones={selectedMyZones}
                    dshowMyzoneFilter={dshowMyzoneFilter}
                    isShowMyZoneMsgDisplay={isShowMyZoneMsgDisplay}
                    dshowMyZoneGroupApplyBtnClick={
                      dshowMyZoneGroupApplyBtnClick
                    }
                    handleMapZoomEvent={handleMapZoomEvent}
                    mapReference={mapReference}
                    zoneSearchValue={zoneSearchValue}
                    dhandleSearchZoneFilter={dhandleSearchZoneFilter}
                    trackData={trackData}
                    loadVesselFilterObj={loadVesselFilterObj}
                    setVesselFilterObjParams={setVesselFilterObjParams}
                    handleOpenVessel={handleOpenVessel}
                    selectimo={selectimo}
                  />

                  {fleetMsg.isShowFleetMsg && (
                    <DialogBox
                      show={fleetMsg.isShowFleetMsg}
                      fetchModelClose={dshowfleetMsg}
                      title="Warning"
                      statusCode=""
                      content={fleetMsg.fleetmessage}
                    />
                  )}
                </Row>
              )}
              {trackData.length > 0 && (
                <Row className="historicaltrackDiv">
                  <Col xs={12}>
                    <ul>
                      {trackData.map((data, keyindex) => (
                        <li
                          id={`vslkey ${keyindex}`}
                          // eslint-disable-next-line react/no-array-index-key
                          key={`key_${keyindex}`}
                        >
                          <Alert
                            color="info"
                            isOpen={data.imo}
                            toggle={() => onDismiss(data)}
                          >
                            {data.vesselName.length > 20
                              ? `${data.vesselName.substring(0, 20)}...`
                              : data.vesselName}
                          </Alert>
                        </li>
                      ))}
                      <li>
                        <Button
                          color="link"
                          onClick={() => clearAllVesselTrack()}
                        >
                          <FormattedMessage {...messages.clearTracksLabel} />
                        </Button>
                      </li>
                    </ul>
                  </Col>
                </Row>
              )}
              {isShowModal && (
                <VesselInfoModal
                  showTrackingComponent={showTrackingComponent}
                  getVesselDataApiCall={getVesselDataApiCall}
                  loadVesselDataByIMO={loadVesselDataByIMO}
                  getVesselByGUI={getVesselApiCallByGUI}
                  vesselInformation={vesselInfoByGUI}
                  vesselMetadata={vesselMetadata}
                  landingVesselTypes={vesselTypes}
                  vesselFormParams={vesselFormParams}
                  vesselDetails={vesselDetails}
                  fetchAisVesselVoyageDetails={fetchAisVesselVoyageDetails}
                  fetchAisVesselDetails={fetchAisVesselDetails}
                  fetchAisVesselData={fetchAisVesselData}
                  fetchselectedImoData={fetchselectedImoData}
                  fetchNearestRangeVesselsByImo={fetchNearestRangeVesselsByImo}
                  imoVesselNumber={getImoVesselNumber}
                  isShowModal={isShowModal}
                  toggleModalStatus={toggleModalStatus}
                  handleMapZoomEvent={handleMapZoomEvent}
                  mapReference={mapReference}
                  fetchVesselHistoricalInfo={fetchVesselHistoricalInfo}
                  historicalData={trackData}
                  mapRef={mapRef}
                />
              )}

              {isShowPortModal && (
                <PortModal
                  isShowPortModal={isShowPortModal}
                  dshowPortModal={dshowPortModal}
                  selectedPortDetail={selectedPortDetail}
                  poiPortData={poiPortData}
                  poifilterValues={poifilterValues}
                  countryOptions={countryOptions}
                  selectedSearch={selectedSearch}
                  poiFilterData={poiFilterData}
                  poiFilterCount={poifilterValues.poiCount}
                  portDetails={portDetails}
                  fetchPortDetails={fetchPortDetails}
                  fetchPortStatisticDetails={fetchPortStatisticDetails}
                  fetchVesselData={fetchVesselData}
                  fetchPortMoveMapData={fetchPortMoveMapData}
                  fetchTerminalCodeNames={fetchTerminalCodeNames}
                  setTrackingComp={setTrackingComp}
                  handleMapZoomEvent={handleMapZoomEvent}
                  mapReference={mapReference}
                  mapRef={mapRef}
                />
              )}
              {isVesselMsgModelOpen && showInfoModal('vesselFilterInfoModal')}
              {isPortMsgModelOpen && showInfoModal('poiFilterInfoModal')}

              <div className="overlay app-progress">
                <div className="overlay__inner">
                  <div className="overlay__content">
                    <span className="spinner" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </Col>
      </Row>

      {/* <Row>
        <Col xs={12}>
          <div
            className={!isLandingPortMapPage ? 'displayNone' : ''}
            style={{ padding: '0px' }}
          >
            <div
              id="map2"
              style={{
                border: 'none !important',
                borderRadius: 'none !important',
              }}
            />
          </div>
        </Col>
      </Row> */}
      <Row>
        <Col xs={12}>
          <div className={getSinglePortData.length > 0 ? 'displayNone' : ''}>
            <div id="map5" />
          </div>
        </Col>
      </Row>
      <div
        className={!isLandingMapPage || isNewLandingPage ? 'displayNone' : ''}
      >
        <AisLandingSearch
          vesselName={vesselName}
          portName={portName}
          vesselTypeOptions={vesselTypeOptions}
          vesselSizeOptions={vesselSizeOptions}
          vesselConditionOptions={vesselConditionOptions}
          vesselStatusOptions={vesselStatusOptions}
          vesselTypeSelected={vesselTypeSelected}
          vesselSizeSelected={vesselSizeSelected}
          vesselConditionSelected={vesselConditionSelected}
          vesselStatusSelected={vesselStatusSelected}
          nextPortSelected={nextPortSelected}
          selectedSearch={selectedSearch}
          vesselDetails={vesselDetails}
          portDetails={portDetails}
          fetchVesselSize={fetchVesselSize}
          fetchPortName={fetchPortName}
          fetchVesselName={fetchVesselName}
          fetchPortDetails={fetchPortDetails}
          fetchPortStatisticDetails={fetchPortStatisticDetails}
          fetchVesselData={fetchVesselData}
          fetchPortMoveMapData={fetchPortMoveMapData}
          fetchAisVesselVoyageDetails={fetchAisVesselVoyageDetails}
          fetchAisVesselDetails={fetchAisVesselDetails}
          fetchAisVesselData={fetchAisVesselData}
          fetchselectedImoData={fetchselectedImoData}
          fetchNearestRangeVesselsByImo={fetchNearestRangeVesselsByImo}
          fetchAdditionFilterData={fetchAdditionFilterData}
          searchAppliedFilter={searchAppliedFilter}
          additionalFilterObj={additionalFilterObj}
          fetchTerminalCodeNames={fetchTerminalCodeNames}
          dCancelSearchApply={dCancelSearchApply}
          fetchVesselList={fetchVesselList}
          fetchTankerMapData={fetchTankerMapData}
          fetchStroogMapData={fetchStroogMapData}
          fetchCargoCarrierMapData={fetchCargoCarrierMapData}
          fetchBulkContainerMapData={fetchBulkContainerMapData}
          isNewLandingPage={isNewLandingPage}
        />
      </div>
      <div
        className={
          !isLandingMapPage || isNewLandingPage
            ? 'displayNone'
            : 'inner-container'
        }
      >
        <AisLandingVesselList
          moduleId={moduleId}
          vesselList={vesselList}
          vesselDetails={vesselDetails}
          fetchAisVesselVoyageDetails={fetchAisVesselVoyageDetails}
          fetchAisVesselDetails={fetchAisVesselDetails}
          fetchAisVesselData={fetchAisVesselData}
          fetchVesselList={fetchVesselList}
          totalRecords={totalRecords}
          fetchselectedImoData={fetchselectedImoData}
          fetchNearestRangeVesselsByImo={fetchNearestRangeVesselsByImo}
          portDetails={portDetails}
          fetchPortStatisticDetails={fetchPortStatisticDetails}
          fetchPortDetails={fetchPortDetails}
          fetchVesselData={fetchVesselData}
          fetchPortMoveMapData={fetchPortMoveMapData}
          fetchTerminalCodeNames={fetchTerminalCodeNames}
        />
      </div>

      {/* vessel port movement */}

      <div
        id="portmovement"
        className={
          isPortMapPage
            ? 'shadow-sm p-3 mb-5 bg-white rounded portSearch'
            : 'displayNone'
        }
      >
        <AisVesselPortSearch
          vesselName={vesselName}
          vesselDetails={vesselDetails}
          fetchVesselName={fetchVesselName}
          fetchAisVesselVoyageDetails={fetchAisVesselVoyageDetails}
          fetchAisVesselDetails={fetchAisVesselDetails}
          fetchAisVesselData={fetchAisVesselData}
          fetchselectedImoData={fetchselectedImoData}
          fetchNearestRangeVesselsByImo={fetchNearestRangeVesselsByImo}
          portName={portName}
          portDetails={portDetails}
          fetchPortName={fetchPortName}
          fetchPortDetails={fetchPortDetails}
          fetchPortStatisticDetails={fetchPortStatisticDetails}
          fetchVesselData={fetchVesselData}
          fetchPortMoveMapData={fetchPortMoveMapData}
          fetchTerminalCodeNames={fetchTerminalCodeNames}
        />
        <Row className="port-movement-section-card">
          <Col>
            <Row className="mb-3">
              <Col xs="10">
                <h4 className="mt-1 mb-1">
                  {portDetailsValue ? portDetailsValue.portName : ''} |{' '}
                  {portDetailsValue ? portDetailsValue.unlocode : ''}
                </h4>
              </Col>
              <Col xs="2" className="text-right">
                <Button
                  color="primary"
                  size="sm"
                  onClick={() => handleBackBtn(false)}
                >
                  <FormattedMessage
                    {...messages.portVesselMovementBackNavBtn}
                  />
                </Button>
              </Col>
            </Row>
            <Row className="port-details-section">
              <Col xs="1">
                <Button
                  outline
                  color="success"
                  size="sm"
                  onClick={toggleButton}
                >
                  <span className="menu-toggler-icon" />
                  <span className="menu-toggler-icon" />
                  <span className="menu-toggler-icon" />
                </Button>
              </Col>
              {panel ? (
                <Col xs="5">
                  <Row>
                    <Col xs="12">
                      <Row className="ais-management-container-search-header mb-4">
                        <Col xs="12">
                          <h4 className="mb-0">
                            <FormattedMessage {...messages.portDetail} />
                          </h4>
                        </Col>
                      </Row>
                      <Row className="ais-port-movement-label-container">
                        <Col xs="4">
                          <Label>
                            <FormattedMessage {...messages.region} />
                          </Label>
                        </Col>
                        <Col xs="4">
                          <Label>
                            <FormattedMessage {...messages.country} />
                          </Label>
                        </Col>
                        <Col xs="4">
                          <Label>
                            <FormattedMessage {...messages.numberofTerminal} />
                          </Label>
                        </Col>
                      </Row>
                      <Row>
                        <Col xs="4">
                          <Label>
                            {portDetailsValue
                              ? portDetailsValue.regionName
                              : ''}
                          </Label>
                        </Col>
                        <Col xs="4">
                          <Label>
                            {portDetailsValue
                              ? portDetailsValue.countryName
                              : ''}
                          </Label>
                        </Col>
                        <Col xs="4">
                          <Label>
                            {portDetailsCounts
                              ? portDetailsCounts.noOfTerminals
                              : ''}
                          </Label>
                        </Col>
                      </Row>

                      <Row className="mt-2 ais-port-movement-label-container">
                        <Col xs="4">
                          <Label>
                            <FormattedMessage {...messages.numberofBerth} />
                          </Label>
                        </Col>
                        <Col xs="4">
                          <Label>
                            <FormattedMessage {...messages.latitude} />
                          </Label>
                        </Col>
                        <Col xs="4">
                          <Label>
                            <FormattedMessage {...messages.longitude} />
                          </Label>
                        </Col>
                      </Row>
                      <Row>
                        <Col xs="4">
                          <Label>
                            {portDetailsCounts
                              ? portDetailsCounts.noOfBerths
                              : ''}
                          </Label>
                        </Col>
                        <Col xs="4">
                          <Label>{latitude}</Label>
                        </Col>
                        <Col xs="4">
                          <Label>{longitude}</Label>
                        </Col>
                      </Row>
                    </Col>
                  </Row>
                  <Row className="mt-4">
                    <Col xs="12">
                      <Row className="port-statistics-section">
                        <Col xs="12">
                          <Row className="ais-management-container-search-header mb-4">
                            <Col xs="12">
                              <h4 className="mb-0">
                                <FormattedMessage
                                  {...messages.portStatistics}
                                />
                              </h4>
                            </Col>
                          </Row>
                          <Row className="ais-port-movement-label-container">
                            <Col xs="4">
                              <Label>
                                <FormattedMessage {...messages.vesselinPort} />
                              </Label>
                            </Col>
                            <Col xs="4">
                              <Label>
                                <FormattedMessage {...messages.vesselatBerth} />
                              </Label>
                            </Col>
                            <Col xs="4">
                              <Label>
                                <FormattedMessage
                                  {...messages.vesselatAnchorage}
                                />
                              </Label>
                            </Col>
                          </Row>

                          <Row>
                            <Col xs="4">
                              <Label>
                                {portStatisticDetails !== null
                                  ? portStatisticDetails.vesselsInPorts
                                  : ''}
                              </Label>
                            </Col>
                            <Col xs="4">
                              <Label>
                                {portStatisticDetails !== null
                                  ? portStatisticDetails.vesselsAtBerth
                                  : ''}
                              </Label>
                            </Col>
                            <Col xs="4">
                              <Label>
                                {portStatisticDetails !== null
                                  ? portStatisticDetails.vesselsAtAnchorage
                                  : ''}
                              </Label>
                            </Col>
                          </Row>

                          <Row className="mt-2 ais-port-movement-label-container">
                            <Col xs="4">
                              <Label>
                                <FormattedMessage
                                  {...messages.vesselDeparted}
                                />
                              </Label>
                            </Col>
                            <Col xs="4">
                              <Label>
                                <FormattedMessage
                                  {...messages.vesselArrivedLast}
                                />
                              </Label>
                            </Col>
                            <Col xs="4">
                              <Label>
                                <FormattedMessage
                                  {...messages.vesselArrivedNext}
                                />
                              </Label>
                            </Col>
                          </Row>

                          <Row>
                            <Col xs="4">
                              <Label>
                                {portStatisticDetails !== null
                                  ? portStatisticDetails.vesselsDeparted
                                  : ''}
                              </Label>
                            </Col>
                            <Col xs="4">
                              <Label>
                                {portStatisticDetails !== null
                                  ? portStatisticDetails.vesselsArrived
                                  : ''}
                              </Label>
                            </Col>
                            <Col xs="4">
                              <Label>
                                {portStatisticDetails !== null
                                  ? portStatisticDetails.vesselsArriving
                                  : ''}
                              </Label>
                            </Col>
                          </Row>
                        </Col>
                      </Row>
                    </Col>
                  </Row>
                </Col>
              ) : (
                ''
              )}
              <Col xs={panel ? '6' : '11'}>
                <Row>
                  <Col xs={12}>
                    <div
                      className="inner-container p-0 mt-0"
                      style={{ display: 'flex' }}
                    >
                      <Col xs={10}>
                        <FormGroup className="mt-0 mb-0 pb-3 pt-3 d-flex form-container">
                          <CustomInput
                            type="checkbox"
                            id="PORT_POLYGON"
                            name="showPort"
                            label="Terminal"
                            className="pr-3"
                            checked={terminalChecked}
                            onClick={evt => onTerminalCheckBoxClicked(evt)}
                          />
                          <CustomInput
                            type="checkbox"
                            id="TERMINAL_POLYGON"
                            name="showTerminal"
                            label="Berth"
                            className="pr-3"
                            checked={berthChecked}
                            onClick={evt => onBerthCheckBoxClicked(evt)}
                          />
                        </FormGroup>
                      </Col>
                      <Col xs={2} className="text-right pt-1">
                        <Button id="shipTypeShow" color="link">
                          <img
                            src={InfoIcon}
                            alt="notification-icon"
                            width="24px"
                            height="24px"
                          />
                        </Button>
                        <UncontrolledPopover
                          trigger="focus"
                          placement="bottom"
                          target="shipTypeShow"
                        >
                          <PopoverBody>
                            <Col xs={12} className="pl-0 pr-0">
                              <h4 className="mb-2">Ship Type</h4>
                            </Col>
                            <Col xs={12} className="pl-0 pr-0">
                              <div className="mb-1">
                                <span className="color vessel-marker-red mr-2 mt-1" />
                                Bulk Carrier
                              </div>
                              <div className="mb-1">
                                <span className="color vessel-marker-paleorange mr-2 mt-1" />
                                Gas Carrier
                              </div>
                              <div className="mb-1">
                                <span className="color vessel-marker-pink mr-2 mt-1" />
                                General Cargo
                              </div>
                              <div className="mb-1">
                                <span className="color vessel-marker-light-blue mr-2 mt-1" />
                                Passenger
                              </div>
                              <div className="mb-1">
                                <span className="color vessel-marker-orange mr-2 mt-1" />
                                Container
                              </div>
                              <div className="mb-1">
                                <span className="color vessel-marker-green mr-2 mt-1" />
                                Tanker
                              </div>
                              <div className="mb-1">
                                <span className="color vessel-marker-brawn mr-2 mt-1" />
                                RoRo
                              </div>
                              <div className="mb-1">
                                <span className="color vessel-marker-grey mr-2 mt-1" />
                                Others
                              </div>
                              <div className="mb-1">
                                <span className="color vessel-marker-black mr-2 mt-1 text-center">
                                  <span className="ballast-color ballast-marker-white" />
                                </span>
                                Ballast
                              </div>
                            </Col>
                            <Col xs={12} className="pl-0 pr-0">
                              <h4 className="mb-2">POI Type</h4>
                            </Col>
                            <Col xs={12} className="pl-0 pr-0">
                              <div className="mb-1">
                                <img
                                  src={PortIcon}
                                  className="poiIcon"
                                  alt="Port Icon"
                                />{' '}
                                Port
                              </div>
                            </Col>
                          </PopoverBody>
                        </UncontrolledPopover>
                      </Col>
                    </div>
                  </Col>
                </Row>
                <div className={!isPortMapPage ? 'displayNone' : ''}>
                  <div id="map3" />
                </div>
              </Col>
            </Row>
            <Row className="mb-3 mt-3">
              <Col>
                <h4 className="ais-management-container-search-header mb-0">
                  <FormattedMessage {...messages.portVesselMovementTitle} />
                </h4>
              </Col>
            </Row>
            <Row>
              <Col
                xs="12"
                className="vessel-movement-check"
                style={{ marginLeft: '6px' }}
              >
                {vesselTypes.map(item => (
                  <FormGroup check className="custom-control custom-checkbox">
                    <Input
                      type="checkbox"
                      id={item.wopVesselDesc}
                      className="custom-control-input"
                      key={Math.random()}
                      name={item.wopVesselDesc}
                      checked={hanldecheckbox(item.mstWopVesselTypeId)}
                      value={item.mstWopVesselTypeId}
                      onChange={e => fgetSearchVessel(e)}
                    />
                    <Label
                      check
                      for={item.wopVesselDesc}
                      className="custom-control-label"
                    >
                      {item.wopVesselDesc}
                    </Label>
                  </FormGroup>
                ))}
              </Col>
              <Col xs="7" className="mt-3">
                <AisReportExport
                  fetchFromDate={fetchFromDate}
                  fetchToDate={fetchToDate}
                  fromDate={fromDate}
                  toDate={toDate}
                  portVesselData={portVesselData}
                  handleExportPortData={handleExport}
                />
              </Col>
            </Row>
            <Row>
              <Col>
                <AisPortSearch
                  moduleId={moduleId}
                  portVesselData={portVesselDataFilter}
                  handleAddRow={dAddVesselRowTableData}
                  mainCargoTypeList={mainCargoTypeList}
                  cargoTypeList={cargoTypeList}
                  terminalsList={terminalsList}
                  berthsList={berthsList}
                  operation={operation}
                  nextPortsList={nextPortsList}
                  preiousPortsList={preiousPortsList}
                  charterersList={charterersList}
                  shippersList={shippersList}
                  receiversList={receiversList}
                  agentsList={agentsList}
                  handleVesselItemChanged={handleVesselItemChanged}
                  handleAddVesselMovement={handleAddVesselMovement}
                  hanldeUpdateVesselMovement={hanldeUpdateVesselMovement}
                  hanldeDeleteVesselMovement={hanldeDeleteVesselMovement}
                  handleCancelVesselMovement={handleCancelVesselMovement}
                  commodityList={commodityList}
                  portId={portIdvalue}
                  changeFieldName={changeFieldName}
                  handleSelectedRowData={handleSelectedRowData}
                  fetchVesselData={getVesselData}
                  totalRecords={vesselTotalCount}
                  handleLocaltime={handleLocaltime}
                  isShowLocaltime={isShowLocaltime}
                  isShowLocalTimeMsg={isShowLocalTimeMsg}
                  berthsData={berthsData}
                  mainCargoTypeData={mainCargoTypeData}
                  cargoTypeData={cargoTypeData}
                  commodityData={commodityData}
                  fetchVesselName={fetchVesselName}
                  vesselName={vesselName}
                  fetchPortName={fetchPortName}
                  portName={portName}
                  dAutoCompletePopover={dAutoCompletePopover}
                  isShowAutoCompletepopOver={isShowAutoCompletepopOver}
                  dTerminalBerthLoadOnEdit={dTerminalBerthLoadOnEdit}
                  vesselOperation={vesselOperation}
                  fetchAisVesselDraught={fetchAisVesselDraught}
                  currentpage={currentpage}
                  setTrackingComp={setTrackingComp}
                />
              </Col>
            </Row>
            {isModelOpen && (
              <DialogBox
                show={isModelOpen}
                fetchModelClose={handleModelClose}
                title={modelMessage.modelTitle}
                statusCode=""
                content={modelMessage.modelContent}
              />
            )}
          </Col>
        </Row>
      </div>

      {/* vessel port movement isVesselMapPage */}

      <div
        className={
          !isVesselMapPage
            ? 'displayNone'
            : 'shadow-sm p-3 mb-5 bg-white rounded portSearch'
        }
      >
        <AisVesselPortSearch
          vesselName={vesselName}
          vesselDetails={dvesselDetails}
          fetchVesselName={fetchVesselName}
          fetchAisVesselVoyageDetails={fetchAisVesselVoyageDetails}
          fetchAisVesselDetails={fetchAisVesselDetails}
          fetchAisVesselData={fetchAisVesselData}
          fetchselectedImoData={fetchselectedImoData}
          fetchNearestRangeVesselsByImo={fetchNearestRangeVesselsByImo}
          portName={portName}
          portDetails={portDetails}
          fetchPortName={fetchPortName}
          fetchPortDetails={fetchPortDetails}
          fetchPortStatisticDetails={fetchPortStatisticDetails}
          fetchVesselData={fetchVesselData}
          fetchPortMoveMapData={fetchPortMoveMapData}
          fetchTerminalCodeNames={fetchTerminalCodeNames}
          isNewLandingPage={isNewLandingPage}
        />
        <Row className="vessel-movement-section-card">
          <Col>
            <Row className="mb-3">
              <Col sm={10} xs="8">
                <h4 className="mt-1 mb-1">
                  {selectVesselName !== null ? selectVesselName : ''} |{' '}
                  {selectVesselImo !== null ? selectVesselImo : ''} |{' '}
                  {aisVesselDetails && aisVesselDetails.vesselStatus !== null
                    ? aisVesselDetails.vesselStatus
                    : '-'}
                </h4>
              </Col>
              <Col sm={2} xs="4" className="text-right">
                <Button
                  color="success"
                  size="sm"
                  onClick={() => handleBackBtn(true)}
                >
                  <FormattedMessage
                    {...messages.portVesselMovementBackNavBtn}
                  />
                </Button>
              </Col>
            </Row>

            <Row className="port-details-section">
              <Col xs="1" sm="1" className="mb-2">
                <Button
                  outline
                  color="success"
                  size="sm"
                  onClick={vToggleButton}
                >
                  <span className="menu-toggler-icon" />
                  <span className="menu-toggler-icon" />
                  <span className="menu-toggler-icon" />
                </Button>
              </Col>
              {vPanel ? (
                <Col xs="12" sm="5">
                  <Row>
                    <Col xs="12">
                      <Row className="ais-management-container-search-header mb-4">
                        <Col xs="12">
                          <h4 className="mb-0">
                            <FormattedMessage {...messages.vesselDetail} />
                          </h4>
                        </Col>
                      </Row>

                      <Row className="ais-vessel-movement-label-container">
                        <Col xs="4">
                          <Label>
                            <FormattedMessage {...messages.vesselType} />
                          </Label>
                        </Col>
                        <Col xs="4">
                          <Label>
                            <FormattedMessage
                              {...messages.vesselClassification}
                            />
                          </Label>
                        </Col>
                        <Col xs="4">
                          <Label>
                            <FormattedMessage {...messages.vesselSubType} />
                          </Label>
                        </Col>
                      </Row>
                      <Row>
                        <Col xs="4">
                          {aisVesselDetails ? (
                            <Label>{aisVesselDetails.wopVesselType}</Label>
                          ) : (
                            ''
                          )}
                        </Col>
                        <Col xs="4">
                          {aisVesselDetails ? (
                            <Label>
                              {aisVesselDetails.wopVesselSizeClassification}
                            </Label>
                          ) : (
                            ''
                          )}
                        </Col>
                        <Col xs="4">
                          {aisVesselDetails ? (
                            <Label>{aisVesselDetails.subType}</Label>
                          ) : (
                            ''
                          )}
                        </Col>
                      </Row>

                      <Row className="mt-2 ais-vessel-movement-label-container">
                        <Col xs="4">
                          <Label>
                            <FormattedMessage {...messages.grt} />
                          </Label>
                        </Col>
                        <Col xs="4">
                          <Label>
                            <FormattedMessage {...messages.dwt} />
                          </Label>
                        </Col>
                        <Col xs="4">
                          <Label>
                            <FormattedMessage {...messages.loa} />
                          </Label>
                        </Col>
                      </Row>

                      <Row>
                        <Col xs="4">
                          {aisVesselDetails ? (
                            <Label>{aisVesselDetails.gross}</Label>
                          ) : (
                            ''
                          )}
                        </Col>
                        <Col xs="4">
                          {aisVesselDetails ? (
                            <Label>{aisVesselDetails.dwt}</Label>
                          ) : (
                            ''
                          )}
                        </Col>
                        <Col xs="4">
                          {aisVesselDetails ? (
                            <Label>{aisVesselDetails.loa}</Label>
                          ) : (
                            ''
                          )}
                        </Col>
                      </Row>
                    </Col>
                  </Row>
                  <Row className="mt-4">
                    <Col xs="12">
                      <Row className="port-statistics-section">
                        <Col xs="12">
                          <Row className="ais-management-container-search-header mb-4">
                            <Col xs="12">
                              <h4 className="mb-0">
                                <FormattedMessage {...messages.voyageDetails} />
                              </h4>
                            </Col>
                          </Row>

                          <Row className="ais-vessel-movement-label-container">
                            <Col xs="4">
                              <Label>
                                <FormattedMessage
                                  {...messages.lastPositionReportDate}
                                />
                              </Label>
                            </Col>
                            <Col xs="4">
                              <Label>
                                <FormattedMessage {...messages.previousPort} />
                              </Label>
                            </Col>
                            <Col xs="4">
                              <Label>
                                <FormattedMessage {...messages.latitude} />
                              </Label>
                            </Col>
                          </Row>
                          <Row>
                            <Col xs="4">
                              {vvd ? <Label>{vvd.recordedDate}</Label> : ''}
                            </Col>
                            <Col xs="4">
                              {vvd ? (
                                <Label>{vvd.previousePortName}</Label>
                              ) : (
                                ''
                              )}
                            </Col>
                            <Col xs="4">
                              <Label>{latd}</Label>
                            </Col>
                          </Row>

                          <Row className="mt-2 ais-vessel-movement-label-container">
                            <Col xs="4">
                              <Label>
                                <FormattedMessage {...messages.nextPort} />
                              </Label>
                            </Col>
                            <Col xs="4">
                              <Label>
                                <FormattedMessage {...messages.eta} />
                              </Label>
                            </Col>
                            <Col xs="4">
                              <Label>
                                <FormattedMessage {...messages.longitude} />
                              </Label>
                            </Col>
                          </Row>

                          <Row>
                            <Col xs="4">
                              <Label>
                                {!showVesselStatus ? vvd.nextPortName : '-'}
                              </Label>
                            </Col>
                            <Col xs="4">
                              <Label>
                                {!showVesselStatus
                                  ? dateTimeConversion(vvd.nextPorteta)
                                  : '-'}
                              </Label>
                            </Col>
                            <Col xs="4">
                              <Label>{langd}</Label>
                            </Col>
                          </Row>

                          <Row className="mt-2 ais-vessel-movement-label-container">
                            <Col xs="4">
                              <Label>
                                <FormattedMessage {...messages.draught} />
                              </Label>
                            </Col>
                            <Col xs="4">
                              <Label>
                                <FormattedMessage {...messages.mooringStatus} />
                              </Label>
                            </Col>
                            <Col xs="4">
                              <Label>
                                <FormattedMessage
                                  {...messages.navigationalStatus}
                                />
                              </Label>
                            </Col>
                          </Row>
                          <Row>
                            <Col xs="4">
                              <Label>{vvd.vesselDraught}</Label>
                            </Col>
                            <Col xs="4">
                              <Label>
                                {!showVesselStatus
                                  ? vvd.vesselMooringStatus
                                  : '-'}
                              </Label>
                            </Col>
                            <Col xs="4">
                              {veselundefined ? (
                                <Label>
                                  {vvd.vesselNavigationalStatus !==
                                    'undefined' && !showVesselStatus
                                    ? vvd.vesselNavigationalStatus
                                    : '-'}
                                </Label>
                              ) : (
                                ''
                              )}
                            </Col>
                          </Row>

                          <Row className="mt-2 ais-vessel-movement-label-container">
                            <Col xs="4">
                              <Label>
                                <FormattedMessage
                                  {...messages.vesselLoadCondition}
                                />
                              </Label>
                            </Col>
                            <Col xs="4">
                              <Label>
                                <FormattedMessage {...messages.cargoType} />
                              </Label>
                            </Col>
                            <Col xs="4">
                              <Label>
                                <FormattedMessage {...messages.commodity} />
                              </Label>
                            </Col>
                          </Row>

                          <Row>
                            <Col xs="4">
                              <Label>
                                {!showVesselStatus
                                  ? vvd.vesselLoadCondition
                                  : '-'}
                              </Label>
                            </Col>
                            <Col xs="4">
                              <Label>
                                {!showVesselStatus ? vvd.cargoType : '-'}
                              </Label>
                            </Col>
                            <Col xs="4">
                              <Label>
                                {!showVesselStatus ? vvd.commodity : '-'}
                              </Label>
                            </Col>
                          </Row>

                          <Row className="mt-2 ais-vessel-movement-label-container">
                            <Col xs="4">
                              <Label>
                                <FormattedMessage
                                  {...messages.quantityOnboard}
                                />
                              </Label>
                            </Col>
                            <Col xs="4">
                              <Label>
                                <FormattedMessage {...messages.speed} />
                              </Label>
                            </Col>
                            <Col xs="4">
                              <Label>
                                <FormattedMessage {...messages.course} />
                              </Label>
                            </Col>
                          </Row>
                          <Row>
                            <Col xs="4">
                              <Label>
                                {!showVesselStatus
                                  ? vvd.vesselQuantityOnboard
                                  : '-'}
                              </Label>
                            </Col>
                            <Col xs="4">
                              <Label>
                                {!showVesselStatus ? vvd.vesselSpeed : '-'}
                              </Label>
                            </Col>
                            <Col xs="4">
                              <Label>
                                {!showVesselStatus ? vvd.vesselCourse : '-'}
                              </Label>
                            </Col>
                          </Row>
                        </Col>
                      </Row>
                    </Col>
                  </Row>
                </Col>
              ) : (
                ''
              )}
              <Col sm={vPanel ? '6' : '11'} xs="12">
                <Row>
                  <Col xs={12}>
                    <div
                      className="inner-container p-0 mt-0"
                      style={{ display: 'flex' }}
                    >
                      <Col xs={10}>
                        <FormGroup className="mt-0 mb-0 pb-3 pt-3 d-flex form-container">
                          <CustomInput
                            type="checkbox"
                            id="PORT_POLYGONN"
                            name="showPort"
                            label="Port"
                            className="pr-3"
                            checked={portChecked}
                            onClick={evt => onPortCheckBoxClicked(evt)}
                          />
                        </FormGroup>
                      </Col>
                      <Col xs={2} className="text-right pt-1">
                        <Button id="vesselTypeShow" color="link">
                          <img
                            src={InfoIcon}
                            alt="notification-icon"
                            width="24px"
                            height="24px"
                          />
                        </Button>
                        <UncontrolledPopover
                          trigger="focus"
                          placement="bottom"
                          target="vesselTypeShow"
                        >
                          <PopoverBody>
                            <Col xs={12} className="pl-0 pr-0">
                              <h4 className="mb-2">Ship Type</h4>
                            </Col>
                            <Col xs={12} className="pl-0 pr-0">
                              <div className="mb-1">
                                <div className="color vessel-marker-red mr-2 mt-1" />
                                Bulk Carrier
                              </div>
                              <div className="mb-1">
                                <div className="color vessel-marker-paleorange mr-2 mt-1" />
                                Gas Carrier
                              </div>
                              <div className="mb-1">
                                <div className="color vessel-marker-pink mr-2 mt-1" />
                                General Cargo
                              </div>
                              <div className="mb-1">
                                <div className="color vessel-marker-light-blue mr-2 mt-1" />
                                Passenger
                              </div>
                              <div className="mb-1">
                                <div className="color vessel-marker-orange mr-2 mt-1" />
                                Container
                              </div>
                              <div className="mb-1">
                                <div className="color vessel-marker-green mr-2 mt-1" />
                                Tanker
                              </div>
                              <div className="mb-1">
                                <div className="color vessel-marker-brawn mr-2 mt-1" />
                                RoRo
                              </div>
                              <div className="mb-1">
                                <div className="color vessel-marker-grey mr-2 mt-1" />
                                Others
                              </div>
                              <div className="mb-1">
                                <div className="color vessel-marker-black mr-2 mt-1 text-center">
                                  <span className="ballast-color ballast-marker-white" />
                                </div>
                                Ballast
                              </div>
                            </Col>
                            <Col xs={12} className="pl-0 pr-0">
                              <h4 className="mb-2">POI Type</h4>
                            </Col>
                            <Col xs={12} className="pl-0 pr-0">
                              <div className="mb-1">
                                <img
                                  src={PortIcon}
                                  className="poiIcon"
                                  alt="Port Icon"
                                />{' '}
                                Port
                              </div>
                            </Col>
                          </PopoverBody>
                        </UncontrolledPopover>
                      </Col>
                    </div>
                  </Col>
                </Row>
                <div className={!isVesselMapPage ? 'displayNone' : ''}>
                  <div id="map4" />
                </div>
              </Col>
            </Row>
            <Row className="mb-3 mt-3">
              <Col>
                <h4 className="ais-management-container-search-header mb-0">
                  <FormattedMessage {...messages.vesselDetailMovementTitle} />
                </h4>
              </Col>
            </Row>
            <Row>
              <Col
                xs="12"
                sm="7"
                className="vessel-movement-check ais-vessel-movement-label-container"
              >
                <Row className="mgtop20">
                  <Col sm={4} xs="12">
                    <DropDown
                      label={<FormattedMessage {...messages.region} />}
                      options={regionOptions}
                      onChange={evt => regionSelector(evt)}
                      selected={vSelectedRegion.regionId}
                    />
                  </Col>
                  <Col sm={4} xs="12">
                    <DropDown
                      label={<FormattedMessage {...messages.country} />}
                      options={countryOptions}
                      onChange={evt => countrySelector(evt)}
                      selected={vSelectedRegion.countryId}
                    />
                  </Col>
                  <Col sm={4} xs="12">
                    <AutoComplete
                      label={<FormattedMessage {...messages.port} />}
                      suggestions={portName}
                      type="nextPort"
                      portDetails={portDetails}
                      fetchPortName={fetchPortName}
                      onNextPortSelected={onNextPortSelected}
                    />
                  </Col>
                </Row>
              </Col>
              <Col sm="7" xs="12" className="mt-3">
                <Export
                  fetchFromDate={fetchFromDate}
                  fetchToDate={fetchToDate}
                  fromDate={fromDate}
                  toDate={toDate}
                  portVesselData={aisVesselDataFilter}
                  handleExportPortData={handleVExport}
                />
              </Col>
            </Row>
            <Row>
              <Col>
                <AisVesselSearch
                  moduleId={moduleId}
                  portVesselData={aisVesselDataFilter}
                  handleAddRow={dAddVesselRowTableData}
                  mainCargoTypeList={mainCargoTypeList}
                  cargoTypeList={cargoTypeList}
                  vesselsList={vesselList}
                  terminalsList={terminalsList}
                  berthsList={berthsList}
                  operation={operation}
                  nextPortsList={nextPortsList}
                  previousPortsList={preiousPortsList}
                  charterersList={charterersList}
                  shippersList={shippersList}
                  receiversList={receiversList}
                  agentsList={agentsList}
                  handleVesselItemChanged={handleVesselItemChanged}
                  handleAddVesselMovement={handleAddVesselMovement}
                  handleUpdateVesselMovement={hanldeUpdateVesselMovement}
                  handleDeleteVesselMovement={hanldeDeleteVesselMovement}
                  handleCancelVesselMovement={handleCancelVesselMovement}
                  vesselImo={vesselImo}
                  commodityList={commodityList}
                  changeFieldName={changeFieldName}
                  handleSelectedRowData={handleSelectedRowData}
                  fetchAisVesselData={getAisVesselData}
                  totalRecords={vesselTotalCount}
                  handleLocaltime={handlevesselLocaltime}
                  isShowLocaltime={isShowLocaltime}
                  isShowLocalTimeMsg={isShowLocalTimeMsg}
                  berthsData={berthsData}
                  mainCargoTypeData={mainCargoTypeData}
                  cargoTypeData={cargoTypeData}
                  commodityData={commodityData}
                  fetchVesselName={fetchVesselName}
                  vesselName={vesselName}
                  fetchPortName={fetchPortName}
                  portName={portName}
                  dAutoCompletePopover={dAutoCompletePopover}
                  isShowAutoCompletepopOver={isShowAutoCompletepopOver}
                  dTerminalBerthLoadOnEdit={dTerminalBerthLoadOnEdit}
                  vesselOperation={vesselOperation}
                  currentpage={currentpage}
                />
              </Col>
            </Row>
            {isModelOpen && (
              <DialogBox
                show={isModelOpen}
                fetchModelClose={handleModelClose}
                title={modelMessage.modelTitle}
                statusCode=""
                content={modelMessage.modelContent}
              />
            )}
          </Col>
        </Row>
        {isShowVesselData && (
          <div>
            <Modal
              className="infoModal"
              isOpen={isShowVesselData}
              toggle={dvesseldataModal}
            >
              <ModalHeader toggle={dvesseldataModal}>
                <FormattedMessage {...messages.vesselTitleInfo} />
              </ModalHeader>
              <ModalBody>
                <div>
                  <span className="delete-xclaim-icon">!</span>
                  <FormattedMessage {...messages.vesselInfo} />
                </div>
              </ModalBody>
              <ModalFooter>
                <Button color="primary" onClick={() => vesselToggle()}>
                  Ok
                </Button>
              </ModalFooter>
            </Modal>
          </div>
        )}
      </div>
    </>
  );
}

AisVesselTracking.propTypes = {
  handleBack: PropTypes.func,
  isLandingMapPage: PropTypes.bool,
  isLandingPortMapPage: PropTypes.bool,
  isVesselMapPage: PropTypes.bool,
  isPortMapPage: PropTypes.bool,
  vesselMapModifiedData: PropTypes.array,
  portMapModifiedData: PropTypes.array,
  portMapData: PropTypes.array,
  aisLandingScreenCenterPosition: PropTypes.string,
  aisLandingPortSelectedZoomLevel: PropTypes.string,
  loadPortOrVesselData: PropTypes.func,
  fetchAllPortsMapData: PropTypes.func.isRequired,
  vesselTypeOptions: PropTypes.array.isRequired,
  vesselSizeOptions: PropTypes.array.isRequired,
  vesselConditionOptions: PropTypes.array.isRequired,
  vesselStatusOptions: PropTypes.array.isRequired,
  selectedSearch: PropTypes.object.isRequired,
  vesselTypeSelected: PropTypes.func.isRequired,
  vesselSizeSelected: PropTypes.func.isRequired,
  vesselConditionSelected: PropTypes.func.isRequired,
  vesselStatusSelected: PropTypes.func.isRequired,
  nextPortSelected: PropTypes.func.isRequired,
  vesselName: PropTypes.array,
  portName: PropTypes.array.isRequired,
  vesselDetails: PropTypes.func.isRequired,
  portDetails: PropTypes.func.isRequired,
  fetchVesselSize: PropTypes.func.isRequired,
  fetchPortName: PropTypes.func,
  fetchVesselName: PropTypes.func,
  fetchPortDetails: PropTypes.func.isRequired,
  fetchPortStatisticDetails: PropTypes.func.isRequired,
  fetchVesselData: PropTypes.func.isRequired,
  fetchPortMoveMapData: PropTypes.func.isRequired,
  fetchAisVesselVoyageDetails: PropTypes.func.isRequired,
  fetchAisVesselDetails: PropTypes.func.isRequired,
  fetchAisVesselData: PropTypes.func.isRequired,
  fetchselectedImoData: PropTypes.func.isRequired,
  fetchNearestRangeVesselsByImo: PropTypes.func.isRequired,
  searchAppliedFilter: PropTypes.func.isRequired,
  fetchAdditionFilterData: PropTypes.func.isRequired,
  additionalFilterObj: PropTypes.object.isRequired,
  fetchTerminalCodeNames: PropTypes.func.isRequired,
  dCancelSearchApply: PropTypes.func.isRequired,
  fetchVesselList: PropTypes.func.isRequired,
  fetchTankerMapData: PropTypes.func,
  fetchStroogMapData: PropTypes.func,
  fetchCargoCarrierMapData: PropTypes.func,
  fetchBulkContainerMapData: PropTypes.func,
  moduleId: PropTypes.number,
  vesselList: PropTypes.array.isRequired,
  totalRecords: PropTypes.number.isRequired,
  portMovementMapData: PropTypes.object,
  countryName: PropTypes.string,
  terminalChecked: PropTypes.bool,
  berthChecked: PropTypes.bool,
  portDetailsValue: PropTypes.object,
  portDetailsCounts: PropTypes.object,
  portTypeFilterOption: PropTypes.array,
  portVesselData: PropTypes.array,
  portStatisticDetails: PropTypes.object,
  fetchTerminalCheckboxUpdate: PropTypes.func,
  fetchBerthCheckboxUpdate: PropTypes.func,
  fetchSearchVessel: PropTypes.func,
  fetchFromDate: PropTypes.func,
  fetchToDate: PropTypes.func,
  fromDate: PropTypes.object,
  toDate: PropTypes.object,
  handleExportPortData: PropTypes.func,
  dAddVesselRowTableData: PropTypes.func,
  mainCargoTypeList: PropTypes.array,
  cargoTypeList: PropTypes.array,
  terminalsList: PropTypes.array,
  berthsList: PropTypes.array,
  operation: PropTypes.array,
  nextPortsList: PropTypes.array,
  preiousPortsList: PropTypes.array,
  charterersList: PropTypes.array,
  shippersList: PropTypes.array,
  receiversList: PropTypes.array,
  agentsList: PropTypes.array,
  handleVesselItemChanged: PropTypes.func,
  handleAddVesselMovement: PropTypes.func,
  hanldeUpdateVesselMovement: PropTypes.func,
  hanldeDeleteVesselMovement: PropTypes.func,
  handleCancelVesselMovement: PropTypes.func,
  commodityList: PropTypes.array,
  changeFieldName: PropTypes.string,
  handleSelectedRowData: PropTypes.func,
  isShowLocaltime: PropTypes.bool,
  isShowLocalTimeMsg: PropTypes.bool,
  berthsData: PropTypes.array,
  mainCargoTypeData: PropTypes.array,
  cargoTypeData: PropTypes.array,
  commodityData: PropTypes.array,
  dAutoCompletePopover: PropTypes.func,
  isShowAutoCompletepopOver: PropTypes.bool,
  dTerminalBerthLoadOnEdit: PropTypes.func,
  vesselOperation: PropTypes.array,
  dshowLocalTime: PropTypes.func,
  isModelOpen: PropTypes.bool,
  handleModelClose: PropTypes.func,
  modelMessage: PropTypes.object,
  vesselTypes: PropTypes.array,
  vvd: PropTypes.object,
  dvesselDetails: PropTypes.func,
  aisVesselData: PropTypes.array,
  vSelectedRegion: PropTypes.object,
  regionOptions: PropTypes.array,
  countryOptions: PropTypes.array,
  onRegionSelected: PropTypes.func,
  onCountrySelected: PropTypes.func,
  fetchPortCheckboxUpdate: PropTypes.func,
  vesselsNearestData: PropTypes.array,
  portChecked: PropTypes.bool,
  dShowPortVesselPopOver: PropTypes.func,
  aisVesselDetails: PropTypes.object,
  vesselTotalCount: PropTypes.number,
  allVesselsData: PropTypes.array,
  mapTankerDataMarker: PropTypes.array,
  mapStroogDataMarker: PropTypes.array,
  mapCargoDataMarker: PropTypes.array,
  mapBulkgDataMarker: PropTypes.array,
  dLandingMarkerCreation: PropTypes.func,
  currentGridPage: PropTypes.number,
  fetchAisVesselDraught: PropTypes.func,
  currentpage: PropTypes.string,
  isNewLandingPage: PropTypes.bool,
  showFleetClick: PropTypes.func,
  showMyFleet: PropTypes.bool,
  isShowPoiFilterModal: PropTypes.bool,
  poiFilterOpenClick: PropTypes.func,
  poiFilterCloseClick: PropTypes.func,
  poifilterValues: PropTypes.object,
  poiFilterData: PropTypes.object,
  cargoTypeTrigger: PropTypes.func,
  cargoTrigger: PropTypes.func,
  gradeTrigger: PropTypes.func,
  shipTypeTrigger: PropTypes.func,
  shipSizeTrigger: PropTypes.func,
  berthStyleTrigger: PropTypes.func,
  vesselTurnAroundTimeTrigger: PropTypes.func,
  isLoading: PropTypes.bool,
  vesselFormParams: PropTypes.any,
  vesselMetadata: PropTypes.any,
  getVesselApiCallByGUI: PropTypes.any,
  vesselInfoByGUI: PropTypes.func,
  getVesselDataApiCall: PropTypes.func,
  loadVesselDataByIMO: PropTypes.any,
  servicesAvailableTrigger: PropTypes.func,
  facilitiesAvailableTrigger: PropTypes.func,
  clearPoiFiltersTrigger: PropTypes.func,
  clearVesselPortCallFiltersTrigger: PropTypes.func,
  onVesseelClick: PropTypes.func,
  show: PropTypes.bool,
  vesselTypeFormattedData: PropTypes.any,
  dHandleVesselCallFilterData: PropTypes.func,
  vesselCallsFilterSearch: PropTypes.any,
  vesselCallsInitialsSearchData: PropTypes.any,
  vesselClassification: PropTypes.any,
  vesselSubTypes: PropTypes.any,
  conditionOptions: PropTypes.any,
  statusOptions: PropTypes.any,
  technicalOwnerData: PropTypes.any,
  beneficialOwnerData: PropTypes.any,
  commercialOperatorData: PropTypes.any,
  registeredOwnerData: PropTypes.any,
  dGetRegisteredOwnerDetails: PropTypes.func,
  dGetBeneficialOwnerDetails: PropTypes.func,
  dGetCommercialOperatorDetails: PropTypes.func,
  dGetTechnicalOwnerDetails: PropTypes.func,
  vesselStatusData: PropTypes.any,
  dCloseVesselPopup: PropTypes.func,
  dGetLastReceivedVessels: PropTypes.func,
  vesselportcallsFilterData: PropTypes.object,
  fetchApplyPoiFilters: PropTypes.func,
  myFleetVesselListCall: PropTypes.func,
  getSinglePortDataApiCall: PropTypes.func,
  getSinglePortData: PropTypes.array,
  dHandleOwnerDetailsChange: PropTypes.func,
  isShowPortModal: PropTypes.bool,
  dshowPortModal: PropTypes.func,
  selectedPortDetail: PropTypes.object,
  vesselFilterValues: PropTypes.object,
  dVesselTypeClick: PropTypes.func,
  dVesselClassficationClick: PropTypes.func,
  dVesselSubTypeClick: PropTypes.func,
  dVesselConditionClick: PropTypes.func,
  dVesselStatusClick: PropTypes.func,
  poiPortData: PropTypes.object,
  clearAutoCompleteTextField: PropTypes.func,
  isVesselFilterApplied: PropTypes.bool,
  isPoiFilter: PropTypes.bool,
  isVesselMsgModelOpen: PropTypes.bool,
  dVesselMsgModelClose: PropTypes.func,
  vesselMsgModelMsg: PropTypes.string,
  isShowVesselData: PropTypes.bool,
  dvesseldataModal: PropTypes.func,
  fetchResetLandingMarkerData: PropTypes.func,
  clearSinglePortField: PropTypes.func,
  vesselFilterDataMarker: PropTypes.array,
  isPortMsgModelOpen: PropTypes.bool,
  portModelMsg: PropTypes.string,
  dportMsgModelClose: PropTypes.func,
  vesselFilterCount: PropTypes.string,
  disPortModalClick: PropTypes.func,
  vesselMooringStatusOptions: PropTypes.any,
  disVesselMooringClick: PropTypes.func,
  disVesselCargoTypeClick: PropTypes.func,
  disVesselVoyageFromDate: PropTypes.func,
  disVesselVoyageToDate: PropTypes.func,
  isVoyageToDateEnable: PropTypes.bool,
  disVoyageNextPortClick: PropTypes.func,
  vesselPortFilterCount: PropTypes.object,
  setRetainPortVal: PropTypes.string,
  dhandleCheckbox: PropTypes.func,
  fleetFilter: PropTypes.object,
  dshowMyfleetModal: PropTypes.func,
  dgetFleetData: PropTypes.func,
  fleetDataList: PropTypes.array,
  selectedFleets: PropTypes.array,
  getShowMyFleetIdList: PropTypes.func,
  isShowFleetMsg: PropTypes.bool,
  showMyFleetInfoMsgCloseAction: PropTypes.func,
  setVesselVoyageFromDate: PropTypes.string,
  vesselVoyageFromDate: PropTypes.string,
  vesselVoyageToDate: PropTypes.string,
  fleetSearchValue: PropTypes.string,
  dhandleSearchFleet: PropTypes.func,
  fleetMsg: PropTypes.object,
  dshowfleetMsg: PropTypes.func,
  isClearTextField: PropTypes.bool,
  dShowMyZoneToggle: PropTypes.func,
  showMyZoneGroup: PropTypes.bool,
  myZoneFilter: PropTypes.object,
  dgetMyzoneData: PropTypes.func,
  myZoneDataList: PropTypes.array,
  dShowMyZoneMsgCloseClick: PropTypes.func,
  dhandleMyZoneCheckBoxChange: PropTypes.func,
  selectedMyZones: PropTypes.array,
  dshowMyzoneFilter: PropTypes.func,
  isShowMyZoneMsgDisplay: PropTypes.bool,
  dshowMyZoneGroupApplyBtnClick: PropTypes.func,
  selectedMyZoneGroupList: PropTypes.array,
  selectedFilter: PropTypes.string,
  isValidFilter: PropTypes.bool,
  zoneSearchValue: PropTypes.string,
  dhandleSearchZoneFilter: PropTypes.func,
  fetchVesselHistoricalInfo: PropTypes.func,
  trackData: PropTypes.array,
  dclearHistoricalVessel: PropTypes.func,
  closeHistoricalErrorInfo: PropTypes.func,
  loadVesselFilterObj: PropTypes.func,
  setVesselFilterObjParams: PropTypes.object,
};

export default memo(AisVesselTracking);
