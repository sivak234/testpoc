/**
 *
 * AisLandingAdditionalFilter
 *
 */

import React, { memo } from 'react';
import PropTypes from 'prop-types';
import { FormattedMessage } from 'react-intl';
import {
  Form,
  FormGroup,
  Row,
  Col,
  Button,
  Popover,
  PopoverBody,
  CustomInput,
} from 'reactstrap';
import messages from './messages';
// import MapViewChangeIcon from '../../assets/images/show-icon.svg';
import AisMap from '../AisMap/Loadable';

function AisLandingAdditionalFilter({
  vesselMapModifiedData,
  portMapModifiedData,
  portMapData,
  fetchAllPortsMapData,
  loadPortOrVesselData,
  aisMapPopUpStatus,
  toggleAisMapPopUpStatus,
  mapRefresh,
  aisLandingScreenCenterPosition,
  aisLandingPortSelectedZoomLevel,
}) {
  const onOptionChange = event => {
    if (event.target.id === 'ShowVessel') {
      loadPortOrVesselData('vessel');
    } else if (event.target.id === 'ShowPort') {
      if (portMapData && portMapData.length > 0) {
        loadPortOrVesselData('port');
      } else {
        fetchAllPortsMapData(true);
      }
    }
  };
  const showPort = <FormattedMessage {...messages.showPort} />;
  const showVessel = <FormattedMessage {...messages.showVessel} />;
  return (
    <Form>
      <Row>
        <Col xs={12}>
          <div className="inner-container p-0 mt-0" style={{ display: 'flex' }}>
            <Col xs={10}>
              <FormGroup className="mt-0 mb-0 pb-3 pt-3 d-flex form-container">
                <CustomInput
                  label={showVessel}
                  className="pr-3"
                  type="radio"
                  id="ShowVessel"
                  name="switchVessel"
                  // className="custom-control-input"
                  checked={!aisMapPopUpStatus.isPortChecked}
                  onChange={evt => onOptionChange(evt)}
                />

                <CustomInput
                  label={showPort}
                  className="pr-3"
                  type="radio"
                  id="ShowPort"
                  name="switchView"
                  // className="custom-control-input"
                  checked={aisMapPopUpStatus.isPortChecked}
                  onChange={evt => onOptionChange(evt)}

                  // onClick={evt => onPortCheckBoxClicked(evt)}
                />
              </FormGroup>
            </Col>
            <Col xs={2} className="text-right pt-1">
              <Button
                id="vessel-info-show"
                color="link"
                onClick={() => toggleAisMapPopUpStatus('info')}
              >
                <i className="fa fa-info color-primary fa-lg" />
              </Button>

              <Popover
                placement="bottom"
                isOpen={aisMapPopUpStatus.isShowInfoPopUp}
                target="vessel-info-show"
              >
                <PopoverBody>
                  <Col xs={12} className="pl-0 pr-0">
                    <h4 className="mb-2">Ship Type</h4>
                  </Col>
                  <Col xs={12} className="pl-0 pr-0">
                    <p className="mb-1">
                      <div className="color vessel-marker-red mr-2 mt-1" />
                      Bulk Carrier
                    </p>
                    <p className="mb-1">
                      <div className="color vessel-marker-paleorange mr-2 mt-1" />
                      Gas Carrier
                    </p>
                    <p className="mb-1">
                      <div className="color vessel-marker-pink mr-2 mt-1" />
                      General Cargo
                    </p>
                    <p className="mb-1">
                      <div className="color vessel-marker-light-blue mr-2 mt-1" />
                      Passenger
                    </p>
                    <p className="mb-1">
                      <div className="color vessel-marker-orange mr-2 mt-1" />
                      Container
                    </p>
                    <p className="mb-1">
                      <div className="color vessel-marker-green mr-2 mt-1" />
                      Tanker
                    </p>
                    <p className="mb-1">
                      <div className="color vessel-marker-brawn mr-2 mt-1" />
                      RoRo
                    </p>
                    <p className="mb-1">
                      <div className="color vessel-marker-grey mr-2 mt-1" />
                      Others
                    </p>
                    <p className="mb-1">
                      <div className="color vessel-marker-black mr-2 mt-1 text-center">
                        <span className="ballast-color ballast-marker-white" />
                      </div>
                      Ballast
                    </p>
                  </Col>
                </PopoverBody>
              </Popover>
            </Col>
          </div>
        </Col>
      </Row>
      <Row>
        <Col xs={12}>
          {vesselMapModifiedData.length > 0 || portMapData ? (
            <AisMap
              mapScreenView="AISLandingScreenMap"
              vesselMapData={vesselMapModifiedData}
              portChecked={aisMapPopUpStatus.isPortChecked}
              portMapData={portMapModifiedData}
              mapHeight="700px"
              mapElementHeight="90%"
              mapRefresh={mapRefresh}
              aisLandingScreenCenterPosition={aisLandingScreenCenterPosition}
              aisLandingPortSelectedZoomLevel={aisLandingPortSelectedZoomLevel}
            />
          ) : (
            <AisMap
              mapRefresh={mapRefresh}
              mapHeight="700px"
              mapElementHeight="90%"
            />
          )}
        </Col>
      </Row>
    </Form>
  );
}

AisLandingAdditionalFilter.propTypes = {
  vesselMapModifiedData: PropTypes.array.isRequired,
  portMapModifiedData: PropTypes.array,
  portMapData: PropTypes.array.isRequired,
  fetchAllPortsMapData: PropTypes.func.isRequired,
  aisMapPopUpStatus: PropTypes.object,
  toggleAisMapPopUpStatus: PropTypes.func,
  loadPortOrVesselData: PropTypes.func,
  mapRefresh: PropTypes.bool,
  aisLandingScreenCenterPosition: PropTypes.string,
  aisLandingPortSelectedZoomLevel: PropTypes.string,
};

export default memo(AisLandingAdditionalFilter);
