/*
 * AisLandingAdditionalFilter Messages
 *
 * This contains all the text for the AisLandingAdditionalFilter component.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.components.AisLandingAdditionalFilter';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'This is the AisLandingAdditionalFilter component!',
  },
  aisAdditionalFilterSectionOneHeading: {
    id: `${scope}.aisAdditionalFilterSectionOneHeading`,
    defaultMessage: 'Additional Filters',
  },
  aisAdditionalFilterSectionOneSubHeading: {
    id: `${scope}.aisAdditionalFilterSectionOneSubHeading`,
    defaultMessage: 'Geography',
  },
  aisAdditionalFilterSectionTwoHeading: {
    id: `${scope}.aisAdditionalFilterSectionTwoHeading`,
    defaultMessage: 'Vessel Dimensions',
  },
  aisAdditionalFilterRegionLabel: {
    id: `${scope}.aisAdditionalFilterRegionLabel`,
    defaultMessage: 'Region',
  },
  aisAdditionalFilterCountryLabel: {
    id: `${scope}.aisAdditionalFilterCountryLabel`,
    defaultMessage: 'Country',
  },
  aisAdditionalFilterDeadWeightLabel: {
    id: `${scope}.aisAdditionalFilterDeadWeightLabel`,
    defaultMessage: 'DeadWeight',
  },
  aisAdditionalFilterLoaLabel: {
    id: `${scope}.aisAdditionalFilterLoaLabel`,
    defaultMessage: 'LOA',
  },
  aisAdditionalFilterDraughtLabel: {
    id: `${scope}.aisAdditionalFilterDraughtLabel`,
    defaultMessage: 'Draught',
  },
  aisAdditionalFilterBeamLabel: {
    id: `${scope}.aisAdditionalFilterBeamLabel`,
    defaultMessage: 'Beam',
  },
  aisAdditionalFilterGrtLabel: {
    id: `${scope}.aisAdditionalFilterGrtLabel`,
    defaultMessage: 'GRT',
  },
  aisAdditionalFilterTeuCapacityLabel: {
    id: `${scope}.aisAdditionalFilterTeuCapacityLabel`,
    defaultMessage: 'TEU Capacity',
  },
  aisAdditionalFilterRegOwnerLabel: {
    id: `${scope}.aisAdditionalFilterRegOwnerLabel`,
    defaultMessage: 'Registered Owner',
  },
  aisAdditionalFilterBenificalOwnerLabel: {
    id: `${scope}.aisAdditionalFilterBenificalOwnerLabel`,
    defaultMessage: 'Beneficial Owner',
  },
  aisAdditionalFilterCommOpeLabel: {
    id: `${scope}.aisAdditionalFilterCommOpeLabel`,
    defaultMessage: 'Commercial Operator',
  },
  aisAdditionalFilterTechMangLabel: {
    id: `${scope}.aisAdditionalFilterTechMangLabel`,
    defaultMessage: 'Technical Manager',
  },
  aisAdditionalFilterApplyBtn: {
    id: `${scope}.aisAdditionalFilterApplyBtn`,
    defaultMessage: 'Apply',
  },
  aisAdditionalFilterFrom: {
    id: `${scope}.aisAdditionalFilterFrom`,
    defaultMessage: 'From',
  },
  aisAdditionalFilterTo: {
    id: `${scope}.aisAdditionalFilterTo`,
    defaultMessage: 'To',
  },
  aisShowPortVesselBtn: {
    id: `${scope}.aisShowPortVesselBtn`,
    defaultMessage: 'Show',
  },
  showPort: {
    id: `${scope}.showPort`,
    defaultMessage: 'Show Ports',
  },
  showVessel: {
    id: `${scope}.showVessel`,
    defaultMessage: 'Show Vessels',
  },
});
