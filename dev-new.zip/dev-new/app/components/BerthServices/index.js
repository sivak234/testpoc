/**
 *
 * BerthServices
 *
 */

import React, { memo } from 'react';
import { Row, Col } from 'reactstrap';
import PropTypes from 'prop-types';

function BerthServices({ passedRef, data }) {
  const showYesNo = field => {
    if (field == null) return '';
    if (field) return 'Yes';
    return 'No';
  };

  return (
    <>
      <Row className="add-berth-section-header mb-3 mt-3">
        <Col xs={12}>
          <h4 className="mb-0" ref={passedRef}>
            Berth Services
          </h4>
        </Col>
      </Row>
      <Row id="berth-service-int-content">
        <Col xs={6} sm={2} md={4} lg={3}>
          <h5>Slop Reception Facility</h5>
          <p className="berth-int-center-content">
            {showYesNo(data.isSlopReceptionFacility)}
          </p>
        </Col>

        <Col xs={6} sm={2} md={4} lg={3}>
          <h5>Slop Reception Notes</h5>
          <p className="berth-int-service-notes">
            {data.slopReceptionNotes ? data.slopReceptionNotes : ''}
          </p>
        </Col>

        <Col xs={6} sm={2} md={4} lg={3}>
          <h5>Dirty Ballast Reception Facility</h5>
          <p className="berth-int-center-content">
            {showYesNo(data.isDirtyBallastReceptFacility)}
          </p>
        </Col>

        <Col xs={6} sm={2} md={4} lg={3}>
          <h5>Dirty Ballast Reception Notes</h5>
          <p className="berth-int-service-notes">
            {data.dirtyBallastReceptNotes ? data.dirtyBallastReceptNotes : ''}
          </p>
        </Col>

        <Col xs={6} sm={2} md={4} lg={3}>
          <h5>Garbage Disposal Facility</h5>
          <p className="berth-int-center-content">
            {showYesNo(data.isGarbageDisposalFacility)}
          </p>
        </Col>

        <Col xs={6} sm={2} md={4} lg={3}>
          <h5>Sewage Reception Facility</h5>
          <p className="berth-int-center-content">
            {showYesNo(data.issewagereceptfacility)}
          </p>
        </Col>

        <Col xs={6} sm={2} md={4} lg={3}>
          <h5>Sewage Reception Notes</h5>
          <p className="berth-int-service-notes">
            {data.sewageReceptionNotes ? data.sewageReceptionNotes : ''}
          </p>
        </Col>

        <Col xs={6} sm={2} md={4} lg={3}>
          <h5>Ship to Ship Available</h5>
          <p className="berth-int-center-content">
            {showYesNo(data.isShiptoShipAvailble)}
          </p>
        </Col>

        <Col xs={6} sm={2} md={4} lg={3}>
          <h5>Ship to Ship Notes</h5>
          <p className="berth-int-service-notes">
            {data.shiptoShipNotes ? data.shiptoShipNotes : ''}
          </p>
        </Col>

        <Col xs={6} sm={2} md={4} lg={3}>
          <h5>Fresh Water </h5>
          <p className="berth-int-center-content">
            {showYesNo(data.isFreshWater)}
          </p>
        </Col>

        <Col xs={6} sm={2} md={4} lg={3}>
          <h5>Fresh Water Notes</h5>
          <p className="berth-int-service-notes">
            {data.freshWaterNotes ? data.freshWaterNotes : ''}
          </p>
        </Col>

        <Col xs={6} sm={2} md={4} lg={3}>
          <h5>Provisions/Stores Delivery Available </h5>
          <p className="berth-int-center-content">
            {showYesNo(data.isProvisionStoresDeliveryAvailable)}
          </p>
        </Col>
      </Row>
    </>
  );
}

BerthServices.propTypes = { passedRef: PropTypes.any, data: PropTypes.object };

export default memo(BerthServices);
