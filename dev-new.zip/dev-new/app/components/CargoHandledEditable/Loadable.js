/**
 *
 * Asynchronously loads the component for CargoHandledEditable
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
