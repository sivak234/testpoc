/**
 *
 * CargoHandledEditable
 *
 */

import React, { memo } from 'react';
import PropTypes from 'prop-types';
import { Row, Col, Button } from 'reactstrap';

import { GroupCargoInputs } from './_helper';

import './index.scss';

function CargoHandledEditable({
  metaData,
  dHandleCargoTypeChange,
  dUpdateBerthDataCargoHandled,
  dDeleteBerthDataCargoHandled,
  data,
  sectionName,
  berthCargoTypeDry = '',
  readOnly,
  berthTypeTransactions = [],
}) {
  let sectionBerthTypeId;

  let cargoSubType = [];

  let noBunkersValueId = '';
  if (sectionName.toLowerCase() === 'dry') {
    sectionBerthTypeId = [berthCargoTypeDry];
  } else if (sectionName.toLowerCase() === 'ship') {
    sectionBerthTypeId = ['0'];
  } else if (sectionName.toLowerCase() === 'bunker') {
    sectionBerthTypeId = ['0'];
  } else {
    sectionBerthTypeId = metaData.berthTypeList
      .filter(i => i.berthTypeDesc.toLowerCase() === sectionName.toLowerCase())
      .map(i => i.berthTypeId);
  }

  if (sectionBerthTypeId.length === 1) {
    if (sectionName.toLowerCase() === 'dry') {
      const allBerthtype = metaData.berthTypeList.filter(
        i => i.terminalSubTypeId === sectionBerthTypeId[0],
      );
      metaData.mainCargoTypeHandledList.forEach(i => {
        allBerthtype.forEach(j => {
          if (i.berthTypeId === j.berthTypeId) cargoSubType.push(i);
        });
      });
    } else if (sectionName.toLowerCase() === 'ship') {
      cargoSubType = metaData.vessels.map(i => ({
        mainCargoTypeId: i.mstWopVesselTypeId,
        mainCargoTypeDesc: i.wopVesselDesc,
      }));
    } else if (sectionName.toLowerCase() === 'bunker') {
      // noBunkerSelected
      metaData.terminalBunkers.forEach(i => {
        if (i.fuelTypeName.toLowerCase() === 'no bunkers') {
          noBunkersValueId = i.fuelTypeId;
        }
        cargoSubType.push({
          mainCargoTypeId: i.fuelTypeId,
          mainCargoTypeDesc: i.fuelTypeName,
        });
      });
    } else {
      // for Oil, Gas & chemical
      cargoSubType = metaData.mainCargoTypeHandledList.filter(
        mainType => mainType.berthTypeId === sectionBerthTypeId[0],
      );
    }
  }
  const removeCargoHandled = index => {
    const cargos = [...data];
    cargos.splice(index, 1);
    dDeleteBerthDataCargoHandled(sectionName.toLowerCase(), cargos);
  };

  // const getSelectedCargos = () => {
  const selectedCargos = [];
  Object.keys(data).forEach(i => {
    if (data[i].cargoType !== '') selectedCargos.push(data[i].cargoType);
  });

  const showPlus = index =>
    !readOnly &&
    index === data.length - 1 &&
    data.length !== cargoSubType.length;

  const row = data.map((i, index) => (
    <Row ke={`cargo-${index}`}>
      <GroupCargoInputs
        cargoSubType={cargoSubType}
        selectedCargos={selectedCargos}
        sectionBerthTypeId={sectionBerthTypeId}
        dHandleCargoTypeChange={dHandleCargoTypeChange}
        data={i} // Single row
        index={index} // Row index
        sectionName={sectionName} // Oil/Gas/Chemical
        metaData={metaData}
        readOnly={readOnly}
        noBunkersValueId={noBunkersValueId}
        berthTypeTransactions={berthTypeTransactions}
      />
      {(noBunkersValueId === '' || noBunkersValueId !== i.cargoType) && (
        <Col className="m-auto">
          {!readOnly && (
            <Button
              size="sm"
              color="primary"
              disabled={data.length === 1}
              onClick={() => removeCargoHandled(index)}
              className="img-upload img-upload-plus btn mr-2"
            >
              <i className="fa fa-minus" aria-hidden="true" />
            </Button>
          )}

          {showPlus(index) && (
            <>
              <Button
                size="sm"
                // outline
                color="primary"
                className="img-upload img-upload-plus btn"
                onClick={() =>
                  dUpdateBerthDataCargoHandled(sectionName.toLowerCase(), {
                    cargoType: '',
                    productTypes: [],
                  })
                }
              >
                <i className="fa fa-plus" aria-hidden="true" />
              </Button>
            </>
          )}
        </Col>
      )}
    </Row>
  ));

  return <>{row}</>;
}

CargoHandledEditable.propTypes = {
  metaData: PropTypes.object,
  dUpdateBerthDataCargoHandled: PropTypes.func,
  dDeleteBerthDataCargoHandled: PropTypes.func,
  data: PropTypes.object, // Form Data BerthAddForm
  sectionName: PropTypes.string, // Form Key Oil
  dHandleCargoTypeChange: PropTypes.func,
  berthCargoTypeDry: PropTypes.string,
  readOnly: PropTypes.bool,
  berthTypeTransactions: PropTypes.oneOfType([
    PropTypes.array,
    PropTypes.object,
  ]),
};

export default memo(CargoHandledEditable);
