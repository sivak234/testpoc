import React from 'react';
import PropTypes from 'prop-types';
import { Col, Label, FormGroup, FormFeedback } from 'reactstrap';
import Dropdown from '../Dropdown';
import MultiSelect from '../MultiSelect';
import { getDescriptionForDropdown } from '../../utils/dataModification';

/*
 *
 * CargoHandledEditable helper
 *
 */

export function defaultFunction(text) {
  return text;
}

export const GroupCargoInputs = ({
  sectionBerthTypeId,
  selectedCargos,
  dHandleCargoTypeChange,
  data,
  index,
  sectionName,
  metaData,
  cargoSubType,
  readOnly,
  noBunkersValueId,
  berthTypeTransactions,
}) => {
  let cargoSubTypeOption = <></>;
  let productHandledOption = [];
  // let cargoSubType = [];
  let productHandled = [];

  if (sectionBerthTypeId.length === 1) {
    if (sectionName.toLowerCase() === 'dry') {
      productHandled = (metaData.productsHandled || []).filter(
        e => e.mainCargoTypeId === data.cargoType,
      );
    } else if (sectionName.toLowerCase() === 'ship') {
      metaData.vesselClassification.forEach(j => {
        if (j.wopVesselTypeID === data.cargoType)
          productHandled.push({
            productTypeHandledId: j.vesselSizeCategoryID,
            productTypeHandledDesc: j.sizeCategory,
          });
      });
    } else if (sectionName.toLowerCase() === 'bunker') {
      metaData.terminalBunkersSubType.forEach(j => {
        productHandled.push({
          productTypeHandledId: j.supplyTypeId,
          productTypeHandledDesc: j.supplyTypeDescription,
        });
      });
    } else {
      productHandled = (metaData.productsHandled || []).filter(
        e => e.mainCargoTypeId === data.cargoType,
      );
    }

    // Berth Type is Dry the Cargo handled should be filtered based on Cargo Type selected
    if (sectionName.toLowerCase() === 'dry') {
      const filteredCargoSubType = [];
      (cargoSubType || []).forEach(i => {
        berthTypeTransactions.forEach(j => {
          if (i.berthTypeId === j.berthTypeId) filteredCargoSubType.push(i);
        });
      });
      cargoSubTypeOption = getOptions(
        filteredCargoSubType,
        'mainCargoTypeId',
        'mainCargoTypeDesc',
        data,
        selectedCargos,
      );
    } else {
      cargoSubTypeOption = getOptions(
        cargoSubType,
        'mainCargoTypeId',
        'mainCargoTypeDesc',
        data,
        selectedCargos,
      );
    }

    productHandledOption = getMultiSelectOptions(
      productHandled,
      'productTypeHandledId',
      'productTypeHandledDesc',
    );
  }

  const handleCargoTypeChange = el => {
    const newData = { ...data };
    newData.cargoType = el.target.value;
    dHandleCargoTypeChange(
      sectionName.toLowerCase(),
      index,
      newData,
      'main-cargo',
    );
  };

  const onProductChangeClick = selectedIds => {
    const newData = { ...data };
    newData.productTypes = [...selectedIds];
    dHandleCargoTypeChange(sectionName.toLowerCase(), index, newData, '');
  };

  const selectedIds = data.productTypes.map(i => i);
  const selectedNames = [];

  selectedIds.forEach(i => {
    if (sectionName.toLowerCase() === 'ship') {
      (metaData.vesselClassification || []).forEach(e => {
        if (
          e.wopVesselTypeID === data.cargoType &&
          e.vesselSizeCategoryID === i
        ) {
          selectedNames.push(e.sizeCategory);
        }
      });
    } else if (sectionName.toLowerCase() === 'bunker') {
      (metaData.terminalBunkersSubType || []).forEach(e => {
        if (e.supplyTypeId === i) {
          selectedNames.push(e.supplyTypeDescription);
        }
      });
    } else {
      (metaData.productsHandled || []).forEach(e => {
        if (
          e.mainCargoTypeId === data.cargoType &&
          e.productTypeHandledId === i
        ) {
          selectedNames.push(e.productTypeHandledDesc);
        }
      });
    }
  });

  let dropdownLabel = '';
  let multiselectLabel = '';
  switch (sectionName.toLowerCase()) {
    case 'ship':
      dropdownLabel = 'Ship Type';
      multiselectLabel = 'Ship Size Classification';
      break;
    case 'bunker':
      dropdownLabel = 'Fuels Handled';
      multiselectLabel = 'Supply Type for Each Bunker';
      break;
    default:
      dropdownLabel = `${sectionName} Cargo Handled`;
      multiselectLabel = 'Products';
      break;
  }
  let readOnlyHeader = <></>;
  let requiredCassName = '';
  if (!readOnly) {
    requiredCassName =
      sectionName.toLowerCase() === 'bunker' &&
      data.cargoType &&
      data.cargoType !== ''
        ? 'mandate'
        : '';
  }

  if (readOnly && index === 0) {
    readOnlyHeader = (
      <>
        <Col md={3} sm={12} className="pb-3">
          <Label>{dropdownLabel}</Label>
        </Col>
        <Col md={6} sm={12}>
          <Label>{multiselectLabel}</Label>
        </Col>
        <Col md={3} sm={12} />
      </>
    );
  }
  return (
    <>
      {readOnlyHeader}
      <Col md={3} sm={12}>
        {readOnly && (
          <div className="pb-2">
            {getDescriptionForDropdown(
              cargoSubType,
              data.cargoType,
              'mainCargoTypeId',
              'mainCargoTypeDesc',
            )}
          </div>
        )}
        {!readOnly && (
          <FormGroup>
            <Dropdown
              name={`mainCargoType-${sectionName.toLowerCase()}-${index}`}
              options={cargoSubTypeOption}
              onChange={handleCargoTypeChange}
              selected={data.cargoType}
              isDisabled={readOnly}
              label={dropdownLabel}
              invalid={data.isInvalid}
              id={`mainCargoType-${sectionName.toLowerCase()}-${index}`}
              required={['oil', 'gas', 'chemical'].includes(
                sectionName.toLowerCase(),
              )}
            />
            <FormFeedback>Cargo handled is mandatory </FormFeedback>
          </FormGroup>
        )}
      </Col>
      {(noBunkersValueId === '' || data.cargoType !== noBunkersValueId) && (
        <Col md={6} sm={12}>
          {readOnly && selectedNames.join(',')}
          {!readOnly && (
            <>
              <Label className={requiredCassName}>{multiselectLabel}</Label>
              <FormGroup>
                <MultiSelect
                  options={productHandledOption}
                  handleIds={onProductChangeClick}
                  selectedCheckIds={selectedIds}
                  selectedCheckValues={selectedNames}
                  multiSelectId={`${sectionName.toLowerCase()}-${index}`}
                  multiDisabled={readOnly}
                  invalid={data.isSupplyTypeInvalid}
                  invalidMessage="Supply type is mandatory"
                />
              </FormGroup>
            </>
          )}
        </Col>
      )}
    </>
  );
};

GroupCargoInputs.propTypes = {
  sectionBerthTypeId: PropTypes.string,
  index: PropTypes.number,
  metaData: PropTypes.object,
  data: PropTypes.object, // Form Data BerthAddForm
  sectionName: PropTypes.string, // Form Key Oil
  dHandleCargoTypeChange: PropTypes.func,
  selectedCargos: PropTypes.array,
  cargoSubType: PropTypes.array,
  readOnly: PropTypes.bool,
  noBunkersValueId: PropTypes.string,
  berthTypeTransactions: PropTypes.oneOfType([
    PropTypes.array,
    PropTypes.object,
  ]),
};
const getOptions = (items, key, label, data, selectedCargos) => {
  const options = [];
  // const allItems = item.itemList;
  // const { key, valKey } = { ...item.key, ...item.valKey };
  Object.keys(items).forEach(iterator => {
    if (Object.keys(selectedCargos).length > 0) {
      if (
        !selectedCargos.includes(items[iterator][key]) ||
        items[iterator][key] === data.cargoType
      ) {
        options.push(
          <option key={items[iterator][key]} value={items[iterator][key]}>
            {items[iterator][label]}
          </option>,
        );
      }
    } else {
      options.push(
        <option key={items[iterator][key]} value={items[iterator][key]}>
          {items[iterator][label]}
        </option>,
      );
    }
  });
  return options;
};

const getMultiSelectOptions = (subTypes, key, label) =>
  subTypes.map((e, index) => {
    const val = {
      name: e[label],
      value: e[key],
      count: index,
    };
    return { props: val };
  });
