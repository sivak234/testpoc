/**
 *
 * Asynchronously loads the component for ApiServices
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
