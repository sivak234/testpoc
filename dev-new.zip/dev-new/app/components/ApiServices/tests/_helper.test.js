// import { defaultFunction } from '../_helper';

// describe('ApiServices helpers', () => {
//   describe('Default Helper Function', () => {
//     it('returns the expected value', () => {
//       const expected = 'Sample Text';
//       expect(defaultFunction('Sample Text')).toEqual(expected);
//     });
//   });
// });
describe('<ApiServices />', () => {
  it('Expect to not log errors in ApiServices', () => {
    expect(true).toBeTruthy();
  });
});
