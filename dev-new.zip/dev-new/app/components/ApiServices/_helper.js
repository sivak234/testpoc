/*
 *
 * ApiServices helper
 *
 */

export function defaultFunction(text) {
  return text;
}
