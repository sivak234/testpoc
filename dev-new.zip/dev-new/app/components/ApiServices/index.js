/**
 *
 * ApiServices
 *
 */

import React, { memo, useState } from 'react';
import {
  Card,
  CardText,
  CardBody,
  Button,
  Row,
  Col,
  CardImg,
  Nav,
  NavItem,
  NavLink,
  Collapse,
  Navbar,
  Input,
  Table,
} from 'reactstrap';
import { NavHashLink as Link } from 'react-router-hash-link';
import { FormattedMessage } from 'react-intl';
import PropTypes from 'prop-types';
import messages from './messages';

import './_helper';

import './index.scss';

function ApiServices({ apiData, dmoreButtonTriggered, dfetchApiListNid }) {
  const [collapsed, setCollapsed] = useState(true);
  const toggleNavbar = () => setCollapsed(!collapsed);
  const moreTriggered = event => {
    const nid = event.target.id;
    dmoreButtonTriggered(true, nid);
    dfetchApiListNid();
  };
  const back = () => (
    <p>
      <Link to="/our-services">
        <FormattedMessage {...messages.back} />
      </Link>
    </p>
  );
  const scrollToViewOptions = () => {
    const isScrollFlag = true;
    return (
      <>
        <Row className="Api_Container">
          <Col xs={8} md={10}>
            <h1 className="title-bg-blue">
              <FormattedMessage {...messages.apiServices} />
            </h1>
          </Col>
          <Col xs={4} md={2}>
            <div>{back()}</div>
          </Col>
        </Row>
        <Row className="Mobile_Api_Row">
          <Col md={12} xs={12} className="d-md-none d-xs-block">
            <Navbar
              color="faded"
              light
              onClick={toggleNavbar}
              className="Arrow_Icon"
            >
              {apiData.apiNavBarData && apiData.apiNavBarData.length >= 1 && (
                <Input type="text" value="Quick jump to">
                  <FormattedMessage {...messages.quickJump} />
                </Input>
              )}
              <Collapse isOpen={!collapsed} navbar className="Api_Navbar_items">
                <Nav navbar>
                  {apiData.apiNavBarData && apiData.apiNavBarData.length >= 1 && (
                    <>
                      {apiData.apiNavBarData.map(apiName => (
                        <NavItem>
                          <NavLink>
                            <Link
                              to={`/api-service-details#${apiName.name
                                .toLowerCase()
                                .replace(/ +/g, '')}`}
                              scroll={el => el.scrollIntoView(!!isScrollFlag)}
                            >
                              {apiName.name}
                            </Link>
                          </NavLink>
                        </NavItem>
                      ))}
                    </>
                  )}
                </Nav>
              </Collapse>
            </Navbar>
          </Col>
        </Row>
        <Row className="Api_Row">
          <Col md={12} className="ApiNavBar d-none d-lg-block">
            <Nav>
              {apiData.apiNavBarData && apiData.apiNavBarData.length >= 1 && (
                <>
                  {apiData.apiNavBarData.map(apiName => (
                    <NavItem>
                      <NavLink>
                        <Link
                          to={`/api-service-details#${apiName.name
                            .toLowerCase()
                            .replace(/ +/g, '')}`}
                          scroll={el => el.scrollIntoView(!!isScrollFlag)}
                        >
                          {apiName.name}
                        </Link>
                      </NavLink>
                    </NavItem>
                  ))}
                </>
              )}
            </Nav>
          </Col>
        </Row>
      </>
    );
  };
  return (
    <>
      <div className="CardTextColor">
        {apiData.apiPortData && apiData.apiPortData.length >= 1 && (
          <>
            {scrollToViewOptions()}
            {apiData.apiPortData.map(apiPort => (
              <>
                {apiPort.map(apiName => (
                  <div
                    className="Card_Section"
                    id={apiName.name.toLowerCase().replace(/ +/g, '')}
                  >
                    <Row className="cardSectionRow">
                      <Col
                        xs="12"
                        md="3"
                        className="Remove_border"
                        style={{
                          backgroundColor: apiName.field_background_color,
                        }}
                      >
                        <Card
                          style={{
                            backgroundColor: apiName.field_background_color,
                          }}
                        >
                          <CardImg
                            height="70px"
                            src={apiName.field_port_model_icon}
                            alt="Card image cap"
                          />
                          <CardBody>
                            <CardText>
                              <div>
                                <h1>{apiName.name}</h1>
                              </div>
                              {React.createElement('div', {
                                dangerouslySetInnerHTML: {
                                  __html: apiName.field_port_model_description,
                                },
                              })}
                            </CardText>
                          </CardBody>
                        </Card>
                      </Col>
                      <Col xs="12" md="9" className="dynamicBox">
                        <Row>
                          {apiName.view.map(apiPortInner => (
                            <Col xs="12" md="4" className="Card_Height">
                              <Table bordered>
                                <thead
                                  style={{
                                    backgroundColor:
                                      apiName.field_background_color,
                                  }}
                                >
                                  <tr className="api_services_row1">
                                    <th className="Table_Text_Left">
                                      {apiPortInner.field_id}
                                    </th>
                                    <th className="Table_Text_Right nowrap">
                                      {apiPortInner.title}
                                    </th>
                                  </tr>
                                </thead>
                                <tbody>
                                  <tr className="api_services_row2">
                                    <td
                                      colSpan={2}
                                      className="nowrap"
                                      style={{ borderBottom: '1px solid #fff' }}
                                    >
                                      {React.createElement('div', {
                                        dangerouslySetInnerHTML: {
                                          __html:
                                            apiPortInner.field_short_description,
                                        },
                                      })}
                                    </td>
                                  </tr>
                                  <tr>
                                    <td
                                      colSpan={2}
                                      className="nowrap"
                                      style={{ borderTop: '1px solid #fff' }}
                                    >
                                      <div className="Card_Button_Alignment">
                                        <Button
                                          onClick={moreTriggered}
                                          id={apiPortInner.nid}
                                        >
                                          <FormattedMessage
                                            {...messages.more}
                                          />
                                        </Button>
                                      </div>
                                    </td>
                                  </tr>
                                </tbody>
                              </Table>
                            </Col>
                          ))}
                        </Row>
                      </Col>
                    </Row>
                  </div>
                ))}
              </>
            ))}
          </>
        )}
      </div>
    </>
  );
}

ApiServices.propTypes = {
  apiData: PropTypes.object.isRequired,
  dmoreButtonTriggered: PropTypes.func.isRequired,
  dfetchApiListNid: PropTypes.func.isRequired,
};

export default memo(ApiServices);
