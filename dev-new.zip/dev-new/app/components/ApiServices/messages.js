/*
 * ApiServices Messages
 *
 * This contains all the text for the ApiServices component.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.components.ApiServices';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'This is the ApiServices component!',
  },
  back: {
    id: `${scope}.back`,
    defaultMessage: '<< Back',
  },
  apiServices: {
    id: `${scope}.apiServices`,
    defaultMessage: 'API SERVICES',
  },
  quickJump: {
    id: `${scope}.quickJump`,
    defaultMessage: 'Quick jump to',
  },
  more: {
    id: `${scope}.more`,
    defaultMessage: 'More',
  },
});
