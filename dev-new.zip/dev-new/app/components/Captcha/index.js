/**
 *
 * Captcha
 *
 */

import React from 'react';
import { Form, Row, Col, Input } from 'reactstrap';
import { intlShape, injectIntl } from 'react-intl';
import PropTypes from 'prop-types';
import messages from './messages';

import './index.scss';

import refreshIcon from '../../assets/icons/refresh-icon.svg';

function Captcha(props) {
  const { intl, captchainfo, RefreshCaptcha, readcaptchinfodetaildet } = props;

  const captchaImageBytes = `data:image/gif;base64,${captchainfo.captchaBytes}`;
  const captchaid = `${captchainfo.id}`;

  const placeholdercaptcha = intl.formatMessage({
    ...messages.placeholdercaptcha,
  });

  const ValidateCaptchadet = event => {
    readcaptchinfodetaildet(event);
  };

  return (
    <React.Fragment>
      <Form id="captcha">
        <Row>
          <Col xs={4} md={5}>
            <img
              src={captchaImageBytes}
              alt={captchaImageBytes}
              id={captchaid}
            />
          </Col>
          <Col xs={4} md={2} onClick={RefreshCaptcha}>
            <img
              src={refreshIcon}
              alt="check"
              className="refreshicon  icon-set-captcha"
            />
          </Col>
          <Col xs={4} md={5} className="top-control-detail">
            <Input
              type="text"
              id="captcha-text"
              className="refreshicon"
              placeholder={placeholdercaptcha}
              onChange={event => ValidateCaptchadet(event.target.value)}
            />
          </Col>
        </Row>
        <Row>
          <Col md={4} />
        </Row>
      </Form>
    </React.Fragment>
  );
}

Captcha.propTypes = {
  intl: intlShape.isRequired,
  captchainfo: PropTypes.object,
  RefreshCaptcha: PropTypes.func.isRequired,
  readcaptchinfodetaildet: PropTypes.func.isRequired,
};

export default injectIntl(Captcha);
