/**
 *
 * Asynchronously loads the component for AisReportExport
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
