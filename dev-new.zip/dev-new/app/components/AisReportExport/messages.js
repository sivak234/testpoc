/*
 * AisReportExport Messages
 *
 * This contains all the text for the AisReportExport component.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.components.AisReportExport';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'Export',
  },
  exportFromDate: {
    id: `${scope}.exportFromDate`,
    defaultMessage: 'From Date',
  },
  exportToDate: {
    id: `${scope}.exportToDate`,
    defaultMessage: 'To Date',
  },
});
