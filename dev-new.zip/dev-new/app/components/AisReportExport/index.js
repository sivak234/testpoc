/**
 *
 * AisReportExport
 *
 */

import React, { memo, Fragment } from 'react';
import PropTypes from 'prop-types';
import { FormGroup, Label, Row, Col } from 'reactstrap';
import DatePicker from 'react-datepicker';
import 'react-datepicker/dist/react-datepicker.css';
import { FormattedMessage } from 'react-intl';
import messages from './messages';
import ExcelIcon from '../../assets/images/excel-icon.svg';

function AisReportExport(props) {
  const {
    fetchFromDate,
    fetchToDate,
    fromDate,
    toDate,
    portVesselData,
    handleExportPortData,
  } = props;
  let fDate = fromDate;
  if (fromDate === null) {
    const date = new Date();
    date.setDate(date.getDate() - 90);
    fDate = date;
  }
  let tDate = toDate;
  if (toDate === null) {
    tDate = new Date();
  }
  return (
    <Fragment>
      <Row>
        <Col xs="3" className="vessel-movement col-2">
          <h4>
            <FormattedMessage {...messages.header} />
          </h4>
        </Col>
      </Row>
      <Row className="ais-port-movement-label-container">
        <Col md={4}>
          <FormGroup controlid="fromdateControl">
            <Label>
              <FormattedMessage {...messages.exportFromDate} />
            </Label>
            <DatePicker
              selected={fDate}
              value={fDate}
              dateFormat="dd/MM/yyyy"
              defaultValue={fDate}
              minDate={new Date().setDate(new Date().getDate() - 90)}
              maxDate={new Date()}
              onChange={e => {
                fetchFromDate(e);
              }}
            />
          </FormGroup>
        </Col>
        <Col md={4}>
          <FormGroup controlid="todateControl">
            <Label>
              <FormattedMessage {...messages.exportToDate} />
            </Label>
            <DatePicker
              selected={tDate}
              value={tDate}
              dateFormat="dd/MM/yyyy"
              defaultValue={tDate}
              minDate={fDate.setDate(fDate.getDate())}
              maxDate={new Date()}
              onChange={e => {
                fetchToDate(e);
              }}
            />
          </FormGroup>
        </Col>
        <Col
          md={2}
          className="export-icon-excel"
          onClick={e => handleExportPortData(portVesselData, e)}
        >
          <img
            src={ExcelIcon}
            alt=""
            style={{ paddingTop: '40px', cursor: 'pointer' }}
          />
        </Col>
      </Row>
    </Fragment>
  );
}

AisReportExport.propTypes = {
  fetchFromDate: PropTypes.func.isRequired,
  fetchToDate: PropTypes.func.isRequired,
  fromDate: PropTypes.object,
  toDate: PropTypes.object,
  portVesselData: PropTypes.array.isRequired,
  handleExportPortData: PropTypes.func.isRequired,
};

export default memo(AisReportExport);
