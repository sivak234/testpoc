/*
 * CargoHandled Messages
 *
 * This contains all the text for the CargoHandled component.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.components.CargoHandled';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'Cargo Handled',
  },
  cargoTypes: {
    id: `${scope}.cargoTypes`,
    defaultMessage: 'Cargo Types',
  },
  commodities: {
    id: `${scope}.commodities`,
    defaultMessage: 'Commodities',
  },
  products: {
    id: `${scope}.products`,
    defaultMessage: 'Products',
  },
});
