/**
 *
 * CargoHandled
 *
 */

import React from 'react';
import PropTypes from 'prop-types';

import { FormattedMessage } from 'react-intl';
import { Table } from 'reactstrap';
import messages from './messages';
import './index.scss';

function CargoHandled({ data, passedRef }) {
  const cargoData = [];

  const capitalize = word => {
    if (typeof word !== 'string') return '';
    return word.charAt(0).toUpperCase() + word.slice(1);
  };

  if (data) {
    const entries = Object.entries(data);
    if (entries.length > 0) {
      entries.forEach(item =>
        cargoData.push(
          <tr key={item[0]}>
            <td>{capitalize(item[0])}</td>
            <td>{item[1][0]}</td>
            <td>{item[1][1]}</td>
          </tr>,
        ),
      );
    } else {
      cargoData.push(
        <tr key="some-key">
          <td>--</td>
          <td>--</td>
          <td>--</td>
        </tr>,
      );
    }
  }
  return (
    <>
      <h4 ref={passedRef}>
        <span className="backgroundcolor">
          <FormattedMessage {...messages.header} />
        </span>
      </h4>
      <Table className="cargoTable">
        <thead className="table-head">
          <tr>
            <th width="33.33%">
              <FormattedMessage {...messages.cargoTypes} />
            </th>
            <th width="33.33%">
              <FormattedMessage {...messages.commodities} />
            </th>
            <th width="33.33%">
              <FormattedMessage {...messages.products} />
            </th>
          </tr>
        </thead>
        <tbody>{cargoData}</tbody>
      </Table>
    </>
  );
}

CargoHandled.propTypes = {
  data: PropTypes.oneOfType([PropTypes.array, PropTypes.object]).isRequired,
  passedRef: PropTypes.func,
};

export default CargoHandled;
