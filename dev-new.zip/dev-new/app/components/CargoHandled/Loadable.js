/**
 *
 * Asynchronously loads the component for CargoHandled
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
