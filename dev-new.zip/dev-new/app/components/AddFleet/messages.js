/*
 * AddFleet Messages
 *
 * This contains all the text for the AddFleet component.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.components.AddFleet';

export default defineMessages({
  createFleet: {
    id: `${scope}.createFleet`,
    defaultMessage: 'Create Fleet',
  },
  fleetName: {
    id: `${scope}.fleetName`,
    defaultMessage: 'Fleet Name',
  },
  fleetDescription: {
    id: `${scope}.fleetDescription`,
    defaultMessage: 'Fleet Description',
  },
  sharedWith: {
    id: `${scope}.sharedWith`,
    defaultMessage: 'Shared with',
  },
  everyone: {
    id: `${scope}.everyone`,
    defaultMessage: 'Everyone',
  },
  onlyMe: {
    id: `${scope}.onlyMe`,
    defaultMessage: 'Only Me',
  },
  vesselsInFleet: {
    id: `${scope}.vesselsInFleet`,
    defaultMessage: 'Vessels in Fleet',
  },
  vesselImo: {
    id: `${scope}.vesselImo`,
    defaultMessage: 'Vessel or IMO',
  },
  addVessel: {
    id: `${scope}.addVessel`,
    defaultMessage: 'Add Vessel',
  },
  cancel: {
    id: `${scope}.cancel`,
    defaultMessage: 'Cancel',
  },
  myFleetdata: {
    id: `${scope}.myFleetdata`,
    defaultMessage: 'My Fleet',
  },
  cancelButton: {
    id: `${scope}.cancelButton`,
    defaultMessage: 'Cancel',
  },
  addVessels: {
    id: `${scope}.addVessels`,
    defaultMessage: 'Add Vessels',
  },
  vesselName: {
    id: `${scope}.vesselName`,
    defaultMessage: 'Vessel Name',
  },
  imo: {
    id: `${scope}.imo`,
    defaultMessage: 'IMO',
  },
  vesselType: {
    id: `${scope}.vesselType`,
    defaultMessage: 'Vessel Type',
  },
  ownerType: {
    id: `${scope}.ownerType`,
    defaultMessage: 'Owner Type',
  },
  ownerDetails: {
    id: `${scope}.ownerDetails`,
    defaultMessage: 'Owner Details',
  },
  searchButton: {
    id: `${scope}.searchButton`,
    defaultMessage: 'Search',
  },
  editFleet: {
    id: `${scope}.editFleet`,
    defaultMessage: 'Edit Fleet',
  },
  saveButton: {
    id: `${scope}.saveButton`,
    defaultMessage: 'Save',
  },
  searchResults: {
    id: `${scope}.searchResults`,
    defaultMessage: 'Search Results',
  },
  fleetNameDuplicateMsg: {
    id: `${scope}.fleetNameDuplicateMsg`,
    defaultMessage: 'Fleet Name already exists!',
  },
  searchMessage: {
    id: `${scope}.searchMessage`,
    defaultMessage: 'Try searching with some parameters.',
  },
  vesselsCount: {
    id: `${scope}.vesselsCount`,
    defaultMessage: 'Vessels Count',
  },
  vesselCount: {
    id: `${scope}.vesselCount`,
    defaultMessage: 'Vessel Count',
  },
  addVesselMsg: {
    id: `${scope}.addVesselMsg`,
    defaultMessage: 'Selected Vessel(s) added to fleet',
  },
});
