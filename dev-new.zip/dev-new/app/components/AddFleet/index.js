/**
 *
 * AddFleet
 *
 */

import React, { memo, useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import { FormattedMessage } from 'react-intl';
import {
  Button,
  Modal,
  ModalHeader,
  ModalBody,
  Label,
  Input,
  Row,
  Col,
  CustomInput,
  Alert,
} from 'reactstrap';
import DataTableList from '../DataTableList/Loadable';
import AddUserSuccessMsgModal from '../AddUserSuccessMsgModal/Loadable';
import messages from './messages';
import { blockNumberDecimalInput } from '../../utils/validation';
import { setSortByData } from '../../utils/dataModification';
import './index.scss';
import DropDown from '../Dropdown';

function AddFleet({
  createFleetModalCloseTrigger,
  isCreateFleetModal,
  fleetInputChange,
  addFleetData,
  searchFleetData,
  addVesselTrigger,
  addVesselButtonTrigger,
  vesselCheckBoxTrigger,
  deleteVesselTrigger,
  addFleetTrigger,
  saveFleetTrigger,
  getVesselSearch,
  isCheckAllVessel,
  duplicateFleetcheck,
  messageObj,
  dcheckAllVessel,
  isExceedVessel,
  isAddVesselClick,
  handledeselectVessel,
}) {
  const [addVesselMsg, setAddVesselMsg] = useState(false);
  const [deleteVesselMsg, setDeleteVesselMsg] = useState(false);
  const [deleteVesselMsgContent, setDeleteVesselMsgContent] = useState('');
  const userType = localStorage.getItem('userType');
  const [sortValue, handleSorting] = useState('asc');
  const [sortField, handleSortField] = useState('vesselName');
  const [sortIcon, handleSortIcon] = useState('fa fa-sort-asc');

  const [myFleetsortValue, handleMyFleetSortOrder] = useState(
    addFleetData.fleetId !== '' ? 'asc' : '',
  );
  const [myfleetsortField, handleMyFleetSortField] = useState(
    addFleetData.fleetId !== '' ? 'vesselName' : '',
  );
  const [myfleetsortIcon, handleMyfleetsortIcon] = useState(
    addFleetData.fleetId !== '' ? 'fa fa-sort-asc' : '',
  );

  const [addFleetsortValue, handleAddFleetSortOrder] = useState('asc');
  const [addFleetsortField, handleAddFleetSortField] = useState('vesselName');
  const [addfleetsortIcon, handleAddfleetsortIcon] = useState('fa fa-sort-asc');
  const handleChange = (type, field, val) => {
    handleMyFleetSortOrder('');
    if (field === 'imo' && val.length <= 8) {
      fleetInputChange(type, field, val);
    } else if (field !== 'imo') fleetInputChange(type, field, val);
  };
  const addFleetClick = () => {
    duplicateFleetcheck(addFleetData.fleetName);
  };
  const saveFleetClick = () => {
    duplicateFleetcheck(addFleetData.fleetName);
  };
  const vesselCheck = (event, vesselId) => {
    if (!isCheckAllVessel) {
      const { addedOriginalVesselList } = addFleetData;
      let checkExist = [];
      if (event.target.checked === true) {
        checkExist = addedOriginalVesselList.filter(
          x => x.vesselId === vesselId,
        );
      }
      if (checkExist.length === 0) {
        vesselCheckBoxTrigger(event.target.checked, vesselId, false);
      }
    } else {
      const { addedOriginalVesselList } = addFleetData;
      let checkExist = [];
      if (event.target.checked === true) {
        checkExist = addedOriginalVesselList.filter(
          x => x.vesselId === vesselId,
        );
      }
      if (checkExist.length === 0) {
        vesselCheckBoxTrigger(event.target.checked, vesselId, false);
      }
      const option = {
        sortOrder: 'asc',
        sortBy: 'vesselName',
        pageNo: 1,
      };
      getVesselSearch(option);
    }
  };
  const vesselCheckAll = event => {
    if (event.target.checked) {
      handleAddFleetSortOrder(sortValue);
      handleAddFleetSortField(sortField);
      handleAddfleetsortIcon(addfleetsortIcon);
      dcheckAllVessel({
        ischeckedAll: event.target.checked,
        pagePerRecord: addFleetData.totalrecords,
        sortBy: sortField,
        sortOrder: sortValue,
      });
    } else {
      handleSorting(sortValue);
      handleSortField(sortField);
      handleSortIcon(addfleetsortIcon);
      handledeselectVessel();
      const option = {
        sortOrder: sortValue,
        sortBy: sortField,
        pageNo: searchFleetData.pageNo,
      };
      getVesselSearch(option);
    }
  };
  const fleetDeleteVesselTrigger = vesselId => {
    const position = addFleetData.addedOriginalVesselList
      .map(item => item.vesselId)
      .indexOf(vesselId);
    const { vesselName } = addFleetData.addedOriginalVesselList[position];
    setDeleteVesselMsgContent(
      `Vessel ${vesselName} has been deleted from ${addFleetData.fleetName}`,
    );
    deleteVesselTrigger(vesselId);
    setDeleteVesselMsg(true);
  };
  const onPageChanged = page => {
    const option = {
      sortOrder: sortValue,
      sortBy: sortField,
      pageNo: page.pageNo,
      fetchRecordCount: page.fetchRecordCount,
    };
    getVesselSearch(option);
  };
  const addVesselButtonClick = () => {
    const srtField = myfleetsortField === '' ? 'vesselName' : myfleetsortField;
    const srtIcon = myfleetsortIcon === '' ? 'fa fa-sort-asc' : myfleetsortIcon;
    const srtValue = myFleetsortValue === '' ? 'asc' : myFleetsortValue;
    handleMyfleetsortIcon(srtIcon);
    handleMyFleetSortOrder(srtValue);
    handleMyFleetSortField(srtField);
    addVesselButtonTrigger();
    setAddVesselMsg(true);
    const option = {
      sortOrder: 'asc',
      sortBy: sortField,
      pageNo: searchFleetData.pageNo,
    };
    getVesselSearch(option);
  };
  const onSortPageChanged = event => {
    const field = event.target.title;
    let sort = '';
    let icon = '';
    if (sortField !== event.target.title) {
      sort = 'asc';
      icon = 'fa fa-sort-asc';
    } else if (sortValue === 'asc') {
      sort = 'desc';
      icon = 'fa fa-sort-desc';
    } else if (sortValue === 'desc') {
      sort = 'asc';
      icon = 'fa fa-sort-asc';
    }
    handleSorting(sort);
    handleSortField(field);
    handleSortIcon(icon);
    const option = {
      sortOrder: sort,
      sortBy: event.target.title,
      pageNo: searchFleetData.pageNo,
    };
    getVesselSearch(option);
  };
  const handleSearchVessel = () => {
    handleSorting('asc');
    handleSortField('vesselName');
    handleSortIcon('fa fa-sort-asc');
    const option = {
      sortOrder: 'asc',
      sortBy: 'vesselName',
      pageNo: 1,
    };
    getVesselSearch(option);
  };
  const handleclose = () => {
    handleMyFleetSortOrder('');
    handleMyFleetSortField('');
    handleMyfleetsortIcon('');
    createFleetModalCloseTrigger();
  };

  useEffect(() => {
    setTimeout(() => {
      setAddVesselMsg(false);
      setDeleteVesselMsg(false);
    }, 5000);
  });

  useEffect(() => {
    if (addFleetData.isDuplicateCheck && !addFleetData.isEditFlag) {
      addFleetTrigger();
    }
    if (addFleetData.isDuplicateCheck && addFleetData.isEditFlag) {
      saveFleetTrigger();
    }
  }, [addFleetData.isDuplicateCheck]);

  function checkAdded(vesselId) {
    const vList = addFleetData.addedOriginalVesselList.filter(
      x => x.vesselId === vesselId,
    );
    if (vList.length > 0) {
      return true;
    }
    return false;
  }
  const checkAllDisable = () => {
    if (isCheckAllVessel && isAddVesselClick && !isExceedVessel) {
      return true;
    }
    return false;
  };

  const vesselHeader = [
    {
      title: (
        <CustomInput
          type="checkbox"
          label=""
          id="all"
          onChange={event => vesselCheckAll(event)}
          checked={isCheckAllVessel}
          disabled={checkAllDisable()}
        />
      ),
      cell: row => (
        <CustomInput
          type="checkbox"
          label=""
          id={row.vesselId}
          checked={addFleetData.vesselIds.indexOf(row.vesselId) > -1}
          onChange={event => vesselCheck(event, row.vesselId)}
          disabled={checkAdded(row.vesselId)}
        />
      ),
    },
    {
      title: (
        <>
          <Label title="vesselName" onClick={e => onSortPageChanged(e)}>
            Vessel Name
            <i
              className={sortField === 'vesselName' ? sortIcon : 'fa fa-sort'}
              style={{
                paddingLeft: '5px',
              }}
              title="vesselName"
            />
          </Label>
        </>
      ),
      prop: 'vesselName',
    },
    {
      title: (
        <>
          <Label title="imo" onClick={e => onSortPageChanged(e)}>
            IMO
            <i
              className={sortField === 'imo' ? sortIcon : 'fa fa-sort'}
              style={{
                paddingLeft: '5px',
              }}
              title="imo"
            />
          </Label>
        </>
      ),
      prop: 'imo',
    },
    {
      title: (
        <>
          <Label title="vesselType" onClick={e => onSortPageChanged(e)}>
            Vessel Type
            <i
              className={sortField === 'vesselType' ? sortIcon : 'fa fa-sort'}
              style={{
                paddingLeft: '5px',
              }}
              title="vesselType"
            />
          </Label>
        </>
      ),
      prop: 'vesselType',
    },
    {
      title: (
        <>
          <Label
            title="vesselSizeClassification"
            onClick={e => onSortPageChanged(e)}
          >
            Vessel Size
            <i
              className={
                sortField === 'vesselSizeClassification'
                  ? sortIcon
                  : 'fa fa-sort'
              }
              style={{
                paddingLeft: '5px',
              }}
              title="vesselSizeClassification"
            />
          </Label>
        </>
      ),
      prop: 'vesselSizeClassification',
    },
    {
      title: (
        <>
          <Label title="status" onClick={e => onSortPageChanged(e)}>
            Vessel Status
            <i
              className={sortField === 'status' ? sortIcon : 'fa fa-sort'}
              style={{
                paddingLeft: '5px',
              }}
              title="status"
            />
          </Label>
        </>
      ),
      prop: 'status',
    },
  ];
  const isDisplaySharedWith = () =>
    userType !== 'int' &&
    !addFleetData.isSingleUser &&
    !addFleetData.isFromSharedFleet;

  const myFleetHeader = [
    {
      title: (
        <>
          <Label title="vesselName" onClick={e => MyFleetSorting(e)}>
            Vessel Name
            <i
              className={
                myfleetsortField === 'vesselName'
                  ? myfleetsortIcon
                  : 'fa fa-sort'
              }
              style={{
                paddingLeft: '5px',
              }}
              title="vesselName"
            />
          </Label>
        </>
      ),
      prop: 'vesselName',
    },
    {
      title: (
        <>
          <Label title="imo" onClick={e => MyFleetSorting(e)}>
            IMO
            <i
              className={
                myfleetsortField === 'imo' ? myfleetsortIcon : 'fa fa-sort'
              }
              style={{
                paddingLeft: '5px',
              }}
              title="imo"
            />
          </Label>
        </>
      ),
      prop: 'imo',
    },
    {
      title: (
        <>
          <Label title="vesselType" onClick={e => MyFleetSorting(e)}>
            Vessel Type
            <i
              className={
                myfleetsortField === 'vesselType'
                  ? myfleetsortIcon
                  : 'fa fa-sort'
              }
              style={{
                paddingLeft: '5px',
              }}
              title="vesselType"
            />
          </Label>
        </>
      ),
      prop: 'vesselType',
    },
    {
      title: (
        <>
          <Label
            title="vesselSizeClassification"
            onClick={e => MyFleetSorting(e)}
          >
            Vessel Size
            <i
              className={
                myfleetsortField === 'vesselSizeClassification'
                  ? myfleetsortIcon
                  : 'fa fa-sort'
              }
              style={{
                paddingLeft: '5px',
              }}
              title="vesselSizeClassification"
            />
          </Label>
        </>
      ),
      prop: 'vesselSizeClassification',
    },
    {
      title: (
        <>
          <Label title="status" onClick={e => MyFleetSorting(e)}>
            Vessel Status
            <i
              className={
                myfleetsortField === 'status' ? myfleetsortIcon : 'fa fa-sort'
              }
              style={{
                paddingLeft: '5px',
              }}
              title="status"
            />
          </Label>
        </>
      ),
      prop: 'status',
    },
  ];
  const fld = myfleetsortField === '' ? 'vesselName' : myfleetsortField;
  const sortorder = myFleetsortValue === '' ? 'asc' : myFleetsortValue;
  const dsortData = setSortByData(
    addFleetData.addedOriginalVesselList,
    fld,
    sortorder,
  );
  let addedOriginalVesselList =
    myFleetsortValue === '' ? addFleetData.addedOriginalVesselList : dsortData;
  const MyFleetSorting = e => {
    const field = e.target.title;
    let sort = '';
    let icon = '';
    if (myfleetsortField !== e.target.title) {
      sort = 'asc';
      icon = 'fa fa-sort-asc';
    } else if (myFleetsortValue === 'asc') {
      sort = 'desc';
      icon = 'fa fa-sort-desc';
    } else if (myFleetsortValue === 'desc') {
      sort = 'asc';
      icon = 'fa fa-sort-asc';
    }
    handleMyFleetSortOrder(sort);
    handleMyFleetSortField(field);
    handleMyfleetsortIcon(icon);
    addedOriginalVesselList = setSortByData(
      addFleetData.addedOriginalVesselList,
      field,
      sort,
    );
  };
  const addFleetHeader = [
    {
      title: (
        <CustomInput
          type="checkbox"
          label=""
          id="all"
          onChange={event => vesselCheckAll(event)}
          checked={isCheckAllVessel}
          disabled={checkAllDisable()}
        />
      ),
      cell: row => (
        <CustomInput
          type="checkbox"
          label=""
          id={row.vesselId}
          checked={addFleetData.vesselIds.indexOf(row.vesselId) > -1}
          onChange={event => vesselCheck(event, row.vesselId)}
          disabled={checkAdded(row.vesselId)}
        />
      ),
    },
    {
      title: (
        <>
          <Label title="vesselName" onClick={e => addFleetSorting(e)}>
            Vessel Name
            <i
              className={
                addFleetsortField === 'vesselName'
                  ? addfleetsortIcon
                  : 'fa fa-sort'
              }
              style={{
                paddingLeft: '5px',
              }}
              title="vesselName"
            />
          </Label>
        </>
      ),
      prop: 'vesselName',
    },
    {
      title: (
        <>
          <Label title="imo" onClick={e => addFleetSorting(e)}>
            IMO
            <i
              className={
                addFleetsortField === 'imo' ? addfleetsortIcon : 'fa fa-sort'
              }
              style={{
                paddingLeft: '5px',
              }}
              title="imo"
            />
          </Label>
        </>
      ),
      prop: 'imo',
    },
    {
      title: (
        <>
          <Label title="vesselType" onClick={e => addFleetSorting(e)}>
            Vessel Type
            <i
              className={
                addFleetsortField === 'vesselType'
                  ? addfleetsortIcon
                  : 'fa fa-sort'
              }
              style={{
                paddingLeft: '5px',
              }}
              title="vesselType"
            />
          </Label>
        </>
      ),
      prop: 'vesselType',
    },
    {
      title: (
        <>
          <Label
            title="vesselSizeClassification"
            onClick={e => addFleetSorting(e)}
          >
            Vessel Size
            <i
              className={
                addFleetsortField === 'vesselSizeClassification'
                  ? addfleetsortIcon
                  : 'fa fa-sort'
              }
              style={{
                paddingLeft: '5px',
              }}
              title="vesselSizeClassification"
            />
          </Label>
        </>
      ),
      prop: 'vesselSizeClassification',
    },
    {
      title: (
        <>
          <Label title="status" onClick={e => addFleetSorting(e)}>
            Vessel Status
            <i
              className={
                addFleetsortField === 'status' ? addfleetsortIcon : 'fa fa-sort'
              }
              style={{
                paddingLeft: '5px',
              }}
              title="status"
            />
          </Label>
        </>
      ),
      prop: 'status',
    },
  ];
  const addfld = addFleetsortField === '' ? 'vesselName' : addFleetsortField;
  const addsort = addFleetsortValue === '' ? 'asc' : addFleetsortValue;
  let addFleetSortData = setSortByData(
    addFleetData.vesselList,
    addfld,
    addsort,
  );
  const addFleetSorting = e => {
    const field = e.target.title;
    let sort = '';
    let icon = '';
    if (addFleetsortField !== e.target.title) {
      sort = 'asc';
      icon = 'fa fa-sort-asc';
    } else if (addFleetsortValue === 'asc') {
      sort = 'desc';
      icon = 'fa fa-sort-desc';
    } else if (addFleetsortValue === 'desc') {
      sort = 'asc';
      icon = 'fa fa-sort-asc';
    }
    handleAddFleetSortOrder(sort);
    handleAddFleetSortField(field);
    handleAddfleetsortIcon(icon);
    addFleetSortData = setSortByData(addFleetData.vesselList, field, sort);
  };
  const addedOriginalVesselListCount =
    addFleetData.addedOriginalVesselList.length;
  if (
    addFleetData.searchParam &&
    addFleetData.searchParam.length > 0 &&
    addFleetData.addedOriginalVesselList.length > 0
  ) {
    const numbers = /^[0-9]+$/;
    const filterData =
      myFleetsortValue === ''
        ? addFleetData.addedOriginalVesselList
        : dsortData;
    if (addFleetData.searchParam.match(numbers) && filterData.length > 0) {
      const originalVesselimoList = filterData.filter(data => {
        const searchimo = data.imo;
        return (
          searchimo
            .toString()
            .indexOf(
              !_.isEmpty(addFleetData.searchParam)
                ? addFleetData.searchParam
                : '',
            ) >= 0
        );
      });
      addedOriginalVesselList = setSortByData(
        originalVesselimoList,
        'imo',
        'asc',
      );
    } else {
      const originalVesselList = filterData.filter(
        data =>
          data.vesselName
            .toLowerCase()
            .indexOf(
              !_.isEmpty(addFleetData.searchParam)
                ? addFleetData.searchParam.toLowerCase()
                : '',
            ) >= 0,
      );
      addedOriginalVesselList = setSortByData(
        originalVesselList,
        'vesselName',
        'asc',
      );
    }
  }
  let isSeachValue = false;
  if (addFleetData.searchParam && addFleetData.searchParam.length > 0) {
    isSeachValue = true;
  }
  return (
    <>
      {addFleetData.isSuccessMsg && (
        <AddUserSuccessMsgModal
          show={addFleetData.isSuccessMsg}
          content={addFleetData.msgContent}
          statusCode="success"
          header={
            !addFleetData.isEditFlag ? (
              <FormattedMessage {...messages.createFleet} />
            ) : (
              <FormattedMessage {...messages.editFleet} />
            )
          }
          successModalCloseTrigger={() => handleclose()}
          closeVesselForm={() => handleclose()}
        />
      )}

      <div className="MyFleetContainer">
        {isCreateFleetModal && (
          <Modal
            md="12"
            isOpen
            toggle={() => handleclose()}
            className="custom-modal-claims"
            size="xl"
            keyboard={false}
            backdrop="static"
          >
            <ModalHeader toggle={() => handleclose()}>
              {!addFleetData.isEditFlag && (
                <FormattedMessage {...messages.createFleet} />
              )}
              {addFleetData.isEditFlag && (
                <FormattedMessage {...messages.editFleet} />
              )}
            </ModalHeader>
            <ModalBody>
              <div id="model">
                <>
                  {addVesselMsg && (
                    <div className="toastmsg">
                      <Row>
                        <Col xs={4}>
                          <Alert color="primary">
                            <i
                              className="fa fa-check-circle"
                              style={{ fontSize: '20px' }}
                            />
                            <span style={{ paddingLeft: '7px' }}>
                              <FormattedMessage {...messages.addVesselMsg} />
                            </span>
                          </Alert>
                        </Col>
                      </Row>
                    </div>
                  )}
                  {deleteVesselMsg && (
                    <div className="toastmsgdelete">
                      <Row>
                        <Col xs={6}>
                          <Alert color="primary">
                            <i
                              className="fa fa-check-circle"
                              style={{ fontSize: '20px' }}
                            />
                            <span style={{ paddingLeft: '7px' }}>
                              {deleteVesselMsgContent}
                            </span>
                          </Alert>
                        </Col>
                      </Row>
                    </div>
                  )}
                  <Row>
                    <Col xs={3}>
                      <Label style={{ fontWeight: 'bold' }}>
                        <FormattedMessage {...messages.fleetName} />
                        <span className="astrick">&nbsp;*</span>
                      </Label>
                      <Input
                        type="text"
                        maxLength="100"
                        id="FleetName"
                        value={addFleetData.fleetName}
                        onChange={e => {
                          handleChange('add', 'fleetName', e.target.value);
                        }}
                      />
                      {addFleetData.isDuplicate && (
                        <p className="validation-content">
                          <FormattedMessage
                            {...messages.fleetNameDuplicateMsg}
                          />
                        </p>
                      )}
                    </Col>
                    <Col xs={6}>
                      <Label style={{ fontWeight: 'bold' }}>
                        <FormattedMessage {...messages.fleetDescription} />
                      </Label>
                      <Input
                        type="textarea"
                        name="text"
                        id="FleetDescription"
                        onChange={e => {
                          handleChange(
                            'add',
                            'fleetDescription',
                            e.target.value,
                          );
                        }}
                        value={addFleetData.fleetDescription}
                        maxLength={100}
                      />
                    </Col>
                    <Col xs={3}>
                      {isDisplaySharedWith() && (
                        <>
                          <Label style={{ fontWeight: 'bold' }}>
                            <FormattedMessage {...messages.sharedWith} />
                            <span className="astrick">&nbsp;*</span>
                          </Label>
                          <div className="MyFleetRadioButton">
                            <div>
                              <Input
                                type="radio"
                                name="radio1"
                                id="EveryOne"
                                onChange={() => {
                                  handleChange('add', 'sharedWith', 'Everyone');
                                }}
                                checked={addFleetData.sharedWith === 'Everyone'}
                              />
                              <FormattedMessage {...messages.everyone} />
                            </div>
                            <div className="MyFleetRadioOnlyMe">
                              <Input
                                type="radio"
                                name="radio1"
                                id="OnlyMe"
                                onChange={() => {
                                  handleChange('add', 'sharedWith', 'Only Me');
                                }}
                                checked={addFleetData.sharedWith === 'Only Me'}
                              />
                              <FormattedMessage {...messages.onlyMe} />
                            </div>
                          </div>
                        </>
                      )}
                    </Col>
                  </Row>
                  <hr />
                  <Row>
                    <Col xs={8}>
                      <Label style={{ fontWeight: 'bold' }}>
                        <FormattedMessage {...messages.vesselsInFleet} /> (
                        {myFleetsortValue === ''
                          ? addedOriginalVesselList.length
                          : dsortData.length}
                        )
                      </Label>
                    </Col>
                    <Col xs={2} style={{ display: 'flex' }}>
                      <Input
                        type="text"
                        maxLength="100"
                        id="VesselImo"
                        value={addFleetData.searchParam}
                        onChange={e => {
                          handleChange('add', 'searchParam', e.target.value);
                        }}
                        placeholder="Vessel or IMO"
                        style={{
                          width: '140px',
                          marginBottom: '5px',
                          marginLeft: '70px',
                        }}
                      />
                    </Col>
                    <Col xs={2}>
                      <Button
                        color="link"
                        type="button"
                        onClick={() => addVesselTrigger()}
                        style={{
                          float: 'right',
                          width: '108px',
                          marginTop: '-5px',
                          marginLeft: '15px',
                        }}
                        id="AddVesselButton"
                      >
                        <FormattedMessage {...messages.addVessel} />
                      </Button>
                    </Col>
                  </Row>
                  {/* {addFleetData.addedOriginalVesselList.length === 1 && (
                    <Row>
                      <Col xs={12}>
                        <Label style={{ fontWeight: 'bold' }}>
                          <FormattedMessage {...messages.vesselCount} /> (
                          {addFleetData.addedOriginalVesselList.length})
                        </Label>
                      </Col>
                    </Row>
                  )}
                  {addFleetData.addedOriginalVesselList.length >= 2 && (
                    <Row>
                      <Col xs={12}>
                        <Label style={{ fontWeight: 'bold' }}>
                          <FormattedMessage {...messages.vesselsCount} /> (
                          {addFleetData.addedOriginalVesselList.length})
                        </Label>
                      </Col>
                    </Row>
                          )} */}
                  <Row className="MyFleetTable">
                    <Col xs="12" id="selectedVesselTable">
                      <DataTableList
                        moduleId={0}
                        primaryProp="vesselId"
                        tableHeader={myFleetHeader}
                        tableBody={
                          myFleetsortValue === ''
                            ? addedOriginalVesselList
                            : dsortData
                        }
                        rowsPerPage={5}
                        totalRecords={addedOriginalVesselListCount}
                        isEditGrid
                        fixedColumn
                        editType={['customDelete']}
                        handleCustomDelete={(vesselId, name) =>
                          fleetDeleteVesselTrigger(vesselId, name)
                        }
                        isCreateFleet
                        isSearchValue={isSeachValue}
                        fixedHeader
                      />
                    </Col>
                  </Row>
                  {addFleetData.isAddVessel && (
                    <>
                      <hr />
                      <Row>
                        <Col xs={12}>
                          <Label style={{ fontWeight: 'bold' }}>
                            <FormattedMessage {...messages.addVessels} />
                          </Label>
                        </Col>
                      </Row>
                      <Row>
                        <Col xs={2}>
                          <Label style={{ fontWeight: 'bold' }}>
                            <FormattedMessage {...messages.vesselName} />
                          </Label>
                          <Input
                            type="text"
                            maxLength="100"
                            id="VesselName"
                            value={searchFleetData.vesselName}
                            onChange={e => {
                              handleChange(
                                'search',
                                'vesselName',
                                e.target.value,
                              );
                            }}
                          />
                        </Col>
                        <Col xs={2}>
                          <Label style={{ fontWeight: 'bold' }}>
                            <FormattedMessage {...messages.imo} />
                          </Label>
                          <Input
                            type="number"
                            maxLength={7}
                            id="ImoNumber"
                            value={searchFleetData.imo}
                            onKeyDown={event =>
                              blockNumberDecimalInput(event, true)
                            }
                            onChange={e => {
                              handleChange('search', 'imo', e.target.value);
                            }}
                            placeholder="Enter Only Number"
                          />
                        </Col>
                        <Col xs={2}>
                          <Label style={{ fontWeight: 'bold' }}>
                            <FormattedMessage {...messages.vesselType} />
                          </Label>
                          <DropDown
                            options={addFleetData.vesselTypes}
                            onChange={e => {
                              handleChange(
                                'search',
                                'vesselType',
                                e.target.value,
                              );
                            }}
                            selected={searchFleetData.vesselType}
                            id="VesselType"
                          />
                        </Col>
                        <Col xs={2}>
                          <Label style={{ fontWeight: 'bold' }}>
                            <FormattedMessage {...messages.ownerType} />
                          </Label>
                          <DropDown
                            options={addFleetData.ownerTypes}
                            onChange={e => {
                              handleChange(
                                'search',
                                'ownerType',
                                e.target.value,
                              );
                            }}
                            selected={searchFleetData.ownerType}
                            id="OwnerType"
                          />
                        </Col>
                        <Col xs={2}>
                          <Label style={{ fontWeight: 'bold' }}>
                            <FormattedMessage {...messages.ownerDetails} />
                          </Label>
                          <Input
                            type="text"
                            maxLength="100"
                            id="OwnerDetails"
                            value={searchFleetData.ownerDetails}
                            onChange={e => {
                              handleChange(
                                'search',
                                'ownerDetails',
                                e.target.value,
                              );
                            }}
                            disabled={searchFleetData.ownerType === ''}
                          />
                        </Col>
                        <Col
                          xs={2}
                          style={{ marginTop: '27px', marginBottom: '10px' }}
                        >
                          <Label />
                          <Button
                            color="primary"
                            type="button"
                            onClick={() => handleSearchVessel()}
                            id="SearchButton"
                          >
                            <FormattedMessage {...messages.searchButton} />
                          </Button>
                        </Col>
                      </Row>
                      {messageObj.isAddFilterClicked ? (
                        <Row>
                          <Col xs="12" id="addVesselTable">
                            <table className="table">
                              <tbody>
                                <tr style={{ height: '180px' }}>
                                  <td
                                    colSpan={5}
                                    style={{ textAlign: 'center' }}
                                  >
                                    <div style={{ marginTop: '90px' }}>
                                      <FormattedMessage
                                        {...messages.searchMessage}
                                      />
                                    </div>
                                  </td>
                                </tr>
                              </tbody>
                            </table>
                          </Col>
                        </Row>
                      ) : (
                        <>
                          <Row>
                            <Col xs={12}>
                              <Label
                                style={{
                                  fontWeight: 'bold',
                                  marginTop: '20px',
                                }}
                              >
                                <FormattedMessage {...messages.searchResults} />{' '}
                                ({addFleetData.totalrecords})
                              </Label>
                            </Col>
                          </Row>
                          <Row>
                            <Col xs="12" id="addVesselTable">
                              {!isCheckAllVessel && (
                                <DataTableList
                                  moduleId={62}
                                  primaryProp="vesselId"
                                  tableHeader={vesselHeader}
                                  tableBody={addFleetData.vesselList}
                                  rowsPerPage={5}
                                  totalRecords={addFleetData.totalrecords}
                                  fetchTableData={onPageChanged}
                                  isCustom
                                  fixedColumn
                                  isCreateFleetGrid
                                />
                              )}
                              {isCheckAllVessel && (
                                <DataTableList
                                  moduleId={0}
                                  primaryProp="vesselId"
                                  tableHeader={addFleetHeader}
                                  tableBody={
                                    addFleetsortValue === ''
                                      ? addFleetData.vesselList
                                      : addFleetSortData
                                  }
                                  rowsPerPage={5}
                                  totalRecords={addFleetData.totalrecords}
                                />
                              )}
                            </Col>
                          </Row>
                        </>
                      )}
                      <Row>
                        <Col
                          xs={12}
                          style={{
                            justifyContent: 'flex-end',
                            display: 'flex',
                          }}
                        >
                          <Button
                            color="primary"
                            type="button"
                            onClick={() => addVesselButtonClick()}
                            id="AddVesselButtonFleet"
                          >
                            <FormattedMessage {...messages.addVessels} />
                          </Button>
                        </Col>
                      </Row>
                    </>
                  )}
                  <Row>
                    <Col xs={12} className="button-align-center">
                      {addFleetData.isEditFlag && (
                        <Button
                          color="primary"
                          type="button"
                          onClick={() => saveFleetClick()}
                          id="SaveFleetButton"
                          disabled={
                            addFleetData.isCreateFleetButtonEnabled ||
                            addFleetData.isDuplicate
                          }
                        >
                          <FormattedMessage {...messages.saveButton} />
                        </Button>
                      )}
                      {!addFleetData.isEditFlag && (
                        <Button
                          color="primary"
                          type="button"
                          onClick={() => addFleetClick()}
                          id="AddFleetButton"
                          style={{ marginLeft: '15px' }}
                          disabled={
                            addFleetData.isCreateFleetButtonEnabled ||
                            addFleetData.isDuplicate
                          }
                        >
                          <FormattedMessage {...messages.createFleet} />
                        </Button>
                      )}
                      <Button
                        color="primary"
                        type="button"
                        onClick={() => handleclose()}
                        id="CancelButton"
                        style={{ marginLeft: '15px' }}
                      >
                        <FormattedMessage {...messages.cancelButton} />
                      </Button>
                    </Col>
                  </Row>
                </>
              </div>
            </ModalBody>
          </Modal>
        )}
      </div>
    </>
  );
}

AddFleet.propTypes = {
  fleetData: PropTypes.object,
  createFleetModalCloseTrigger: PropTypes.func,
  isCreateFleetModal: PropTypes.bool,
  fleetInputChange: PropTypes.func,
  addFleetData: PropTypes.object,
  searchFleetData: PropTypes.object,
  addVesselTrigger: PropTypes.func,
  addVesselButtonTrigger: PropTypes.func,
  vesselCheckBoxTrigger: PropTypes.func,
  deleteVesselTrigger: PropTypes.func,
  addFleetTrigger: PropTypes.func,
  saveFleetTrigger: PropTypes.func,
  getVesselSearch: PropTypes.func,
  isCheckAllVessel: PropTypes.bool,
  duplicateFleetcheck: PropTypes.func,
  messageObj: PropTypes.object,
  dcheckAllVessel: PropTypes.func,
  configDetails: PropTypes.array,
  isExceedVessel: PropTypes.bool,
  isCheckAllAddVessel: PropTypes.bool,
  isAddVesselClick: PropTypes.bool,
  handledeselectVessel: PropTypes.func,
};

export default memo(AddFleet);
