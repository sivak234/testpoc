/*
 *
 * AddFleet helper
 *
 */

export function defaultFunction(text) {
  return text;
}

export const primaryProp = 'apiParameterDetailID';
export const fixedColumns = true;
export const changeHandler = () => {};

export const emptyRow = {
  vesselName: '',
  vesselIMO: '',
  wopVesselType: '',
  wopVesselSizeClassification: '',
  vesselStatus: '',
};

export function FleetHeader() {
  const tblheader = [
    { title: 'Vessel Name', prop: 'vesselName' },
    { title: 'IMO', prop: 'imo' },
    { title: 'Vessel Type', prop: 'vesselType' },
    { title: 'Vessel Size', prop: 'vesselSizeClassification' },
    { title: 'Vessel Status', prop: 'status' },
  ];
  return tblheader;
}
