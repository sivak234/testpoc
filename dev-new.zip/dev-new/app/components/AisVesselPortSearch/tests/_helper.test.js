// import { defaultFunction } from '../_helper';

// describe('AisVesselPortSearch helpers', () => {
//   describe('Default Helper Function', () => {
//     it('returns the expected value', () => {
//       const expected = 'Sample Text';
//       expect(defaultFunction('Sample Text')).toEqual(expected);
//     });
//   });
// });
describe('<AisVesselPortSearch />', () => {
  it('Expect to not log errors in AisVesselPortSearch', () => {
    expect(true).toBeTruthy();
  });
});
