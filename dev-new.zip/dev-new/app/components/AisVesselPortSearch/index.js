/**
 *
 * AisVesselPortSearch
 *
 */

import React from 'react';
import { Row, Col } from 'reactstrap';
import { FormattedMessage } from 'react-intl';
import PropTypes from 'prop-types';
import messages from './messages';
import AutoComplete from '../AutoCompleteTextBox/Loadable';

import './_helper';

function AisVesselPortSearch({
  vesselName,
  vesselDetails,
  fetchVesselName,
  fetchAisVesselVoyageDetails,
  fetchAisVesselDetails,
  fetchAisVesselData,
  fetchselectedImoData,
  fetchNearestRangeVesselsByImo,
  portName,
  portDetails,
  fetchPortName,
  fetchPortDetails,
  fetchPortStatisticDetails,
  fetchVesselData,
  fetchPortMoveMapData,
  fetchTerminalCodeNames,
  isNewLandingPage,
}) {
  return (
    <>
      <Row md={12}>
        <Col sm={6}>
          <AutoComplete
            label={
              <FormattedMessage
                {...messages.aisSearchPageVesselAutocompleteLabel}
              />
            }
            suggestions={vesselName}
            type="vessel"
            vesselDetails={vesselDetails}
            fetchVesselName={fetchVesselName}
            fetchAisVesselVoyageDetails={fetchAisVesselVoyageDetails}
            fetchAisVesselDetails={fetchAisVesselDetails}
            fetchAisVesselData={fetchAisVesselData}
            fetchselectedImoData={fetchselectedImoData}
            fetchNearestRangeVesselsByImo={fetchNearestRangeVesselsByImo}
            placeholder="Vessel Search"
            isNewLandingPage={isNewLandingPage}
          />
        </Col>
        <Col sm={6}>
          <AutoComplete
            label={
              <FormattedMessage
                {...messages.aisSearchPagePortAutocompleteLabel}
              />
            }
            suggestions={portName}
            type="port"
            portDetails={portDetails}
            fetchPortName={fetchPortName}
            fetchPortDetails={fetchPortDetails}
            fetchPortStatisticDetails={fetchPortStatisticDetails}
            fetchVesselData={fetchVesselData}
            fetchPortMoveMapData={fetchPortMoveMapData}
            fetchTerminalCodeNames={fetchTerminalCodeNames}
            placeholder="Port Search"
            isNewLandingPage={isNewLandingPage}
          />
        </Col>
      </Row>
    </>
  );
}

AisVesselPortSearch.propTypes = {
  vesselName: PropTypes.array,
  portName: PropTypes.array.isRequired,
  vesselDetails: PropTypes.func.isRequired,
  portDetails: PropTypes.func.isRequired,
  fetchPortName: PropTypes.func,
  fetchVesselName: PropTypes.func,
  fetchPortDetails: PropTypes.func.isRequired,
  fetchPortStatisticDetails: PropTypes.func.isRequired,
  fetchVesselData: PropTypes.func.isRequired,
  fetchPortMoveMapData: PropTypes.func.isRequired,
  fetchAisVesselVoyageDetails: PropTypes.func.isRequired,
  fetchAisVesselDetails: PropTypes.func.isRequired,
  fetchAisVesselData: PropTypes.func.isRequired,
  fetchselectedImoData: PropTypes.func.isRequired,
  fetchNearestRangeVesselsByImo: PropTypes.func.isRequired,
  fetchTerminalCodeNames: PropTypes.func.isRequired,
  isMovement: PropTypes.bool,
  isNewLandingPage: PropTypes.bool,
};

export default AisVesselPortSearch;
