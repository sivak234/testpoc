/*
 * AisVesselPortSearch Messages
 *
 * This contains all the text for the AisVesselPortSearch component.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.components.AisVesselPortSearch';

export default defineMessages({
  aisSearchPageVesselAutocompleteLabel: {
    id: `${scope}.aisSearchPageVesselAutocompleteLabel`,
    defaultMessage: 'Vessel Name or IMO',
  },
  aisSearchPagePortAutocompleteLabel: {
    id: `${scope}.aisSearchPagePortAutocompleteLabel`,
    defaultMessage: 'Port Name or UNLOCODE',
  },
});
