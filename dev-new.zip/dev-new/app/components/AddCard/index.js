/**
 *
 * AddCard
 *
 */

import React, { memo } from 'react';
import { Container, Button, Row, Form, Col, Label } from 'reactstrap';
import PropTypes from 'prop-types';
import LegacyDataPortAddModal from '../LegacyDataPortAddModal/Loadable';
import LegacyDataTerminalAddModal from '../LegacyDataTerminalAddModal/Loadable';
import LegacyDataBerthAddModal from '../LegacyDataBerthAddModal/Loadable';
import { filteredAccess } from '../../utils/rbac';

function AddCard({
  title,
  isAddModelOpen,
  isAddPortModelOpen,
  isAddBerthModelOpen,
  openAddPortForm,
  closeAddPortForm,
  openAddTerminalForm,
  closeAddTerminalForm,
  openAddBerthForm,
  closeAddBerthForm,
  regions,
  countries,
  ports,
  terminals,
  selected,
  onRegionSelect,
  onCountrySelect,
  onPortSelect,
  regionCountryPortAPi,
  publishAddPort,
  publishAddTerminal,
  legacyBerthDetails,
  berthTypeList,
  userData,
  legacyBerthFormParams,
  addBerthDetails,
  updateBerthDetails,
  dHandleInputChange,
  dHandleBerthInputChange,
  dHandleFetchBerthCode,
  formType,
  handleViewUpdateClick,
  handleDeleteBerth,
  berthMessage,
  berthMessageModalOpen,
  berthMessageModal,
  legacyTerminalsList,
  legacyPortsList,
  dshowModel,
  handleUpdateClickFromView,
  handleDeleteClickFromView,
  handleDeleteTerminal,
  handleViewTerminalDetails,
  handleEditTerminalDetails,
  handleDeleteModalClose,
  deleteTerminalSearchRes,
  editTerminalData,
  handleDeleteModalOpen,
  deletePortSearchRes,
  portSearchResults,
  handleDeletePort,
  handleEditPortDetails,
  dGetSecuredCountriesListByRegion,
  moduleId,
  berthAddValidationStatus,
  isDeleteClicked,
  setDeleteClicked,
}) {
  function open() {
    if (title === 'Port') {
      openAddPortForm();
    } else if (title === 'Terminal') {
      openAddTerminalForm();
    } else if (title === 'Berth') {
      openAddBerthForm(0, 'Add');
    }
  }
  const getModuleId = () => {
    let moduleIdinfo;
    if (title === 'Port') {
      moduleIdinfo = 47;
    } else if (title === 'Terminal') {
      moduleIdinfo = 48;
    } else if (title === 'Berth') {
      moduleIdinfo = 49;
    }
    return moduleIdinfo;
  };

  return (
    <>
      <Container>
        <Form id="add-from">
          <Row>
            <Col xs="12" className="text-right">
              {filteredAccess(getModuleId(), 'publish') && (
                <Button
                  color="link"
                  onClick={() => dshowModel({ show: true, showOn: title })}
                >
                  Import
                </Button>
              )}
              {filteredAccess(getModuleId(), 'publish') && (
                <Label className="mr-3 ml-1"> OR </Label>
              )}
              {filteredAccess(getModuleId(), 'add') && (
                <Button
                  color="primary"
                  className="add-btn"
                  type="button"
                  onClick={open}
                >
                  <i className="fa fa-plus mr-1" />
                  Add {title}
                </Button>
              )}
            </Col>
          </Row>
        </Form>
      </Container>
      {isAddPortModelOpen && title === 'Port' && (
        <LegacyDataPortAddModal
          show={isAddPortModelOpen}
          title={title}
          content="Success"
          closeAddPortForm={closeAddPortForm}
          regions={regions}
          countries={countries}
          selected={selected}
          onRegionSelect={onRegionSelect}
          onCountrySelect={onCountrySelect}
          regionCountryPortAPi={regionCountryPortAPi}
          publishAddPort={publishAddPort}
          handleDeleteModalOpen={handleDeleteModalOpen}
          deletePortSearchRes={deletePortSearchRes}
          portSearchResults={portSearchResults}
          handleDeleteModalClose={handleDeleteModalClose}
          handleDeletePort={handleDeletePort}
          handleEditPortDetails={handleEditPortDetails}
          moduleId={moduleId}
        />
      )}
      {isAddModelOpen && title === 'Terminal' && (
        <LegacyDataTerminalAddModal
          show={isAddModelOpen}
          title={title}
          content="Success"
          closeAddTerminalForm={closeAddTerminalForm}
          regions={regions}
          countries={countries}
          ports={ports}
          selected={selected}
          onRegionSelect={onRegionSelect}
          onCountrySelect={onCountrySelect}
          onPortSelect={onPortSelect}
          regionCountryPortAPi={regionCountryPortAPi}
          publishAddTerminal={publishAddTerminal}
          handleUpdateClickFromView={handleUpdateClickFromView}
          handleDeleteClickFromView={handleDeleteClickFromView}
          handleDeleteTerminal={handleDeleteTerminal}
          handleViewTerminalDetails={handleViewTerminalDetails}
          handleEditTerminalDetails={handleEditTerminalDetails}
          handleDeleteModalClose={handleDeleteModalClose}
          deleteTerminalSearchRes={deleteTerminalSearchRes}
          editTerminalData={editTerminalData}
          moduleId={moduleId}
          isDeleteClicked={isDeleteClicked}
          setDeleteClicked={setDeleteClicked}
        />
      )}
      {isAddBerthModelOpen && title === 'Berth' && (
        <LegacyDataBerthAddModal
          show={isAddBerthModelOpen}
          title={title}
          content="Success"
          closeAddBerthForm={closeAddBerthForm}
          regions={regions}
          countries={countries}
          ports={ports}
          terminals={terminals}
          userData={userData}
          berthTypeList={berthTypeList}
          selected={selected}
          onRegionSelect={onRegionSelect}
          onCountrySelect={onCountrySelect}
          onPortSelect={onPortSelect}
          regionCountryPortAPi={regionCountryPortAPi}
          legacyBerthDetails={legacyBerthDetails}
          legacyBerthFormParams={legacyBerthFormParams}
          addBerthDetails={addBerthDetails}
          updateBerthDetails={updateBerthDetails}
          dHandleInputChange={dHandleInputChange}
          dHandleBerthInputChange={dHandleBerthInputChange}
          dHandleFetchBerthCode={dHandleFetchBerthCode}
          formType={formType}
          handleViewUpdateClick={handleViewUpdateClick}
          handleDeleteBerth={handleDeleteBerth}
          berthMessage={berthMessage}
          berthMessageModalOpen={berthMessageModalOpen}
          berthMessageModal={berthMessageModal}
          legacyTerminalsList={legacyTerminalsList}
          legacyPortsList={legacyPortsList}
          dGetSecuredCountriesListByRegion={dGetSecuredCountriesListByRegion}
          moduleId={moduleId}
          berthAddValidationStatus={berthAddValidationStatus}
        />
      )}
    </>
  );
}

AddCard.propTypes = {
  title: PropTypes.string,
  openAddPortForm: PropTypes.func,
  closeAddPortForm: PropTypes.func,
  openAddTerminalForm: PropTypes.func,
  closeAddTerminalForm: PropTypes.func,
  openAddBerthForm: PropTypes.func,
  closeAddBerthForm: PropTypes.func,
  isAddModelOpen: PropTypes.bool,
  isAddPortModelOpen: PropTypes.bool,
  isAddBerthModelOpen: PropTypes.bool,
  regions: PropTypes.array,
  countries: PropTypes.array,
  ports: PropTypes.array,
  terminals: PropTypes.array,
  selected: PropTypes.array,
  onRegionSelect: PropTypes.func,
  onCountrySelect: PropTypes.func,
  onPortSelect: PropTypes.func,
  regionCountryPortAPi: PropTypes.func,
  publishAddPort: PropTypes.func,
  publishAddTerminal: PropTypes.func,
  legacyBerthDetails: PropTypes.object,
  berthTypeList: PropTypes.any,
  userData: PropTypes.array,
  legacyBerthFormParams: PropTypes.array,
  addBerthDetails: PropTypes.func,
  updateBerthDetails: PropTypes.func,
  dHandleInputChange: PropTypes.func,
  dHandleBerthInputChange: PropTypes.func,
  dHandleFetchBerthCode: PropTypes.func,
  formType: PropTypes.string,
  handleViewUpdateClick: PropTypes.func,
  handleDeleteBerth: PropTypes.func,
  berthMessage: PropTypes.string,
  berthMessageModalOpen: PropTypes.bool,
  berthMessageModal: PropTypes.func,
  legacyTerminalsList: PropTypes.array,
  legacyPortsList: PropTypes.array,
  dshowModel: PropTypes.func,
  handleUpdateClickFromView: PropTypes.func,
  handleDeleteClickFromView: PropTypes.func,
  handleDeleteTerminal: PropTypes.func,
  handleViewTerminalDetails: PropTypes.func,
  handleEditTerminalDetails: PropTypes.func,
  handleDeleteModalClose: PropTypes.func,
  deleteTerminalSearchRes: PropTypes.bool,
  editTerminalData: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  handleDeleteModalOpen: PropTypes.func,
  deletePortSearchRes: PropTypes.bool,
  portSearchResults: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  handleDeletePort: PropTypes.func.isRequired,
  handleEditPortDetails: PropTypes.func,
  dGetSecuredCountriesListByRegion: PropTypes.func,
  moduleId: PropTypes.number,
  berthAddValidationStatus: PropTypes.any,
  isDeleteClicked: PropTypes.bool,
  setDeleteClicked: PropTypes.func,
};
export default memo(AddCard);
