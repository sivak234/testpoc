/**
 *
 * BerthCreateInLegacy
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import { Row, Col, Label, Input, FormFeedback } from 'reactstrap';

function BerthCreateInLegacy({
  data = {},
  handleBerthInputChange,
  berthValidationStatus,
  refData,
  formType,
}) {
  return (
    <>
      <div className="permissible-params">
        <Row className="mt-3">
          {(refData.isOfType(refData.oil) ||
            refData.isOfType(refData.chemical)) && (
            <>
              <Col xs={6} md={3} className="five-col">
                <Label for="legacySystemOilBerthName" className="mandate">
                  Legacy System Oil/Chemical Berth Name
                </Label>
                <Input
                  readOnly={formType === 'view'}
                  id="legacySystemOilBerthName"
                  name="legacySystemOilBerthName"
                  onChange={handleBerthInputChange}
                  value={data.legacySystemOilBerthName}
                  invalid={berthValidationStatus.legacySystemOilBerthName}
                />
                <FormFeedback>
                  Legacy System Oil/Chemical Berth Name is mandatory
                </FormFeedback>
              </Col>
              {formType !== 'add' && (
                <Col xs={6} md={3} className="five-col">
                  <Label for="legacySystemOilBerthCode">
                    Legacy System Oil/Chemical Berth Code
                  </Label>
                  <Input
                    readOnly
                    id="legacySystemOilBerthCode"
                    name="legacySystemOilBerthCode"
                    onChange={handleBerthInputChange}
                    value={data.legacySystemOilBerthCode}
                  />
                </Col>
              )}
            </>
          )}
          {refData.isOfType(refData.gas) && (
            <>
              <Col xs={6} md={3} className="five-col">
                <Label for="legacySystemGasBerthName" className="mandate">
                  Legacy System Gas Berth Name
                </Label>
                <Input
                  readOnly={formType === 'view'}
                  id="legacySystemGasBerthName"
                  name="legacySystemGasBerthName"
                  onChange={handleBerthInputChange}
                  value={data.legacySystemGasBerthName}
                  invalid={berthValidationStatus.legacySystemGasBerthName}
                />
                <FormFeedback>
                  Legacy System Gas Berth Name is mandatory
                </FormFeedback>
              </Col>
              {formType !== 'add' && (
                <Col xs={6} md={3} className="five-col">
                  <Label for="legacySystemGasBerthCode">
                    Legacy System Gas Berth Code
                  </Label>
                  <Input
                    readOnly
                    id="legacySystemGasBerthCode"
                    name="legacySystemGasBerthCode"
                    onChange={handleBerthInputChange}
                    value={data.legacySystemGasBerthCode}
                  />
                </Col>
              )}
            </>
          )}
        </Row>
      </div>
    </>
  );
}

BerthCreateInLegacy.propTypes = {
  data: PropTypes.object,
  handleBerthInputChange: PropTypes.func,
  berthValidationStatus: PropTypes.object,
  refData: PropTypes.object,
  formType: PropTypes.bool,
};

export default BerthCreateInLegacy;
