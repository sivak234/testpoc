/**
 *
 * Asynchronously loads the component for BerthCreateInLegacy
 *
 */

import loadable from 'utils/loadable';

export default loadable(() => import('./index'));
