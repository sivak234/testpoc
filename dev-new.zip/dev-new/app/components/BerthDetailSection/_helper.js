/*
 *
 * BerthDetailSection helper
 *
 */
import React from 'react';
import PropTypes from 'prop-types';
import { FormattedMessage } from 'react-intl';
import { CustomInput, Row, Col, Button } from 'reactstrap';
import messages from './messages';
import { pdfStructure } from '../../utils/pdfExport';
import { getImageFromS3Bucket } from '../../containers/PortDetails/_helper';
import {
  zeroToNRA,
  dateConversion,
  dateTimeConversion,
  toTitleCase,
} from '../../utils/dataModification';

const types = {
  SIMPLE: 'singleRow',
  MULTIPLE: 'multipleRow',
  CELL: 'singleCell',
  IMAGES: 'images',
  CUSTOMGRID: 'grid',
  TABLE: 'table',
  CARGOHANDLED: 'cargohandled',
};

const berthSections = {
  generalParticulars: {
    jumpId: 'generalParticulars',
    data: [],
    type: types.SIMPLE,
    isVisible: false,
    pdfStructure: pdfStructure.HEADLESSFOURCOLUMNS,
  },
  geocodes: {
    jumpId: 'geocodes',
    data: [],
    type: types.SIMPLE,
    isVisible: false,
    pdfStructure: pdfStructure.HEADLESSFOURCOLUMNS,
  },
  berthPermissibleVSLRestriction: {
    jumpId: 'berthPermissibleVSLRestriction',
    data: {},
    type: types.CUSTOMGRID,
    isVisible: false,
    pdfStructure: pdfStructure.RESTRICTIONGRID,
  },
  oilPermissibleVSLParameters: {
    jumpId: 'oilPermissibleVSLParameters',
    data: {},
    type: types.SIMPLE,
    isVisible: false,
    pdfStructure: pdfStructure.HEADLESSFOURCOLUMNS,
  },
  gasPermissibleVSLParameters: {
    jumpId: 'gasPermissibleVSLParameters',
    data: {},
    type: types.SIMPLE,
    isVisible: false,
    pdfStructure: pdfStructure.HEADLESSFOURCOLUMNS,
  },
  dryPermissibleVSLParameters: {
    jumpId: 'dryPermissibleVSLParameters',
    data: {},
    type: types.SIMPLE,
    isVisible: false,
    pdfStructure: pdfStructure.HEADLESSFOURCOLUMNS,
  },
  permissibleManifoldParametersOil: {
    jumpId: 'permissibleManifoldParametersOil',
    data: {},
    type: types.SIMPLE,
    isVisible: false,
    pdfStructure: pdfStructure.HEADLESSFOURCOLUMNS,
  },
  permissibleManifoldParametersGas: {
    jumpId: 'permissibleManifoldParametersGas',
    data: {},
    type: types.SIMPLE,
    isVisible: false,
    pdfStructure: pdfStructure.HEADLESSFOURCOLUMNS,
  },
  restriction: {
    jumpId: 'restriction',
    data: [],
    type: types.SIMPLE,
    isVisible: false,
    pdfStructure: pdfStructure.HEADLESSTWOCOLUMNS,
  },
  services: {
    jumpId: 'services',
    data: [],
    type: types.SIMPLE,
    isVisible: false,
    pdfStructure: pdfStructure.HEADLESSTWOCOLUMNS,
  },
  berthCargoGearFacility: {
    jumpId: 'berthCargoGearFacility',
    data: {},
    type: types.SIMPLE,
    isVisible: false,
    pdfStructure: pdfStructure.HEADLESSTWOCOLUMNS,
  },
  dryCargoHandled: {
    jumpId: 'dryCargoHandled',
    data: [],
    type: types.CARGOHANDLED,
    isVisible: false,
    pdfStructure: pdfStructure.HEADLESSTWOCOLUMNS,
  },
  oilCargoHandled: {
    jumpId: 'oilCargoHandled',
    data: [],
    type: types.CARGOHANDLED,
    isVisible: false,
    pdfStructure: pdfStructure.HEADLESSTWOCOLUMNS,
  },
  gasCargoHandled: {
    jumpId: 'gasCargoHandled',
    data: [],
    type: types.CARGOHANDLED,
    isVisible: false,
    pdfStructure: pdfStructure.HEADLESSTWOCOLUMNS,
  },
  chemicalCargoHandled: {
    jumpId: 'chemicalCargoHandled',
    data: [],
    type: types.CARGOHANDLED,
    isVisible: false,
    pdfStructure: pdfStructure.HEADLESSTWOCOLUMNS,
  },
  shipHandled: {
    jumpId: 'shipHandled',
    data: [],
    type: types.TABLE,
    isVisible: false,
    pdfStructure: pdfStructure.GRID,
  },
  berthNotes: {
    jumpId: 'berthNotes',
    data: '',
    type: types.CELL,
    isVisible: false,
    pdfStructure: pdfStructure.HEADLESSONECOLUMN,
  },
  ptbImage: {
    jumpId: 'ptbImage',
    data: [],
    type: types.IMAGES,
    isVisible: false,
  },
  ptbDocument: {
    jumpId: 'ptbDocument',
    data: [],
    type: types.TABLE,
    isVisible: false,
    pdfStructure: pdfStructure.GRID,
  },

  contactDetails: {
    jumpId: 'contactDetails',
    data: [],
    type: types.SIMPLE,
    isVisible: false,
    pdfStructure: pdfStructure.GRID,
  },
  changeHistory: {
    jumpId: 'changeHistory',
    isVisible: false,
    data: [],
    type: types.TABLE,
    pdfStructure: pdfStructure.GRID,
  },
  lastFiveVesselsCalledAtBerth: {
    jumpId: 'lastFiveVesselsCalledAtBerth',
    data: [],
    type: types.MULTIPLE,
    pdfStructure: pdfStructure.GRID,
  },
};

export const formatPdfData = data => {
  const pdfData = {};
  Object.keys(data).forEach(item => {
    if (data[item].data && data[item].data.products) {
      const { products, ...tempData } = data[item].data;
      pdfData[`${item}Product`] = {
        data: products,
        pdfStructure: pdfStructure.GRID,
      };

      if (
        tempData &&
        tempData.storageType &&
        tempData.storageType.length === 0
      ) {
        delete tempData.storageType;
      }
      pdfData[item] = {
        data: tempData,
        pdfStructure: data[item].pdfStructure,
        isHeaderNotRequired: true,
      };
    } else {
      pdfData[item] = Object.assign({}, data[item]);
    }
  });

  return pdfData;
};
function makeGeneralParticulars(data, formattedMaster) {
  const status = [];
  status.true = 'Active';
  status.false = 'Inactive';
  const newData = {
    berthTerminalSubTypes:
      data.berthTerminalSubTypes && data.berthTerminalSubTypes.length > 0
        ? data.berthTerminalSubTypes.slice(0, 1)
        : data.berthTerminalSubTypes,
    berthCode: data.berthCode,
    berthTypeId: data.berthTypeTransactions,
    style: data.style,
    berthName: data.berthName,
    alternativeName: data.alternativeName,
    portName: data.portName,
    terminalName: data.terminalName,
    priority: data.priority,
    status: data.status ? status[data.status] : '',
    timeZoneName: data.timeZoneName,
    waterSalinity: data.salinityOfWater,
    gangWayArrangements: data.gangWayArrangements,
    berthFenderingTypes: data.berthFenderingTypes,
    typesOfBottom: data.typesOfBottom,
    lastHydrographicalSurvey: dateConversion(data.lastHydrographicalSurvey),
    lastStructuralSurvey: dateConversion(data.lastStructuralSurvey),
    berthOwner: data.berthOwner,
    berthOperator: data.berthOperator,
  };

  return mapKeyValueFromMaster(newData, formattedMaster);
}

// commenting GeoCode as are showing it in map
// function makeGeoCode(data) {
//   return {
//     x: data && data.berthCoordinates ? data.berthCoordinates.x : '',
//     y: data && data.berthCoordinates ? data.berthCoordinates.y : '',
//   };
// }

function permissibleManifoldParameters(allSection, rawData, masterData) {
  const sections = { ...allSection };
  const masterKeys = masterData.berthTypeId.data;
  rawData.map(item => {
    const tempItem = item;
    if (
      sections[`permissibleManifoldParameters${masterKeys[item.berthTypeId]}`]
    )
      if (item.berthTypeDesc) delete tempItem.berthTypeDesc;

    let keyCargoType = toTitleCase(masterKeys[item.berthTypeId]);
    if (
      masterKeys[item.berthTypeId].toLowerCase() === 'oil' ||
      masterKeys[item.berthTypeId].toLowerCase() === 'chemical'
    )
      keyCargoType = 'Oil';
    sections[`permissibleManifoldParameters${keyCargoType}`].data = {
      ...filterAuditFeilds(item),
    };
    return sections;
  });
  return sections;
}

const getDescription = (productId, master, key, des) => {
  let productDes = '';

  master.some(product => {
    if (product[key] === productId) {
      productDes = product[des];
      // cargo = product.mainCargoType.mainCargoTypeDesc;
      return true;
    }
    return false;
  });
  return productDes;
};

const getStorageTypeDes = (s, master) => {
  let storage = '';
  master.some(type => {
    if (
      type.storageTypeId === s.storageTypeId &&
      s.berthTypeId === type.berthTypeId
    ) {
      storage = type.storageTypeDesc;
      return true;
    }
    return false;
  });
  return storage;
};

function cargoHandleFormatter(allSection, rawData, master) {
  const sections = { ...allSection };
  const berthTypeMaster = [];

  Object.keys(master.berthTypeList).forEach(key => {
    berthTypeMaster[
      master.berthTypeList[key].berthTypeId
    ] = master.berthTypeList[key].berthTypeDesc.toLowerCase();
  });

  const cargoHandled = {
    oil: {},
    gas: {},
    chemical: {},
    dry: {},
  };

  const productCargoHandled = {
    oil: [],
    gas: [],
    chemical: [],
    dry: [],
  };
  const productCargos = [];
  rawData.berthMainCargo.forEach(product => {
    const berthType = berthTypeMaster[product.berthTypeId];
    if (
      berthType === 'oil' ||
      berthType === 'gas' ||
      berthType === 'chemical'
    ) {
      if (!productCargoHandled[berthType][product.mainCargoTypeId])
        productCargoHandled[berthType][product.mainCargoTypeId] = [];
    } else if (!productCargoHandled.dry[product.mainCargoTypeId]) {
      productCargoHandled.dry[product.mainCargoTypeId] = [];
    }
    const detail = getDescription(
      product.mainCargoTypeId,
      master.mainCargoTypeHandledList,
      'mainCargoTypeId',
      'mainCargoTypeDesc',
    );
    productCargos[product.mainCargoTypeId] = detail;
  });

  rawData.berthProductHandle.forEach(product => {
    const berthType = berthTypeMaster[product.berthTypeId];
    const productDetails = getDescription(
      product.productTypeHandledId,
      master.productTypeHandledList,
      'productTypeHandledId',
      'productTypeHandledDesc',
    );

    if (
      berthType === 'oil' ||
      berthType === 'gas' ||
      berthType === 'chemical'
    ) {
      productCargoHandled[berthType][product.mainCargoTypeId].push(
        productDetails,
      );
    } else {
      productCargoHandled.dry[product.mainCargoTypeId].push(productDetails);
    }
  });

  // Storage Types;
  const allowedBerthStorageTypes = ['gas', 'chemical'];
  allowedBerthStorageTypes.forEach(i => {
    cargoHandled[i].storageType = [];
    rawData.berthStorageHandle.forEach(j => {
      const storage = getStorageTypeDes(j, master.storageTypeList);
      if (
        cargoHandled[i] &&
        berthTypeMaster[j.berthTypeId] &&
        berthTypeMaster[j.berthTypeId] === i
      )
        cargoHandled[i].storageType.push(storage);
    });
  });

  // Loading and Discharge rate
  rawData.berthLoadingRate.forEach(j => {
    let berthType = berthTypeMaster[j.berthTypeId];
    if (
      berthType !== 'oil' &&
      berthType !== 'gas' &&
      berthType !== 'chemical'
    ) {
      berthType = 'dry';
    }
    cargoHandled[berthType].loadingRate = j.loadingRate;
    cargoHandled[berthType].dischargeRate = j.dischargeRate;
  });

  // Dry Loading rate
  rawData.berthDryCargoLoadingRate.forEach(i => {
    cargoHandled.dry.loadingRate = i.loadingRate;
    cargoHandled.dry.dischargeRate = i.dischargeRate;
  });

  Object.keys(productCargoHandled).forEach(type => {
    Object.keys(productCargoHandled[type]).forEach(pro => {
      if (!cargoHandled[type].products) cargoHandled[type].products = [];
      cargoHandled[type].products.push({
        cargoHandled: productCargos[pro],
        products: productCargoHandled[type][pro],
      });
    });
    sections[`${type}CargoHandled`].data = cargoHandled[type];
  });

  return sections;
}

function shipHandleFormatter(rawData) {
  const shipHandledSection = [];
  const ships = [];
  // unquie ships and multple classification
  Object.keys(rawData).forEach(shipKey => {
    if (rawData[shipKey].wopVesselDesc) {
      if (!ships[rawData[shipKey].wopVesselDesc]) {
        ships[rawData[shipKey].wopVesselDesc] = [];
      }
      if (rawData[shipKey].sizeCategory)
        ships[rawData[shipKey].wopVesselDesc].push(
          rawData[shipKey].sizeCategory,
        );
    }
  });
  Object.keys(ships).forEach(key => {
    shipHandledSection.push({
      shipType: key,
      shipClassification: ships[key],
    });
  });
  return shipHandledSection;
}
function berthPermissibleVSLRestriction(allSection, rawData, key) {
  const sections = { ...allSection };
  const berthPermissibleVSLSection = {
    airDraught: [],
    maxDraftAtApproaches: [],
    depthAtApproaches: [],
    minUKCValM: [],
    minUKCAtApproaches: [],
  };
  const header = [];
  rawData.map(item => {
    if (!header.includes(key)) {
      header.push(key);
    }
    if (
      item.airDraught === null &&
      item.maxDraftAtApproaches === null &&
      item.depthAtApproaches === null &&
      item.minUKCValM === null &&
      item.minUKCAtApproaches === null
    ) {
      return berthPermissibleVSLSection;
    }
    berthPermissibleVSLSection.airDraught.push({
      key: item.mstwopVesselTypeDesc,
      value: item.airDraught,
    });
    berthPermissibleVSLSection.maxDraftAtApproaches.push({
      key: item.mstwopVesselTypeDesc,
      value: item.maxDraftAtApproaches,
    });
    berthPermissibleVSLSection.depthAtApproaches.push({
      key: item.mstwopVesselTypeDesc,
      value: item.depthAtApproaches,
    });
    berthPermissibleVSLSection.minUKCValM.push({
      key: item.mstwopVesselTypeDesc,
      value: item.minUKCValM,
    });
    berthPermissibleVSLSection.minUKCAtApproaches.push({
      key: item.mstwopVesselTypeDesc,
      value: item.minUKCAtApproaches,
    });
    return berthPermissibleVSLSection;
  });
  sections[key].data = berthPermissibleVSLSection;
  sections[key].header = header;
  return sections;
}

export function formatMasterData(data) {
  const masterData = {
    typesOfBottom: {
      key: 'typeOfBottomId',
      value: 'typeOfBottomDescription',
      data: [],
      masterKey: 'typesOfBottom',
    },

    berthTypeId: {
      key: 'berthTypeId',
      value: 'berthTypeDesc',
      data: [],
      masterKey: 'berthTypeList',
    },
    priority: {
      key: 'priorityTypeId',
      value: 'priorityTypeDesc',
      data: [],
      masterKey: 'priorityTypeList',
    },
    gangWayArrangements: {
      key: 'gangwayArrangementId',
      value: 'gangwayArrangementDesc',
      data: [],
      masterKey: 'gangwayArrangementList',
    },
    // berthCargoGearFacility: {
    //   key: 'berthGearsId',
    //   value: 'berthGearsDesc',
    //   data: [],
    //   masterKey: 'berthGearsList',
    // },
    style: {
      key: 'berthStyleId',
      value: 'berthStyleDesc',
      data: [],
      masterKey: 'berthStyleList',
    },
    berthmCargoTypeList: {
      key: 'berthmCargoTypeId',
      value: 'berthmCargoTypeDesc',
      data: [],
      masterKey: 'berthmCargoTypeList',
    },
    berthDocuments: {
      key: 'documentTypeId',
      value: 'documentTypeDesc',
      data: [],
      masterKey: 'documentTypeList',
    },
    berthFenderingTypes: {
      key: 'fenderingTypeId',
      value: 'fenderingTypeDesc',
      data: [],
      masterKey: 'fenderingTypeList',
    },
    berthTerminalSubTypes: {
      key: 'terminalSubTypeId',
      value: 'terminalSubTypeDescription',
      data: [],
      masterKey: 'terminalSubTypeList',
    },
    connectorTypeId: {
      key: 'connectorTypeId',
      value: 'connectorTypeDesc',
      data: [],
      masterKey: 'connectorTypeList',
    },
    gearAvailabilityMaster: {
      key: 'berthGearsId',
      value: 'berthGearsDesc',
      data: [],
      masterKey: 'berthGearsList',
    },
  };
  Object.keys(masterData).forEach(key => {
    const masterRec = masterData[key];
    if (data && data[masterRec.masterKey]) {
      data[masterRec.masterKey].forEach(item => {
        masterRec.data[item[masterRec.key]] = item[masterRec.value];
      });
    }
  });

  return masterData;
}

const filterSectionByType = (data, masterData, allSection) => {
  const updatedSections = { ...allSection };
  let isTypeMatch = false;
  for (let index = 0; index < data.berthTypeTransactions.length; index += 1) {
    const item = data.berthTypeTransactions[index];
    if (
      masterData.berthTypeId.data &&
      masterData.berthTypeId.data[item.berthTypeId]
    ) {
      const itemType = masterData.berthTypeId.data[
        item.berthTypeId
      ].toLowerCase();
      isTypeMatch =
        itemType === 'oil' || itemType === 'gas' || itemType === 'chemical';
      break;
    }
  }
  if (isTypeMatch === false) {
    delete updatedSections.oilPermissibleVSLParameters;
    delete updatedSections.permissibleManifoldParametersOil;
    delete updatedSections.permissibleManifoldParametersGas;
    delete updatedSections.gasPermissibleVSLParameters;
    delete updatedSections.oilCargoHandled;
    delete updatedSections.gasCargoHandled;
    delete updatedSections.chemicalCargoHandled;
  } else {
    delete updatedSections.dryCargoHandled;
  }
  return updatedSections;
};

export function formatData(data, master, formattedMaster) {
  let allSection = { ...berthSections };
  try {
    Object.keys(allSection).forEach(key => {
      if (key === 'ptbImage') {
        allSection[key].data = data[key];
      } else if (key === 'changeHistory') {
        allSection[key].data = data.berthChangedHistory;
      } else if (key === 'ptbDocument') {
        allSection[key].data = formatPtbDocuments(data[key]);
      } else if (key === 'shipHandled') {
        allSection[key].data = shipHandleFormatter(data[key]);
      } else if (key === 'berthCargoGearFacility') {
        allSection[key].data = berthCargoGearFacilityFormatter(
          data,
          formattedMaster,
        );
      } else {
        allSection[key].data = data[key] ? filterAuditFeilds(data[key]) : [];
        allSection[key].data = mapKeyValueFromMaster(
          allSection[key].data,
          formattedMaster,
        );
      }
    });
    allSection.generalParticulars.data = makeGeneralParticulars(
      data,
      formattedMaster,
    );
    // allSection.geocodes.data = makeGeoCode(data.berthGeoCode);
    allSection.berthNotes.data = data.berthNotes ? data.berthNotes.notes : '';
    if (allSection.berthNotes.data === '') delete allSection.berthNotes;

    allSection = permissibleManifoldParameters(
      allSection,
      data.permissibleManifoldParameters,
      formattedMaster,
    );
    allSection = berthPermissibleVSLRestriction(
      allSection,
      data.berthPermissibleVSLRestriction,
      'berthPermissibleVSLRestriction',
    );

    allSection = cargoHandleFormatter(allSection, data, master);

    // delete logic here
    Object.keys(allSection).forEach(key => {
      if (
        {}.hasOwnProperty.call(allSection[key], 'isVisible') &&
        {}.hasOwnProperty.call(allSection[key], 'data') &&
        allSection[key].data
      ) {
        if (allSection[key].data.length === 0) delete allSection[key];
        else {
          const nullItems = [];
          const originalItems = Object.keys(allSection[key].data);
          originalItems.forEach(k => {
            if (
              allSection[key].data[k] === undefined ||
              allSection[key].data[k] === null ||
              allSection[key].data[k] === ''
            ) {
              nullItems.push(k);
            } else if (
              Array.isArray(allSection[key].data[k]) &&
              allSection[key].data[k].length === 0
            ) {
              nullItems.push(k);
            } else if (typeof allSection[key].data[k] === 'number') {
              allSection[key].data[k] = allSection[key].data[k].toString();
            } else if (typeof allSection[key].data[k] === 'boolean') {
              if (allSection[key].data[k] === true)
                allSection[key].data[k] = 'Yes';
              if (allSection[key].data[k] === false)
                allSection[key].data[k] = 'No';
            }
          });
          if (originalItems.length === nullItems.length) {
            delete allSection[key];
          }
        }
      }
    });
    allSection = filterSectionByType(data, formattedMaster, allSection);

    // Convert 0.00 to NRA

    Object.keys(allSection).forEach(key => {
      if (
        Object.hasOwnProperty.call(allSection[key], 'data') &&
        !Array.isArray(allSection[key].data)
      ) {
        allSection[key].data = zeroToNRA(allSection[key].data);
      } else if (
        key.toLowerCase() === 'changehistory' &&
        Object.hasOwnProperty.call(allSection[key], 'data') &&
        Array.isArray(allSection[key].data)
      ) {
        allSection[key].data.forEach(i => {
          const item = i;
          item.newValue = zeroToNRA(i.newValue);
          item.oldValue = zeroToNRA(i.oldValue);
        });
      }
    });
    // eslint-disable-next-line no-empty
  } catch (e) {}

  return allSection;
}

function mapKeyValueFromMaster(data, master) {
  if (!data || data.length === 0) return data;
  const pairedValue = { ...data };
  Object.keys(data).forEach(field => {
    const item = data[field];
    if (Array.isArray(item)) {
      pairedValue[field] = [];
      Object.keys(item).forEach(subKey => {
        if ({}.hasOwnProperty.call(master, field)) {
          pairedValue[field].push(
            master[field].data[item[subKey][master[field].key]],
          );
        }
      });
    } else if ({}.hasOwnProperty.call(master, field)) {
      if (field === 'typesOfBottom') {
        pairedValue[field] = pairedValue[field]
          ? pairedValue[field].split(',')
          : '';
      } else {
        pairedValue[field] = master[field].data[item];
      }
    }
  });
  return pairedValue;
}

function berthCargoGearFacilityFormatter(data, formattedData) {
  if (!data.berthCargoGearFacility) {
    return [];
  }
  const gearAvailabilityData = [];
  const gearData = data.berthCargoGearFacility;
  data.berthGearsTransactions.forEach(gear => {
    gearAvailabilityData.push(
      formattedData.gearAvailabilityMaster.data[gear.berthGearsId],
    );
  });
  return {
    gearAvailabilityBerthId: gearAvailabilityData,
    connectorTypeId: gearData.connectorTypeId
      ? formattedData.connectorTypeId.data[gearData.connectorTypeId]
      : '',
    connectionFlangeSize: gearData.connectionFlangeSize,
    gearNotes: gearData.gearNotes,
  };
}

function formatPtbDocuments(data) {
  const formattedData = [];
  data.forEach(item => {
    const namesplit = item.filename.toString().split('/');
    formattedData.push({
      documentName: item.documentName,
      documentType: item.documentTypeName,
      attachmentUploadPath: namesplit[namesplit.length - 1],
    });
  });
  return formattedData;
}

export function filterAuditFeilds(data) {
  if (Array.isArray(data)) {
    return data.map(item => deleteKeys(item));
  }
  return deleteKeys(data);
}

function deleteKeys(data) {
  const formattedData = { ...data };
  const ignoreFields = {
    isCargo: 'isCargo',
    createdBy: 'createdBy',
    createdTimeStamp: 'createdTimeStamp',
    updatedBy: 'updatedBy',
    updatedTimeStamp: 'updatedTimeStamp',
    isDelete: 'isDelete',
    berthId: 'berthId',
    terminalId: 'terminalId',
    timeSpentInPort: 'timeSpentInPort',
    vesselimonumber: 'vesselimonumber',
  };

  if (formattedData) {
    Object.keys(ignoreFields).forEach(keys => {
      delete formattedData[keys];
      Object.keys(data).forEach(key => {
        if (key.match(/Id/g)) delete formattedData[key];
      });
    });
  }

  return formattedData;
}

function CustomGridCell({ data }) {
  return data.map(item => (
    <Col xs={3} sm={1} md={1} lg={1}>
      {item.value}
    </Col>
  ));
}
CustomGridCell.propTypes = {
  data: PropTypes.oneOfType([PropTypes.array, PropTypes.object]).isRequired,
};

function CustomTable({ data, downloadDocumentInformation }) {
  const header = [];
  const tableBody = [];
  if (!Array.isArray(data) || (Array.isArray(data) && data.length === 0))
    return <></>;

  Object.keys(data[0]).forEach(head => {
    const attr = messages[head] ? (
      <FormattedMessage {...messages[head]} />
    ) : (
      head
    );
    header.push(<th>{attr}</th>);
  });

  data.forEach(item => {
    const tableCols = [];
    Object.keys(item).forEach(keys => {
      if (keys === 'attachmentUploadPath') {
        tableCols.push(
          <td>
            {item[keys] ? (
              <Button
                color="link"
                className="filenamecheck"
                onClick={() => downloadDocumentInformation(item[keys])}
              >
                {item[keys]}
              </Button>
            ) : (
              ''
            )}
          </td>,
        );
      } else {
        tableCols.push(<td>{item[keys] ? item[keys].toString() : ''}</td>);
      }
    });
    tableBody.push(<tr>{tableCols}</tr>);
  });

  return (
    <>
      <table className="table berth-table">
        <thead className="table-head">
          <tr>{header}</tr>
        </thead>
        <tbody>{tableBody}</tbody>
      </table>
    </>
  );
}
CustomTable.propTypes = {
  data: PropTypes.oneOfType([PropTypes.array, PropTypes.object]).isRequired,
  downloadDocumentInformation: PropTypes.func,
};

const CustomGrid = ({ data }) => {
  const element = [];
  const header = [];
  if (Object.keys(data).length > 0) {
    data[Object.keys(data)[0]].forEach(headIndex => {
      const label = messages[headIndex.key] ? (
        <FormattedMessage {...messages[headIndex.key]} />
      ) : (
        <>{headIndex.key}</>
      );
      header.push(
        <Col xs={3} sm={1} md={1} lg={1}>
          {label}
        </Col>,
      );
    });
    element.push(
      <Row className="port_overview_row_cls customRow">
        <Col xs={6} sm={2} md={4} lg={3} />
        {header}
      </Row>,
    );
  }
  Object.keys(data).forEach(key => {
    element.push(
      <Row className="port_overview_row_cls customRow">
        <Col xs={6} sm={2} md={4} lg={3}>
          <FormattedMessage {...messages[key]} />
        </Col>
        <CustomGridCell data={data[key]} />
      </Row>,
    );
  });

  return element;
};
CustomGrid.propTypes = {
  data: PropTypes.oneOfType([PropTypes.array, PropTypes.object]).isRequired,
};

function stringifyValue(data, attr) {
  let labelValue;
  if (Array.isArray(data[attr])) {
    labelValue = [];
    data[attr].forEach(item => {
      labelValue.push(
        <CustomInput disabled type="checkbox" label={item} id={item} checked />,
      );
    });
  } else {
    labelValue = data[attr] ? data[attr].toString() : '';
  }

  return labelValue;
}

const berthRestriction = [
  'nightBerthingNotes',
  'tankCleaningNotes',
  'tidalNotes',
  'ballastNotes',
  'nitrogenSupplyNotes',
  'crudeOilNotes',
  'vapourRecoveryNotes',
  'chainStopperNotes',
  'mooringRequirements',
  'specificBerthIngRestrictions',
  'dirtyBallastReceptNotes',
  'slopReceptionNotes',
  'sewageReceptionNotes',
  'shiptoShipNotes',
  'freshWaterNotes',
];

const checkBerthRestrictionLabel = label => {
  let berthres = false;
  berthRestriction.forEach(x => {
    if (x === label) berthres = true;
  });
  return berthres;
};

const Cell = ({ data, type, attr, hanldeShowImage }) => {
  if (!data[attr] || data[attr].length === 0) {
    return <></>;
  }
  let element;
  const label = messages[attr] ? (
    <FormattedMessage {...messages[attr]} />
  ) : (
    <>{attr}</>
  );
  const labelValue = stringifyValue(data, attr);
  const isCheckBox = Array.isArray(data[attr]);
  const checkNotesInfo = checkBerthRestrictionLabel(attr);
  switch (type) {
    case types.SIMPLE:
      element = (
        <>
          <h5>{label}</h5>
          {!checkNotesInfo && (
            <p className={isCheckBox ? 'checkbox-berth' : 'custom-checkbox-p'}>
              {labelValue}
            </p>
          )}
          {checkNotesInfo && <p className="sectionheight">{labelValue}</p>}
        </>
      );
      break;
    // Check the Index file
    case types.IMAGES:
      return (
        <Col
          xs={6}
          sm={2}
          md={1}
          lg={1}
          onClick={() => hanldeShowImage(true, data[attr].seclectIndex)}
        >
          <img src={data[attr].filename} className="berth-img" alt="BerthImg" />
          {data[attr].name}
        </Col>
      );

    case types.MULTIPLE:
      element = (
        <>
          <h5>{label}</h5>
          {attr === 'attachmentUploadPath' ? (
            <a href={data[attr]} download>
              {data[attr]}
            </a>
          ) : (
            <p className="custom-checkbox-p">{labelValue}</p>
          )}
        </>
      );
      break;
    default:
      element = <></>;
  }
  return (
    <Col sm={4} xs={2}>
      {element}
    </Col>
  );
};
Cell.propTypes = {
  data: PropTypes.oneOfType([PropTypes.array, PropTypes.object]).isRequired,
  type: PropTypes.oneOfType([PropTypes.array, PropTypes.object]).isRequired,
  attr: PropTypes.oneOfType([PropTypes.array, PropTypes.object]).isRequired,
  masterData: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  hanldeShowImage: PropTypes.func.isRequired,
};

const Columns = ({
  data,
  type,
  hanldeShowImage,
  downloadDocumentInformation,
}) => {
  const cols = [];
  if (type === types.CUSTOMGRID)
    return (
      <div className="vessel-restriction">
        <CustomGrid data={data} />
      </div>
    );
  if (type === types.TABLE)
    return (
      <CustomTable
        data={data}
        downloadDocumentInformation={downloadDocumentInformation}
      />
    );
  if (typeof data !== 'object') {
    return (
      <Col>
        <p
          className="CodeMirror cm-s-easymde CodeMirror-wrap"
          style={{ 'z-index': 0 }}
        >
          {data ? data.toString() : ''}
        </p>
      </Col>
    );
  }
  Object.keys(data).forEach(key => {
    cols.push(
      <Cell
        data={data}
        type={type}
        attr={key}
        hanldeShowImage={hanldeShowImage}
      />,
    );
  });
  return <>{cols}</>;
};
Columns.propTypes = {
  data: PropTypes.oneOfType([PropTypes.array, PropTypes.object]).isRequired,
  type: PropTypes.oneOfType([PropTypes.array, PropTypes.object]).isRequired,
  hanldeShowImage: PropTypes.func.isRequired,
  downloadDocumentInformation: PropTypes.func.isRequired,
};

export const CommonSection = ({
  data,
  type,
  hanldeShowImage,
  downloadDocumentInformation,
}) => {
  if (type === types.CARGOHANDLED) {
    const otherData = { ...data };
    if (otherData.products) delete otherData.products;
    return (
      <>
        {data.products && <Columns data={data.products} type={types.TABLE} />}
        <Columns data={otherData} type={types.SIMPLE} />
      </>
    );
  }
  if (Array.isArray(data) && type !== types.TABLE) {
    return data.map(item => (
      <>
        <Columns
          data={item}
          type={type}
          hanldeShowImage={hanldeShowImage}
          downloadDocumentInformation={downloadDocumentInformation}
        />
      </>
    ));
  }
  return (
    <Columns
      data={data}
      type={type}
      hanldeShowImage={hanldeShowImage}
      downloadDocumentInformation={downloadDocumentInformation}
    />
  );
};
CommonSection.propTypes = {
  data: PropTypes.oneOfType([PropTypes.array, PropTypes.object]).isRequired,
  type: PropTypes.oneOfType([PropTypes.array, PropTypes.object]).isRequired,
  hanldeShowImage: PropTypes.func.isRequired,
  downloadDocumentInformation: PropTypes.func.isRequired,
};

export const getSectionTitles = sections => {
  const sectionTitles = [];
  Object.keys(sections).forEach(key => {
    if (berthSections[key].data && berthSections[key].data.length !== 0) {
      sectionTitles.push(messages[key].defaultMessage.toLowerCase());
    }
  });
  return sectionTitles;
};

export const PreferenceFilter = ({ data, dPreferenceChange, berthData }) => {
  const filters = [];
  const titles = getSectionTitles(berthData);

  Object.keys(data).forEach(key => {
    const item = data[key];
    if (item.isVisible === true && titles.includes(item.label.toLowerCase())) {
      filters.push(
        <Col xs={12} sm={4} md={4} lg={4} xl={4} style={{ flex: '1 0 auto' }}>
          <CustomInput
            type="checkbox"
            label={item.label}
            id={item.entityId}
            checked={item.isChecked}
            data-value={item.entityId}
            onClick={dPreferenceChange}
          />
        </Col>,
      );
    }
  });

  return (
    <Row className="p-4">
      {filters}
      <Col>
        <Button
          color="link"
          className="btn-sm"
          onClick={() => {
            dPreferenceChange('all');
          }}
        >
          Show All
        </Button>
      </Col>
    </Row>
  );
};

PreferenceFilter.propTypes = {
  data: PropTypes.oneOfType([PropTypes.array, PropTypes.object]).isRequired,
  dPreferenceChange: PropTypes.func,
  berthData: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
};

export const getHeaders = type => {
  let headers = {};
  switch (type) {
    case 'lastFiveVesselsCalledAtBerth':
      headers = formatTopVessel();
      break;
    case 'changeHistory':
      headers = [
        {
          title: 'Updated Date',
          cell: row => dateTimeConversion(row.createdTimeStamp),
        },
        {
          title: 'Field Name',
          prop: 'fieldName',
        },
        {
          title: 'Old Value',
          prop: 'oldValue',
        },
        {
          title: 'New Value',
          prop: 'newValue',
        },
      ];
      break;
    default:
      break;
  }
  return headers;
};
export const formatTopVessel = () => [
  {
    title: messages.vesselName.defaultMessage,
    prop: 'vesselName',
  },
  {
    title: messages.vesselType.defaultMessage,
    prop: 'vesselType',
  },
  {
    title: messages.nextPortName.defaultMessage,
    prop: 'nextPortName',
  },
  {
    title: messages.berthArrivalDate.defaultMessage,
    prop: 'berthArrivalDate',
  },
  {
    title: messages.departureBerthTime.defaultMessage,
    prop: 'departureBerthTime',
  },
];

export function formatPtbImages(data, dSetBerthImages, dHandleFileDownload) {
  data.forEach(item => {
    getImageFromS3Bucket(
      item.filename,
      item.ptbImageId,
      dSetBerthImages,
      item.key,
      dHandleFileDownload,
    );
  });
}
