/*
 * BerthDetailSection Messages
 *
 * This contains all the text for the BerthDetailSection component.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.components.BerthDetailSection';

export default defineMessages({
  cargoHandled: {
    id: `${scope}.cargoHandled`,
    defaultMessage: 'Cargo Handled',
  },
  products: {
    id: `${scope}.products`,
    defaultMessage: 'Products',
  },
  header: {
    id: `${scope}.header`,
    defaultMessage: 'Berth Details',
  },
  filter: {
    id: `${scope}.filter`,
    defaultMessage: 'Filter',
  },
  chooseSections: {
    id: `${scope}.chooseSections`,
    defaultMessage: 'Choose Sections',
  },
  oilCargoHandled: {
    id: `${scope}.oilCargoHandled`,
    defaultMessage: 'Oil Cargo Handled',
  },
  oilCargoHandledProduct: {
    id: `${scope}.oilCargoHandledProduct`,
    defaultMessage: 'Oil Cargo Handled',
  },
  gasCargoHandled: {
    id: `${scope}.gasCargoHandled`,
    defaultMessage: 'Gas Cargo Handled',
  },
  gasCargoHandledProduct: {
    id: `${scope}.gasCargoHandledProduct`,
    defaultMessage: 'Gas Cargo Handled',
  },
  chemicalCargoHandled: {
    id: `${scope}.chemicalCargoHandled`,
    defaultMessage: 'Chemical Cargo Handled',
  },
  chemicalCargoHandledProduct: {
    id: `${scope}.chemicalCargoHandledProduct`,
    defaultMessage: 'Chemical Cargo Handled',
  },
  dryCargoHandled: {
    id: `${scope}.dryCargoHandled`,
    defaultMessage: 'Dry Cargo Handled',
  },
  dryCargoHandledProduct: {
    id: `${scope}.dryCargoHandledProduct`,
    defaultMessage: 'Dry Cargo Handled Products',
  },

  mainCargoType: {
    id: `${scope}.mainCargoType`,
    defaultMessage: 'Cargo Types',
  },
  productType: {
    id: `${scope}.productType`,
    defaultMessage: 'Type of Products',
  },
  storageType: {
    id: `${scope}.storageType`,
    defaultMessage: 'Storage Type',
  },
  loadingRate: {
    id: `${scope}.loadingRate`,
    defaultMessage: 'Loading Rate',
  },
  dischargeRate: {
    id: `${scope}.dischargeRate`,
    defaultMessage: 'Discharging Rate',
  },
  generalParticulars: {
    id: `${scope}.generalParticulars`,
    defaultMessage: 'General Particulars',
  },
  geocodes: {
    id: `${scope}.geocodes`,
    defaultMessage: 'Geocodes',
  },
  oilPermissibleVSLParameters: {
    id: `${scope}.oilPermissibleVSLParameters`,
    defaultMessage: 'Permissible Vessel Parameters - Oil',
  },
  permissibleManifoldParametersOil: {
    id: `${scope}.permissibleManifoldParametersOil`,
    defaultMessage: 'Permissible Manifold Parameters - Oil',
  },
  permissibleManifoldParametersGas: {
    id: `${scope}.permissibleManifoldParametersGas`,
    defaultMessage: 'Permissible Manifold Parameters - Gas',
  },
  gasPermissibleVSLParameters: {
    id: `${scope}.gasPermissibleVSLParameters`,
    defaultMessage: 'Permissible Vessel Parameters - Gas',
  },
  berthCargoGearFacility: {
    id: `${scope}.berthCargoGearFacility`,
    defaultMessage: 'Berth Cargo Gear Facility',
  },
  changeHistory: {
    id: `${scope}.changeHistory`,
    defaultMessage: 'Changed History',
  },
  shipHandled: {
    id: `${scope}.shipHandled`,
    defaultMessage: 'Ship Handled',
  },
  ptbDocument: {
    id: `${scope}.ptbDocument`,
    defaultMessage: 'Berth Document',
  },
  berthNotes: { id: `${scope}.berthNotes`, defaultMessage: 'Berth Notes' },
  ptbImage: { id: `${scope}.ptbImage`, defaultMessage: 'Images' },
  services: { id: `${scope}.services`, defaultMessage: 'Berth Services' },
  // change History
  fieldName: { id: `${scope}.fieldName`, defaultMessage: 'Field Name' },
  OldValue: { id: `${scope}.OldValue`, defaultMessage: 'Old Value' },
  NewValue: { id: `${scope}.NewValue`, defaultMessage: 'New Value' },
  updatedValue: {
    id: `${scope}.updatedValue`,
    defaultMessage: 'Updated Value',
  },
  // ship Handled
  shipType: {
    id: `${scope}.shipType`,
    defaultMessage: 'Ship Type',
  },
  shipClassification: {
    id: `${scope}.shipClassification`,
    defaultMessage: 'Ship Type Classification',
  },
  // General Particular
  berthTerminalSubTypes: {
    id: `${scope}.berthTerminalSubTypes`,
    defaultMessage: 'Berth Type',
  },
  berthCode: { id: `${scope}.berthCode`, defaultMessage: 'Berth Code' },
  berthTypeId: { id: `${scope}.berthTypeId`, defaultMessage: 'Type' },
  style: { id: `${scope}.style`, defaultMessage: 'Style' },
  berthName: { id: `${scope}.berthName`, defaultMessage: 'Berth Name' },
  alternativeName: {
    id: `${scope}.alternativeName`,
    defaultMessage: 'Alternate Name',
  },
  portName: { id: `${scope}.portName`, defaultMessage: 'Port' },
  terminalName: { id: `${scope}.terminalName`, defaultMessage: 'Terminal' },
  priority: { id: `${scope}.priority`, defaultMessage: 'Priority' },
  status: { id: `${scope}.status`, defaultMessage: 'Status' },
  timeZoneName: { id: `${scope}.timeZoneName`, defaultMessage: 'Time Zone' },
  waterSalinity: {
    id: `${scope}.waterSalinity`,
    defaultMessage: 'Salinity of Water',
  },
  gangWayArrangements: {
    id: `${scope}.gangWayArrangements`,
    defaultMessage: 'Ganway Arrangements',
  },
  berthFenderingTypes: {
    id: `${scope}.berthFenderingTypes`,
    defaultMessage: 'Type of Fendering',
  },
  typesOfBottom: {
    id: `${scope}.typesOfBottom`,
    defaultMessage: 'Type of Bottom',
  },
  lastHydrographicalSurvey: {
    id: `${scope}.lastHydrographicalSurvey`,
    defaultMessage: 'Last Hydrographical',
  },
  lastStructuralSurvey: {
    id: `${scope}.lastStructuralSurvey`,
    defaultMessage: 'Last Structural ',
  },
  berthOwner: { id: `${scope}.berthOwner`, defaultMessage: 'Berth Owner' },
  berthOperator: {
    id: `${scope}.berthOperator`,
    defaultMessage: 'Berth Operator',
  },
  // GeoCode
  latitude: {
    id: `${scope}.latitude`,
    defaultMessage: 'Berth Latitude',
  },
  longitude: {
    id: `${scope}.longitude`,
    defaultMessage: 'Berth Longitude',
  },
  // Permissible Vessel Parameters Oil
  lengthOfBerth: {
    id: `${scope}.lengthOfBerth`,
    defaultMessage: 'Length of Berth (m)',
  },
  continuousQuayWharfLength: {
    id: `${scope}.continuousQuayWharfLength`,
    defaultMessage: 'Continous Quay/Wharf Length',
  },
  berthWidth: {
    id: `${scope}.berthWidth`,
    defaultMessage: 'Berth Width (m)',
  },
  berthFlatSide: {
    id: `${scope}.berthFlatSide`,
    defaultMessage: 'Berth Flatside (m)',
  },
  wharfHeight: {
    id: `${scope}.wharfHeight`,
    defaultMessage: 'Wharf Height (m)',
  },
  maxArrivalDisplacement: {
    id: `${scope}.maxArrivalDisplacement`,
    defaultMessage: 'Maximum Arrival Displacement (mt)',
  },
  maxDisplacementAlongSide: {
    id: `${scope}.maxDisplacementAlongSide`,
    defaultMessage: 'Maximum Displacement Alongside (mt)',
  },
  minDisplacementAlongSide: {
    id: `${scope}.minDisplacementAlongSide`,
    defaultMessage: 'Minimum Displacement Alongside (mt)',
  },
  maxDeadWeightDWT: {
    id: `${scope}.maxDeadWeightDWT`,
    defaultMessage: 'Maximum Deadweight (mt)',
  },
  minDeadWeightDWT: {
    id: `${scope}.minDeadWeightDWT`,
    defaultMessage: 'Minimum Deadweight (mt)',
  },
  maxFreeBoard: {
    id: `${scope}.maxFreeBoard`,
    defaultMessage: 'Maximum Freeboard (m)',
  },
  maxLengthOverAllLOA: {
    id: `${scope}.maxLengthOverAllLOA`,
    defaultMessage: 'Maximum Length Overall (m)',
  },
  minLengthOverAllLOA: {
    id: `${scope}.minLengthOverAllLOA`,
    defaultMessage: 'Minimum Length Overall (m)',
  },
  maxBeamWidth: {
    id: `${scope}.maxBeamWidth`,
    defaultMessage: 'Maximum Beam (m)',
  },
  minBeam: {
    id: `${scope}.minBeam`,
    defaultMessage: 'Minimum Beam (m)',
  },
  maximumAirDraftAlongSide: {
    id: `${scope}.maximumAirDraftAlongSide`,
    defaultMessage: 'Maximum Air Draught Alongside (m)',
  },
  maxAirDraftUndershoreGear: {
    id: `${scope}.maxAirDraftUndershoreGear`,
    defaultMessage: 'Maximum Air Draught Under Shore Gear (m)',
  },
  depthAlongSide: {
    id: `${scope}.depthAlongSide`,
    defaultMessage: 'Depth Alongside (m)',
  },
  maxDraftAlongSide: {
    id: `${scope}.maxDraftAlongSide`,
    defaultMessage: 'Maximum Draught Alongside (m)',
  },
  minAlongSideUKC: {
    id: `${scope}.minAlongSideUKC`,
    defaultMessage: 'Minimum Alongside UKC (m)',
  },
  minPMB: {
    id: `${scope}.minPMB`,
    defaultMessage: 'Minimum PMB (m)',
  },
  pblFwdArrival: {
    id: `${scope}.pblFwdArrival`,
    defaultMessage: 'PBL Forward Arrival (m)',
  },
  minPMBForwardOfShipManiFold: {
    id: `${scope}.minPMBForwardOfShipManiFold`,
    defaultMessage: 'Minimum PMB Forward of Ships Manifold (m)',
  },
  pblAftArrival: {
    id: `${scope}.pblAftArrival`,
    defaultMessage: 'PBL Aft Arrival (m)',
  },
  minPMBAftOfShipManiFold: {
    id: `${scope}.minPMBAftOfShipManiFold`,
    defaultMessage: 'Minimum PMB Aft of Ships Manifold (m)',
  },
  minFreeBoard: {
    id: `${scope}.minFreeBoard`,
    defaultMessage: 'Minimum Freeboard (m)',
  },
  fendersForwardOfManiFold: {
    id: `${scope}.fendersForwardOfManiFold`,
    defaultMessage: 'Fenders Forward of Manifold',
  },
  berthingSide: {
    id: `${scope}.berthingSide`,
    defaultMessage: 'Berthing Side',
  },
  berthingSpeed: {
    id: `${scope}.berthingSpeed`,
    defaultMessage: 'Berthing Speed (kts)',
  },
  berthingAngle: {
    id: `${scope}.berthingAngle`,
    defaultMessage: 'Berthing Angle (deg)',
  },
  fendersAftOfManiFold: {
    id: `${scope}.fendersAftOfManiFold`,
    defaultMessage: 'Fenders Aft of Manifold',
  },
  // Permissible Vessel Parameters - Gas
  cubicCapacityGasCarriersMaximum: {
    id: `${scope}.cubicCapacityGasCarriersMaximum`,
    defaultMessage: 'Cubic Capacity (Gas Carriers) Maximum (m3)',
  },
  cubicCapacityGasCarriersMinimum: {
    id: `${scope}.cubicCapacityGasCarriersMinimum`,
    defaultMessage: 'Cubic Capacity (Gas Carriers) Minimum (m3)',
  },
  minPMBForwardOfShipsManiFold: {
    id: `${scope}.minPMBForwardOfShipsManiFold`,
    defaultMessage: "Minimum PMB Forward of Ship's Manifold (m)",
  },
  minPMBAftOfShipsManiFold: {
    id: `${scope}.minPMBAftOfShipsManiFold`,
    defaultMessage: "Minimum PMB Aft of Ship's Manifold (m)",
  },
  maxAirDraftUnderShoreGear: {
    id: `${scope}.maxAirDraftUnderShoreGear`,
    defaultMessage: 'Maximum Air Draught Under Shore Gear (m)',
  },
  fendersAftOfManifold: {
    id: `${scope}.fendersAftOfManifold`,
    defaultMessage: 'Fenders Aft of Manifold',
  },
  // Permissible Manifold Parameters - Oil/Gas
  maxHeightManifoldAWL: {
    id: `${scope}.maxHeightManifoldAWL`,
    defaultMessage: 'Maximum Height Manifold AWL (m)',
  },
  minHeightManifoldAWL: {
    id: `${scope}.minHeightManifoldAWL`,
    defaultMessage: 'Minimum Height Manifold AWL (m)',
  },
  minBCM: {
    id: `${scope}.minBCM`,
    defaultMessage: 'Minimum Bow to centre of Manifold distance (m)',
  },
  maxBowManiFoldDistance: {
    id: `${scope}.maxBowManiFoldDistance`,
    defaultMessage: 'Maximum Bow to Centre of Manifold Distance (m)',
  },
  minSCM: {
    id: `${scope}.minSCM`,
    defaultMessage: 'Minimum Stern to centre of Manifold distance (m)',
  },
  maxSternManifoldDistance: {
    id: `${scope}.maxSternManifoldDistance`,
    defaultMessage: 'Maximum Stern to Centre of Manifold Distance (m)',
  },
  minHeightAboveDeck: {
    id: `${scope}.minHeightAboveDeck`,
    defaultMessage: 'Minimum Height of Manifold Above Deck (m)',
  },
  maxDistanceSideRail: {
    id: `${scope}.maxDistanceSideRail`,
    defaultMessage: 'Maximum Distance from Manifold to Ship Side Rail (m)',
  },
  minDistanceSideRail: {
    id: `${scope}.minDistanceSideRail`,
    defaultMessage: 'Minimum Distance from Manifold to Ship Side Rail (m)',
  },
  maximumHeightDripTray: {
    id: `${scope}.maximumHeightDripTray`,
    defaultMessage: 'Maximum Height of Manifold Above Deck or Drip Tray (m)',
  },
  minimumHeightDripTray: {
    id: `${scope}.minimumHeightDripTray`,
    defaultMessage: 'Minimum Height of Manifold Above Deck or Drip Tray (m)',
  },
  maximumManifoldSetBack: {
    id: `${scope}.maximumManifoldSetBack`,
    defaultMessage: 'Maximum Manifold Setback (m)',
  },
  minimumManifoldSetBack: {
    id: `${scope}.minimumManifoldSetBack`,
    defaultMessage: 'Minimum Manifold Setback (m)',
  },
  maximumManifoldSpacing: {
    id: `${scope}.maximumManifoldSpacing`,
    defaultMessage: 'Maximum Manifold Spacing (m)',
  },
  minimumManifoldSpacing: {
    id: `${scope}.minimumManifoldSpacing`,
    defaultMessage: 'Minimum Manifold Spacing (m)',
  },
  hoseDerrickMinSWL: {
    id: `${scope}.hoseDerrickMinSWL`,
    defaultMessage: 'Hose Derrick Minimum SWL (mt)',
  },
  // Berth Cargo Gear Facility
  connectionFlangeSize: {
    id: `${scope}.connectionFlangeSize`,
    defaultMessage: 'Connector Flange Size',
  },
  gearNotes: {
    id: `${scope}.gearNotes`,
    defaultMessage: 'Gear Notes',
  },
  // Documents
  documentName: {
    id: `${scope}.documentName`,
    defaultMessage: 'Document Name',
  },
  documentType: {
    id: `${scope}.documentType`,
    defaultMessage: 'Document Type',
  },
  noOfCopies: {
    id: `${scope}.noOfCopies`,
    defaultMessage: 'Number of Copies',
  },
  attachmentUploadPath: {
    id: `${scope}.attachmentUploadPath`,
    defaultMessage: 'Attachment',
  },
  // Berth Services
  isCargo: {
    id: `${scope}.isCargo`,
    defaultMessage: 'Cargo',
  },
  isDirtyBallastReceptFacility: {
    id: `${scope}.isDirtyBallastReceptFacility`,
    defaultMessage: 'Dirty Ballast Reception Facility',
  },
  dirtyBallastReceptNotes: {
    id: `${scope}.dirtyBallastReceptNotes`,
    defaultMessage: 'Dirty Ballast Reception Notes ',
  },
  issewagereceptfacility: {
    id: `${scope}.issewagereceptfacility`,
    defaultMessage: 'Sewage Reception Facility',
  },
  isSlopReceptionFacility: {
    id: `${scope}.isSlopReceptionFacility`,
    defaultMessage: 'Slop Reception Facility',
  },
  slopReceptionNotes: {
    id: `${scope}.slopReceptionNotes`,
    defaultMessage: 'Slop Reception Notes',
  },
  isGarbageDisposalFacility: {
    id: `${scope}.isGarbageDisposalFacility`,
    defaultMessage: 'Garbage Disposal Facility',
  },
  sewageReceptionNotes: {
    id: `${scope}.sewageReceptionNotes`,
    defaultMessage: 'Sewage Reception Notes',
  },
  isShiptoShipAvailble: {
    id: `${scope}.isShiptoShipAvailble`,
    defaultMessage: 'Ship to Ship Available',
  },
  shiptoShipNotes: {
    id: `${scope}.shiptoShipNotes`,
    defaultMessage: 'Ship to Ship Notes',
  },
  isFreshWater: {
    id: `${scope}.isFreshWater`,
    defaultMessage: 'Fresh Water',
  },
  freshWaterNotes: {
    id: `${scope}.freshWaterNotes`,
    defaultMessage: 'Fresh Water Notes',
  },
  isProvisionStoresDeliveryAvailable: {
    id: `${scope}.isProvisionStoresDeliveryAvailable`,
    defaultMessage: 'Provisions/Stores Delivery Available',
  },
  // Berth Contacts
  contactDetails: {
    id: `${scope}.contactDetails`,
    defaultMessage: 'Berth Contacts',
  },
  designation: {
    id: `${scope}.designation`,
    defaultMessage: 'Designation ',
  },
  name: {
    id: `${scope}.name`,
    defaultMessage: 'Name',
  },
  address: {
    id: `${scope}.address`,
    defaultMessage: 'Address',
  },
  postalCode: {
    id: `${scope}.postalCode`,
    defaultMessage: 'Postal Code',
  },
  email: {
    id: `${scope}.email`,
    defaultMessage: 'Email',
  },
  phoneNumber: {
    id: `${scope}.phoneNumber`,
    defaultMessage: 'Phone Number',
  },
  // Berth Restriction
  restriction: {
    id: `${scope}.restriction`,
    defaultMessage: 'Berth Restrictions',
  },
  isNightBerthingUnberthing: {
    id: `${scope}.isNightBerthingUnberthing`,
    defaultMessage: 'Night Berthing/Unberthing Permitted',
  },
  nightBerthingNotes: {
    id: `${scope}.nightBerthingNotes`,
    defaultMessage: 'Night Berthing Notes',
  },
  isTankCleaningAllowedAlongside: {
    id: `${scope}.isTankCleaningAllowedAlongside`,
    defaultMessage: 'Tank Cleaning Allowed Alongside',
  },
  tankCleaningNotes: {
    id: `${scope}.tankCleaningNotes`,
    defaultMessage: 'Tank Cleaning Notes',
  },
  isTidalRestrictions: {
    id: `${scope}.isTidalRestrictions`,
    defaultMessage: 'Tidal Restrictions',
  },
  tidalNotes: {
    id: `${scope}.tidalNotes`,
    defaultMessage: 'Tidal Notes',
  },
  isCleanBallastDeBallastRestrictions: {
    id: `${scope}.isCleanBallastDeBallastRestrictions`,
    defaultMessage: 'Clean Ballast / De-Ballast Restriction',
  },
  ballastNotes: {
    id: `${scope}.ballastNotes`,
    defaultMessage: 'Ballast Notes',
  },
  isNitrogenSupplyAvailable: {
    id: `${scope}.isNitrogenSupplyAvailable`,
    defaultMessage: 'Nitrogen Supply Available',
  },
  nitrogenSupplyNotes: {
    id: `${scope}.nitrogenSupplyNotes`,
    defaultMessage: 'Nitrogen Supply Notes',
  },
  isCrudeOilWashIngPermitted: {
    id: `${scope}.isCrudeOilWashIngPermitted`,
    defaultMessage: 'Crude Oil Washing Permitted',
  },
  crudeOilNotes: {
    id: `${scope}.crudeOilNotes`,
    defaultMessage: 'Crude Oil Notes',
  },
  isVapourRecoveryRequiremts: {
    id: `${scope}.isVapourRecoveryRequiremts`,
    defaultMessage: 'Vapour Recovery Requirements',
  },
  vapourRecoveryNotes: {
    id: `${scope}.vapourRecoveryNotes`,
    defaultMessage: 'Vapour Recovery Notes',
  },
  chainStopperDescription: {
    id: `${scope}.chainStopperDescription`,
    defaultMessage: 'Chain Stopper Requirements',
  },
  chainStopperNotes: {
    id: `${scope}.chainStopperNotes`,
    defaultMessage: 'Chain Stopper Notes',
  },
  isBowLoading: {
    id: `${scope}.isBowLoading`,
    defaultMessage: 'Bow Loading',
  },
  sternLoading: {
    id: `${scope}.sternLoading`,
    defaultMessage: 'Stern Loading',
  },
  isEmergencyTowOffPreRequire: {
    id: `${scope}.isEmergencyTowOffPreRequire`,
    defaultMessage: 'Emergency Towing Off Pennants (ETOPs) Required ',
  },
  mooringRequirements: {
    id: `${scope}.mooringRequirements`,
    defaultMessage: 'Mooring Requirements',
  },
  maxPermitTedVesselAge: {
    id: `${scope}.restriction`,
    defaultMessage: 'Maximum Permitted Vessel Age',
  },
  specificBerthIngRestrictions: {
    id: `${scope}.specificBerthIngRestrictions`,
    defaultMessage: 'Specific Berthing Restrictions',
  },
  // Vessel Restrictions at Approaches
  berthPermissibleVSLRestriction: {
    id: `${scope}.berthPermissibleVSLRestriction`,
    defaultMessage: 'Vessel Restrictions at Approaches',
  },
  airDraught: {
    id: `${scope}.airDraught`,
    defaultMessage: 'Air Draught at Approaches (m)',
  },
  maxDraftAtApproaches: {
    id: `${scope}.maxDraftAtApproaches`,
    defaultMessage: 'Maximum Draught at Approaches (m)',
  },
  depthAtApproaches: {
    id: `${scope}.depthAtApproaches`,
    defaultMessage: 'Depth at Approaches (m)',
  },
  minUKCValM: {
    id: `${scope}.minUKCValM`,
    defaultMessage: 'Minimum UKC at Approaches (m)',
  },
  minUKCAtApproaches: {
    id: `${scope}.berthPermissibleVSLRestriction`,
    defaultMessage: 'Minimum UKC at Approaches (%)',
  },
  lastFiveVesselsCalledAtBerth: {
    id: `${scope}.lastFiveVesselsCalledAtBerth`,
    defaultMessage: 'Last Five Vessels Called At Berth',
  },
  vesselimonumber: {
    id: `${scope}.vesselimonumber`,
    defaultMessage: 'Vessel IMO',
  },
  vesselName: {
    id: `${scope}.vesselName`,
    defaultMessage: 'Vessel Name',
  },
  vesselType: {
    id: `${scope}.vesselType`,
    defaultMessage: 'Vessel Type',
  },
  nextPortName: {
    id: `${scope}.nextPortName`,
    defaultMessage: 'Next Port',
  },
  berthArrivalDate: {
    id: `${scope}.berthArrivalDate`,
    defaultMessage: 'Time of Arrival',
  },
  departureBerthTime: {
    id: `${scope}.departureBerthTime`,
    defaultMessage: 'Time of Departure',
  },

  connectorTypeId: {
    id: `${scope}.connectorTypeId`,
    defaultMessage: 'Connector Type',
  },
  gearAvailabilityBerthId: {
    id: `${scope}.gearAvailabilityBerthId`,
    defaultMessage: 'Gear Availability At Berth',
  },
  dryPermissibleVSLParameters: {
    id: `${scope}.dryPermissibleVSLParameters`,
    defaultMessage: 'Permissible Vessel Parameters - Dry',
  },

  createdTimeStamp: {
    id: `${scope}.createdTimeStamp`,
    defaultMessage: 'Updated Date',
  },
  oldValue: { id: `${scope}.oldValue`, defaultMessage: 'Old Value' },
  newValue: { id: `${scope}.newValue`, defaultMessage: 'New Value' },
});
