/**
 *
 * BerthDetailSection
 *
 */

import React, { useEffect, useState, createRef } from 'react';
import PropTypes from 'prop-types';
import { Container, Col, Row, Modal, ModalBody } from 'react-bootstrap';
import {
  Popover,
  PopoverBody,
  CustomInput,
  Button,
  Collapse,
  Input,
  Navbar,
} from 'reactstrap';

import { FormattedMessage } from 'react-intl';
import { StickyContainer, Sticky } from 'react-sticky';
import messages from './messages';
import PtbImageCarousel from '../PtbImageCarousel/Loadable';
import {
  formatData,
  CommonSection,
  formatMasterData,
  PreferenceFilter,
  getHeaders,
  filterAuditFeilds,
  formatPtbImages,
  formatPdfData,
} from './_helper';
import berthDetailsIcon from '../../assets/icons/Berth-White.svg';
import BerthFilterIcon from '../../assets/icons/Filter.svg';
import './index.scss';
import PdfExport from '../../utils/pdfExport';
import DataTableList from '../DataTableList/Loadable';
import { scrollToCenter } from '../PortDetailsSection/_helper';
import { dateTimeConversion } from '../../utils/dataModification';

function BerthDetailSection({
  data,
  topVessels,
  rawBerthPreferences,
  dSetBerthPrefrences,
  dSaveBerthPreferences,
  dToggleBerthSectionPopup,
  berthPreferences,
  showBerthPreferencesSection,
  dToggleIsSaveMyPreferenceChecked,
  isSaveMyBerthPreferenceChecked,
  dSetFilteredBerthPreferences,
  dSetBerthImages,
  berthSectionImages,
  dberthCaroselShowList,
  dHandleFileDownload,
}) {
  useEffect(() => {
    if (data.ptbImage && data.ptbImage.length > 0) {
      formatPtbImages(data.ptbImage, dSetBerthImages, dHandleFileDownload);
    }
  }, [data]);

  // Moved to top to return if data and master data is empty
  const [showImage, hanldeShowImage] = useState(false);
  const [collapsed, setCollapsed] = useState(true);
  const toggleNavbar = () => setCollapsed(!collapsed);

  if (
    data === null ||
    data === undefined ||
    Object.keys(data).length === 0 ||
    !Object.hasOwnProperty.call(data, 'masterData')
  ) {
    return <></>;
  }
  const pdfBerthData = [];
  const masterData = formatMasterData(data.masterData);
  const berthData = formatData(data, data.masterData, masterData);
  berthData.lastFiveVesselsCalledAtBerth.data = filterAuditFeilds([
    ...topVessels,
  ]);
  // Pass the Index No.
  const hanldeShowImages = (value, seclectIndexNo) => {
    const obj = {
      berthImageList: berthSectionImages,
      isShow: value,
      seclectIndex: seclectIndexNo,
    };
    dberthCaroselShowList(obj);
  };
  if (berthData.ptbImage) {
    berthData.ptbImage.data = berthSectionImages;
  }
  const jumpMenuItems = [];
  const sections = [];
  let fileName = '';
  let filterCount = 0;
  const jumpRef = [];
  const onPreferenceChange = seletedItem => {
    const myPreferences = { ...berthPreferences };
    if (seletedItem === 'all') {
      Object.keys(myPreferences).forEach(key => {
        myPreferences[key].isChecked = true;
      });
    } else {
      myPreferences[seletedItem.target.getAttribute('data-value')].isChecked =
        seletedItem.target.checked;
    }
    dSetBerthPrefrences(myPreferences);
  };

  const applyPrefrences = () => {
    const myPreferences = [...rawBerthPreferences];
    Object.keys(myPreferences).forEach(key => {
      const item = myPreferences[key];
      myPreferences[key].isVisible =
        berthPreferences[item.ptbSectionId].isChecked;
    });
    if (isSaveMyBerthPreferenceChecked === true) {
      dSaveBerthPreferences(myPreferences);
    }
    dSetFilteredBerthPreferences(myPreferences);
    dToggleBerthSectionPopup(false);
  };

  const downloadDocumentInformation = filename => {
    if (filename !== undefined) {
      const existFileData = data.ptbDocument.filter(x =>
        x.filename.includes(filename),
      );
      if (existFileData.length > 0) {
        let filed = null;
        let filekey = null;
        filed = existFileData[0].filename;
        const filenamesplit = existFileData[0].filename.split('/');
        filekey = existFileData[0].key;
        const name = filenamesplit[filenamesplit.length - 1];
        dHandleFileDownload(filekey, filed, name);
      }
    }
  };

  const userAgent = navigator.userAgent || navigator.vendor || window.opera;
  const isMobile = /iPhone|iPad|iPod|Android/i.test(userAgent);
  if (
    berthData &&
    {}.hasOwnProperty.call(berthData, 'generalParticulars') &&
    {}.hasOwnProperty.call(berthData.generalParticulars, 'data')
  )
    fileName = berthData.generalParticulars.data.berthName;
  Object.keys(berthData).forEach(key => {
    let sectionVisible = true;
    jumpRef[berthData[key].jumpId] = createRef();
    Object.keys(rawBerthPreferences).forEach(bkey => {
      const item = rawBerthPreferences[bkey];
      const prefLable = item.sectionDesc.toLowerCase();
      if (
        prefLable === messages[key].defaultMessage.toLowerCase() &&
        item.isVisible === false
      ) {
        sectionVisible = false;
      }
    });
    if (
      sectionVisible === false &&
      berthData[key].data &&
      berthData[key].data.length !== 0
    ) {
      if (isMobile)
        jumpMenuItems.push(
          <li>
            <Button
              size="sm"
              outline
              color="primary"
              className="mb-2 mr-3"
              disabled
            >
              <FormattedMessage {...messages[key]} />
            </Button>
          </li>,
        );
      else
        jumpMenuItems.push(
          <Button outline color="primary" className="mb-2 mr-3" disabled>
            <FormattedMessage {...messages[key]} />
          </Button>,
        );
    } else if (berthData[key].data && berthData[key].data.length !== 0) {
      filterCount += 1;
      if (isMobile)
        jumpMenuItems.push(
          <li>
            <Button
              outline
              size="sm"
              color="primary"
              className="mb-1 mr-2"
              onClick={() => {
                jumpRef[berthData[key].jumpId].current.scrollIntoView({
                  behavior: 'auto',
                  block: 'center',
                  inline: 'end',
                });
              }}
            >
              <FormattedMessage {...messages[key]} />
            </Button>
          </li>,
        );
      else
        jumpMenuItems.push(
          <>
            <Button
              outline
              size="sm"
              color="primary"
              className="mb-1 mr-2"
              onClick={() => {
                scrollToCenter(berthData[key].jumpId);
              }}
            >
              <FormattedMessage {...messages[key]} />
            </Button>
          </>,
        );
    }
    if (sectionVisible === true) {
      pdfBerthData[key] = berthData[key];
      let commonSec = <></>;
      if (
        (key === 'lastFiveVesselsCalledAtBerth' &&
          berthData[key].data &&
          berthData[key].data.length !== 0) ||
        key === 'changeHistory'
      ) {
        const gridHeader = getHeaders(key);
        commonSec = (
          <Col>
            <DataTableList
              tableHeader={gridHeader}
              tableBody={berthData[key].data}
              rowsPerPage={5}
            />
          </Col>
        );

        if (key.toLowerCase() === 'changehistory') {
          try {
            pdfBerthData[key].data = [
              ...pdfBerthData[key].data.map(i => ({
                createdTimeStamp: dateTimeConversion(i.createdTimeStamp),
                fieldName: i.fieldName,
                oldValue: i.oldValue,
                newValue: i.newValue,
              })),
            ];
          } catch {
            // console.log('Error in change history');
          }
        }
      } else {
        commonSec = (
          <CommonSection
            data={berthData[key].data || {}}
            type={berthData[key].type}
            hanldeShowImage={hanldeShowImages}
            downloadDocumentInformation={downloadDocumentInformation}
          />
        );
      }
      sections.push(
        <>
          {berthData[key].data && berthData[key].data.length !== 0 && (
            <Row
              className="berth_section"
              id={berthData[key].jumpId}
              ref={jumpRef[berthData[key].jumpId]}
            >
              <Col>
                <Row className="port-dashboard-section-header-port pt-1">
                  <Col>
                    <h4 className="mb-0">
                      <FormattedMessage {...messages[key]} />
                    </h4>
                  </Col>
                </Row>
                <Row className="port_overview_row_cls text-justified mb-2 custom-five-colum">
                  {commonSec}
                </Row>
              </Col>
            </Row>
          )}
        </>,
      );
    }
  });
  let quickJumpEl = <></>;
  if (isMobile)
    quickJumpEl = (
      <Navbar color="faded" light onClick={toggleNavbar} className="Arrow_Icon">
        <Input type="text" value="Quick jump" readOnly />
        <Collapse isOpen={!collapsed} navbar className="Port_Navbar_items">
          <ul className="detailSection">{jumpMenuItems}</ul>
        </Collapse>
      </Navbar>
    );
  else quickJumpEl = jumpMenuItems;

  const filterButton = (
    <Button
      color="link"
      size="sm"
      className="mb-1"
      id="preference-popover"
      onClick={() => {
        dToggleBerthSectionPopup(true);
      }}
    >
      <img src={BerthFilterIcon} alt="Berth Filter Icon" className="mr-2" />
      {!isMobile && <FormattedMessage {...messages.filter} />}
      {!isMobile && <span className="ml-1">({filterCount})</span>}
    </Button>
  );

  let filterButtonEl = <></>;
  if (isMobile)
    filterButtonEl = (
      <Row className="mobile-view">
        <Col sm={12} xs={11}>
          {quickJumpEl}
        </Col>
        <Col xs={1}>{filterButton}</Col>
      </Row>
    );
  else
    filterButtonEl = (
      <>
        <Row>
          <Col xs={12}>{quickJumpEl}</Col>
        </Row>
        <Row>
          <Col xs={12} className="text-right external-ptb-berth-filter">
            {filterButton}
          </Col>
        </Row>
      </>
    );

  return (
    <StickyContainer>
      <Container className="inner-container">
        <Row className="port-dashboard-section-header-port">
          <Col xs="2" sm="auto">
            <img src={berthDetailsIcon} alt="Berth Details" />
          </Col>
          <Col xs="10" sm="auto">
            <h4 className="mb-0 page-header">
              <FormattedMessage {...messages.header} />
              <PdfExport
                messages={messages}
                data={formatPdfData(pdfBerthData)}
                fileName={fileName}
              />
            </h4>
          </Col>
        </Row>

        <Row>
          <Col className="pl-0 pr-0">
            <Sticky>
              {({ style, isSticky }) => (
                <Row
                  style={style}
                  className={
                    isSticky
                      ? 'is-sticky no-gutters sticky pt-0'
                      : 'no-gutters sticky pt-0'
                  }
                >
                  <Col xs={12}>
                    <div className="jump_btn_container pb-0 sticky">
                      {filterButtonEl}
                    </div>
                  </Col>
                  <Popover
                    placement="bottom"
                    isOpen={showBerthPreferencesSection}
                    target="preference-popover"
                    trigger="legacy"
                    delay={0}
                    className="preference-filter-popover"
                  >
                    <PopoverBody className="p-0">
                      <Row>
                        <Col className="px-4 pt-3 pb-0">
                          <h4 className="mb-0">
                            <FormattedMessage {...messages.chooseSections} />
                            <i
                              className="fa fa-times float-right color-primary"
                              aria-hidden="true"
                              onClick={() => dToggleBerthSectionPopup(false)}
                            />
                          </h4>
                        </Col>
                      </Row>
                      <Row className="no-gutters">
                        <Col>
                          <hr className="margin-custom-gutters" />
                        </Col>
                      </Row>
                      <Row>
                        <PreferenceFilter
                          data={berthPreferences}
                          dPreferenceChange={onPreferenceChange}
                          berthData={berthData}
                        />
                      </Row>
                      <Row className="p-2">
                        <Col />
                        <Col>
                          <CustomInput
                            className="float-right"
                            type="checkbox"
                            label="Save Preferences"
                            id="save_preferences"
                            checked={isSaveMyBerthPreferenceChecked}
                            onClick={() =>
                              dToggleIsSaveMyPreferenceChecked(
                                !isSaveMyBerthPreferenceChecked,
                              )
                            }
                          />
                        </Col>
                        <Col>
                          <Button
                            color="primary"
                            onClick={applyPrefrences}
                            size="sm"
                          >
                            Apply
                          </Button>
                        </Col>
                        <Col />
                      </Row>
                    </PopoverBody>
                  </Popover>
                </Row>
              )}
            </Sticky>
          </Col>
        </Row>

        {sections}
        {showImage && (
          <Modal
            isOpen={showImage}
            toggle={() => hanldeShowImage(false)}
            className="custom-modal-claims modal-lg"
          >
            <ModalBody className="text-center">
              <PtbImageCarousel
                imageList={berthSectionImages}
                isMapImage={false}
                seclectIndex={0}
                isBerthView
              />
            </ModalBody>
          </Modal>
        )}
      </Container>
    </StickyContainer>
  );
}

BerthDetailSection.propTypes = {
  data: PropTypes.oneOfType([PropTypes.array, PropTypes.object]).isRequired,
  topVessels: PropTypes.oneOfType([PropTypes.array, PropTypes.object])
    .isRequired,
  dFetchPortCauroselImages: PropTypes.func.isRequired,
  dSetBerthPrefrences: PropTypes.func,
  dSaveBerthPreferences: PropTypes.func,
  dToggleBerthSectionPopup: PropTypes.func,
  berthPreferences: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  showBerthPreferencesSection: PropTypes.bool,
  rawBerthPreferences: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  dToggleIsSaveMyPreferenceChecked: PropTypes.func,
  isSaveMyBerthPreferenceChecked: PropTypes.bool,
  dSetFilteredBerthPreferences: PropTypes.func,
  dSetBerthImages: PropTypes.func,
  berthSectionImages: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  dberthCaroselShowList: PropTypes.func,
  dHandleFileDownload: PropTypes.func,
};

export default BerthDetailSection;
