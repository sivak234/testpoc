// // import { defaultFunction } from '../_helper';

// describe('BerthDetailSection helpers', () => {
//   describe('Default Helper Function', () => {
//     it('returns the expected value', () => {
//       const expected = 'Sample Text';
//       expect('Sample Text').toEqual(expected);
//     });
//   });
// });

describe('<BerthDetailSection />', () => {
  it('Expect to not log errors in BerthDetailSection', () => {
    expect(true).toBeTruthy();
  });
});
