/*
 * AisLandingVesselList Messages
 *
 * This contains all the text for the AisLandingVesselList component.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.components.AisLandingVesselList';

export default defineMessages({
  header: {
    id: `${scope}.header`,
    defaultMessage: 'Vessel List',
  },
  showing: {
    id: `${scope}.showing`,
    defaultMessage: 'showing',
  },
});
