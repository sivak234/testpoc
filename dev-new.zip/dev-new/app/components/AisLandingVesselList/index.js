/**
 *
 * AisLandingVesselList
 *
 */

import React, { memo } from 'react';
import PropTypes from 'prop-types';
import { Button, Col, Row, UncontrolledTooltip } from 'reactstrap';
import { FormattedMessage } from 'react-intl';
import messages from './messages';
import DataTableList from '../DataTableList/Loadable';
import { FETCH_RECORD_COUNT } from '../../utils/constants';
function AisLandingVesselList({
  moduleId,
  vesselList,
  vesselDetails,
  fetchAisVesselDetails,
  fetchAisVesselVoyageDetails,
  fetchAisVesselData,
  fetchVesselList,
  totalRecords,
  fetchselectedImoData,
  fetchNearestRangeVesselsByImo,
  portDetails,
  fetchPortDetails,
  fetchPortStatisticDetails,
  fetchVesselData,
  fetchPortMoveMapData,
  fetchTerminalCodeNames,
}) {
  const clicked = e => {
    vesselDetails(e.currentTarget.innerText);
    fetchAisVesselDetails(e.currentTarget.innerText);
    fetchAisVesselVoyageDetails(e.currentTarget.innerText);
    const options = {
      imo: e.currentTarget.innerText,
      pageNo: 0,
      fetchRecordCount: FETCH_RECORD_COUNT,
    };
    fetchAisVesselData(options);
    fetchselectedImoData(e.currentTarget.innerText);
    fetchNearestRangeVesselsByImo(e.currentTarget.innerText);
  };

  const handlePort = selectPortId => {
    portDetails(selectPortId);
    fetchPortDetails(selectPortId);
    fetchPortStatisticDetails(selectPortId);
    const options = {
      portId: selectPortId,
      pageNo: 0,
      fetchRecordCount: FETCH_RECORD_COUNT,
    };
    fetchVesselData(options);
    fetchPortMoveMapData(selectPortId);
    fetchTerminalCodeNames({
      portId: selectPortId,
      type: 'portMovement',
    });
  };
  const handleFieldSize = value => {
    const res = value ? value.substring(0, 15) : '';
    return res;
  };
  let body = [];
  const name = 'Vessel Listerer';
  const header = [
    {
      title: 'Vessel IMO',
      prop: 'imo',
      cell: row => (
        <Button className="no-padd" color="link" onClick={e => clicked(e)}>
          {row.imo}
        </Button>
      ),
      editable: false,
    },
    {
      title: 'Vessel Name',
      prop: 'vesselName',
      editable: false,
    },
    {
      title: 'Vessel Type',
      prop: 'vesselType',
      editable: false,
    },
    {
      title: 'Condition',
      prop: 'vesselLoadCondition',
      editable: false,
    },
    {
      title: 'Next Port',
      prop: 'nextport',
      cell: row => (
        <div>
          <p>
            <span href="#" id={`nextport_${row.srNo}`}>
              {handleFieldSize(row.nextport)}
            </span>
          </p>
          <UncontrolledTooltip placement="top" target={`nextport_${row.srNo}`}>
            {row.nextport}
          </UncontrolledTooltip>
        </div>
      ),
      editable: false,
    },
    {
      title: 'Current Port',
      prop: 'tempPortName',
      cell: row => (
        <div>
          <UncontrolledTooltip
            placement="top"
            target={`tempPortName${row.srNo}`}
          >
            {row.tempPortName}
          </UncontrolledTooltip>
          <Button
            id={`tempPortName${row.srNo}`}
            className="no-padd"
            color="link"
            onClick={() => handlePort(row.tempPortId)}
          >
            {handleFieldSize(row.tempPortName)}
          </Button>
        </div>
      ),
      editable: false,
    },
    {
      title: 'ETA',
      prop: 'nextPorteta',
      editable: false,
    },
  ];

  if (
    vesselList !== undefined &&
    vesselList.length > 0 &&
    vesselList !== null
  ) {
    body = vesselList.map((vesselObj, index) => ({
      srNo: index + 1,
      imo: vesselObj.imo,
      vesselName: vesselObj.vesselName,
      vesselType: vesselObj.vesselType,
      country: vesselObj.vesselDimensionA,
      vesselLoadCondition: vesselObj.vesselLoadCondition,
      nextport: vesselObj.nextPortName,
      nextPortId: vesselObj.nextPortId,
      nextPorteta: vesselObj.nextPorteta,
      tempPortId: vesselObj.tempPortId,
      tempPortName: vesselObj.tempPortName,
    }));
  }
  return (
    <div>
      <>
        <Row className="ais-management-container-search-header mb-3">
          <Col>
            <h4 className="mb-0">
              <FormattedMessage {...messages.header} />: ({totalRecords})
            </h4>
          </Col>
        </Row>
        <Row>
          <Col>
            <DataTableList
              moduleId={moduleId}
              tableHeader={header}
              tableBody={body}
              tableName={name}
              fetchTableData={fetchVesselList}
              totalRecords={totalRecords}
              isCustom
            />
          </Col>
        </Row>
      </>
    </div>
  );
}

AisLandingVesselList.propTypes = {
  moduleId: PropTypes.number.isRequired,
  vesselList: PropTypes.array.isRequired,
  vesselDetails: PropTypes.func.isRequired,
  fetchAisVesselDetails: PropTypes.func.isRequired,
  fetchAisVesselVoyageDetails: PropTypes.func.isRequired,
  fetchAisVesselData: PropTypes.func.isRequired,
  fetchVesselList: PropTypes.func.isRequired,
  totalRecords: PropTypes.number.isRequired,
  fetchselectedImoData: PropTypes.func,
  fetchNearestRangeVesselsByImo: PropTypes.func,
  fetchPortStatisticDetails: PropTypes.func,
  portDetails: PropTypes.func,
  fetchPortDetails: PropTypes.func,
  fetchVesselData: PropTypes.func,
  fetchPortMoveMapData: PropTypes.func,
  fetchTerminalCodeNames: PropTypes.func,
};

export default memo(AisLandingVesselList);
