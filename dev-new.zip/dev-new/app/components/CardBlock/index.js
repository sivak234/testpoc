/**
 *
 * CardBlock
 *
 */

import React, { memo } from 'react';
import PropTypes from 'prop-types';
import { Card } from 'reactstrap';

function CardBlock({ children }) {
  return <Card>{children}</Card>;
}

CardBlock.propTypes = {
  children: PropTypes.node.isRequired,
};

export default memo(CardBlock);
