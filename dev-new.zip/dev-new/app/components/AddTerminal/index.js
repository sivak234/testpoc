/**
 *
 * AddTerminal
 *
 */

import React from 'react';
import PropTypes from 'prop-types';
import {
  Container,
  Row,
  Col,
  Button,
  Modal,
  ModalHeader,
  ModalBody,
  Label,
} from 'reactstrap';

import { filteredAccess } from '../../utils/rbac';
import PtbImport from '../PtbImport/Loadable';
import Popup from '../Popup/Loadable';
import TerminalAddViewUpdate from '../TerminalAddViewUpdate/Loadable';
import { buttons } from './_helper';

function AddTerminal({
  moduleId,
  isLoading,
  metaData,
  berthMetaData,
  isTerminalAddOpen,
  terminalData,
  terminalValidationStatus,
  handleModalOpen,
  handleModalClose,
  handleTerminalInputChange,
  validateTerminalData,
  validateTerminalDataPublish,
  onFileChangeHandler,
  ptbImage,
  updateImageData,
  uploadStatus,
  dPortImagesData,
  dHandleFileUpload,
  dHandleFileDownload,
  ptbDocumentsList,
  dPtbDocumentsData,
  updateDocumentData,
  onFilterValueSelected,
  dterminalUpdateImagesData,
  dshowModel,
  importPtb,
  dshandleImportChanged,
  getbtpLogResults,
  logResult,
  islogResult,
  totalRecords,
  regionList,
  countryList,
  portsList,
  dGetPortsList,
  getGeoFencingData,
  finalGeoFenceData,
  selectedGeoFenceData,
  portViewData,
  moduleType,
  formType,
  dAddDryBulkItem,
  dDeleteDryBulkChange,
  dHandleDryBulkChange,

  // Terminal Bunker
  dHandleCargoTypeChange,
  dUpdateTerminalDataCargoHandled,
  dDeleteTerminalDataCargoHandled,
  terminalptbDocument,
  terminalMasterData,
  dterminalDocumentsData,
  dvalidatedocumnet,
  dsetDocumentName,
  dsetDocumentType,
  dvalidatedfileuploaddocument,
  terminalselecteddocument,
  dHandleUpdateTerminalInputChange,
  dgetAllPortsDataForMapByCountryId,
  terminalIssTransfer,
  dhandleYssTransferCheck,
  dGetCountryList,
  typeAheadDropdown,
  geoSelectedPortId,
  dGetUserDetails,
  isTerminalNotClientSelected,
  dgetAllPortsDataForMapByPortId,
  linkedWithLegacy,
  ptbStatus,
  isMapRefresh,
  isNotPublishedPTB,
  dsetNewLatLong,
  ptbMapCoordinates,
  dlocateLatLong,
  ptbSelectedCoordinates,
  isLocateClicked,
  dDisableLocate,
  isInValidLatLng,
  dcloseLocateDialog,
}) {
  const isOrVisible =
    filteredAccess(moduleId, 'add') && filteredAccess(moduleId, 'publish');
  return (
    <>
      <Container>
        <Row>
          <Col>
            {(filteredAccess(moduleId, 'add') ||
              filteredAccess(moduleId, 'publish')) && (
              <h4 className="mt-3">Add Terminal</h4>
            )}
          </Col>

          <Col xs="auto" className="align-self-center">
            {filteredAccess(moduleId, 'publish') && (
              <Button
                color="link"
                onClick={() => dshowModel({ show: true, showOn: 'Terminal' })}
              >
                Import
              </Button>
            )}
            {isOrVisible && <Label className="mr-3 ml-1"> OR </Label>}

            {filteredAccess(moduleId, 'add') && (
              <Button color="primary" onClick={handleModalOpen}>
                <i className="fa fa-plus mr-1" /> Add Terminal
              </Button>
            )}
          </Col>
        </Row>
      </Container>

      {(filteredAccess(moduleId, 'add') ||
        filteredAccess(moduleId, 'publish')) && <hr />}
      <Popup
        size="xl"
        show={isTerminalAddOpen}
        close={handleModalClose}
        title="Add Terminal"
        className="ptbModal_form"
        buttons={buttons(
          validateTerminalData,
          validateTerminalDataPublish,
          handleModalClose,
          terminalData,
          12,
        )}
        center={false}
        keyboard={false}
      >
        <TerminalAddViewUpdate
          metaData={metaData}
          berthMetaData={berthMetaData}
          data={terminalData}
          terminalValidationStatus={terminalValidationStatus}
          handleTerminalInputChange={handleTerminalInputChange}
          onFileChangeHandler={e => onFileChangeHandler(e, ptbImage)}
          ptbImage={ptbImage}
          updateImageData={updateImageData}
          uploadStatus={uploadStatus}
          dPortImagesData={dPortImagesData}
          dHandleFileUpload={dHandleFileUpload}
          dHandleFileDownload={dHandleFileDownload}
          ptbDocumentsList={ptbDocumentsList}
          dPtbDocumentsData={dPtbDocumentsData}
          updateDocumentData={updateDocumentData}
          onFilterValueSelected={onFilterValueSelected}
          regionList={regionList}
          countryList={countryList}
          portsList={portsList}
          dGetPortsList={dGetPortsList}
          dterminalUpdateImagesData={dterminalUpdateImagesData}
          getGeoFencingData={getGeoFencingData}
          finalGeoFenceData={finalGeoFenceData}
          selectedGeoFenceData={selectedGeoFenceData}
          portViewData={portViewData}
          moduleType={moduleType}
          formType={formType}
          dAddDryBulkItem={dAddDryBulkItem}
          dGetUserDetails={dGetUserDetails}
          dDeleteDryBulkChange={dDeleteDryBulkChange}
          dHandleDryBulkChange={dHandleDryBulkChange}
          dHandleCargoTypeChange={dHandleCargoTypeChange}
          dUpdateTerminalDataCargoHandled={dUpdateTerminalDataCargoHandled}
          dDeleteTerminalDataCargoHandled={dDeleteTerminalDataCargoHandled}
          terminalptbDocument={terminalptbDocument}
          terminalMasterData={terminalMasterData}
          dterminalDocumentsData={dterminalDocumentsData}
          dvalidatedocumnet={dvalidatedocumnet}
          dsetDocumentName={dsetDocumentName}
          dsetDocumentType={dsetDocumentType}
          dvalidatedfileuploaddocument={dvalidatedfileuploaddocument}
          terminalselecteddocument={terminalselecteddocument}
          dHandleUpdateTerminalInputChange={dHandleUpdateTerminalInputChange}
          dgetAllPortsDataForMapByCountryId={dgetAllPortsDataForMapByCountryId}
          terminalIssTransfer={terminalIssTransfer}
          dhandleYssTransferCheck={dhandleYssTransferCheck}
          dGetCountryList={dGetCountryList}
          typeAheadDropdown={typeAheadDropdown}
          geoSelectedPortId={geoSelectedPortId}
          isLoading={isLoading}
          isTerminalNotClientSelected={isTerminalNotClientSelected}
          dgetAllPortsDataForMapByPortId={dgetAllPortsDataForMapByPortId}
          linkedWithLegacy={linkedWithLegacy}
          ptbStatus={ptbStatus}
          isMapRefresh={isMapRefresh}
          isNotPublishedPTB={isNotPublishedPTB}
          dsetNewLatLong={dsetNewLatLong}
          ptbMapCoordinates={ptbMapCoordinates}
          dlocateLatLong={dlocateLatLong}
          ptbSelectedCoordinates={ptbSelectedCoordinates}
          isLocateClicked={isLocateClicked}
          dDisableLocate={dDisableLocate}
          isInValidLatLng={isInValidLatLng}
          dcloseLocateDialog={dcloseLocateDialog}
        />
      </Popup>
      {importPtb.btpType === 'Terminal' ? (
        <Modal
          isOpen={importPtb.isShowModel}
          toggle={() => dshowModel({ show: false, showOn: 'Port' })}
          className="custom-modal-claims"
        >
          <ModalHeader
            className="modelheader"
            toggle={() => dshowModel({ show: false, showOn: 'Port' })}
          >
            {importPtb.btpType} {''} Import
          </ModalHeader>
          <ModalBody>
            <PtbImport
              importPtb={importPtb}
              dshandleImportChanged={dshandleImportChanged}
              getbtpLogResults={getbtpLogResults}
              logResult={logResult}
              islogResult={islogResult}
              btpName={importPtb.btpType}
              totalRecords={totalRecords}
            />
          </ModalBody>
        </Modal>
      ) : (
        ''
      )}
    </>
  );
}

AddTerminal.propTypes = {
  moduleId: PropTypes.number,
  isLoading: PropTypes.bool,
  metaData: PropTypes.object,
  berthMetaData: PropTypes.object,
  isTerminalAddOpen: PropTypes.bool,
  terminalData: PropTypes.object,
  terminalValidationStatus: PropTypes.object,
  handleModalOpen: PropTypes.func,
  handleModalClose: PropTypes.func,
  handleTerminalInputChange: PropTypes.func,
  validateTerminalData: PropTypes.func,
  validateTerminalDataPublish: PropTypes.func,
  onFileChangeHandler: PropTypes.func,
  ptbImage: PropTypes.array,
  updateImageData: PropTypes.func,
  uploadStatus: PropTypes.string,
  dPortImagesData: PropTypes.func,
  dHandleFileUpload: PropTypes.func,
  dHandleFileDownload: PropTypes.func,
  ptbDocumentsList: PropTypes.array,
  dPtbDocumentsData: PropTypes.func,
  updateDocumentData: PropTypes.func,
  onFilterValueSelected: PropTypes.func,
  dterminalUpdateImagesData: PropTypes.func,
  dshowModel: PropTypes.func,
  importPtb: PropTypes.object,
  dshandleImportChanged: PropTypes.func,
  getbtpLogResults: PropTypes.func,
  logResult: PropTypes.array,
  islogResult: PropTypes.bool,
  totalRecords: PropTypes.number,
  countryList: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  regionList: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  portsList: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  dGetPortsList: PropTypes.func,
  getGeoFencingData: PropTypes.func,
  finalGeoFenceData: PropTypes.object,
  selectedGeoFenceData: PropTypes.object,
  portViewData: PropTypes.object,
  moduleType: PropTypes.string,
  formType: PropTypes.string,
  dAddDryBulkItem: PropTypes.func,
  dDeleteDryBulkChange: PropTypes.func,
  dHandleDryBulkChange: PropTypes.func,

  // terminal bunker
  dHandleCargoTypeChange: PropTypes.func,
  dUpdateTerminalDataCargoHandled: PropTypes.func,
  dDeleteTerminalDataCargoHandled: PropTypes.func,
  terminalptbDocument: PropTypes.array,
  terminalMasterData: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  dterminalDocumentsData: PropTypes.func,
  dvalidatedocumnet: PropTypes.func,
  dsetDocumentName: PropTypes.func,
  dsetDocumentType: PropTypes.func,
  dvalidatedfileuploaddocument: PropTypes.func,
  terminalselecteddocument: PropTypes.array,
  dHandleUpdateTerminalInputChange: PropTypes.func,
  dgetAllPortsDataForMapByCountryId: PropTypes.func,
  terminalIssTransfer: PropTypes.bool,
  dhandleYssTransferCheck: PropTypes.func,
  dGetCountryList: PropTypes.func,
  typeAheadDropdown: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  geoSelectedPortId: PropTypes.string,
  dGetUserDetails: PropTypes.func,
  isTerminalNotClientSelected: PropTypes.bool,
  dgetAllPortsDataForMapByPortId: PropTypes.func,
  linkedWithLegacy: PropTypes.object,
  ptbStatus: PropTypes.object,
  isMapRefresh: PropTypes.bool,
  isNotPublishedPTB: PropTypes.bool,
  dsetNewLatLong: PropTypes.func,
  dlocateLatLong: PropTypes.func,
  ptbMapCoordinates: PropTypes.object,
  ptbSelectedCoordinates: PropTypes.object,
  isLocateClicked: PropTypes.bool,
  dDisableLocate: PropTypes.func,
  isInValidLatLng: PropTypes.bool,
  dcloseLocateDialog: PropTypes.func,
};

export default AddTerminal;
