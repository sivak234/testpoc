/*
 *
 * AddTerminal helper
 *
 */

import { filteredAccess } from '../../utils/rbac';

export function buttons(save, publish, close, terminalData, moduleId) {
  const publishArray = [
    {
      title: 'Add Terminal',
      action: () => save(),
    },
    {
      title: 'Add and Publish',
      action: () => publish(),
    },
    {
      title: 'Cancel',
      action: close,
      id: 'btncancelid',
    },
  ];
  const createLegacyArray = [
    {
      title: 'Add and Publish',
      action: () => publish(),
    },
    {
      title: 'Cancel',
      action: close,
      id: 'btncancelid',
    },
  ];
  const addArray = [
    {
      title: 'Add Terminal',
      action: () => save(),
    },
    {
      title: 'Cancel',
      action: close,
      id: 'btncancelid',
    },
  ];
  const noneArray = [
    {
      title: 'Cancel',
      action: close,
      id: 'btncancelid',
    },
  ];
  if (terminalData.terminalTypeId) {
    if (filteredAccess(moduleId, 'publish')) {
      return !terminalData.createInLegacy ? publishArray : createLegacyArray;
    }
    if (filteredAccess(moduleId, 'add')) {
      return addArray;
    }
  }
  return noneArray;
}
