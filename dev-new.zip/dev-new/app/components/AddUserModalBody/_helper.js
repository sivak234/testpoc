// eslint-disable-next-line consistent-return
export function buttons(
  testing,
  editUserFlag,
  submitAddUserData,
  triggerUpdateUserButton,
  addUserModalClose,
  type,
) {
  let title;
  let action;
  if (type !== 'View') {
    if (!editUserFlag) {
      title = 'Add User';
      action = submitAddUserData;
    } else {
      title = 'Save';
      action = triggerUpdateUserButton;
    }
    if (!testing.length) {
      return [
        {
          title,
          action: e => action(e),
        },
        {
          title: 'Cancel',
          action: e => addUserModalClose(e),
          id: 'btncancelid',
        },
      ];
    }
  }
}
