/* eslint-disable no-useless-escape */
/* eslint-disable indent */
/**
 *
 * AddUserModalBody
 *
 */

import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { compose } from 'redux';
import moment from 'moment';
import {
  Button,
  Form,
  Label,
  Input,
  CustomInput,
  Row,
  Col,
  FormGroup,
} from 'reactstrap';
import { createStructuredSelector } from 'reselect';
import { FormattedMessage } from 'react-intl';
import messages from './messages';
import Popup from '../Popup/Loadable';
import LoadingIndicator from '../LoadingIndicator';
import { userNameCharCheck } from '../../utils/dataValidation';
import './index.scss';
import {
  makeSelectRoles,
  makeSelectCountries,
  makeSelectPorts,
  makeSelectRegionCountryPortArr,
  makeSelectRoleMasterList,
  makeSelectfocusField,
} from '../../containers/UserRoleManagement/selectors';

import Dropdown from '../Dropdown';
import AssignRoles from '../AssignRole/Loadable';
import { buttons } from './_helper';
import { getValuesByIdAndByType } from '../../utils/dataModification';
import {
  userNameValidationRegex,
  emailValidationRegex,
  mobileValidation,
} from '../../utils/validation';

function AddUserModalBody({
  show,
  addUserModalClose,
  selected,
  onRegionSelect,
  onCountrySelect,
  regionCountryPortAPi,
  regions,
  countries,
  roleNames,
  fetchFromDate,
  fetchToDate,
  addUserData,
  fChangeaddUserDataValue,
  viewUserData,
  editUserFlag,
  handleUserUpdateButton,
  onPortSelect,
  onRoleSelect,
  onComponentAdd,
  onComponentRemove,
  type,
  checkUserNameExist,
  userNameExistFlag,
  isLoading,
  hasError,
  error,
  regionCountryPortArr,
  roleMasterList,
  focusField,
}) {
  const [isValid, handleValid] = useState(false);
  const isADUser = selected.isAdUser || false;
  const passwordValidation = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[^\w\s]).{8,}$/;
  function region1Select(event) {
    onRegionSelect(event.target.value, 0, event.target.selectedOptions[0].text);
  }
  function region2Select(id, value, count) {
    onRegionSelect(id, count, value);
  }
  const handleChange = (field, Val) => {
    if (field === 'phoneNumber') {
      const updatedVal = Val.replace(mobileValidation, '');
      fChangeaddUserDataValue(field, updatedVal);
    } else if (
      field === 'city' ||
      field === 'organization' ||
      field === 'firstName' ||
      field === 'lastName' ||
      field === 'postalCode'
    ) {
      if (!Val.match(/[^a-zA-Z0-9 ]/g)) {
        const updatedVal = Val.replace(/[^a-zA-Z0-9 ]/g, '');
        fChangeaddUserDataValue(field, updatedVal);
      }
    } else if (field === 'address1' || field === 'address2') {
      fChangeaddUserDataValue(field, Val);
    } else if (field === 'username') {
      const updatedVal = Val.replace(/[<>=]/g, '');
      fChangeaddUserDataValue(field, updatedVal);
    } else {
      fChangeaddUserDataValue(field, Val);
    }
  };
  function country1Select(event) {
    onCountrySelect(
      event.target.value,
      0,
      event.target.selectedOptions[0].text,
      event.target.selectedOptions[0].id,
    );

    regionCountryPortAPi();
  }
  function country2Select(id, value, count) {
    onCountrySelect(id, count, value);
  }

  function roleSelect(id, name, count) {
    onRoleSelect(id, name, count);
  }

  const testing = viewUserData;

  const triggerUpdateUserButton = event => {
    let dateValid = false;
    const dateSelect = [];
    if (selected) {
      selected.assignedRole.forEach(item => {
        const d1 = moment(item.fDate).format('MM/DD/YYYY');
        const d2 = moment(item.tDate).format('MM/DD/YYYY');
        const dt1 = new Date(d1);
        const dt2 = new Date(d2);
        if (dt1 !== undefined && dt2 !== undefined && dt1 > dt2) {
          dateSelect.push(item);
        }
      });
    }
    if (dateSelect.length > 0) {
      handleValid(true);
      dateValid = true;
    } else {
      handleValid(false);
    }
    if (!dateValid) {
      handleUserUpdateButton(event);
    }
  };
  const triggerAddUserButton = event => {
    let dateValid = false;
    const dateSelect = [];
    if (selected) {
      selected.assignedRole.forEach(item => {
        const d1 = moment(item.fDate).format('MM/DD/YYYY');
        const d2 = moment(item.tDate).format('MM/DD/YYYY');
        const dt1 = new Date(d1);
        const dt2 = new Date(d2);
        if (dt1 !== undefined && dt2 !== undefined && dt1 > dt2) {
          dateSelect.push(item);
        }
      });
    }
    if (dateSelect.length > 0) {
      handleValid(true);
      dateValid = true;
    } else {
      handleValid(false);
    }
    if (!dateValid) {
      addUserData(event);
    }
  };
  const minDate = new Date(Date.now());

  function port1Select(id, value, count) {
    onPortSelect(id, count, value);
  }

  const regionCheckBoxTriggered = (
    regionSelectedId,
    regionCheckVals,
    selectindex,
  ) => {
    region2Select(regionSelectedId, regionCheckVals, selectindex);
  };
  const countryCheckBoxTriggered = (
    countrySelectedId,
    countryCheckVals,
    selectindex,
  ) => {
    country2Select(countrySelectedId, countryCheckVals, selectindex);
  };
  const portCheckBoxTriggered = (portSelectedId, portCheckVals, countkey) => {
    port1Select(portSelectedId, portCheckVals, countkey);
  };
  const fetchFromDate1 = (e, countkey) => {
    fetchFromDate(e, countkey);
    handleValid(false);
  };

  const fetchToDate1 = (date, countkey) => {
    fetchToDate(date, countkey);
    handleValid(false);
  };

  const roleSelect1 = event => {
    handleValid(false);
    const currentDate = new Date();
    const dateandId = event.evt.target.value.split('-');
    const dateVal = dateandId[1];
    const year = dateVal && dateVal.substring(0, 2);
    const month = dateVal && dateVal.substring(2, 4);
    const datecalc = dateVal && dateVal.substring(4, 6);
    const yearcalc = parseInt(year, 10) * 365;
    const monthcalc = parseInt(month, 10) * 30;
    const totalcalc = yearcalc + monthcalc + parseInt(datecalc, 10);
    currentDate.setDate(currentDate.getDate() + totalcalc);
    const valDate = currentDate;
    const countkey = event.count;
    roleSelect(event.evt.target.value, event.evt.target.name, countkey);
    fetchFromDate(new Date(), countkey);
    fetchToDate(event.evt.target.value !== '' ? valDate : new Date(), countkey);
  };

  let isAddTriggerd = true;

  const componentAddTrigger = () => {
    const count = selected.addCmpArr.length + 1;
    onComponentAdd(count);
    isAddTriggerd = false;
  };

  const componentRemoveTrigger = selectindex => {
    if (type === 'Add') {
      const selectedData = selected.assignedRole;
      const remList = selectedData.map((item, index) => {
        if (index !== selectindex) {
          return item;
        }
        return null;
      });
      const filterData = remList.filter(item => item !== null);
      const removeCmp = {
        assignedRole: filterData,
        type,
      };
      onComponentRemove(removeCmp);
    }
    if (type === 'Update') {
      let removeCmp;
      const selectData = selected.assignedRole.map((item, index) =>
        index === selectindex ? item : null,
      );
      const filterDatas = selectData.filter(item => item !== null);
      if (filterDatas.length > 0 && filterDatas[0].userRoleId !== 0) {
        removeCmp = {
          selectindex,
          type,
          userRoleId: filterDatas[0].userRoleId,
        };
      } else {
        const seldata = selected.assignedRole;
        const remLists = seldata.map((item, index) => {
          if (index !== selectindex) {
            return item;
          }
          return null;
        });
        const filtData = remLists.filter(item => item !== null);
        removeCmp = {
          assignedRole: filtData,
          type: 'UpdateRemove',
        };
      }
      onComponentRemove(removeCmp);
    }
  };

  const userNameExist = userName => {
    if (userName) {
      checkUserNameExist(userName);
    }
  };
  const getRoleNameById = id => {
    if (roleMasterList && roleMasterList.length > 0) {
      const selectedRole = roleMasterList.filter(ele => ele.roleId === id);
      if (selectedRole && selectedRole.length > 0) {
        return selectedRole[0].roleName;
      }
    }
    return '';
  };

  const assignRole = selected.assignedRole.filter(x => x.isDelete === false);
  if (selected.validationFlag) {
    const selectField = document.getElementById(focusField);
    if (selectField) selectField.focus();
  }

  return (
    <>
      <Popup
        size="xl"
        show={show}
        close={() => addUserModalClose({ value: false })}
        title={`${type} User`}
        center={false}
        buttons={buttons(
          testing,
          editUserFlag,
          triggerAddUserButton,
          triggerUpdateUserButton,
          addUserModalClose,
          type,
        )}
      >
        <Form className="userValidation">
          <Row>
            <Col xs={2} md>
              <FormGroup>
                <Label
                  className={type === 'View' ? 'mandate viewLbl' : 'mandate'}
                >
                  <FormattedMessage {...messages.addUsrPopupUsrName} />
                </Label>
                <br />
                {type === 'View' && testing && (
                  <Label>{testing.userName}</Label>
                )}
                {type !== 'View' && (
                  <Input
                    type="text"
                    id="username"
                    name="username"
                    maxLength="100"
                    onChange={event => {
                      const { value } = event.target;
                      if (userNameCharCheck(value)) {
                        handleChange('username', value);
                      }
                    }}
                    onBlur={e => {
                      userNameExist(e.target.value);
                    }}
                    autoComplete="new-password"
                    value={selected.username}
                    disabled={editUserFlag}
                  />
                )}
                {type !== 'View' &&
                  selected.username.trim() === '' &&
                  selected.validationFlag && (
                    <p className="validation-content">
                      <FormattedMessage {...messages.userNameRequiredMsg} />
                    </p>
                  )}
                {type !== 'View' &&
                  selected.username.trim() !== '' &&
                  selected.error === 'User Name already exist' &&
                  selected.validationFlag && (
                    <p className="validation-content">
                      <FormattedMessage {...messages.userExistMsg} />
                    </p>
                  )}
                {type !== 'View' &&
                  selected.username !== '' &&
                  !selected.username.match(userNameValidationRegex) &&
                  selected.validationFlag && (
                    <p className="validation-content">
                      <FormattedMessage
                        {...messages.userNameRequiredMsgValid}
                      />
                    </p>
                  )}
                {userNameExistFlag && (
                  <p className="validation-content">
                    <FormattedMessage {...messages.userExistMsg} />
                  </p>
                )}
              </FormGroup>
            </Col>
            <Col xs={2} md>
              <FormGroup>
                <Label
                  className={type === 'View' ? 'mandate viewLbl' : 'mandate'}
                >
                  <FormattedMessage {...messages.addUsrPopupFname} />
                </Label>
                <br />
                {type === 'View' && testing && testing.userProfile && (
                  <Label>{testing.userProfile.firstName}</Label>
                )}
                {type !== 'View' && (
                  <Input
                    type="text"
                    id="firstName"
                    name="firstName"
                    maxLength="100"
                    onChange={e => {
                      handleChange('firstName', e.target.value);
                    }}
                    value={selected.firstName}
                    disabled={isADUser}
                  />
                )}
                {type !== 'View' &&
                  selected.firstName === '' &&
                  selected.validationFlag && (
                    <p className="validation-content">
                      <FormattedMessage
                        {...messages.userFirstNameRequiredMsg}
                      />
                    </p>
                  )}
              </FormGroup>
            </Col>
            <Col xs={2} md>
              <FormGroup>
                <Label
                  className={type === 'View' ? 'mandate viewLbl' : 'mandate'}
                >
                  <FormattedMessage {...messages.addUsrPopupLname} />
                </Label>
                <br />
                {type === 'View' && testing.userProfile && (
                  <Label>{testing.userProfile.lastName}</Label>
                )}
                {type !== 'View' && (
                  <Input
                    type="text"
                    id="lastName"
                    name="lastName"
                    maxLength="100"
                    onChange={e => {
                      handleChange('lastName', e.target.value);
                    }}
                    value={selected.lastName}
                    disabled={isADUser}
                  />
                )}
                {type !== 'View' &&
                  selected.lastName === '' &&
                  selected.validationFlag && (
                    <p className="validation-content">
                      <FormattedMessage {...messages.userLastNameRequiredMsg} />
                    </p>
                  )}
              </FormGroup>
            </Col>
            <Col xs={2} md>
              <FormGroup>
                <Label
                  className={
                    // eslint-disable-next-line no-nested-ternary
                    isADUser
                      ? ''
                      : type === 'View'
                      ? 'mandate viewLbl'
                      : 'mandate'
                  }
                >
                  <FormattedMessage {...messages.addUsrPopupAddr1} />
                </Label>
                <br />
                {type === 'View' && testing.userProfile && (
                  <Label>{testing.userProfile.address1}</Label>
                )}
                {type !== 'View' && (
                  <Input
                    type="text"
                    id="address1"
                    name="address1"
                    maxLength="255"
                    onChange={e => {
                      handleChange('address1', e.target.value);
                    }}
                    value={selected.address1}
                    disabled={isADUser}
                  />
                )}
                {type !== 'View' &&
                  (!isADUser && selected.address1 === '') &&
                  selected.validationFlag && (
                    <p className="validation-content">
                      <FormattedMessage {...messages.userAddressRequiredMsg} />
                    </p>
                  )}
              </FormGroup>
            </Col>
            <Col xs={2} md>
              <FormGroup>
                <Label className={type === 'View' ? 'viewLbl' : ''}>
                  <FormattedMessage {...messages.addUsrPopupAddr2} />
                </Label>
                <br />
                {type === 'View' && testing.userProfile && (
                  <Label>{testing.userProfile.address2}</Label>
                )}
                {type !== 'View' && (
                  <Input
                    type="text"
                    name="address2"
                    maxLength="255"
                    onChange={e => {
                      handleChange('address2', e.target.value);
                    }}
                    value={selected.address2}
                    disabled={isADUser}
                  />
                )}
              </FormGroup>
            </Col>
          </Row>
          <Row>
            <Col xs={2} md>
              <FormGroup>
                <Label
                  className={
                    // eslint-disable-next-line no-nested-ternary
                    isADUser
                      ? ''
                      : type === 'View'
                      ? 'mandate viewLbl'
                      : 'mandate'
                  }
                >
                  <FormattedMessage {...messages.cityName} />
                </Label>
                <br />
                {type === 'View' && testing.userProfile && (
                  <Label>{testing.userProfile.city}</Label>
                )}
                {type !== 'View' && (
                  <Input
                    type="text"
                    id="city"
                    name="city"
                    maxLength="255"
                    onChange={e => {
                      handleChange('city', e.target.value);
                    }}
                    value={selected.city}
                    disabled={isADUser}
                  />
                )}
                {type !== 'View' &&
                  (!isADUser && selected.city) === '' &&
                  selected.validationFlag && (
                    <p className="validation-content">
                      <FormattedMessage {...messages.userCityRequiredMsg} />
                    </p>
                  )}
              </FormGroup>
            </Col>
            <Col xs={2} md>
              {type === 'View' && testing.userProfile && (
                <>
                  <Label className={type === 'View' ? 'viewLbl' : ''}>
                    <FormattedMessage {...messages.regionName} />
                  </Label>
                  <br />
                  <Label>
                    {getValuesByIdAndByType(
                      regionCountryPortArr,
                      [testing.userProfile.regionId],
                      [],
                      [],
                      'r',
                      'label',
                    )}
                  </Label>
                </>
              )}
              {type !== 'View' && (
                <Dropdown
                  id="regionId"
                  label="Region"
                  options={regions}
                  onChange={region1Select}
                  selected={selected.regionId}
                  className="mandate"
                  isDisabled={isADUser}
                />
              )}
              {type !== 'View' &&
                selected.regionId === '' &&
                selected.validationFlag && (
                  <p className="validation-content">
                    <FormattedMessage {...messages.userRegionRequiredMsg} />
                  </p>
                )}
            </Col>
            <Col xs={2} md>
              {type === 'View' && testing.userProfile && (
                <>
                  <Label className={type === 'View' ? 'viewLbl' : ''}>
                    <FormattedMessage {...messages.countryName} />
                  </Label>
                  <br />
                  <Label>
                    {getValuesByIdAndByType(
                      regionCountryPortArr,
                      [testing.userProfile.regionId],
                      [testing.userProfile.countryId],
                      [],
                      'c',
                      'label',
                    )}
                  </Label>
                </>
              )}
              {type !== 'View' && (
                <Dropdown
                  id="countryId"
                  label="Country"
                  className="mandate"
                  options={countries[0]}
                  onChange={country1Select}
                  selected={selected.countryId}
                  isDisabled={isADUser}
                />
              )}
              {type !== 'View' &&
                selected.countryId === '' &&
                selected.validationFlag && (
                  <p className="validation-content">
                    <FormattedMessage {...messages.userCountryRequiredMsg} />
                  </p>
                )}
            </Col>
            <Col xs={2} md>
              <FormGroup>
                <Label
                  className={
                    // eslint-disable-next-line no-nested-ternary
                    isADUser
                      ? ''
                      : type === 'View'
                      ? 'mandate viewLbl'
                      : 'mandate'
                  }
                >
                  <FormattedMessage {...messages.postCodeValue} />
                </Label>
                <br />
                {type === 'View' && testing.userProfile && (
                  <Label>{testing.userProfile.postalCode}</Label>
                )}
                {type !== 'View' && (
                  <Input
                    type="text"
                    id="postalCode"
                    name="postalCode"
                    maxLength="30"
                    value={selected.postalCode}
                    onChange={e => {
                      handleChange('postalCode', e.target.value);
                    }}
                    disabled={isADUser}
                  />
                )}
                {type !== 'View' &&
                  (!isADUser && selected.postalCode === '') &&
                  selected.validationFlag && (
                    <p className="validation-content">
                      <FormattedMessage {...messages.userPostcodeRequiredMsg} />
                    </p>
                  )}
              </FormGroup>
            </Col>
            <Col xs={2} md>
              <FormGroup>
                <Label
                  className={type === 'View' ? 'mandate viewLbl' : 'mandate'}
                >
                  <FormattedMessage {...messages.emailValue} />
                </Label>
                <br />
                {type === 'View' && testing.userProfile && (
                  <Label>{testing.userProfile.emailId}</Label>
                )}
                {type !== 'View' && (
                  <Input
                    type="text"
                    id="emailId"
                    name="emailId"
                    maxLength="255"
                    value={selected.emailId}
                    onChange={e => {
                      handleChange('emailId', e.target.value);
                    }}
                    disabled={isADUser}
                  />
                )}
                {type !== 'View' &&
                  selected.emailId === '' &&
                  selected.validationFlag && (
                    <p className="validation-content">
                      <FormattedMessage {...messages.userEmailRequiredMsg} />
                    </p>
                  )}
                {type !== 'View' &&
                  selected.emailId !== '' &&
                  !selected.emailId.match(emailValidationRegex) &&
                  selected.validationFlag && (
                    <p className="validation-content">
                      <FormattedMessage
                        {...messages.userEmailRequiredMsgValid}
                      />
                    </p>
                  )}
              </FormGroup>
            </Col>
          </Row>
          <Row>
            <Col xs={2} md>
              <FormGroup>
                <Label
                  className={
                    // eslint-disable-next-line no-nested-ternary
                    isADUser
                      ? ''
                      : type === 'View'
                      ? 'mandate viewLbl'
                      : 'mandate'
                  }
                >
                  <FormattedMessage {...messages.phoneNumber} />
                </Label>
                <br />
                {type === 'View' && testing.userProfile && (
                  <Label>{testing.userProfile.phoneNumber}</Label>
                )}
                {type !== 'View' && (
                  <Input
                    type="text"
                    id="phoneNumber"
                    name="phoneNumber"
                    maxLength={25}
                    value={selected.phoneNumber}
                    onChange={e => {
                      handleChange('phoneNumber', e.target.value, e);
                    }}
                    disabled={isADUser}
                  />
                )}
                {type !== 'View' &&
                  (!isADUser && selected.phoneNumber === '') &&
                  selected.validationFlag && (
                    <p className="validation-content">
                      <FormattedMessage {...messages.userPhoneRequiredMsg} />
                    </p>
                  )}
              </FormGroup>
            </Col>
            <Col xs={2} md>
              <FormGroup>
                <Label className={type === 'View' ? 'viewLbl' : ''}>
                  <FormattedMessage {...messages.organizationName} />
                </Label>
                <br />
                {type === 'View' && testing.userProfile && (
                  <Label>{testing.userProfile.organization}</Label>
                )}
                {type !== 'View' && (
                  <Input
                    type="text"
                    name="organization"
                    maxLength="255"
                    pattern="^[a-zA-Z0-9]+$"
                    value={selected.organization}
                    onChange={e => {
                      handleChange('organization', e.target.value);
                    }}
                    disabled={isADUser}
                  />
                )}
              </FormGroup>
            </Col>
            {type !== 'View' && type === 'Add' && (
              <Col xs={2} md>
                <FormGroup>
                  <Label className="mandate">
                    <FormattedMessage {...messages.pwdValue} />
                  </Label>
                  <Input
                    type="password"
                    id="password"
                    name="password"
                    maxLength="255"
                    value={selected.password}
                    onChange={e => {
                      handleChange('password', e.target.value);
                    }}
                    autoComplete="new-password"
                  />
                  {type !== 'View' &&
                    selected.password === '' &&
                    selected.validationFlag && (
                      <p className="validation-content">
                        <FormattedMessage
                          {...messages.userPasswordRequiredMsg}
                        />
                      </p>
                    )}
                  {type !== 'View' &&
                    selected.password !== '' &&
                    selected.validationFlag &&
                    !passwordValidation.test(selected.password) && (
                      <p className="validation-content">
                        <FormattedMessage
                          {...messages.userPasswordRequiredMsgValidate}
                        />
                      </p>
                    )}
                </FormGroup>
              </Col>
            )}
            <Col xs={2} md className="align-self-end">
              <FormGroup>
                {type === 'View' && (
                  <CustomInput
                    type="checkbox"
                    label={
                      <Label>
                        <FormattedMessage {...messages.isActiveChk} />
                      </Label>
                    }
                    name="isActive"
                    id="isActive"
                    disabled
                    checked={testing.isActive}
                    onChange={e => {
                      handleChange('isActive', e.target.checked);
                    }}
                  />
                )}
                {type !== 'View' && (
                  <CustomInput
                    type="checkbox"
                    label={
                      <Label>
                        <FormattedMessage {...messages.isActiveChk} />
                      </Label>
                    }
                    name="isActive"
                    id="isActive"
                    checked={selected.isActive}
                    onChange={e => {
                      handleChange('isActive', e.target.checked);
                    }}
                  />
                )}
              </FormGroup>
            </Col>
            {type === 'View' && <Col xs={6} md />}
            <Col xs={6} md />
          </Row>
          <Row>
            <Col className="text-left">
              <h4 className="user-role-search-title">
                <FormattedMessage {...messages.assignRoles} />
              </h4>
            </Col>
          </Row>
          {type === 'Add' &&
            selected.assignedRole &&
            selected.assignedRole.length > 0 &&
            selected.assignedRole.map((item, index) => (
              <AssignRoles
                testing={testing}
                roleNames={roleNames}
                roleSelect1={roleSelect1}
                regionCheckBoxTriggered={regionCheckBoxTriggered}
                countryCheckBoxTriggered={countryCheckBoxTriggered}
                portCheckBoxTriggered={portCheckBoxTriggered}
                minDate={minDate}
                fetchFromDate1={fetchFromDate1}
                fetchToDate1={fetchToDate1}
                componentAdd={componentAddTrigger}
                componentRemove={componentRemoveTrigger}
                assignComponent={[]}
                count={index}
                selected
                multiselectId={selected.addCmpArr.length}
                isRemoveComponent={false}
                isAddComponent={isAddTriggerd}
                item={item}
                indexKey={index}
                type={type}
                isValid={isValid}
              />
            ))}
          {type === 'Update' &&
            selected.assignedRole &&
            selected.assignedRole.length > 0 &&
            selected.assignedRole.map((item, index) => {
              if (item.isDelete === false) {
                return (
                  <AssignRoles
                    testing={testing}
                    roleNames={roleNames}
                    roleSelect1={roleSelect1}
                    regionCheckBoxTriggered={regionCheckBoxTriggered}
                    countryCheckBoxTriggered={countryCheckBoxTriggered}
                    portCheckBoxTriggered={portCheckBoxTriggered}
                    minDate={minDate}
                    fetchFromDate1={fetchFromDate1}
                    fetchToDate1={fetchToDate1}
                    componentAdd={componentAddTrigger}
                    componentRemove={componentRemoveTrigger}
                    assignComponent={[]}
                    count={index}
                    selected
                    multiselectId={selected.addCmpArr.length}
                    isRemoveComponent={false}
                    isAddComponent={isAddTriggerd}
                    item={item}
                    indexKey={index}
                    type={type}
                    isValid={isValid}
                  />
                );
              }
              return null;
            })}
          <Row>
            <Col>
              <LoadingIndicator
                isLoading={isLoading}
                hasError={hasError}
                error={error}
              />
            </Col>
          </Row>
          <Row>
            <Col xs={2} md />
            <Col xs={4} md />
            <Col xs={4} md />
            <Col xs={2} md>
              {type === 'Add' &&
                selected.assignedRole &&
                selected.assignedRole.length === 0 && (
                  <Button
                    type="button"
                    name="addBtn"
                    className="buttonTop buttonLeft assign-role-buttons"
                    outline
                    color="primary"
                    size="sm"
                    onClick={() => componentAddTrigger()}
                  >
                    <i className="fa fa-plus" aria-hidden="true" />
                  </Button>
                )}
              {type === 'Update' &&
                selected.assignedRole &&
                assignRole.length === 0 && (
                  <Button
                    type="button"
                    name="addBtn"
                    className="buttonTop buttonLeft assign-role-buttons"
                    outline
                    color="primary"
                    size="sm"
                    onClick={() => componentAddTrigger()}
                  >
                    <i className="fa fa-plus" aria-hidden="true" />
                  </Button>
                )}
            </Col>
          </Row>

          {type === 'View' &&
            testing.userRoleAccess &&
            testing.userRoleAccess.length !== 0 && (
              <div>
                {testing.userRoleAccess.map(userRole => (
                  <div>
                    <Row>
                      <Col xs={2} md>
                        <Label className="viewLbl">
                          <FormattedMessage {...messages.role} />
                        </Label>
                        <br />
                        <Label>{getRoleNameById(userRole.roleId)}</Label>
                      </Col>
                      <Col xs={2} md>
                        <Label className="viewLbl">
                          <FormattedMessage {...messages.regionName} />
                        </Label>
                        <br />
                        <Label>
                          {getValuesByIdAndByType(
                            regionCountryPortArr,
                            userRole.regionListId,
                            userRole.countryListId,
                            userRole.portListId,
                            'r',
                            'label',
                          )}
                        </Label>
                      </Col>
                      <Col xs={2} md>
                        <Label className="viewLbl">
                          <FormattedMessage {...messages.countryName} />
                        </Label>
                        <br />
                        <Label>
                          {getValuesByIdAndByType(
                            regionCountryPortArr,
                            userRole.regionListId,
                            userRole.countryListId,
                            userRole.portListId,
                            'c',
                            'label',
                          )}
                        </Label>
                      </Col>
                      <Col xs={2} md>
                        <Label className="viewLbl">
                          <FormattedMessage {...messages.portsValues} />
                        </Label>
                        <br />
                        <Label>
                          {getValuesByIdAndByType(
                            regionCountryPortArr,
                            userRole.regionListId,
                            userRole.countryListId,
                            userRole.portListId,
                            'p',
                            'label',
                          )}
                        </Label>
                      </Col>
                      <Col xs={2} md />
                    </Row>

                    <Row className="mt-2 mb-2">
                      <Col xs={2} md>
                        <Label className="viewLbl">
                          <FormattedMessage {...messages.fromDate} />
                        </Label>
                        <br />
                        <Label>
                          {userRole.fromDate.split('T')[0].split('-')[2]}/
                          {userRole.fromDate.split('T')[0].split('-')[1]}/
                          {userRole.fromDate.split('T')[0].split('-')[0]}
                        </Label>
                      </Col>
                      <Col xs={2} md>
                        <Label className="viewLbl">
                          <FormattedMessage {...messages.toDate} />
                        </Label>
                        <br />
                        <Label>
                          {userRole.toDate.split('T')[0].split('-')[2]}/
                          {userRole.toDate.split('T')[0].split('-')[1]}/
                          {userRole.toDate.split('T')[0].split('-')[0]}
                        </Label>
                      </Col>
                      <Col xs={2} md />
                      <Col xs={2} md />
                      <Col xs={2} md />
                    </Row>
                  </div>
                ))}
              </div>
            )}
        </Form>
      </Popup>
    </>
  );
}

AddUserModalBody.propTypes = {
  show: PropTypes.bool,
  addUserModalClose: PropTypes.func.isRequired,
  onRegionSelect: PropTypes.func,
  onCountrySelect: PropTypes.func,
  regionCountryPortAPi: PropTypes.func.isRequired,
  regions: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  countries: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  selected: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  roleNames: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  fetchFromDate: PropTypes.func.isRequired,
  fetchToDate: PropTypes.func.isRequired,
  addUserData: PropTypes.func.isRequired,
  fChangeaddUserDataValue: PropTypes.func.isRequired,
  viewUserData: PropTypes.oneOfType([PropTypes.array, PropTypes.object]),
  editUserFlag: PropTypes.bool.isRequired,
  handleUserUpdateButton: PropTypes.func.isRequired,
  onPortSelect: PropTypes.func.isRequired,
  onRoleSelect: PropTypes.func.isRequired,
  onComponentAdd: PropTypes.func.isRequired,
  onComponentRemove: PropTypes.func.isRequired,
  type: PropTypes.string.isRequired,
  checkUserNameExist: PropTypes.func,
  userNameExistFlag: PropTypes.bool,
  isLoading: PropTypes.oneOfType([PropTypes.bool, PropTypes.string]),
  hasError: PropTypes.oneOfType([PropTypes.bool, PropTypes.string]),
  error: PropTypes.oneOfType([
    PropTypes.array,
    PropTypes.object,
    PropTypes.string,
  ]),
  regionCountryPortArr: PropTypes.array,
  roleMasterList: PropTypes.array,
  focusField: PropTypes.string,
};
const mapStateToProps = createStructuredSelector({
  roleNames: makeSelectRoles(),
  countries: makeSelectCountries(),
  ports: makeSelectPorts(),
  regionCountryPortArr: makeSelectRegionCountryPortArr(),
  roleMasterList: makeSelectRoleMasterList(),
  focusField: makeSelectfocusField(),
});

const withConnect = connect(mapStateToProps);
export default compose(withConnect)(AddUserModalBody);
