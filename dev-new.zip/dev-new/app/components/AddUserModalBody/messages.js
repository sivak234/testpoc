/*
 * AddUserModalBody Messages
 *
 * This contains all the text for the AddUserModalBody component.
 */

import { defineMessages } from 'react-intl';

export const scope = 'app.components.AddUserModalBody';

export default defineMessages({
  modalHeader: {
    id: `${scope}.modalHeader`,
    defaultMessage: 'Add User',
  },
  updateUser: {
    id: `${scope}.updateUser`,
    defaultMessage: 'Update User',
  },
  viewUser: {
    id: `${scope}.viewUser`,
    defaultMessage: 'View User',
  },
  save: {
    id: `${scope}.save`,
    defaultMessage: 'Save',
  },
  addUsrPopupUsrName: {
    id: `${scope}.addUsrPopupUsrName`,
    defaultMessage: 'User Name',
  },
  addUsrPopupFname: {
    id: `${scope}.addUsrPopupFname`,
    defaultMessage: 'First Name',
  },
  addUsrPopupLname: {
    id: `${scope}.addUsrPopupLname`,
    defaultMessage: 'Last Name',
  },
  addUsrPopupAddr1: {
    id: `${scope}.addUsrPopupAddr1`,
    defaultMessage: 'Address1',
  },
  addUsrPopupAddr2: {
    id: `${scope}.addUsrPopupAddr2`,
    defaultMessage: 'Address2',
  },
  cityName: {
    id: `${scope}.cityName`,
    defaultMessage: 'City',
  },
  postCodeValue: {
    id: `${scope}.postCodeValue`,
    defaultMessage: 'Postcode',
  },
  emailValue: {
    id: `${scope}.emailValue`,
    defaultMessage: 'Email',
  },
  regionName: {
    id: `${scope}.regionName`,
    defaultMessage: 'Region',
  },
  countryName: {
    id: `${scope}.countryName`,
    defaultMessage: 'Country',
  },
  phoneNumber: {
    id: `${scope}.phoneNumber`,
    defaultMessage: 'Phone',
  },
  organizationName: {
    id: `${scope}.organizationName`,
    defaultMessage: 'Organisation',
  },
  pwdValue: {
    id: `${scope}.pwdValue`,
    defaultMessage: 'Password',
  },
  isActiveChk: {
    id: `${scope}.isActiveChk`,
    defaultMessage: 'Is Active',
  },
  assignRoles: {
    id: `${scope}.assignRoles`,
    defaultMessage: 'Assign Roles',
  },
  portsValues: {
    id: `${scope}.portsValues`,
    defaultMessage: 'Ports',
  },
  fromDate: {
    id: `${scope}.fromDate`,
    defaultMessage: 'From Date',
  },
  toDate: {
    id: `${scope}.toDate`,
    defaultMessage: 'To Date',
  },
  role: {
    id: `${scope}.role`,
    defaultMessage: 'Role',
  },
  addUsr: {
    id: `${scope}.addUsr`,
    defaultMessage: 'ADD USER',
  },
  cancel: {
    id: `${scope}.cancel`,
    defaultMessage: 'CANCEL',
  },
  userExistMsg: {
    id: `${scope}.userExistMsg`,
    defaultMessage: 'User Name already exist',
  },
  userNameRequiredMsg: {
    id: `${scope}.userNameRequiredMsg`,
    defaultMessage: 'Please provide User Name',
  },
  userFirstNameRequiredMsg: {
    id: `${scope}.userFirstNameRequiredMsg`,
    defaultMessage: 'Please provide First Name',
  },
  userLastNameRequiredMsg: {
    id: `${scope}.userLastNameRequiredMsg`,
    defaultMessage: 'Please provide Last Name',
  },
  userAddressRequiredMsg: {
    id: `${scope}.userAddressRequiredMsg`,
    defaultMessage: 'Please provide address',
  },
  userCityRequiredMsg: {
    id: `${scope}.userCityRequiredMsg`,
    defaultMessage: 'Please provide City',
  },
  userRegionRequiredMsg: {
    id: `${scope}.userRegionRequiredMsg`,
    defaultMessage: 'Please select Region',
  },
  userCountryRequiredMsg: {
    id: `${scope}.userCountryRequiredMsg`,
    defaultMessage: 'Please select Country',
  },
  userPostcodeRequiredMsg: {
    id: `${scope}.userPostcodeRequiredMsg`,
    defaultMessage: 'Please provide Postcode',
  },
  userEmailRequiredMsg: {
    id: `${scope}.userEmailRequiredMsg`,
    defaultMessage: 'Please provide Email',
  },
  userEmailRequiredMsgValid: {
    id: `${scope}.userEmailRequiredMsgValid`,
    defaultMessage: 'Please enter valid email-ID',
  },
  userPhoneRequiredMsg: {
    id: `${scope}.userPhoneRequiredMsg`,
    defaultMessage: 'Please provide Phone number',
  },
  userPasswordRequiredMsg: {
    id: `${scope}.userPasswordRequiredMsg`,
    defaultMessage: 'Please provide Password',
  },
  userPasswordRequiredMsgValidate: {
    id: `${scope}.userPasswordRequiredMsgValidate`,
    defaultMessage:
      'Password should contain minimum 1 Upper case, 1 Lower Case, 1 special character, 1 number.',
  },
  userNameRequiredMsgValid: {
    id: `${scope}.userNameRequiredMsgValid`,
    defaultMessage: 'UserName is not vaild',
  },
});
