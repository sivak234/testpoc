import React from 'react'
import {Router,Switch, Route} from 'react-router-dom'
import getHistory from 'history/createHashHistory'
import UserContainer from '../containers/UserContainer'

const history = getHistory()
console.log('history=%o', history)

history.listen((location, action) => {
console.log('history-listener: location=%o, action=%o', location, action)
})

export default () => {
  const routerdiv = (
    <div id="router-div">
          <Router history={history}>
          <Switch>
              <Route path="/" exact component={UserContainer} />
          </Switch>
      </Router>
    </div>
  )
  return routerdiv
}
