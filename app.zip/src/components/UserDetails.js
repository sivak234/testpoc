import React, { Component } from 'react'
import Pagination from "react-js-pagination";

class UserDetails extends Component {
    constructor(props){
        super(props)
        this.state = {
            todotext: '',
            activePage: 15,
        }
        this.onChangeTodoText = this.onChangeTodoText.bind(this)
        // this.handleSelectRow = this.handleSelectRow.bind()
    }

    onChangeTodoText(e){
        this.setState({
            todotext: e.target.value
        })
    }
    handleSelectRow= (data)=> {
        this.props.handleSelect(data);
    }
    handleDeleteRow = (data) => {
        this.props.handleDeleteRow(data);
    }
    handlePageChange(pageNumber) {
        debugger
        console.log(`active page is ${pageNumber}`);
        this.setState({activePage: pageNumber});
    }
     
    render() {
        const { userDetail,searchValue } = this.props;
        return (<div>
            <table class="table">
            <thead>
                <tr>
                <th scope="col">Name</th>
                <th scope="col">Role</th>
                <th scope="col">Create</th>
                <th scope="col">Status</th>
                <th scope="col">Action</th>
                </tr>
            </thead>
                <tbody>
                {userDetail.filter(data => {
                                  return (
                                    data.firstName
                                      .toLowerCase()
                                      .indexOf(searchValue) >= 0
                                  )
                                }).map(data => {
                return( <tr key={data.firstName}>
                    <th scope="row">{data.firstName} {data.lastName}</th>
                    <td>{data.role}</td>
                    <td>{data.created}</td>
                    <td>{data.status}</td>
                    <td> <button type="button" onClick={()=> this.handleSelectRow(data)} className="btn btn-link">Edit</button></td>
                    <td> <button type="button" onClick={()=> this.handleDeleteRow(data)} className="btn btn-link">Delete</button></td>
                    </tr>)
                }
              )
            }
            </tbody>
            </table>
            {userDetail.length> 0 && 
            <Pagination
                activePage={this.state.activePage}
                itemsCountPerPage={2}
                totalItemsCount={userDetail.length}
                pageRangeDisplayed={2}
                onChange={this.handlePageChange.bind(this)}
            />
            }
          </div>
        );
    }
}


export default UserDetails;