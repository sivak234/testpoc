import React, { Component } from 'react'
import { Button, Modal, ModalHeader, ModalBody, ModalFooter, Col,Form,FormGroup, Label, Input  } from 'reactstrap';
import { connect } from 'react-redux'
import { addUsers } from '../actions/actionCreator'
import { bindActionCreators } from 'redux'
import UserDetails from '../components/UserDetails'
import moment from 'moment'

class UserContainer extends Component {
    constructor(props){
        super(props)
        this.state = {
            searchValue: '',
            userDetail: [],
            show: false,
            firstName: '',
            lastName: '',
            email: '',
            role: 'Role',
            status: 'Active',
            isEdit: false,
            userId: '',
        }
        this.onChangeTodoText = this.onChangeTodoText.bind(this)
    }
    onChangeTodoText(e){
        this.setState({
            searchValue: e.target.value
        })
    }
    handleClose() {
        this.setState({
            show: false,
            firstName: '',
            lastName: '',
            email: '',
            role: 'Role',
            status: 'Active',
            isEdit: false,
            userId: '',
        })
    }
    handleOpen() {
        this.setState({show: true})
    }
    handleChange(field, e) {
        this.setState({[field]: e.target.value})
    }
    handleAdd() {
        const { userDetail, firstName, lastName, email, role, status,userId } = this.state;
        if (this.state.isEdit === false) {
            const formatedDate = moment(new Date()).format('YYYY-MM-DD');
            const userObj = {
                id: userDetail.length + 1,
                firstName: firstName,
                lastName: lastName,
                email: email,
                role: role,
                status: status,
                created: formatedDate
            }
            userDetail.push(userObj);
            this.setState({
                show: false,
                firstName: '',
                lastName: '',
                email: '',
                role: 'Role',
                status: 'Active'
            });
        } else {
            userDetail.forEach(item => {
                if (item.id === userId) {
                    item.firstName = firstName;
                    item.lastName = lastName;
                    item.email = email;
                    item.role = role;
                    item.status = status;
                }
            })
            this.setState({ userDetail , show: false,});
        }
    }
    handleSelect = (data) => {
        this.setState({
            userId: data.id,
            firstName: data.firstName,
            lastName: data.lastName,
            email: data.email,
            role: data.role,
            status: data.status,
            show: true,
            isEdit: true
        });
    }
    handleDeleteRow = (data) => {
        const { userDetail } = this.state;
        const userdata = userDetail.filter(x => x.id !== data.id);
        this.setState({
            userDetail: userdata,
            firstName: '',
            lastName: '',
            email: '',
            role: 'Role',
            status: 'Active',
        })
    }
    render() {
        const { show,firstName,lastName,email,role,status,isEdit,searchValue } = this.state;
        return (
         <div className="container">
          <div className="row">
                    <div className="col-sm-1 col-sm-push-4">
                       <Button id="button" onClick={() => { this.handleOpen()}} className="btn btn-success">Add</Button>
                    </div>
                    <div className="col-sm-3 col-sm-pull-4">
                        <Input type="text" name="searchValue" value={searchValue} id="searchValue" onChange={e => this.onChangeTodoText(e)} placeholder="Search" />
                    </div>
           </div>
            <div className="row">
                    <UserDetails
                        userDetail={this.state.userDetail}
                        handleSelect={this.handleSelect}
                        handleDeleteRow={this.handleDeleteRow}
                        searchValue={searchValue}
                   />
            </div>
        <div>
      <Modal isOpen={show} toggle={()=> this.handleClose()}>
        <ModalHeader toggle={()=> this.handleClose()}>Add Users</ModalHeader>
        <ModalBody>
        <Form>
            <FormGroup row>
                <Label for="exampleEmail" sm={3}>First Name</Label>
                <Col sm={10}>
                <Input type="text" name="firstname" value={firstName} id="firstname" onChange={e => this.handleChange('firstName', e)} placeholder="First Name" />
                </Col>
            </FormGroup>
            <FormGroup row>
                <Label for="examplePassword" sm={3}>Last Name</Label>
                <Col sm={10}>
                <Input type="text" name="lastname" value={lastName} id="lastname" onChange={e => this.handleChange('lastName', e)} placeholder="Last Name" />
                </Col>
            </FormGroup>
            <FormGroup row>
                <Label for="exampleSelect" sm={3}>Select</Label>
                <Col sm={10}>
                <Input type="select" name="select" value={role} onChange={e => this.handleChange('role', e)} id="exampleSelect">
                    <option value="Role">Role</option>
                    <option value='Admin'>Admin</option>
                    <option value='Partner'>Partner</option>
                </Input>
                </Col>
            </FormGroup>
            <FormGroup row>
                <Label for="exampleEmail" sm={3}>Email</Label>
                <Col sm={10}>
                <Input type="email" value={email} name="email" id="exampleEmail" onChange={e => this.handleChange('email', e)} placeholder="Email" />
                </Col>
              </FormGroup>
             <FormGroup row>
                <Label for="exampleSelect" sm={3}>Select</Label>
                <Col sm={10}>
                <Input type="select" value={status} name="select" onChange={e => this.handleChange('status', e)} id="statusSelect">
                    <option value="active">Active</option>
                    <option value='inactive'>Inactive</option>
                </Input>
                </Col>
            </FormGroup>
            </Form>
        </ModalBody>
        <ModalFooter>
          <Button color="primary" onClick={() => this.handleAdd()}>{isEdit === true ? 'Save' : 'Add'}</Button>{' '}
          <Button color="secondary" onClick={()=> this.handleClose()}>Cancel</Button>
        </ModalFooter>
      </Modal>
    </div>
      </div>
        );
    }
}

const mapDispatchToProps = (dispatch) => {
    return bindActionCreators({
        addUsers
    }, dispatch)
}

export default connect(mapDispatchToProps)(UserContainer)