import React, {useState, useEffect} from 'react';
import axios from 'axios';
import ProfileImg from './img/profileImg.svg'; 
import activeStar from './img/activeStar.svg';
import inactiveStar from './img/inactiveStar.svg';
import chatIcon from './img/chatIcon.svg';
import userProfileImg from './img/userProfileImg.svg'


import './UserProflieList.css'

import {
    BrowserRouter as Router,
    Switch,
    Route,
    Link
} from 'react-router-dom';

function fetchList (){
    const user =  UserProflieList();
    if (user && user.length > 0) {
      this.setState({ userDetails: user });
    }
  };
 
function UserProflieList() {
   
   
    const{
        userDetails,
        setUser
    }=useState({});
   
    
    useEffect(() => {    
        axios.get('http://localhost:4001/app/userprofile')
            .then(response => {   
                console.log(response.data)
                setUser(response.data.data); 
               
            })
            .catch(err => {
                console.log(err)
            })

    })

  


    return (

        <div>
            {userDetails.map(user => (
                
        <div className="userListWrapper">
            <figure>
                <img src={userProfileImg} alt=""/>  
            </figure>
            <article>
                <h5 className="UserProfileName">{user.name}</h5>
                <div className="typeRatingWrapper">
                    <span className="largePara UserListType">Type 3</span>
                    <div className="RatingWrapper">
                        <img src={activeStar} alt=""/>
                        <img src={activeStar} alt=""/>
                        <img src={activeStar} alt=""/>
                        <img src={activeStar} alt=""/>
                        <img src={inactiveStar} alt=""/>
                    </div>
                </div>
                <p className="UserProfliePara">Nines are accepting, trusting, and stable. They are usually creative, optimistic, and supportive.. More</p>
                <div className="compatibilityChat">
                    <button className="btn compatibilityBtn">Compatibility</button>
                    <span><img src={chatIcon} alt=""/></span>
                </div>
            </article>
        </div>    
            ))}
        </div>    
    )
}
export default UserProflieList;