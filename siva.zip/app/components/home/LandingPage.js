import React from 'react';
import './LandingPage.scss';
import PropTypes from 'prop-types';
import {
  Link
} from 'react-router-dom';
import loginImg from '../../img/bannerBg.svg';
import loginBg from '../../img/biggerlogo-bg.svg';
import downArrow from '../../img/downArrow.svg';
import Landingimg from '../../img/landing-img.png';
import Landingimg1 from '../../img/landing-icon-1.png';
import Landingimg2 from '../../img/landing-icon-2.png';
import Landingimg3 from '../../img/landing-icon-3.png';
import Landingimg4 from '../../img/landing-icon-4.png';
import Landingimg5 from '../../img/landing-icon-5.png';
import Landingimg6 from '../../img/landing-icon-6.png';
import Landingimg7 from '../../img/landing-icon-7.png';
import Landingimg8 from '../../img/landing-icon-8.png';
import Landingimg9 from '../../img/landing-icon-9.png';

function LandingPage({ handleLogin, isLoginSuccess }) {
  // eslint-disable-next-line no-console
  console.log(handleLogin);
  return (
    <React.Fragment>
      <div className="container">
        <div className="row">
          <div className="col-md-7">
            <div className="loginImgWrapper" style={{ backgroundImage: `url(${loginBg})` }}>
              <div className="loginImg">
                <img src={loginImg} alt="" />
              </div>
            </div>
          </div>
          <div className="col-lg-5">
            <div className="banner-header">
              <h1>Find the right match for your <span className="color-peach">Ennea</span> type</h1>
              <div className="bannerBtn">
                <Link to="Login" className="btn greenBtn loginBtn">Login</Link>
              </div>
            </div>
          </div>

          <div className="scrollDownWrapper">
            <h4>Want to know about Ennegram</h4>
            <span className="downArrow"><img src={downArrow} alt="" /></span>
          </div>
        </div>
      </div>
      <div className="landingBottom" style={{ backgroundImage: `url(${loginBg})` }}>
        <div className="container">
          <div className="row">
            <div className="col-lg-4">
              <div className="landingBottomContent">
                <h2>What is Enneagram ?</h2>
                <p>The Enneagram is a system of personality typing that describes patterns in how people interpret the world and manage their emotions. The Enneagram describes nine different personality types and maps each of these types on a nine-pointed diagram which helps to illustrate how the types relate to one another.</p>
                <h4 className="color-peach subHead">Want to know your Ennea type?</h4>
                <Link to="SignUp" className="btn greenBtn loginBtn mt-2">Sign Up</Link>
              </div>
            </div>
            <div className="col-lg-8">
              <div className="landingImgWrapper">
                <div className="landingImg">
                  <img src={Landingimg} alt="" />
                  <div className="typeCircle type1">
                    <h4 className="typeName">The Performer</h4>
                    <img src={Landingimg1} alt="" />
                  </div>

                  <div className="typeCircle type2">
                    <img src={Landingimg2} alt="" />
                    <h4 className="typeName">The Helper</h4>
                  </div>

                  <div className="typeCircle type3">
                    <img src={Landingimg3} alt="" />
                    <h4 className="typeName">The Achiever</h4>
                  </div>

                  <div className="typeCircle type4">
                    <img src={Landingimg4} alt="" />
                    <h4 className="typeName">The Originalist</h4>
                  </div>

                  <div className="typeCircle type5">
                    <img src={Landingimg5} alt="" />
                    <h4 className="typeName">The Sage</h4>
                  </div>

                  <div className="typeCircle type6">
                    <img src={Landingimg6} alt="" />
                    <h4 className="typeName">The Loyalist</h4>
                  </div>

                  <div className="typeCircle type7">
                    <img src={Landingimg7} alt="" />
                    <h4 className="typeName">The Enthusiast</h4>
                  </div>

                  <div className="typeCircle type8">
                    <h4 className="typeName">The Challenger</h4>
                    <img src={Landingimg8} alt="" />
                  </div>

                  <div className="typeCircle type9">
                    <h4 className="typeName">The Peacemaker</h4>
                    <img src={Landingimg9} alt="" />
                  </div>

                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div><input type="button" id="btnlogin" value="Login" onClick={() => handleLogin()} /></div>
      <div>{ isLoginSuccess ? 'login Success' : 'login failed'}</div>
    </React.Fragment>
  );
}
LandingPage.propTypes = {
  isLoginSuccess: PropTypes.bool,
  handleLogin: PropTypes.bool,
};
export default LandingPage;
