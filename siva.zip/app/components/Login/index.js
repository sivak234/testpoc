/* eslint-disable no-cond-assign */
import React, { useState } from 'react';

import axios from 'axios';
import PropTypes from 'prop-types';
import {
  Link
} from 'react-router-dom';
import { Button } from 'reactstrap';
import { apiUrl } from '../../const/env';
import LoginImage from './LoginImage';

function Login({
  loginUser, onChangeUsername, duseLogin, dhandleSignup
}) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const onChange = () => {
    setEmail(document.querySelector('#email').value);
    setPassword(document.querySelector('#password').value);
  };

  const LoginApp = () => {
    const details = {
      email,
      password
    };

    let err = 0;
    // eslint-disable-next-line no-useless-escape
    const validEmailRegex = RegExp(/^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i);


    if (!validEmailRegex.test(email)) {
      document.querySelector('.email-err').innerHTML = 'Please enter a valid email';
      err = 1;
    } else {
      document.querySelector('.email-err').innerHTML = '';
    }

    if (password.length === 0) {
      document.querySelector('.password-err').innerHTML = 'Field Required';
      err = 1;
    } else {
      document.querySelector('.password-err').innerHTML = '';
    }

    if (err === 0) {
      axios.post(`${apiUrl}/users/login`, details)
        .then((res) => {
          const log = res.data;
          (log.message = 'success') ? props.history.push('/UserProfile') : document.querySelector('.invalid').innerHTML = 'please check mail';
          localStorage.setItem('Id', JSON.stringify(log.data.id));
        });
    }
  };

  const handleChange = (e, type) => {
    onChangeUsername({
      value:
        e.target.value,
      inputType: type
    });
  };
  const handleClick = () => {
    duseLogin({ userName: loginUser.username, password: loginUser.password });
  };
  return (
    <React.Fragment>
      <div className="container">
        <div className="row">
          <div className="col-md-8">
            <LoginImage />
          </div>
          <div className="col-md-3">
            <div className="loginWrapper">
              <div className="loginarea">
                <div className="loginHeadWrapper">
                  <h3 className="loginHead">Login</h3>
                  <p className="largePara">Personality based Match Making</p>
                  <div className="err-msg invalid"></div>
                </div>
                <div className="loginSignupForm">
                  <div className="formgroup">
                    <input type="email" value={loginUser ? loginUser.username : ''} onChange={(e) => { handleChange(e, 'username'); }} placeholder="Email*" id="email" />
                    <p className="err-msg email-err"></p>
                  </div>
                  <div className="formgroup">
                    <input type="password" value={loginUser ? loginUser.password : ''} onChange={(e) => { handleChange(e, 'pwd'); }} placeholder="Password*" id="password" />
                    <p className="err-msg password-err"></p>
                  </div>
                </div>
                <div className="loginBtnArea">
                  <Button color="primary" className="btn largeBtn greenBtn" onClick={() => handleClick()}>Login</Button>
                  <div className="rememberForgot">
                    <span className="remember">
                      <label htmlFor="">
                        <input type="checkbox" /> Remember me
                      </label>
                    </span>
                    <span>
                      <Link to="/Forgot" className="color-peach">Forgot Password?</Link>
                    </span>
                  </div>
                </div>
                <p className="noAccount">Don't know your Ennea type? <Button color="link" onClick={() => dhandleSignup(true)} className="greenLink">Signup</Button></p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </React.Fragment>
  );
}
Login.propTypes = {
  // loading: PropTypes.bool,
  // error: PropTypes.oneOfType([PropTypes.object, PropTypes.bool]),
  // repos: PropTypes.oneOfType([PropTypes.array, PropTypes.bool]),
  // onSubmitForm: PropTypes.func,
  // username: PropTypes.string,
  onChangeUsername: PropTypes.func,
  loginUser: PropTypes.object,
  // loginStatus: PropTypes.bool,
  duseLogin: PropTypes.func,
  dhandleSignup: PropTypes.func,
};
export default Login;
