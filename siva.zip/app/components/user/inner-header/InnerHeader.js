import React from 'react';
import '../../Header/header.scss';
import {
  Link
} from 'react-router-dom';
import logo from '../../../img/logo.svg';
import BellImg from '../../../img/bell.svg';
import ShareImg from '../../../img/share.svg';
import SettingsImg from '../../../img/settings.svg';


function InnerHeader() {
  return (
    <React.Fragment>
      <header>
        <div className="container">
          <div className="header mt-0">
            <div className="logo">
              <Link to="LandingPage">
                <img src={logo} alt="logo" />
              </Link>
            </div>
            <div className="header-right">
              <div className="headerIconsWrapper">
                <span className="headerIcons"><img src={BellImg} alt="" /></span>
                <span className="headerIcons"><img src={ShareImg} alt="" /></span>
                <span className="headerIcons"><img src={SettingsImg} alt="" /></span>
              </div>
            </div>
          </div>
        </div>
      </header>
    </React.Fragment>
  );
}

export default InnerHeader;
