import React, { useState, useEffect } from 'react';
import axios from 'axios';

import './UserProfileCard.scss';

import ProfileImg from '../../../img/profileImg.svg';



function UserProfileCard() {

  const [user, setUser] = useState('');
 
  useEffect(() => {
      var id = localStorage.getItem('id');
    
  axios.get(`https://emmdev.tech:4001/app/userprofile/${id}`)
  .then(response => {        
  
       setUser(response.data.data); 
  })
  },[])

  return (

    <div className="userProfileCard">
      <div className="profileImg">
        <img src={ProfileImg} alt="" />
      </div>
      <div className="profileDatas">
        <h4 className="profileCardName">{user.name}</h4>
        <h6>Personality Type:  <strong>{user.type}</strong></h6>
        <div className="genderAgeWrapper">
          <span className="genderAge">Gender : <strong>{user.gender}</strong></span>
          <span className="genderAge">Age : <strong>{user.age}</strong></span>
        </div>
      </div>
    </div>

  );
}

export default UserProfileCard;
