import React, { useState, useEffect } from 'react';
import axios from 'axios';

import './UserProfileDetails.scss';

function UserProfileDetails() {
  const [users, setUser] = useState('');
  const [attribute,setAttribute] = useState([]);
  
  useEffect(() => {
      var id = localStorage.getItem('id');
   
  axios.get(`https://emmdev.tech:4001/app/userprofile/${id}`)
  .then(response => {        
  
       setUser(response.data.data); 
  })
  axios.get(`https://emmdev.tech:4001/app/userprofile/attribute/${id}`)
  .then(response => {        
  
       setAttribute(response.data.data); 
  })
  
  
  
 
  },[])
 
  return (


      <div className="userProfiledetailsWrapper">
          <h4 className="userDetailHead">{users.secondary_name}</h4>
          <div className="userDetailsRow">
              <div className="briefDetails">
                  <h6 className="briefDetailsHead"> {users.type} - In Brief</h6>
                  <p>{users.description}</p>
              </div>


            
              <div className="keyDrives">
                  <h6 className="keyDrivesHead">Key Drives</h6>
              
                 {attribute.result ? attribute.result.map((attribute) => {
                    
          return  <div className="keyDrivesDetails">
          <strong>{attribute.key_drive}</strong>
          <p>{attribute.key_type}</p>
      </div>
     
      })
     :"loading..." }
                 
              </div>
              
          </div>
      </div>
  )
}


export default UserProfileDetails;
