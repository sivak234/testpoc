import React from 'react';

import './UserProfile.scss';

import InnerHeader from '../inner-header/InnerHeader';
import UserProfileCard from '../user-profile-card/UserProfileCard';
import UserProfileDetails from '../user-profile-details/UserProfileDetails';
import UserProfileList from '../user-profile-list/UserProflieList';
import Filter from '../../filter/Filter';
import '../../../CheckCompatibilityPopup.scss';

function UserProfile() {
  return (
    <div className="innerPage">

      {/* <div className="innerPageWhiteBG"></div> */}
      <InnerHeader />
      <div className="container">
        <div className="userProfileRow">
          <div className="userProfileLeft">
            <UserProfileCard />
            <UserProfileDetails />
          </div>
          <div className="userProfileRight">
            <Filter />
            <div className="userProfileListWrapper">
              {/* <UserProfileList /> */}
            </div>
          </div>
        </div>
      </div>

    </div>
  );
}

export default UserProfile;
