import React from 'react';
import {
  Link
} from 'react-router-dom';
// eslint-disable-next-line import/no-unresolved
import './header.scss';
import logo from '../../img/logo.svg';

function Header() {
  return (
    <React.Fragment>
      <header>
        <div className="container">
          <div className="header">
            <div className="logo">
              <Link to="LandingPage">
                <img src={logo} alt="logo" />
              </Link>
            </div>
            <div className="header-right">
              <Link to="SignUp" className="btn loginBtn">Sign Up</Link>
            </div>
          </div>
        </div>
      </header>
    </React.Fragment>
  );
}

export default Header;
