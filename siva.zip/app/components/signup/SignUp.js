import React, { useState } from 'react';
import PropTypes from 'prop-types';
import axios from 'axios';
// import { Link } from 'react-router-dom';
import { Button } from 'reactstrap';
// import env from '../../const/env';
import LoginImage from '../Login/LoginImage';


function SignUp({
  dregisterInputchange, dhandleRegister, dhandleSignup, userRegister
}) {
  // const [name, setName] = useState('');
  // const [email, setEmail] = useState('');
  // const [password, setPassword] = useState('');
  let disableBtn = false;
  // const Onchange = () => {
  //   setName(document.querySelector('#name').value);
  //   setEmail(document.querySelector('#email').value);
  //   setPassword(document.querySelector('#password').value);
  // };
  const Register = () => {
    let err = 0;
    // eslint-disable-next-line no-useless-escape
    const validEmailRegex = RegExp(/^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i);

    if (userRegister.userName.length === 0) {
      document.querySelector('.name-err').innerHTML = 'Field Required';
      err = 1;
    } else {
      document.querySelector('.name-err').innerHTML = '';
    }

    if (!validEmailRegex.test(userRegister.email)) {
      document.querySelector('.email-err').innerHTML = 'Please enter a valid email';
      err = 1;
    } else {
      document.querySelector('.email-err').innerHTML = '';
    }

    if (userRegister.password.length === 0) {
      document.querySelector('.password-err').innerHTML = 'Field Required';
      err = 1;
    } else {
      document.querySelector('.password-err').innerHTML = '';
    }


    if (err === 0) {
      disableBtn = true;
      dhandleRegister(userRegister);
      // axios.post(`${env.apiUrl}users/register`, details)
      //   .then((res) => {
      //     const persons = res.data;
      //     disableBtn = false;
      //     (persons.message === 'success') ? props.history.push('/Login') : alert('err');
      //   });
    }
  };


  return (
    <React.Fragment>
      <div className="container">
        <div className="row">
          <div className="col-md-8">
            <LoginImage />
          </div>

          <div className="col-md-3">
            <div className="loginWrapper">
              <div className="loginarea">
                <div className="loginHeadWrapper">
                  <h3 className="loginHead">Register Here</h3>
                  <p className="largePara">Discover your Enneagram Personality Type</p>
                </div>
                <div className="loginSignupForm">
                  <div className="formgroup">
                    <input type="text" onChange={(e) => dregisterInputchange({ field: 'username', value: e.target.value })} placeholder="Name*" id="name" />
                    <p className="err-msg name-err"></p>
                  </div>
                  <div className="formgroup">
                    <input type="text" onChange={(e) => dregisterInputchange({ field: 'email', value: e.target.value })} placeholder="Type your Email*" id="email" />
                    <p className="err-msg email-err"></p>
                  </div>
                  <div className="formgroup">
                    <input type="password" onChange={(e) => dregisterInputchange({ field: 'password', value: e.target.value })} placeholder="Password*" id="password" />
                    <p className="err-msg password-err"></p>
                  </div>
                </div>
                <div className="loginBtnArea">

                  <Button color="primary" className="btn largeBtn greenBtn" onClick={Register}>Register</Button>
                  <div className="rememberForgot">
                    <span className="remember">
                      <label>
                        <input type="checkbox" /> Remember me
                      </label>
                    </span>
                  </div>
                </div>
                <p className="noAccount">Already have account? <Button color="link" onClick={() => dhandleSignup(false)}>Login</Button></p>
              </div>
            </div>
          </div>
        </div>

      </div>
    </React.Fragment>
  );
}
SignUp.propTypes = {
  dregisterInputchange: PropTypes.func,
  dhandleRegister: PropTypes.func,
  dhandleSignup: PropTypes.func,
  userRegister: PropTypes.object,
};
export default SignUp;
