import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { compose } from 'redux';
// import { Container, Row, Col } from 'react-bootstrap';
import { createStructuredSelector } from 'reselect';
import injectReducer from 'utils/injectReducer';
import injectSaga from 'utils/injectSaga';
import {
  makeSelectRepos,
  makeSelectLoading,
  makeSelectError
} from 'containers/App/selectors';
import { loadRepos } from '../App/actions';
import {
  changeUsername, useLogin, registerInputchange, handleRegister, handleSignup,
} from './actions';
import {
  makeSelectUsername, makeSelectloginUser, makeSelectloginStatus, makeSelectisSignup,
  makeSelectuserRegister
} from './selectors';
import reducer from './reducer';
import saga from './saga';
import Login from '../../components/Login/index';
import SignUp from '../../components/signup/SignUp';

function HomePage({
  onChangeUsername, loginUser, duseLogin, dregisterInputchange,
  dhandleRegister, dhandleSignup, isSignup, userRegister
}) {
  return (
    <div>
      {/* <Container>
        <Row>
          <Col>1</Col>
          <Col>2</Col>
          <Col>3</Col>
        </Row>
      </Container> */}
      {!isSignup && (
        <div style={{ marginLeft: '20px' }}>
          <Login loginUser={loginUser} onChangeUsername={onChangeUsername} duseLogin={duseLogin} dhandleSignup={dhandleSignup} />
        </div>
      )}
      {isSignup && (
        <div>
          <SignUp
            dregisterInputchange={dregisterInputchange}
            dhandleRegister={dhandleRegister}
            dhandleSignup={dhandleSignup}
            userRegister={userRegister}
          />
        </div>
      )}
    </div>
  );
}
const mapDispatchToProps = (dispatch) => ({
  onChangeUsername: (option) => dispatch(changeUsername(option)),
  onSubmitForm: (evt) => {
    if (evt !== undefined && evt.preventDefault) evt.preventDefault();
    dispatch(loadRepos());
  },
  duseLogin: (option) => dispatch(useLogin(option)),
  dregisterInputchange: (option) => dispatch(registerInputchange(option)),
  dhandleRegister: (option) => dispatch(handleRegister(option)),
  dhandleSignup: (option) => dispatch(handleSignup(option)),
});

const mapStateToProps = createStructuredSelector({
  repos: makeSelectRepos(),
  username: makeSelectUsername(),
  loading: makeSelectLoading(),
  error: makeSelectError(),
  loginUser: makeSelectloginUser(),
  loginStatus: makeSelectloginStatus(),
  isSignup: makeSelectisSignup(),
  userRegister: makeSelectuserRegister(),
});
HomePage.propTypes = {
  // loading: PropTypes.bool,
  // error: PropTypes.oneOfType([PropTypes.object, PropTypes.bool]),
  // repos: PropTypes.oneOfType([PropTypes.array, PropTypes.bool]),
  // onSubmitForm: PropTypes.func,
  // username: PropTypes.string,
  // loginStatus: PropTypes.bool,
  onChangeUsername: PropTypes.func,
  loginUser: PropTypes.object,
  duseLogin: PropTypes.func,
  dregisterInputchange: PropTypes.func,
  dhandleRegister: PropTypes.func,
  dhandleSignup: PropTypes.func,
  isSignup: PropTypes.bool,
  userRegister: PropTypes.object,
};
const withReducer = injectReducer({ key: 'home', reducer });
const withSaga = injectSaga({ key: 'home', saga });

const withConnect = connect(mapStateToProps, mapDispatchToProps);
export default compose(withReducer, withSaga, withConnect)(HomePage);
export { mapDispatchToProps };
