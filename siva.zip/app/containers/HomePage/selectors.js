import { createSelector } from 'reselect';

const selectHome = (state) => state.home;

const makeSelectUsername = () => createSelector(
  selectHome,
  (homeState) => homeState.username
);
const makeSelectloginUser = () => createSelector(
  selectHome,
  (homeState) => homeState.loginUser
);
const makeSelectloginStatus = () => createSelector(
  selectHome,
  (homeState) => homeState.loginStatus
);
const makeSelectisSignup = () => createSelector(
  selectHome,
  (homeState) => homeState.isSignup
);
const makeSelectuserRegister = () => createSelector(
  selectHome,
  (homeState) => homeState.userRegister
);

export {
  selectHome,
  makeSelectUsername,
  makeSelectloginUser,
  makeSelectloginStatus,
  makeSelectisSignup,
  makeSelectuserRegister,
};
