/*
 * Home Actions
 *
 * Actions change things in your application
 * Since this boilerplate uses a uni-directional data flow, specifically redux,
 * we have these actions which are the only way your application interacts with
 * your application state. This guarantees that your state is up to date and nobody
 * messes it up weirdly somewhere.
 *
 * To add a new Action:
 * 1) Import your constant
 * 2) Add a function like this:
 *    export function yourAction(var) {
 *        return { type: YOUR_ACTION_CONSTANT, var: var }
 *    }
 */

import {
  CHANGE_USERNAME, HANDLE_CHANGE, USERLOGIN, USERLOGIN_SUCCESS, USERLOGIN_FAILURE,
  HANDLE_REGISTER_CHANGE, HANDLE_REGISTER, HANDLE_REGISTER_SUCCESS, HANDLE_REGISTER_FAILURE,
  CHANGE_SIGNUP,
} from './constants';

/**
 * Changes the input field of the form
 *
 * @param  {name} name The new teHANDLE_REGISTERxt of the input field
 *
 * @return {object}    An action object with a type of CHANGE_USERNAME
 */
export function changeUsername(option) {
  return {
    type: CHANGE_USERNAME,
    payload: { option }
  };
}
export function handleChange(option) {
  return {
    type: HANDLE_CHANGE,
    payload: { option }
  };
}
export function useLogin(option) {
  return {
    type: USERLOGIN,
    payload: { option }
  };
}
export function useLoginSuccess(response) {
  return {
    type: USERLOGIN_SUCCESS,
    payload: { response }
  };
}
export function useLoginFailure(error) {
  return {
    type: USERLOGIN_FAILURE,
    payload: { error }
  };
}
export function registerInputchange(option) {
  return {
    type: HANDLE_REGISTER_CHANGE,
    payload: { option }
  };
}
export function handleRegister(option) {
  return {
    type: HANDLE_REGISTER,
    payload: { option }
  };
}
export function handleRegisterSuccess(response) {
  return {
    type: HANDLE_REGISTER_SUCCESS,
    payload: { response }
  };
}
export function handleRegisterFailure(error) {
  return {
    type: HANDLE_REGISTER_FAILURE,
    payload: { error }
  };
}
export function handleSignup(option) {
  return {
    type: CHANGE_SIGNUP,
    payload: { option }
  };
}
