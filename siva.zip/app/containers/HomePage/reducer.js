import produce from 'immer';
import {
  CHANGE_USERNAME, USERLOGIN_SUCCESS, USERLOGIN_FAILURE, CHANGE_SIGNUP, HANDLE_REGISTER_CHANGE,
  HANDLE_REGISTER_SUCCESS, HANDLE_REGISTER_FAILURE
} from './constants';

const initialState = {
  isLoading: false,
  username: '',
  loginUser: { username: '', password: '' },
  loginStatus: false,
  isSignup: false,
  userRegister: { firstName: '', email: '', password: '' },
};
/* eslint-disable default-case, no-param-reassign */
const accessibilityReducer = (state = initialState, action) => produce(state, (draft) => {
  switch (action.type) {
    case CHANGE_USERNAME:
      if (action.payload.option.inputType === 'username') {
        draft.loginUser.username = action.payload.option.value;
      } else {
        draft.loginUser.password = action.payload.option.value;
      }
      break;
    case USERLOGIN_SUCCESS:
      draft.loginStatus = true;
      break;
    case USERLOGIN_FAILURE:
      draft.loginStatus = false;
      break;
    case CHANGE_SIGNUP:
      draft.isSignup = action.payload.option;
      break;
    case HANDLE_REGISTER_CHANGE:
      draft.userRegister[action.payload.option.field] = action.payload.option.value;
      break;
    case HANDLE_REGISTER_SUCCESS:
      break;
    case HANDLE_REGISTER_FAILURE:
      break;
  }
});

export default accessibilityReducer;
