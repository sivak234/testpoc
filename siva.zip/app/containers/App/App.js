/**
 *
 * App
 *
 * This component is the skeleton around the actual pages, and should only
 * contain code that should be seen on all pages. (e.g. navigation bar)
 */

import React from 'react';
import { Helmet } from 'react-helmet';
import { Switch, Route } from 'react-router-dom';

import HomePage from 'containers/HomePage/Loadable';
// import FeaturePage from 'containers/FeaturePage/Loadable';
// import NotFoundPage from 'containers/NotFoundPage/Loadable';
import Header from '../../components/header/Header';
import Footer from '../../components/Footer';
import LandingPage from '../../components/home/LandingPage';
import Login from '../../components/Login/index';
import SignUp from '../../components/signup/SignUp';
import Forgot from '../../components/forgot-password/Forgot';
import UserProfile from '../../components/user/userprofile/UserProfile';
import 'bootstrap/dist/css/bootstrap.min.css';
import './style.scss';

const App = () => (
  <div className="app-wrappers">
    <Helmet
      titleTemplate=""
      defaultTitle=""
    >
      <meta name="description" content="" />
    </Helmet>
    <Header />
    <hr />
    <Switch>
      <Route exact path="/" component={HomePage} />
      {/* <Route path="/features" component={FeaturePage} />
      <Route path="" component={NotFoundPage} /> */}
      {/* <Route exact path="/" component={LandingPage} /> */}
      <Route exact path="/LandingPage" component={LandingPage} />
      <Route exact path="/Login" component={Login} />
      <Route exact path="/Forgot" component={Forgot} />
      <Route exact path="/Signup" component={SignUp} />
      <Route exact path="/UserProfile" component={UserProfile} />
    </Switch>
    <Footer />
  </div>
);

export default App;
