export const apiUrl = 'https://emmdev.tech:4001/app';
