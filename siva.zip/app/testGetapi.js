// import React, {useState, useEffect} from 'react';
// import axios from 'axios';


// function testGetApi(){
//     const[posts, setPosts] = useState([]);

//     useEffect(() =>  {
//         axios.get('https://jsonplaceholder.typicode.com/posts')
//         .then( res => {
//             console.log(res)
//             setPosts(res.data)
//         })
//         .catch(err => {
//             console.log(res)
//         })
//     }, [])

//     return(
//         <div>
//             {posts.map(post => {
//                 <h3 key={post.id}>{posts.title}</h3>
//                 })
//             }
//         </div>
//     )

    
// }

// export default testGetApi;