import React, {Component, useState} from 'react';
import Header from './InnerHeader';
import axios from 'axios';

import './CheckCompatibilityPopup.css';

import ProfileImg from './img/profileImg.svg';
import starImg from './img/starImg.svg';

import {
    BrowserRouter as Router,
    Switch,
    Route,
    Link
} from 'react-router-dom';

function CheckCompatibilityPopup() {
    return (
        <div className="popupWrapper">
            <div className="popContent">
                <div className="popHead">
                    <h4>Check Compactibility <span className="close">X</span></h4>
                </div>
                <div className="popContentArea">
                    <div className="check-compatibilityArea">

                        <div className="types-wrapper">
                            <div className="typeSingle">
                                <div className="typeProfileImg">
                                    <img src={ProfileImg} alt=""/>
                                </div>
                                <div className="typeProfileContent">
                                    <h4>Type-8</h4>
                                    <h6>Kuriachan Abraham</h6>
                                    <div className="viewProfilfeButtonWrapper">
                                        <button className="btn compatibilityBtn">View Profile</button>
                                    </div>
                                </div>
                            </div>
                            <div className="typeSingle">
                                <div className="typeProfileImg">
                                    <img src={ProfileImg} alt=""/>
                                </div>
                                <div className="typeProfileContent">
                                    <h4>Type-8</h4>
                                    <h6>Kuriachan Abraham</h6>
                                    <div className="viewProfilfeButtonWrapper">
                                        <button className="btn compatibilityBtn">View Profile</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div className="findings-matchmeter">
                            <h4 className="findType"><span>What you find in this type</span></h4>
                            <div className="matchmeterWrapper">
                                <h5>Match Meter</h5>
                                <span className="starArea">
                                    <img src={starImg} alt=""/>
                                    <img src={starImg} alt=""/>
                                    <img src={starImg} alt=""/>
                                    <img src={starImg} alt=""/>
                                    <img src={starImg} alt=""/>
                                </span>
                            </div>
                        </div>

                        <div className="matchLists">
                            <ul>
                                <li>
                                    <input type="checkbox"/>
                                    Intense bond with each other, a chemistry unlike other combinations.High-Energy, vitality and Passion.
                                </li>
                                <li>
                                    <input type="checkbox"/>
                                    They invigorate and relax each other.
                                </li>
                                <li>
                                    <input type="checkbox"/>
                                    They find Matching Energy.
                                </li>
                                <li>
                                    <input type="checkbox"/>
                                    Quiet confidence. They have confidence in each other as a Team.
                                </li>
                                <li>
                                    <input type="checkbox"/>
                                    Frequent Deep conversations.
                                </li>
                                <li>
                                    <input type="checkbox"/>
                                    Mutual Respect; Generosity and Transparency
                                </li>
                            </ul>
                        </div>

                    </div>                    
                </div>
            </div>
        </div>
    )
}
export default CheckCompatibilityPopup;