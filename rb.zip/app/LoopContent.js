import React, {useState, useEffect} from 'react';
import axios from 'axios';

function LoopContent() {
    const [posts, setPosts] = useState([])

    useEffect(() => {
        axios
          .get('http://localhost:4001/app/userprofile/')
          .then((res) => {
            console.log(res)
            setPosts(res.data.results)
          })
          .catch((err) => {
            console.log(err)
          })
      },[])
    
    return (
        <div>
            <ul>
                {
                    posts.map(post => <li key={post.id}>{post.name}</li>)
                }
            </ul>

        </div>
    )
}
export default LoopContent;