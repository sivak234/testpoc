import React, {Component, useState} from 'react';
import Header from './InnerHeader';
import axios from 'axios';

import './UserProfile.css';

import {
    BrowserRouter as Router,
    Switch,
    Route,
    Link
} from 'react-router-dom';
import InnerHeader from './InnerHeader';
import UserProfileCard from './UserProfileCard';
import UserProfileDetails from './UserProfileDetails';
import UserProfileList from './UserProflieList';
import Filter from './Filter';
import CheckCompatibilityPopup from './CheckCompatibilityPopup';

function UserProfile(){

    return (
        <div className="innerPage">
            {/* <CheckCompatibilityPopup/> */}
            <div className="innerPageWhiteBG"></div>
            <InnerHeader/>
            <div className="container">                
            <div className="userProfileRow">                
                <div className="userProfileLeft">                    
                    <UserProfileCard />
                    <UserProfileDetails />                    
                </div>                
                <div className="userProfileRight">
                    <Filter/>
                    <div className="userProfileListWrapper">
                        <UserProfileList />
                    </div>                
                </div>                
            </div>                
            </div>
        </div>                
    )
}

export default UserProfile;
