import produce from 'immer';
import { CHANGE_USERNAME, USERLOGIN_SUCCESS, USERLOGIN_FAILURE } from './constants';

const initialState = {
  username: '',
  loginUser: { username: '', password: '' },
  loginStatus: false,
};
/* eslint-disable default-case, no-param-reassign */
const accessibilityReducer = (state = initialState, action) => produce(state, (draft) => {
  switch (action.type) {
    case CHANGE_USERNAME:
      debugger
      if (action.payload.option.inputType === 'username') {
        draft.loginUser.username = action.payload.option.value;
      } else {
        draft.loginUser.password = action.payload.option.value;
      }
      break;
    case USERLOGIN_SUCCESS:
      debugger
      draft.loginStatus = true;
      break;
    case USERLOGIN_FAILURE:
      debugger
      draft.loginStatus = true;
      break;
  }
});

export default accessibilityReducer;
