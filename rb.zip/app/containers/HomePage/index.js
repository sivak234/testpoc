import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { compose } from 'redux';
import { createStructuredSelector } from 'reselect';
import injectReducer from 'utils/injectReducer';
import injectSaga from 'utils/injectSaga';
import {
  makeSelectRepos,
  makeSelectLoading,
  makeSelectError
} from 'containers/App/selectors';
import { loadRepos } from '../App/actions';
import { changeUsername, useLogin } from './actions';
import { makeSelectUsername, makeSelectloginUser, makeSelectloginStatus } from './selectors';
import reducer from './reducer';
import saga from './saga';
// import UserProfile from '../../components/user/userprofile/UserProfile';

function HomePage({
  onChangeUsername, loginUser, loginStatus, duseLogin
}) {
  const handleChange = (e, type) => {
    onChangeUsername({
      value:
        e.target.value,
      inputType: type
    });
  };
  const handleClick = () => {
    duseLogin({ userName: loginUser.username, password: loginUser.password });
  };
  return (
    <div> <input type="text" value={loginUser.username} onChange={(e) => { handleChange(e, 'username'); }} /><br />
      <input type="password" value={loginUser.password} onChange={(e) => { handleChange(e, 'pwd'); }} /> <br />
      <input type="button" value="Submit" onClick={() => handleClick()} /><br />
      {loginStatus ? 'success' : ''}
      {/* <UserProfile /> */}
    </div>
  );
}
const mapDispatchToProps = (dispatch) => ({
  onChangeUsername: (option) => dispatch(changeUsername(option)),
  onSubmitForm: (evt) => {
    if (evt !== undefined && evt.preventDefault) evt.preventDefault();
    dispatch(loadRepos());
  },
  duseLogin: (option) => dispatch(useLogin(option)),
});

const mapStateToProps = createStructuredSelector({
  repos: makeSelectRepos(),
  username: makeSelectUsername(),
  loading: makeSelectLoading(),
  error: makeSelectError(),
  loginUser: makeSelectloginUser(),
  loginStatus: makeSelectloginStatus(),
});
HomePage.propTypes = {
  // loading: PropTypes.bool,
  // error: PropTypes.oneOfType([PropTypes.object, PropTypes.bool]),
  // repos: PropTypes.oneOfType([PropTypes.array, PropTypes.bool]),
  // onSubmitForm: PropTypes.func,
  // username: PropTypes.string,
  onChangeUsername: PropTypes.func,
  loginUser: PropTypes.object,
  loginStatus: PropTypes.bool,
  duseLogin: PropTypes.func,
};
const withReducer = injectReducer({ key: 'home', reducer });
const withSaga = injectSaga({ key: 'home', saga });

const withConnect = connect(mapStateToProps, mapDispatchToProps);
export default compose(withReducer, withSaga, withConnect)(HomePage);
export { mapDispatchToProps };
