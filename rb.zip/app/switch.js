// <?php
// 	include('site-config-inc.php');	
// 	$response = array();
// 	if(isset($_POST['prid']) && !empty($_POST['prid'])){
// 		$prid = $user->escape_string($user->strip_all($user->decrypt($_POST['prid'])));
// 		$getUserDetailsById = $user->getUserDetailsById($prid);
// 		$loggedInUserDetailsArr = $user->sessionExists();
// 		$getMatchingPoints = $user->getMatchingPoints($loggedInUserDetailsArr['type'],$getUserDetailsById['type']);
// 		$pb 
 
// 		ob_start();
// ?>


// <?php
// //print_r($points);


// switch ($points) {
//   case "1":
//     echo '
//      <h4 class="match-meter-head ">Match Meter</h4>
//     <div class="meter-graph-wrapper">
//                                 <span class="meter-graph graph-active"></span>
//                                 <span class="meter-graph "></span>
//                                 <span class="meter-graph"></span>
//                                 <span class="meter-graph"></span>
//                                 <span class="meter-graph"></span>
//                                 </div>
// ';
//     break;
//   case "2":
//      echo '  <h4 class="match-meter-head ">Match Meter</h4><div class="meter-graph-wrapper">
//                                 <span class="meter-graph graph-active"></span>
//                                 <span class="meter-graph graph-active "></span>
//                                 <span class="meter-graph"></span>
//                                 <span class="meter-graph"></span>
//                                 <span class="meter-graph"></span>
//                                 </div>
// ';
//     break;
//   case "3":
//      echo ' <h4 class="match-meter-head ">Match Meter</h4> <div class="meter-graph-wrapper">
//                                 <span class="meter-graph graph-active"></span>
//                                 <span class="meter-graph graph-active "></span>
//                                 <span class="meter-graph graph-active"></span>
//                                 <span class="meter-graph"></span>
//                                 <span class="meter-graph"></span>
//                                 </div>
// ';
//     break;
//     case "4":
//     echo ' <h4 class="match-meter-head ">Match Meter</h4><div class="meter-graph-wrapper">
//                                 <span class="meter-graph graph-active"></span>
//                                 <span class="meter-graph graph-active "></span>
//                                 <span class="meter-graph graph-active"></span>
//                                 <span class="meter-graph graph-active"></span>
//                                 <span class="meter-graph"></span>
//                                 </div>
// ';
//     break;
//     case "5":
//      echo ' <h4 class="match-meter-head ">Match Meter</h4> <div class="meter-graph-wrapper">
//                                 <span class="meter-graph graph-active"></span>
//                                 <span class="meter-graph graph-active "></span>
//                                 <span class="meter-graph graph-active" ></span>
//                                 <span class="meter-graph graph-active"></span>
//                                 <span class="meter-graph graph-active"></span>
//                                 </div>
// ';
//     break;
//   default:
//     echo ' <h4 class="match-meter-head ">Match Meter</h4> <div class="meter-graph-wrapper">
//                                 <span class="meter-graph "></span>
//                                 <span class="meter-graph "></span>
//                                 <span class="meter-graph"></span>
//                                 <span class="meter-graph"></span>
//                                 <span class="meter-graph"></span>
//                                 </div>
// ';
// }
// ?>


                        

		
// 		<?php		
// 		}
// 		$content = ob_get_contents();
// 		ob_end_clean();
// 		$response['content'] = $content;
// 		echo json_encode($response);
	
	
// ?>				