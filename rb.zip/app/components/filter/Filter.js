import React from 'react';
// import axios from 'axios';

import './Filter.scss';

// import Header from '../user/inner-header/InnerHeader';

function Filter() {
  return (
    <div>
      <div className="searchWrapper">
        <div className="searchInput">
          <input type="text" name="Search User" placeholder="Search User" />
        </div>
        <div className="filterWrapper">
          <span className="clearBtn">Clear filter</span>
          <div className="filterSingle">
            <select name="" id="">
              <option value="">Select Type</option>
              <option value="">Type 1</option>
              <option value="">Type 2</option>
              <option value="">Type 3</option>
            </select>
          </div>
          <div className="filterSingle">
            <select name="" id="">
              <option value="">Age</option>
              <option value="">18</option>
              <option value="">19</option>
              <option value="">20</option>
              <option value="">21</option>
              <option value="">22</option>
            </select>
          </div>
          <div className="filterSingle">
            <select name="" id="">
              <option value="">Age</option>
              <option value="">18</option>
              <option value="">19</option>
              <option value="">20</option>
              <option value="">21</option>
              <option value="">22</option>
            </select>
          </div>
          <div className="filterSingle">
            <select name="" id="">
              <option value="">Gender</option>
              <option value="">Male</option>
              <option value="">Female</option>
            </select>
          </div>
        </div>
      </div>
    </div>
  );
}
export default Filter;
