import React from 'react'
import './Loader'
function Loader() {
    return (
        <div className="flex justify-center">
            loading................
            <div className="loader"></div>
        </div>
    )
}

export default Loader