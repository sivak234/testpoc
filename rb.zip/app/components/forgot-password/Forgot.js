import React from 'react';
import loginImg from '../../img/bannerBg.svg'; 
import loginBg from '../../img/biggerlogo-bg.svg'; 

import Header from '../header/Header';

import {
    Link
} from 'react-router-dom';


function Forgot() {
    return (
        <React.Fragment>
        <Header/>        
        <div className="container">
        <div className="row">
            <div className="col-md-7">
                <div className="loginImgWrapper" style={{backgroundImage: `url(${loginBg})`}}>
                    <div className="loginImg">
                        <img src={loginImg} alt=""/>
                    </div>
                </div>
            </div>
            <div className="col-md-5">
                <div className="loginWrapper">
                    <div className="loginarea">
                        <div className="loginHeadWrapper">
                            <h3 className="loginHead">Forgot Password?</h3>
                            <p className="largePara">Please enter your mail</p>
                        </div>
                        <div className="loginSignupForm">
                            <div className="formgroup">
                                <input type="text" placeholder="Email*"/>
                            </div>
                        </div>
                        <div className="loginBtnArea">
                            <button className="btn largeBtn greenBtn">Submit</button>
                            <div className="rememberForgot">
                                <span>Already have account? <Link to="/Login">Login</Link></span>
                            </div>
                        </div>                       
                        <p className="noAccount text-left">Don't know your Ennea type? <Link to="/Signup" className="greenLink">Signup</Link></p>                       
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </React.Fragment>
    )
}

export default Forgot;