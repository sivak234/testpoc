import React from 'react'; 
import loginImg from '../../img/bannerBg.svg'; 
import loginBg from '../../img/biggerlogo-bg.svg'; 

function LoginImage() {
    return (
        <React.Fragment>        
        <div className="loginImgWrapper" style={{backgroundImage: `url(${loginBg})`}}>
            <div className="loginImg">
                <img src={loginImg} alt=""/>
            </div>
        </div>
        </React.Fragment>
    )
}

export default LoginImage;