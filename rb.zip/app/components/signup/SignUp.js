import React, { useState } from 'react';
import axios from 'axios';
import {
  Link
} from 'react-router-dom';
import env from '../../const/env';
import LoginImage from '../login/LoginImage';


function SignUp(props) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  let disableBtn = false;
  const Onchange = () => {
    setName(document.querySelector('#name').value);
    setEmail(document.querySelector('#email').value);
    setPassword(document.querySelector('#password').value);
  };
  const Register = () => {
    const details = {
      first_name: name,
      email,
      password
    };
    let err = 0;
    // eslint-disable-next-line no-useless-escape
    const validEmailRegex = RegExp(/^(([^<>()\[\]\.,;:\s@\"]+(\.[^<>()\[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i);

    if (name.length === 0) {
      document.querySelector('.name-err').innerHTML = 'Field Required';
      err = 1;
    } else {
      document.querySelector('.name-err').innerHTML = '';
    }

    if (!validEmailRegex.test(email)) {
      document.querySelector('.email-err').innerHTML = 'Please enter a valid email';
      err = 1;
    } else {
      document.querySelector('.email-err').innerHTML = '';
    }

    if (password.length === 0) {
      document.querySelector('.password-err').innerHTML = 'Field Required';
      err = 1;
    } else {
      document.querySelector('.password-err').innerHTML = '';
    }


    if (err == 0) {
      disableBtn = true;

      axios.post(`${env.apiUrl}users/register`, details)
        .then((res) => {
          const persons = res.data;
          disableBtn = false;
          (persons.message === 'success') ? props.history.push('/Login') : alert('err');
        });
    }
  };


  return (
    <React.Fragment>
      <div className="container">
        <div className="row">
          <div className="col-md-7">
            <LoginImage />
          </div>

          <div className="col-md-5">
            <div className="loginWrapper">
              <div className="loginarea">
                <div className="loginHeadWrapper">
                  <h3 className="loginHead">Register Here</h3>
                  <p className="largePara">Discover your Enneagram Personality Type</p>
                </div>
                <div className="loginSignupForm">
                  <div className="formgroup">
                    <input type="text" onChange={Onchange} placeholder="Name*" id="name" />
                    <p className="err-msg name-err"></p>
                  </div>
                  <div className="formgroup">
                    <input type="text" onChange={Onchange} placeholder="Type your Email*" id="email" />
                    <p className="err-msg email-err"></p>
                  </div>
                  <div className="formgroup">
                    <input type="password" onChange={Onchange} placeholder="Password*" id="password" />
                    <p className="err-msg password-err"></p>
                  </div>
                </div>
                <div className="loginBtnArea">

                  <button type="button" className="btn largeBtn greenBtn" onClick={Register}>Register</button>
                  <div className="rememberForgot">
                    <span className="remember">
                      <label>
                        <input type="checkbox" /> Remember me
                      </label>
                    </span>
                  </div>
                </div>
                <p className="noAccount">Already have account? <Link to="/Login">Login</Link></p>
              </div>
            </div>
          </div>
        </div>

      </div>
    </React.Fragment>
  );
}

export default SignUp;
