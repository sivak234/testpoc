import React, { useState, useEffect } from 'react';
import axios from 'axios';

import './UserProfileDetails.scss';


function UserProfileDetails() {
  const [user, setUser] = useState('');
  const id = localStorage.getItem('Id');
  // console.log(id);
  useEffect(() => {
    axios.get(`http://31.220.48.35:4001/app/userprofile/${id}`)
      .then((response) => {
        // console.log(response.data);
        setUser(response.data.data);
      });
  }, []);

  return (
    <div className="userProfiledetailsWrapper">
      <h4 className="userDetailHead">{user.secondary_name}</h4>
      <div className="userDetailsRow">
        <div className="briefDetails">
          <h6 className="briefDetailsHead"> {user.type} - In Brief</h6>
          <p>{user.description}</p>
        </div>
        <div className="keyDrives">
          <h6 className="keyDrivesHead">Key Drives</h6>
          <div className="keyDrivesDetails">
            <strong>{user.key_drive}</strong>
            <p>{user.key_types}</p>
          </div>
          <div className="keyDrivesDetails">
            <strong>Basic fear</strong>
            <p>Loss, fragmentation, separation</p>
          </div>
          <div className="keyDrivesDetails">
            <strong>Characteristic role</strong>
            <p>Peacemaker, Mediator</p>
          </div>
          <div className="keyDrivesDetails">
            <strong>Ego fixation</strong>
            <p>Indolence(Daydreaming)</p>
          </div>
          <div className="keyDrivesDetails">
            <strong>Holy idea</strong>
            <p>Love</p>
          </div>
          <div className="keyDrivesDetails">
            <strong>Temptation</strong>
            <p>Avoiding conflicts, avoiding</p>
            <p>self-assertion</p>
          </div>
          <div className="keyDrivesDetails">
            <strong>Vice-Passion</strong>
            <p>Sloth(Disengagement)</p>
          </div>
          <div className="keyDrivesDetails">
            <strong>Virtue</strong>
            <p>Action</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default UserProfileDetails;
