/* eslint-disable react/jsx-key */
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import activeStar from '../../../img/activeStar.svg';
import inactiveStar from '../../../img/inactiveStar.svg';
import chatIcon from '../../../img/chatIcon.svg';
import starImg from '../../../img/starImg.svg';
import ProfileImg from '../../../img/profileImg.svg';
import userProfileImg from '../../../img/userProfileImg.svg';
import { useAxiosGet } from '../../../Hooks/HttpRequests';
import Loader from '../../loader/Loader';


// // import ProfileImg from '../../img/profileImg.svg';
// import ProfileImg from '../../../img/profileImg.svg'
// // import starImg from '../../../img/starImg.svg';
// import starImg from '../../../img/starImg.svg'
// // import starImg from '../../img/starImg.svg';

import './UserProflieList.scss';


function UserProflieList() {
  const [popupUser, setUser] = useState('');
  const id = localStorage.getItem('Id');

  useEffect(() => {
    axios.get(`http://31.220.48.35:4001/app/userprofile/${id}`)
      .then((response) => {
      //  console.log(response.data)
        setUser(response.data.data);
      });
  }, []);

  // function myFunction() {
  //     var element = document.getElementById("popupWrapper");
  //     element.classList.add("popup-on");
  // }
  // function closePopup() {
  //     var element = document.getElementById("popupWrapper");
  //     element.classList.remove("popup-on");
  // }

  const checkCompatibilityPopup = (e, user) => {
    // console.log(user);

    const element = document.getElementById('popupWrapper');
    element.classList.add('popup-on');
  };

  const popClose = () => {
    const element = document.getElementById('popupWrapper');
    element.classList.remove('popup-on');
  };


  const url = 'http://31.220.48.35:4001/app/userprofile';

  const user = useAxiosGet(url);

  let content = null;
  if (user.error) {
    content = (
      <div>

        <div className="bg-red-300 p-3">
                There was an error please refresh or try again later.
        </div>
      </div>
    );
  }
  if (user.loading) {
    content = <Loader></Loader>;
  }

  if (user.data) {
    // console.log(user.data);
    content = user.data.map((userdetail) => (
      <div className="userListWrapper">
        <figure>
          <img src={userProfileImg} alt="" />
        </figure>
        <article>
          <h5 className="UserProfileName">{userdetail.name}</h5>
          <div className="typeRatingWrapper">
            <span className="largePara UserListType">{userdetail.type}</span>
            <div className="RatingWrapper">
              <img src={activeStar} alt="" />
              <img src={activeStar} alt="" />
              <img src={activeStar} alt="" />
              <img src={activeStar} alt="" />
              <img src={inactiveStar} alt="" />
            </div>
          </div>
          <p className="UserProfliePara">
            {userdetail.description}
          </p>
          <div className="compatibilityChat">
            <button type="button" className="btn compatibilityBtn" onClick={((e) => checkCompatibilityPopup(e, userdetail))}>Compatibility</button>
            <span><img src={chatIcon} alt="" /></span>
          </div>
        </article>
      </div>
    ));
  }

  return (
    <div>
      {content}

      <div className="popupWrapper" id="popupWrapper">
        <div className="popContent">
          <div className="popHead">
            <h4>Check Compactibility <span className="close" onClick={popClose}>X</span></h4>
          </div>
          <div className="popContentArea">
            <div className="check-compatibilityArea">

              <div className="types-wrapper">
                <div className="typeSingle">
                  <div className="typeProfileImg">
                    <img src={ProfileImg} alt="" />
                  </div>
                  <div className="typeProfileContent">
                    <h4>{popupUser.type}</h4>
                    <h6>{popupUser.name}</h6>
                    <div className="viewProfilfeButtonWrapper">
                      <button type="button" className="btn compatibilityBtn">View Profile</button>
                    </div>
                  </div>
                </div>
                <div className="typeSingle">
                  <div className="typeProfileImg">
                    <img src={ProfileImg} alt="" />
                  </div>
                  <div className="typeProfileContent">
                    <h4>Type-5</h4>
                    <h6>Name 1</h6>
                    <div className="viewProfilfeButtonWrapper">
                      <button type="button" className="btn compatibilityBtn">View Profile</button>
                    </div>
                  </div>
                </div>
              </div>

              <div className="findings-matchmeter">
                <h4 className="findType"><span>What you find in this type</span></h4>
                <div className="matchmeterWrapper">
                  <h5>Match Meter</h5>
                  <span className="starArea">
                    <img src={starImg} alt="" />
                    <img src={starImg} alt="" />
                    <img src={starImg} alt="" />
                    <img src={starImg} alt="" />
                    <img src={starImg} alt="" />
                  </span>
                </div>
              </div>

              <div className="matchLists">
                <ul>
                  <li>
                    <input type="checkbox" />
                                        Enneagram Fives need to be more identified with their body and with their instinctive energy; they need to be more engaged with the practical world and to feel their own sense of power and capacity. They can learn these qualities from Eights
                  </li>
                  <li>
                    <input type="checkbox" />
                                        Eights need to be more thoughtful and aware of the impact of their actions on themselves and on their environment. They need to know more and to think of consequences more carefully before acting. Every action produces a reaction, and it is not necessarily the one that the Eight wants to happen. This kind of analytic foresight is something Eights can learn from Fives.
                  </li>
                </ul>
              </div>

            </div>
          </div>
        </div>
      </div>

    </div>
  );
}
export default UserProflieList;
